package drivers;

import java.io.File;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;

import customExceptions.DriverException;
import factories.DriverFactory;
import frameworkConstants.FrameworkConstants;
import frameworkEnums.ConfigProperties;
import utilities.ApplicationPropertyUtils;

public final class Driver {

	public static String closeBrowser = ApplicationPropertyUtils.get(ConfigProperties.CLOSEBROWSER);

	public static void initDriver(String platform) throws InterruptedException {
		String appURL = ApplicationPropertyUtils.get(ConfigProperties.APPURL);
		String browser = ApplicationPropertyUtils.get(ConfigProperties.BROWSER);
		String device = ApplicationPropertyUtils.get(ConfigProperties.DEVICE);
		String headlessMode = ApplicationPropertyUtils.get(ConfigProperties.HEADLESSMODE);
		String lambdaTestString =ApplicationPropertyUtils.get(ConfigProperties.LAMBDATEST);


		deleteFiles(new File("reports").getAbsoluteFile());
		deleteFiles(new File("Ashot").getAbsoluteFile());
		


		// deleteFiles(new File("reports").getAbsoluteFile());

		System.out.println("file deleting steps");

		if (Objects.isNull(DriverManager.getDriver())) {
			try {
				DriverManager.setDriver(
						DriverFactory.createDriverSession(browser, platform, device, headlessMode, closeBrowser, lambdaTestString));
			} catch (Exception e) {
				throw new DriverException("Unable to Configure and Launch Driver. " + e.getMessage());
			}

			// Pause for manual inspection

			System.out.println(DriverManager.getDriver().getCurrentUrl());

			DriverManager.getDriver().manage().deleteAllCookies();

			DriverManager.getDriver().get(appURL);

			Thread.sleep(Duration.ofSeconds(2).toMillis());

			if (headlessMode.equalsIgnoreCase("yes")) {
				Thread.sleep(Duration.ofSeconds(2).toMillis());
				System.out.println(
						DriverManager.getDriver().getCurrentUrl() + ":" + DriverManager.getDriver().getTitle());

				DriverManager.getDriver().manage().window().setSize(new Dimension(1920, 1080));
				// DriverManager.getDriver().manage().window().maximize();

			} else {
				Thread.sleep(Duration.ofSeconds(2).toMillis());
				System.out.println(
						DriverManager.getDriver().getCurrentUrl() + ":" + DriverManager.getDriver().getTitle());

				DriverManager.getDriver().manage().window().maximize();
			}

			DriverManager.getDriver().manage().timeouts().implicitlyWait(FrameworkConstants.getImplicitWait(),
					TimeUnit.SECONDS);
			DriverManager.getDriver().manage().timeouts().pageLoadTimeout(FrameworkConstants.getPageLoadTimeout(),
					TimeUnit.SECONDS);
		}

	}

	public static void quitDriver() {

		if (closeBrowser.equalsIgnoreCase("yes"))
			if (Objects.nonNull(DriverManager.getDriver())) {
				DriverManager.getDriver().quit();
				DriverManager.unloadDriver();
			}
	}

	// Delete files from reports folder

	public static void deleteFiles(File folder) {
		System.out.println(folder.isDirectory() + " :" + folder);
		try {
			File[] files = folder.listFiles();
			// Arrays.sort(files);

			for (File file : files) {
				if (file.isFile()) {
					String fileName = file.getName();
					boolean del = file.delete();
					System.out.println(fileName + " : got deleted ? " + del);
				} else if (file.isDirectory()) {
					deleteFiles(file);
				}
			}
		} catch (Exception e) {
			System.out.println(e + " File not present");
		}

	}
}
