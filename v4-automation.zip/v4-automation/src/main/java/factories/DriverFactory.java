package factories;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import frameworkConstants.FrameworkConstants;
import io.github.bonigarcia.wdm.WebDriverManager;

public final class DriverFactory {

	public static WebDriver createDriverSession(String browser, String platform, String device, String headlessMode,
			String closeBrowser, String LambdaTest) throws MalformedURLException {

		WebDriver driver = null;
		String downloadPath = FrameworkConstants.getDownloadPath();
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> chromePref = new HashMap<>();


		
	
		
		
		System.setProperty("webdriver.chrome.whitelistedIps", "");

		/*
		 * System.setProperty("webdriver.chrome.logfile", "/tmp/chromedriver.log");
		 * System.setProperty("webdriver.chrome.verboseLogging", "true");
		 */
		chromePref.put("plugins.always_open_pdf_externally", true);
		chromePref.put("profile.default_content_settings.popups", 0);
		chromePref.put("download.default_directory", downloadPath);
		options.setExperimentalOption("prefs", chromePref);
		if(LambdaTest.equalsIgnoreCase("No")) {
        if(browser.equalsIgnoreCase("Chrome")) {
			   
        	System.out.println(options.getBrowserName() + ": " + options.getVersion() + ": "
					+ options.getCapabilityNames() + " :" + options.getPlatform());
			WebDriverManager.chromedriver().setup();


			if (headlessMode.equalsIgnoreCase("yes")) {
			
				options.addArguments("--headless");
				options.setHeadless(true);

				}
				options.addArguments("start-maximized");
				options.addArguments("--incognito");
				options.addArguments("enable-automation");
				options.setPageLoadStrategy(PageLoadStrategy.NONE);
				options.addArguments("chrome.switches", "--disable-extensions");
				options.setExperimentalOption("useAutomationExtension", false);
				//options.addArguments("--remote-debugging-port=9225");
				options.addArguments("--disable-notifications");
				options.addArguments("--dns-prefetch-disable");
				options.addArguments("disable-infobars");
				options.setAcceptInsecureCerts(true);
				options.addArguments("--disable-extensions");
				options.addArguments("--disable-gpu");
				options.addArguments("--no-sandbox");
				options.addArguments("--disable-dev-shm-usage");
				options.addArguments("--verbose");
				//options.addArguments("force-device-scale-factor=0.65");
				//options.addArguments("high-dpi-support=0.65");
				options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
				options.addArguments("--privileged");
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

				driver = new ChromeDriver(options);
			} else {
				System.out.println(options.getBrowserName() + ": " + options.getVersion() + ": "
						+ options.getCapabilityNames() + " :" + options.getPlatform());

				System.out.println("Going inside the headless mode configuration");

				// System.setProperty("webdriver.chrome.driver", "/usr/local/bin/chromedriver");

				
				options.addArguments("start-maximized");
				// options.addArguments("--incognito");
				options.addArguments("chrome.switches", "--disable-extensions");
				options.setPageLoadStrategy(PageLoadStrategy.NONE);
				options.addArguments("--test-type");
				options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
				options.setExperimentalOption("useAutomationExtension", false);
				options.addArguments("--remote-debugging-port=9225");
				options.addArguments("--no-sandbox");
				options.addArguments("--disable-dev-shm-usage");
				options.addArguments("--verbose");
				options.addArguments("--whitelisted-ips=''");
				// options.addArguments("--proxy-server='direct://'");
				// options.addArguments("--proxy-bypass-list=*");
				options.addArguments("disable-infobars"); // disabling infobars
				options.addArguments("--disable-extensions"); // disabling extensions
				options.addArguments("--disable-gpu");

				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(platform, Platform.LINUX);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				options.merge(capabilities);
				driver = new ChromeDriver(options);

			} 
		
		}
        
		
		else {
			
			
			try {
	            String username = "smitafreshprints";
	            String authkey = "a98kPt3LaxbMAu69iRTfh9kvsKvyML8MvOfME5CKVsLXYIzrdS";
	            String hub = "@hub.lambdatest.com/wd/hub";

	            DesiredCapabilities caps = new DesiredCapabilities();
	            caps.setCapability("browser", "Chrome");
	            caps.setCapability("version", "86");
	            caps.setCapability("platform", "win10"); // If this cap isn't specified, it will just get any available one.
	            caps.setCapability("build", " Automation_Kirty");
	            caps.setCapability("name", " Automation_local");
	            caps.setCapability("network", true);
	            caps.setCapability("visual", true); 
	            caps.setCapability("video", true);
	            caps.setCapability("console", true);
	          
	            caps.setCapability("tunnel",true);
	              
	            System.out.println("Desired Caps: " + caps);
	            driver = new RemoteWebDriver(new URL("https://" + username + ":" + authkey + hub), caps);
	        }
	        catch(Exception e)
	        {
	            System.out.println(e);
	        }
	    }
			
	
		return driver;
			
			
	}	
	}
		
        





