package frameworkConstants;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*; 


//import java.io.File;

public final class FrameworkConstants {
	
	private static final int EXPLICITWAIT = 10;
	private static final int IMPLICITWAIT = 3;
	private static final int PAGELOADTIMEOUT = 30;
	private static final int FAILEDTESTCASERETRYCOUNT = 1;
	private static final String RESOURCESPATH = System.getProperty("user.dir") + "/src/test/resources";
	private static final String APPCONFIGFILEPATH = RESOURCESPATH + "/config/AppConfig.properties";
	private static final String INPUTPROPERTYFILEPATH = RESOURCESPATH + "/inputdata/InputData.properties";
	private static final String RUNTIMEPROPERTYFILEPATH = RESOURCESPATH + "/inputdata/RunTimeData.properties";
	private static final String RUNTIMEPROPERTYFOLDERPATH = RESOURCESPATH + "/runtimedata/";
	private static final String TESTARTIFACTSPATH = System.getProperty("user.dir")+File.separatorChar+"artifacts";
//	private static final String TESTARTIFACTSPATH = System.getProperty("user.dir")+ "/artifacts";
	static String fileSuffix = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss").format(new Date());

//	private static final String EXTENTREPORTSPATH = System.getProperty("user.dir") + "/reports/%s"+fileSuffix+".html";
	private static final String EXTENTREPORTSPATH = System.getProperty("user.dir") + "/reports/%s"+".html";
	private static final String LOG4JCONFIGFILEPATH = System.getProperty("user.dir") + "/config/log4j2.xml";
	
	
	public static int getExplicitWait() {
		return EXPLICITWAIT;
	}
	
	public static int getImplicitWait() {
		return IMPLICITWAIT;
	}
	
	public static int getPageLoadTimeout() {
		return PAGELOADTIMEOUT;
	}
	
	public static int getFailedTestCaseRetryCount() {
		return FAILEDTESTCASERETRYCOUNT;
	}
	
	public static String getResourcesPath() {
		return RESOURCESPATH;
	}
	
	public static String getAppConfigFilePath() {
		return APPCONFIGFILEPATH;
	}
	
	public static String getInputPropertyFilePath() {
		return INPUTPROPERTYFILEPATH;
	}
	
	public static String getRuntimePropertyFilePath() {
		return RUNTIMEPROPERTYFILEPATH;
	}
	
	public static String getRuntimePropertyFolderPath() {
		return RUNTIMEPROPERTYFOLDERPATH;
	}

	public static String getExtentReportsPath() {
		return EXTENTREPORTSPATH;
	}
	
	public static String getLog4jConfigFilePath() {
		return LOG4JCONFIGFILEPATH;
	}
	
	public static String getDownloadPath() {
		return TESTARTIFACTSPATH;
	}
	
}
