package frameworkEnums;

public enum ElementCheckStrategy {
	DISPLAYED,
	ENABLED,
	SELECTED;

}
