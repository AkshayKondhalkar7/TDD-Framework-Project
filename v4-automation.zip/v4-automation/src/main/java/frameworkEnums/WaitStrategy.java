package frameworkEnums;

public enum WaitStrategy {
	
	CLICKABLE,
	PRESENCE,
	VISIBLE,
	INVISIBLE;

}
