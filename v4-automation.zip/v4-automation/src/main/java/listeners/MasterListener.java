package listeners;

import java.io.IOException;
import java.util.HashMap;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import customAnnotations.TestRailAnnotation.TestRail;
import frameworkEnums.ConfigProperties;
import reports.ExtentLogger;
import reports.ExtentReport;
import testRail.TestRailLogger;
import utilities.ApplicationPropertyUtils;
import utilities.S3ReportUtils;

public class MasterListener implements ITestListener, ISuiteListener {

	HashMap<Object, Object> data = new HashMap<Object, Object>();

	public void onStart(ISuite suite) {
		System.out.println(suite.getName() + " is getting Executed...");
		ExtentReport.initReports(suite.getName());
	}

	public void onFinish(ISuite suite) {
		try {
			ExtentReport.flushReports(suite.getName());
			S3ReportUtils.uploadToS3(suite.getName());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onTestStart(ITestResult result) {
		ExtentReport.createTest(result.getMethod().getMethodName(), result.getTestContext().getName());
	}

	public void onTestSuccess(ITestResult result) {
		ExtentLogger.markUpPass(result.getMethod().getMethodName() + " is Passed");
		
		if (ApplicationPropertyUtils.get(ConfigProperties.UPLOADRESULTSTOTESTRAIL).equalsIgnoreCase("yes")) {
			if (System.getProperty("env").equalsIgnoreCase("testing")) {
				if (result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class).TestingTC()
						.length() != 0) {
					
					TestRailLogger.uploadResultsToTestRail(result.getMethod().getMethodName(),
							result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class)
									.TestingTC(),
							"Pass", result.getMethod().getMethodName()
									+ " is Passed.\n Check v4-automation-results S3 Bucket in AWS for Detailed Reports.");

				} else {
					System.out.println("Add Testing TestRail ID to " + result.getMethod().getMethodName()
							+ " for Uploading Test Results");
				}
			} else if (System.getProperty("env").equalsIgnoreCase("staging")) {
				if (result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class).StagingTC()
						.length() != 0) {
					TestRailLogger.uploadResultsToTestRail(result.getMethod().getMethodName(),
							result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class)
									.StagingTC(),
							"Pass", result.getMethod().getMethodName()
									+ " is Passed.\n Check v4-automation-results S3 Bucket in AWS for Detailed Reports.");
				} else {
					System.out.println("Add Testing TestRail ID to " + result.getMethod().getMethodName()
							+ " for Uploading Test Results");
				}
			}
		}
	}

	public void onTestFailure(ITestResult result) {
		ExtentLogger.markUpFail(result.getMethod().getMethodName() + " is Failed");
		ExtentLogger.log(result.getThrowable().toString());

		if (ApplicationPropertyUtils.get(ConfigProperties.UPLOADRESULTSTOTESTRAIL).equalsIgnoreCase("yes")) {
			if (System.getProperty("env").equalsIgnoreCase("testing")) {
				if (result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class).TestingTC()
						.length() != 0) {
					
					TestRailLogger.uploadResultsToTestRail(result.getMethod().getMethodName(),
							result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class)
									.TestingTC(),
							"Fail", result.getMethod().getMethodName() + " is Failed.\n" + result.getThrowable().toString()
									+ "\n Check v4-automation-results S3 Bucket in AWS for Detailed Reports.");
				} else {
					System.out.println("Add Staging TestRail ID to " + result.getMethod().getMethodName()
							+ " for Uploading Test Results");
				}
			} else if (System.getProperty("env").equalsIgnoreCase("staging")) {
				if (result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class).StagingTC()
						.length() != 0) {
					TestRailLogger.uploadResultsToTestRail(result.getMethod().getMethodName(),
							result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(TestRail.class)
									.StagingTC(),
							"Fail", result.getMethod().getMethodName() + " is Failed.\n" + result.getThrowable().toString()
									+ "\n Check v4-automation-results S3 Bucket in AWS for Detailed Reports.");
				} else {
					System.out.println("Add Staging TestRail ID to " + result.getMethod().getMethodName()
							+ " for Uploading Test Results");
				}
			}
		}
	}

	public void onTestSkipped(ITestResult result) {
		ExtentLogger.skip(result.getMethod().getMethodName() + " is Skipped");

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
	}

	public void onFinish(ITestContext context) {

	}

}
