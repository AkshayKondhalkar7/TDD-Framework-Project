
package reports;

import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import frameworkEnums.ConfigProperties;
import utilities.ApplicationPropertyUtils;
import utilities.ScreenshotUtils;

public final class ExtentLogger {

	private static Logger logger = LogManager.getLogger();

	public static void markUpPass(String message) {
		ExtentReportManager.getExtentTest().pass(MarkupHelper.createLabel(message, ExtentColor.GREEN));
		if (ApplicationPropertyUtils.get(ConfigProperties.LOGSTEPSINCONSOLE).trim().equalsIgnoreCase("yes")) {
			logger.info(message);
		}
	}

	public static void markUpFail(String message) {

		if (!Objects.isNull(ExtentReportManager.getExtentTest())) {
			ExtentReportManager.getExtentTest().fail(MarkupHelper.createLabel(message, ExtentColor.RED));
			ExtentReportManager.getExtentTest()
					.info(MediaEntityBuilder.createScreenCaptureFromBase64String(ScreenshotUtils.getBase64Image()).build());
		}	
		logger.error(message);
	}

	public static void pass(String message) {

		if (!Objects.isNull(ExtentReportManager.getExtentTest())) {
			if (ApplicationPropertyUtils.get(ConfigProperties.SCREENSHOTFORPASSEDSTEPS).trim()
					.equalsIgnoreCase("yes")) {
				ExtentReportManager.getExtentTest().pass(message, MediaEntityBuilder
						.createScreenCaptureFromBase64String(ScreenshotUtils.getBase64Image()).build());

			} else {
				ExtentReportManager.getExtentTest().pass(message);
			}
		}

		if (ApplicationPropertyUtils.get(ConfigProperties.LOGSTEPSINCONSOLE).trim().equalsIgnoreCase("yes")) {
			logger.info(message);
		}
	}

	public static void fail(String message) {

		if (!Objects.isNull(ExtentReportManager.getExtentTest())) {
			ExtentReportManager.getExtentTest().fail(message,
					MediaEntityBuilder.createScreenCaptureFromBase64String(ScreenshotUtils.getBase64Image()).build());
		}
		logger.error(message);
	}

	public static void skip(String message) {

		if (!Objects.isNull(ExtentReportManager.getExtentTest())) {

			if (ApplicationPropertyUtils.get(ConfigProperties.SCREENSHOTFORSKIPPEDSTEPS).trim()
					.equalsIgnoreCase("yes")) {
				ExtentReportManager.getExtentTest().skip(message, MediaEntityBuilder
						.createScreenCaptureFromBase64String(ScreenshotUtils.getBase64Image()).build());
			} else {
				ExtentReportManager.getExtentTest().skip(message);
			}
		}
		if (ApplicationPropertyUtils.get(ConfigProperties.LOGSTEPSINCONSOLE).trim().equalsIgnoreCase("yes")) {
			logger.info(message);
		}
	}

	public static void log(String message) {

		if (!Objects.isNull(ExtentReportManager.getExtentTest())) {
			ExtentReportManager.getExtentTest().log(Status.INFO, message);
		}
		if (ApplicationPropertyUtils.get(ConfigProperties.LOGSTEPSINCONSOLE).trim().equalsIgnoreCase("yes")) {
			logger.info(message);
		}
	}

}
