
package reports;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import frameworkConstants.FrameworkConstants;
import frameworkEnums.ConfigProperties;
import utilities.ApplicationPropertyUtils;

public final class ExtentReport {

	private static ExtentReports extent;

	public static void initReports(String suiteName) {
		if (Objects.isNull(extent)) {
			extent = new ExtentReports();
			ExtentSparkReporter sparkReporter = new ExtentSparkReporter(
					String.format(FrameworkConstants.getExtentReportsPath(), suiteName));
			extent.attachReporter(sparkReporter);
			sparkReporter.config().setTheme(Theme.DARK);
			sparkReporter.config().setDocumentTitle(suiteName + " Test Results");
			sparkReporter.config().setReportName(ApplicationPropertyUtils.get(ConfigProperties.REPORTNAME));
		}
	}

	public static void flushReports(String suiteName) throws IOException {
		if (Objects.nonNull(extent)) {
			extent.flush();
		}
		ExtentReportManager.unloadTest();
		if (ApplicationPropertyUtils.get(ConfigProperties.OPENREPORTAUTOMATICALLY).equalsIgnoreCase("yes")) {
			String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

			Desktop.getDesktop().browse(new File("reports" + File.separatorChar + suiteName + ".html").toURI());
		}
	}

	public static void createTest(String testCaseName, String testScenario) {
		String device = "Not Specified";

		if (!Objects.isNull(System.getProperty("platform"))) {
			device = System.getProperty("platform");
		}

		ExtentReportManager.setExtentTest(extent.createTest(testCaseName).assignCategory(testScenario)
				.assignDevice(StringUtils.capitalize(device)));
	}

}
