package testRail;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import frameworkEnums.ConfigProperties;
import utilities.ApplicationPropertyUtils;

public class TestRailClient {

	private static String username = ApplicationPropertyUtils.get(ConfigProperties.TESTRAILUSERNAME);
	private static String password = ApplicationPropertyUtils.get(ConfigProperties.TESTRAILPASSWORD);
	private static String appurl = ApplicationPropertyUtils.get(ConfigProperties.TESTRAILURL);

	public static Object sendGet(String uri, String data) throws Exception {
		return sendRequest("GET", uri, data);
	}

	public static Object sendGet(String uri) throws Exception {
		return sendRequest("GET", uri, null);
	}

	public static Object sendPost(String uri, Object data) throws Exception {
		return sendRequest("POST", uri, data);
	}

	private static Object sendRequest(String method, String uri, Object data) throws Exception {
		URL url = new URL(appurl + uri);

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		String auth = getAuthorization(username, password);
		conn.addRequestProperty("Authorization", "Basic " + auth);

		if (method.equals("POST")) {
			conn.setRequestMethod("POST");

			if (data != null) {
				if (uri.startsWith("add_attachment")) {
					String boundary = "TestRailAPIAttachmentBoundary";
					File uploadFile = new File((String) data);

					conn.setDoOutput(true);
					conn.addRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

					OutputStream ostreamBody = conn.getOutputStream();
					BufferedWriter bodyWriter = new BufferedWriter(new OutputStreamWriter(ostreamBody));

					bodyWriter.write("\n\n--" + boundary + "\r\n");
					bodyWriter.write("Content-Disposition: form-data; name=\"attachment\"; filename=\""
							+ uploadFile.getName() + "\"");
					bodyWriter.write("\r\n\r\n");
					bodyWriter.flush();

					InputStream istreamFile = new FileInputStream(uploadFile);
					int bytesRead;
					byte[] dataBuffer = new byte[1024];
					while ((bytesRead = istreamFile.read(dataBuffer)) != -1) {
						ostreamBody.write(dataBuffer, 0, bytesRead);
					}

					ostreamBody.flush();

					bodyWriter.write("\r\n--" + boundary + "--\r\n");
					bodyWriter.flush();

					istreamFile.close();
					ostreamBody.close();
					bodyWriter.close();
				} else {
					conn.addRequestProperty("Content-Type", "application/json");
					byte[] block = JSONValue.toJSONString(data).getBytes("UTF-8");

					conn.setDoOutput(true);
					OutputStream ostream = conn.getOutputStream();
					ostream.write(block);
					ostream.close();
				}
			}
		} else {
			conn.addRequestProperty("Content-Type", "application/json");
		}

		int status = conn.getResponseCode();

		InputStream istream;
		if (status != 200) {
			istream = conn.getErrorStream();
			if (istream == null) {
				throw new Exception("TestRail API return HTTP " + status + " (No additional error message received)");
			}
		} else {
			istream = conn.getInputStream();
		}

		if ((istream != null) && (uri.startsWith("get_attachment/"))) {
			FileOutputStream outputStream = new FileOutputStream((String) data);

			int bytesRead = 0;
			byte[] buffer = new byte[1024];
			while ((bytesRead = istream.read(buffer)) > 0) {
				outputStream.write(buffer, 0, bytesRead);
			}

			outputStream.close();
			istream.close();
			return (String) data;
		}

		String text = "";
		if (istream != null) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(istream, "UTF-8"));

			String line;
			while ((line = reader.readLine()) != null) {
				text += line;
				text += System.getProperty("line.separator");
			}
			reader.close();
		}

		Object result;
		if (!text.equals("")) {
			result = JSONValue.parse(text);
		} else {
			result = new JSONObject();
		}

		if (status != 200) {
			String error = "No additional error message received";
			if (result != null && result instanceof JSONObject) {
				JSONObject obj = (JSONObject) result;
				if (obj.containsKey("error")) {
					error = '"' + (String) obj.get("error") + '"';
				}
			}
			throw new Exception("TestRail API returned HTTP " + status + "(" + error + ")");
		}
		return result;
	}

	private static String getAuthorization(String user, String password) {
		try {
			return new String(Base64.getEncoder().encode((user + ":" + password).getBytes()));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}

		return "";
	}
}
