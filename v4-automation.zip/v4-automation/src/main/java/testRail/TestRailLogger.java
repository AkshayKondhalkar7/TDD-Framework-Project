package testRail;

import java.util.HashMap;

import frameworkEnums.ConfigProperties;
import utilities.ApplicationPropertyUtils;

public class TestRailLogger {

	static HashMap<Object, Object> data = new HashMap<Object, Object>();

	public static void uploadResultsToTestRail(String testCaseName, String testCaseID, String status, String comment) {

		try {
			if (ApplicationPropertyUtils.get(ConfigProperties.UPLOADRESULTSTOTESTRAIL).equalsIgnoreCase("yes")) {
				if (status.equalsIgnoreCase("pass")) {
					data.put("status_id", 1);
				} else if (status.equalsIgnoreCase("fail")) {
					data.put("status_id", 5);
				}
				data.put("comment", comment);

				TestRailClient.sendPost("add_result/" + testCaseID, data);
				
				System.out.println("Uploaded Test Results to TestRail for " + testCaseName);
			}
			data.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
