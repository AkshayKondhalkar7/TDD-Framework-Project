package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.amazonaws.services.athena.model.ResultSet;
import com.mysql.cj.jdbc.DatabaseMetaData;
import com.mysql.cj.protocol.Resultset;

import frameworkEnums.ConfigProperties;

public final class DBSetupUtils {
	
	static Statement selectStmt = null;

	public static Connection setupUserDatabase() {
		 Connection con = null;

		
			  String dbHostName=ApplicationPropertyUtils.get(ConfigProperties.DBHOST);
			  String dbUserName=ApplicationPropertyUtils.get(ConfigProperties.DBUSERNAME);
			  String dbPassword=ApplicationPropertyUtils.get(ConfigProperties.DBPASSWORD);
			 
		 //freshprints-dev.ci008uhawggf.us-west-2.rds.amazonaws.com
		/*  String dbHostName="jdbc:mysql://freshprintstest.ci008uhawggf.us-west-2.rds.amazonaws.com";
    		String dbUserName="freshpri";
    		String dbPassword="testmasterpassword";*/
           
		 
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Class.forName("org.postgresql.Driver");

			con = DriverManager.getConnection(dbHostName,
					dbUserName, dbPassword);
			
			System.out.println("Database Connected"+con.toString());
			selectStmt = con.createStatement();
			selectStmt.executeQuery("USE freshprints_e2e;");
		

			selectStmt.executeQuery("call automationTest_userSetup();");
			
			
			
			java.sql.ResultSet rs =selectStmt.executeQuery("SELECT * FROM freshprints_e2e.user;");
			
			 while (rs.next()) {
				 
	                int id = rs.getInt("id");
	                String name = rs.getString("first_name");
	                String email = rs.getString("email");
	                System.out.println(id + "\t\t" + name
	                                   + "\t\t" + email);
	            }
	        
			
			

			String query = "SELECT * FROM freshprints_e2e.user WHERE email = 'testmanager@xyz.com';";
			//Executing first SELECT query
			java.sql.ResultSet data = (java.sql.ResultSet) selectStmt.executeQuery(query);	
			
			
			 while (data.next()) {
				 
	                int id = data.getInt("id");
	                String name = data.getString("first_name");
	                String email = data.getString("email");
	                System.out.println(id + "\t\t" + name
	                                   + "\t\t" + email);
	            }
	        
		
			System.out.println("Result of executing query1"); 


			

			
			
			
		
			System.out.println("DB Setup Successful");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				selectStmt.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return con;
	}
	
	public static java.sql.ResultSet selectQuery( String email) throws SQLException {
		 Connection con = null;
		 java.sql.ResultSet rs = null ;
		 String dbHostName=ApplicationPropertyUtils.get(ConfigProperties.DBHOST);
			String dbUserName=ApplicationPropertyUtils.get(ConfigProperties.DBUSERNAME);
			String dbPassword=ApplicationPropertyUtils.get(ConfigProperties.DBPASSWORD);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dbHostName,dbUserName, dbPassword);
			
			System.out.println("Database Connected again to fetch the unsubscribe list");
		
		selectStmt = setupUserDatabase().createStatement();
		String query = "SELECT * FROM freshprints_e2e.unsubscriber WHERE email = " +email;
		//Executing first SELECT query
		 rs = selectStmt.executeQuery(query);	
		System.out.println("Result of executing query1");
		
		if(rs == null) {
			
			System.out.print("Database doesnt have the value of the user in unsubscriber table");
		}
		else {
		//looping through the number of row/rows retrieved after executing query2
		while(rs.next()) 	
		{
			
			
		System.out.print(rs.getString("ID") + "\t");
		System.out.print(rs.getString("email") + "\t" + "\t");
		
		}
		
		
		}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				selectStmt.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return rs;
		
	}
	
	public static java.sql.ResultSet refresh() {
		 Connection con = null;
		 java.sql.ResultSet rs = null ;
		 String dbHostName=ApplicationPropertyUtils.get(ConfigProperties.DBHOST);
		 String dbUserName=ApplicationPropertyUtils.get(ConfigProperties.DBUSERNAME);
		 String dbPassword=ApplicationPropertyUtils.get(ConfigProperties.DBPASSWORD);
			
			try {
				
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(dbHostName,dbUserName, dbPassword);
				rs.refreshRow();
				System.out.println("refreshing");
				
			} catch (Exception e) {
				
			}
		
			return rs;
	}
	
}

