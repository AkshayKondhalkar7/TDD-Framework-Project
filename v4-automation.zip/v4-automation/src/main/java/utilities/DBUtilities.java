package utilities;

import java.security.MessageDigest;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import frameworkEnums.ConfigProperties;

public class DBUtilities {
	Connection conn = null;
	Statement stmt = null;

	public Connection getConnection() {
		return conn;
	}

	String dbHostName = "freshprintstest.ci008uhawggf.us-west-2.rds.amazonaws.com";
	String dbUserName = "freshpri";
	String dbPassword = "testmasterpassword";

	public DBUtilities() {

		try {
			System.out.println(dbHostName + "has " + dbUserName + " has" + dbPassword);
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbHostName, dbUserName, dbPassword);
			System.out.println(dbHostName + "has " + dbUserName + " has" + dbPassword);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ResultSet executeStatement(String query) throws Exception {
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);

		rSet.next();
		return rSet;

	}

	public ResultSet execute(String query) throws Exception {
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);

		return rSet;
	}

	public boolean isGbgfAlreadyRegistered(String gbgfName) throws Exception {
		boolean status = false;
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM GBGF WHERE GBGF_NAME = '" + gbgfName.trim() + "'";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public boolean isProjectAlreadyRegistered(String projectName) throws Exception {
		boolean status = false;
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM PROJECT WHERE PROJECT_NAME = '" + projectName.trim() + "'";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = rSet.getInt(1);
		}
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public boolean createProject(int GBGF_ID, String projectName, String projectOwner, int programId, int serviceLineId,
			String measurement, String managerEmailId, String grafanaFolderId, String grafanaFolderUid, String gbgfName,
			String serviceLine) throws Exception {
		int count = 0;
		boolean status = false;
		try {
			if (isProjectAlreadyRegistered(projectName) == true) {
				return status;
			}
			stmt = conn.createStatement();
			String sql = "INSERT INTO PROJECT (GBGF_ID, PROJECT_NAME, PROJECT_OWNER, PROGRAM_ID,"
					+ " SERVICE_LINE_ID, MEASUREMENT,ADMIN_MANAGER_MAIL_ID, GRAFANA_FOLDER_ID,"
					+ "GRAFANA_FOLDER_UID,GBGF_NAME,SERVICE_LINE) VALUES (" + GBGF_ID + ",'" + projectName + "','"
					+ projectOwner + "'," + programId + "," + serviceLineId + ",'" + measurement + "','"
					+ managerEmailId + "','" + grafanaFolderId + "','" + grafanaFolderUid + "','" + gbgfName + "','"
					+ serviceLine + "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public boolean createUser(String gbgfId, String projectId, String programId, String serviceLineId, String mail,
			String date, String managerMailId, String userPsId, String managerPsId, String grafanaUserId)
			throws Exception {
		int count = 0;
		boolean status = false;
		try {
			if (isUserAlreadyRegistered(mail) == true) {
				return status;
			}
			stmt = conn.createStatement();
			String sql = "INSERT INTO USERS_DETAILS (GBGF_ID, PROJECT_ID, PROGRAM_ID, SERVICE_LINE_ID, "
					+ "REGISTER_MAIL,REGISTER_DATE, MANAGER_MAIL,USER_PS_ID,MANAGER_PS_ID,GRAFANA_USER_ID) VALUES ('"
					+ gbgfId + "','" + projectId + "','" + programId + "','" + serviceLineId + "','" + mail + "','"
					+ date + "','" + managerMailId + "','" + userPsId + "','" + managerPsId + "','" + grafanaUserId
					+ "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public boolean deleteUser(String mail) throws SQLException {
		boolean status = false;
		int count = 0;

		stmt = conn.createStatement();

		String sql = "DELETE FROM USERS_DETAILS WHERE REGISTER_MAIL='" + mail + "'";
		count = stmt.executeUpdate(sql);
		stmt.close();
		if (count != 0) {
			status = true;
		}

		return status;
	}

	public boolean deleteProject(String projectName) throws SQLException {
		boolean status = false;
		int count = 0;

		stmt = conn.createStatement();

		String sql = "DELETE FROM PROJECT WHERE PROJECT_NAME='" + projectName + "'";
		count = stmt.executeUpdate(sql);
		stmt.close();
		if (count != 0) {
			status = true;
		}

		return status;
	}

	private boolean isUserAlreadyRegistered(String userName) throws Exception {
		boolean status = false;
		String query = "SELECT COUNT(*) FROM USERS_DETAILS WHERE REGISTER_MAIL = '" + userName.trim() + "'";
		ResultSet rSet = executeStatement(query);
		int rowCount = Integer.parseInt(rSet.getString(1));
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public int createRunner(int projectId, String jmxFileName, String parameters, String runAt, boolean isRecurring,
			String executionTime, String currentStatus, String rawReportFile, String htmlReportLocation, String desc,
			String scenarioName, int remoteHostId, String uuid, String transactionSLA, double programSLA, int tgCount,
			String performanceTestType, int userId) throws Exception {
		int count = 0;
		boolean status = false;
		int runIdGenerated = -1;
		try {

			Statement stmt = conn.createStatement();
			String sql = "INSERT INTO RUNNER (PROJECT_ID ,  JMX_FILE_NAME , PARAMETERS ,RUN_AT , IS_RECURRING ,EXEC_TIME ,CURRENT_STATUS ,  RAW_REPORT_FILE ,"
					+ "  HTML_REPORT_LOC ,DESC, SCENARIO_NAME,REMOTE_HOST_ID, UUID, TRANSACTION_SLA,PROGRAM_SLA,TG_COUNT,"
					+ " PERFORMANCE_TEST_TYPE, USER_ID) VALUES (" + projectId + ", '" + jmxFileName + "', '"
					+ parameters + "', '" + runAt + "', " + isRecurring + " , '" + executionTime + "' , '"
					+ currentStatus + "', '" + rawReportFile + "', '" + htmlReportLocation + "', '" + desc + "', '"
					+ scenarioName + "', " + remoteHostId + ", '" + uuid + "','" + transactionSLA + "'," + programSLA
					+ "," + tgCount + ",'" + performanceTestType + "'," + userId + ")";
			count = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			ResultSet rSet = stmt.getGeneratedKeys();
			while (rSet.next()) {
				runIdGenerated = rSet.getInt("RUN_ID");
				System.out.println("Run Id in db utils: " + rSet.getInt("RUN_ID") + "  " + rSet.getInt(1));
			}
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1) {
			status = true;
			return runIdGenerated;
		}
		return -1;
	}

	public boolean checkTestDetailExists(int runId) throws SQLException {
		boolean exist = false;
		int count = 0;

		String query = "SELECT COUNT(*) FROM RUNNER WHERE RUN_ID=" + runId;

		Statement stmt = conn.createStatement();
		ResultSet rSet = stmt.executeQuery(query);
		while (rSet.next()) {
			count = rSet.getInt(1);
		}
		if (count == 1) {
			exist = true;
		}

		return exist;

	}

	public int createRunnerForRetest(int runId) throws Exception {
		int count = 0;
		boolean status = false;
		int runIdGenerated = -1;

		Statement selectStmt = conn.createStatement();
		String selectQuery = "SELECT * FROM RUNNER WHERE RUN_ID=" + runId;

		ResultSet selectQueryResultSet = selectStmt.executeQuery(selectQuery);

		int projectId = 0, remoteHostId = 0, tgCount = 0;
		double programSLA = 0.0;
		String pattern = "ddMMMyyyyHHmmss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		String jmxFileName = null, parameters = null, runAt = "Now", currentStatus = "LOADED", desc = null,
				scenarioName = null, uuid = null, transactionSLA = null, performanceTestType = null;

		while (selectQueryResultSet.next()) {
			projectId = selectQueryResultSet.getInt("PROJECT_ID");
			remoteHostId = selectQueryResultSet.getInt("REMOTE_HOST_ID");
			tgCount = selectQueryResultSet.getInt("TG_COUNT");
			jmxFileName = selectQueryResultSet.getString("JMX_FILE_NAME");
			parameters = selectQueryResultSet.getString("PARAMETERS");
			desc = selectQueryResultSet.getString("DESC");
			scenarioName = selectQueryResultSet.getString("SCENARIO_NAME");
			uuid = selectQueryResultSet.getString("UUID");
			transactionSLA = selectQueryResultSet.getString("TRANSACTION_SLA");
			programSLA = selectQueryResultSet.getDouble("PROGRAM_SLA");
			performanceTestType = selectQueryResultSet.getString("PERFORMANCE_TEST_TYPE");
		}

		try {

			Statement stmt = conn.createStatement();
			String sql = "INSERT INTO  RUNNER (PROJECT_ID , JMX_FILE_NAME , PARAMETERS ,RUN_AT  ,EXEC_TIME ,"
					+ "CURRENT_STATUS  ,DESC, SCENARIO_NAME,REMOTE_HOST_ID, UUID, TRANSACTION_SLA,PROGRAM_SLA,"
					+ "TG_COUNT, PERFORMANCE_TEST_TYPE ) VALUES (" + projectId + ", '" + jmxFileName + "', '"
					+ parameters + "', '" + runAt + "', '" + date + "' , '" + currentStatus + "', '" + desc + "', '"
					+ scenarioName + "', " + remoteHostId + ", '" + uuid + "','" + transactionSLA + "'," + programSLA
					+ "," + tgCount + ",'" + performanceTestType + "')";
			count = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
			ResultSet rSet = stmt.getGeneratedKeys();
			while (rSet.next()) {
				runIdGenerated = rSet.getInt("RUN_ID");
				// System.out.println("Run Id in db utils:
				// "+rSet.getInt("RUN_ID")+" "+rSet.getInt(1));
			}
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1) {
			status = true;
			return runIdGenerated;
		}
		return -1;
	}

	public boolean createGBGF(String gbgfName) throws Exception {
		int count = 0;
		boolean status = false;
		try {
			if (isGbgfAlreadyRegistered(gbgfName) == true) {
				return status;
			}
			stmt = conn.createStatement();
			String sql = "INSERT INTO GBGF (GBGF_NAME) VALUES ('" + gbgfName + "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public boolean createRemoteHost(String hostName, String userName, String password, String node, String ipAddress,
			String jmeterPath) throws Exception {
		int count = 0;
		boolean status = false;
		try {
			// if (isRemoteHostAlreadyRegistered(hostName) == true) {
			// return status;
			// }
			stmt = conn.createStatement();
			String sql = "INSERT INTO REMOTE_HOST (HOST_NAME, USERNAME, PASSWORD, NODE, IP_ADDRESS,JMETER_PATH) VALUES ('"
					+ hostName + "','" + userName + "','" + password + "','" + node + "','" + ipAddress + "','"
					+ jmeterPath + "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public List<String> getScenarioNames(String projectName, String jmxFileName) {

		List<String> scenarioList = new ArrayList<String>();
		try {
			stmt = conn.createStatement();
			int projectId = getProjectId(projectName);
			String sql = "SELECT DISTINCT SCENARIO_NAME FROM RUNNER WHERE PROJECT_ID=" + projectId
					+ "AND JMX_FILE_NAME='" + jmxFileName + "'";
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				String scenarioName = rs.getString("SCENARIO_NAME");
				scenarioList.add("\"" + scenarioName + "\"");

			}

			rs.close();
			stmt.close();
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return scenarioList;

	}

	public Map<String, Double> getSlaValues(String projectName, String jmxFileName, String scenarioName,
			String timeStamp) {

		Map<String, Double> slaValuesMap = new TreeMap<String, Double>();

		try {
			stmt = conn.createStatement();
			int projectId = getProjectId(projectName);
			String sql = "SELECT TRANSACTION_SLA, PROGRAM_SLA FROM RUNNER WHERE PROJECT_ID=" + projectId
					+ "AND JMX_FILE_NAME='" + jmxFileName + "' AND SCENARIO_NAME='" + scenarioName
					+ "' AND HTML_REPORT_LOC='" + timeStamp + "'";
			ResultSet rs = stmt.executeQuery(sql);

			String transactionSla = "";
			double programSla = 0.0;

			while (rs.next()) {

				transactionSla = rs.getString("TRANSACTION_SLA");
				programSla = rs.getDouble("PROGRAM_SLA");

			}

			if (transactionSla == null)
				transactionSla = "";

			String transactionSLAArray[] = transactionSla.split(",");

			System.out.println(transactionSla);
			for (String temp : transactionSLAArray) {
				String tgName = temp.substring(0, temp.lastIndexOf("="));
				String value = temp.substring(temp.lastIndexOf("=") + 1).trim();
				if (value.isEmpty() || value.equals(",") || value.contains("null") || value == null)
					value = "0.0";
				slaValuesMap.put(tgName, Double.parseDouble(value));
			}
			slaValuesMap.put("programSLA", programSla);

			rs.close();
			stmt.close();
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return slaValuesMap;

	}

	public Map<Integer, String> getAllGBGF() throws Exception {
		Map<Integer, String> gbgfMap = new HashMap<Integer, String>();
		ResultSet rSet = executeStatement("SELECT * FROM GBGF");
		do {
			int gbgfId = rSet.getInt("GBGF_ID");
			String gbgfName = rSet.getString("GBGF_NAME");
			gbgfMap.put(gbgfId, gbgfName);

		} while (rSet.next());

		return gbgfMap;
	}

	public int getGBGFId(String gbgfName) throws Exception {
		String query = "SELECT GBGF_ID FROM GBGF WHERE GBGF_NAME = '" + gbgfName.trim() + "'";
		ResultSet rSet = executeStatement(query);
		int id = Integer.parseInt(rSet.getString(1));
		return id;
	}

	public int getServiceLineId(String serviceLineName, int gbgfId) throws Exception {
		String query = "SELECT SERVICE_LINE_ID FROM SERVICE_LINE WHERE SERVICE_LINE_NAME = '" + serviceLineName.trim()
				+ "' AND GBGF_ID=" + gbgfId;
		ResultSet rSet = executeStatement(query);
		int id = Integer.parseInt(rSet.getString(1));
		return id;
	}

	public int getProgramId(String programName, int gbgfId, int serviceLineId) throws Exception {
		String query = "SELECT PROGRAM_ID FROM PROGRAMS WHERE PROGRAM_NAME = '" + programName.trim() + "' AND GBGF_ID="
				+ gbgfId + " AND SERVICE_LINE_ID=" + serviceLineId;
		ResultSet rSet = executeStatement(query);
		int id = Integer.parseInt(rSet.getString(1));
		return id;
	}

	public int getUserId(String registerMail) throws Exception {
		String query = "SELECT USER_ID FROM USERS_DETAILS WHERE REGISTER_MAIL = '" + registerMail.trim() + "'";
		ResultSet rSet = execute(query);
		int id = 0;
		while (rSet.next()) {
			id = rSet.getInt("USER_ID");
		}
		return id;
	}

	public String getGrafanaUserId(String registerMail) throws Exception {
		String query = "SELECT GRAFANA_USER_ID FROM USERS_DETAILS WHERE REGISTER_MAIL = '" + registerMail.trim() + "'";
		ResultSet rSet = execute(query);
		String id = "";
		while (rSet.next()) {
			id = rSet.getString("GRAFANA_USER_ID");
		}
		return id;
	}

	public int getProjectId(String projectName) throws Exception {
		String query = "SELECT PROJECT_ID FROM PROJECT WHERE PROJECT_NAME = '" + projectName.trim() + "'";
		ResultSet rSet = execute(query);
		int id = 0;
		while (rSet.next()) {
			id = rSet.getInt("PROJECT_ID");
		}
		return id;
	}

	public boolean updateRunDetailsForProject(int runId, String status, String htmlReport) {
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE RUNNER SET CURRENT_STATUS = '" + status + "', HTML_REPORT_LOC = '" + htmlReport
					+ "' WHERE RUN_ID = " + runId;
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean updateRunningStatus(int runId, String status) {
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE RUNNER SET CURRENT_STATUS = '" + status + "' WHERE RUN_ID = " + runId;
			stmt.executeUpdate(sql);
			stmt.close();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public boolean updateCancelJobStatus(int runId, boolean status) throws SQLException {
		boolean updateDoneStatus = false;
		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE RUNNER SET CANCEL_JOB_STATUS = " + status + " WHERE RUN_ID = " + runId;
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			updateDoneStatus = true;
		}
		stmt.close();
		return updateDoneStatus;

	}

	public boolean saveProcessId(int runId, String processId) throws SQLException {
		boolean updateDoneStatus = false;
		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE RUNNER SET PROCESS_ID = '" + processId + "' WHERE RUN_ID = " + runId;
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			updateDoneStatus = true;
		}
		stmt.close();
		return updateDoneStatus;

	}

	public String getProjectName(int projectId) throws Exception {
		String query = "SELECT PROJECT_NAME FROM PROJECT WHERE PROJECT_ID = " + projectId;
		ResultSet rSet = executeStatement(query);
		String name = rSet.getString(1);
		return name;
	}

	public String getJMXFileName(String uuid) throws Exception {
		String query = "SELECT JMX_FILE_NAME FROM PARK_FILE WHERE UID = '" + uuid + "'";
		ResultSet rSet = executeStatement(query);
		String name = rSet.getString(1);
		return name;
	}

	public String getJMXFolderNamefromAPI(String uuid) throws Exception {

		String name = "";
		String query = "SELECT FILE_PATH FROM API_TEST WHERE UID = '" + uuid + "'";
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);
		while (rSet.next()) {
			name = rSet.getString("FILE_PATH");
		}
		return name;
	}

	public String getJMXFolderName(String uuid) throws Exception {

		String name = "";
		String query = "SELECT FOLDER_NAME FROM PARK_FILE WHERE UID = '" + uuid + "'";
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);
		while (rSet.next()) {
			name = rSet.getString("FOLDER_NAME");
		}
		return name;
	}

	public boolean createJMXEntry(int projectId, String jmxFileName, boolean fromGIT, String gitInstance,
			String gitRepoName, String gitBranch, String gitFilePath, String gitUsername, String gitPassword,
			String desc, String gitUrl, String gitDataFiles[], String uuid, String gitFolderName) {
		int count = 0;
		boolean status = false;
		try {

			String sql = "INSERT INTO JMX_FILES (PROJECT_ID,JMX_FILE_NAME,FROM_GIT , GIT_INSTANCE ,GIT_REPO,GIT_BRANCH,GIT_FILE_PATH,GIT_USERNAME , GIT_PASSWORD, DESC , GIT_URL, GIT_DATA_FILES, UUID ,GIT_FOLDER_NAME) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement insertPreparedStatement = conn.prepareStatement(sql);

			insertPreparedStatement.setInt(1, projectId);
			insertPreparedStatement.setString(2, jmxFileName);
			insertPreparedStatement.setBoolean(3, fromGIT);
			insertPreparedStatement.setString(4, gitInstance);
			insertPreparedStatement.setString(5, gitRepoName);
			insertPreparedStatement.setString(6, gitBranch);
			insertPreparedStatement.setString(7, gitFilePath);
			insertPreparedStatement.setString(8, gitUsername);
			insertPreparedStatement.setString(9, gitPassword);
			insertPreparedStatement.setString(10, desc);
			insertPreparedStatement.setString(11, gitUrl);
			insertPreparedStatement.setArray(12, conn.createArrayOf("VARCHAR", gitDataFiles));
			insertPreparedStatement.setString(13, uuid);
			insertPreparedStatement.setString(14, gitFolderName);

			count = insertPreparedStatement.executeUpdate();
			insertPreparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	public boolean parkFile(String jmxFileName, String uuid, String[] dataFiles, String folderName, int projectId) {
		boolean status = false;
		int count = -1;
		try {

			// stmt = conn.createStatement();
			// String sql = "INSERT INTO PARK_FILE (UID,JMX_FILE_NAME,DATA_FILES
			// ) VALUES
			// ('" + uuid + "', '" + jmxFileName + "','"+dataFiles+"')";

			String sql = "INSERT INTO PARK_FILE (UID,JMX_FILE_NAME,DATA_FILES ,FOLDER_NAME, PROJECT_ID) VALUES (?,?,?,?,?)";

			PreparedStatement insertPreparedStatement = conn.prepareStatement(sql);

			insertPreparedStatement.setString(1, uuid);
			insertPreparedStatement.setString(2, jmxFileName);
			insertPreparedStatement.setArray(3, conn.createArrayOf("VARCHAR", dataFiles));
			insertPreparedStatement.setString(4, folderName);
			insertPreparedStatement.setInt(5, projectId);

			count = insertPreparedStatement.executeUpdate();
			insertPreparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	public boolean createServiceLine(int gbgfId, String serviceLineName) throws Exception {
		int count = 0;
		boolean status = false;
		try {
			if (isServiceLineAlreadyRegistered(serviceLineName, gbgfId) == true) {
				return status;
			}
			stmt = conn.createStatement();
			String sql = "INSERT INTO SERVICE_LINE (GBGF_ID, SERVICE_LINE_NAME) VALUES (" + gbgfId + ",'"
					+ serviceLineName + "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public List<String> getDataFiles(int projectId, String fileName) throws SQLException {

		List<String> dataFileList = new ArrayList<String>();
		String query = "SELECT DATA_FILES FROM PARK_FILE WHERE PROJECT_ID=" + projectId + " AND JMX_FILE_NAME='"
				+ fileName + "'";
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);

		Array dataFilesDBArray = null;
		Object[] dataFiles = null;
		while (rSet.next()) {
			dataFilesDBArray = rSet.getArray("DATA_FILES");
		}
		if (dataFilesDBArray != null) {
			dataFiles = (Object[]) dataFilesDBArray.getArray();

			for (Object dataFileName : dataFiles) {
				dataFileList.add((String) dataFileName);
			}
		}
		return dataFileList;
	}

	public boolean deleteDuplicateFile(int projectId, String fileName) throws SQLException {
		boolean status = false;
		int count = 0;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String sql = "DELETE FROM PARK_FILE WHERE PROJECT_ID=" + projectId + " AND JMX_FILE_NAME='" + fileName + "'";
		count = stmt.executeUpdate(sql);
		stmt.close();
		if (count != 0) {
			status = true;
		}

		return status;
	}

	public boolean checkFileExistsForProject(int projectId, String jmxFileName) throws SQLException {
		boolean status = false;
		int count = 0;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = "SELECT COUNT(*) FROM PARK_FILE WHERE PROJECT_ID=" + projectId + " AND JMX_FILE_NAME='"
				+ jmxFileName + "'";
		ResultSet rset = stmt.executeQuery(sql);
		if (rset.next()) {
			count = rset.getInt(1);
		}
		stmt.close();
		if (count != 0) {
			status = true;
		}
		return status;
	}

	public boolean isServiceLineAlreadyRegistered(String serviceLineName, int gbgfId) throws Exception {
		boolean status = false;
		String query = "SELECT COUNT(*) FROM SERVICE_LINE WHERE SERVICE_LINE_NAME = '" + serviceLineName.trim()
				+ "' AND GBGF_ID=" + gbgfId;
		ResultSet rSet = executeStatement(query);
		int rowCount = Integer.parseInt(rSet.getString(1));
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public Map<Integer, String> getAllServiceLine(int gbgfId) throws Exception {
		Map<Integer, String> serviceMap = new HashMap<Integer, String>();
		ResultSet rSet = executeStatement("SELECT * FROM SERVICE_LINE WHERE GBGF_ID=" + gbgfId);
		do {
			int serviceLineId = rSet.getInt("SERVICE_LINE_ID");
			String serviceLineName = rSet.getString("SERVICE_LINE_NAME");
			serviceMap.put(serviceLineId, serviceLineName);

		} while (rSet.next());

		return serviceMap;
	}

	public boolean createProgram(int gbgfId, int serviceLineId, String programName) throws Exception {
		int count = 0;
		boolean status = false;
		try {
			if (isProgramAlreadyRegistered(programName, gbgfId, serviceLineId) == true) {
				return status;
			}
			stmt = conn.createStatement();
			String sql = "INSERT INTO PROGRAMS (GBGF_ID, SERVICE_LINE_ID, PROGRAM_NAME) VALUES (" + gbgfId + ","
					+ serviceLineId + ",'" + programName + "')";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;
	}

	public boolean isProgramAlreadyRegistered(String programName, int gbgfId, int serviceLineId) throws Exception {
		boolean status = false;
		String query = "SELECT COUNT(*) FROM PROGRAMS WHERE SERVICE_LINE_ID = " + serviceLineId + " AND GBGF_ID="
				+ gbgfId + " AND PROGRAM_NAME='" + programName + "'";
		ResultSet rSet = executeStatement(query);
		int rowCount = Integer.parseInt(rSet.getString(1));
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public Map<Integer, String> getAllPrograms(int gbgfId, int serviceLineId) throws Exception {
		Map<Integer, String> programMap = new HashMap<Integer, String>();
		ResultSet rSet = executeStatement(
				"SELECT * FROM PROGRAMS WHERE GBGF_ID=" + gbgfId + " AND SERVICE_LINE_ID=" + serviceLineId);
		do {
			int programId = rSet.getInt("PROGRAM_ID");
			String programName = rSet.getString("PROGRAM_NAME");
			programMap.put(programId, programName);

		} while (rSet.next());

		return programMap;
	}

	public boolean fileExistsInLocal(int projectId, String fileName) throws Exception {
		boolean status = false;
		String query = "SELECT FOLDER_NAME FROM PARK_FILE WHERE PROJECT_ID = " + projectId + " AND JMX_FILE_NAME='"
				+ fileName + "'";
		ResultSet rSet = executeStatement(query);
		int rowCount = Integer.parseInt(rSet.getString(1));
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public Map<String, String> getParameterForBreakpoint(String projectName, String fileName, String scenarioName,
			String testType, String htmlReportLocation, String uid) throws Exception {
		Map<String, String> map = new HashMap<String, String>();

		int users = 0;
		int rampUp = 0;

		stmt = conn.createStatement();
		int projectId = getProjectId(projectName);
		String sql = "SELECT PARAMETERS FROM RUNNER WHERE PROJECT_ID=" + projectId + " AND JMX_FILE_NAME='" + fileName
				+ "' AND SCENARIO_NAME='" + scenarioName + "' AND UUID='" + uid + "' AND HTML_REPORT_LOC='"
				+ htmlReportLocation + "'";
		ResultSet rs = stmt.executeQuery(sql);

		String parameters = "";

		while (rs.next()) {
			parameters = rs.getString("PARAMETERS");
			break;
		}
		List<String> allParameterList = new ArrayList<String>();
		parameters = parameters.replaceAll("-G", "").replaceAll("-J", "");
		String temp[] = parameters.split(",");
		for (String s : temp) {
			String temp2[] = s.split("\\s");
			for (String s1 : temp2) {
				allParameterList.add(s1);
			}
		}

		for (String s : allParameterList) {

			if (s.toLowerCase().contains("usercount") || s.toLowerCase().contains("numberofusers")
					|| s.toLowerCase().contains("nousers")) {
				String param = s.substring(0, s.lastIndexOf("="));
				int paramValue = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));
				users += paramValue;
			}
			if (s.toLowerCase().contains("rampupuser") || s.toLowerCase().contains("userrampup")) {

				String param = s.substring(0, s.lastIndexOf("="));
				int paramValue = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));
				rampUp += paramValue;
			}

		}
		map.put("users", users + "");
		map.put("rampUp", rampUp + "");
		System.out.println(users + "--" + rampUp);

		// System.out.println(map);
		rs.close();
		stmt.close();

		return map;

	}

	public static String encrypt(String variable) throws Exception {
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] passBytes = variable.getBytes();
		md.reset();
		byte[] digested = md.digest(passBytes);
		StringBuffer br = new StringBuffer();
		for (int i = 0; i < digested.length; i++) {
			br.append(Integer.toHexString(0xff & digested[i]));
		}
		return br.toString();
	}

	public boolean validateUser(String email, String password) throws Exception {
		stmt = conn.createStatement();
		boolean status = false;
		int count = 0;
		String encryptedEmail = DBUtilities.encrypt(email);
		String encryptedPassword = DBUtilities.encrypt(password);
		System.out.println("In dbutils validate user: " + email + "--" + password);
		String sql = "SELECT COUNT(*) FROM USERS WHERE EMAIL='" + encryptedEmail + "' AND PASSWORD='"
				+ encryptedPassword + "'";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			count = rs.getInt(1);
			System.out.println(count);
		}
		if (count == 1) {
			status = true;
		}

		return status;
	}

	public boolean updateSessionId(String email, String password, String sessionId) throws Exception {
		stmt = conn.createStatement();
		System.out.println("hi");
		boolean status = false;
		int count = 0;
		// String encryptedEmail=DBUtils.encrypt(email);
		// String encryptedPassword=DBUtils.encrypt(password);

		String sql = "UPDATE USERS SET SID='" + sessionId + "' WHERE EMAIL='" + email + "' AND PASSWORD='" + password
				+ "'";
		count = stmt.executeUpdate(sql);
		System.out.println("hii");

		if (count == 1) {
			System.out.println("hiii");

			status = true;
		}

		return status;

	}

	public boolean insertParamJmx(int projectId, String parameters, String fileName, String uuid) {
		// TODO Auto-generated method stub
		int count = 0;
		boolean status = false;
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE JMX_FILES SET PARAMETERS='" + parameters + "' WHERE UUID='" + uuid + "'";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	public boolean insertParamPark(int projectId, String parameters, String fileName, String uuid) {
		// TODO Auto-generated method stub
		int count = 0;
		boolean status = false;
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE PARK_FILE SET PARAMETERS='" + parameters + "' WHERE UID='" + uuid + "'";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	public String paramFromPark(int projectId, String fileName, String uuid) throws Exception {
		String param = "";
		String query = "SELECT PARAMETERS FROM PARK_FILE WHERE UID='" + uuid + "'";
		ResultSet rSet = executeStatement(query);
		while (rSet.next()) {
			param = rSet.getString("PARAMETERS");
		}
		return param;
	}

	public String paramFromJmx(int projectId, String fileName, String uuid) throws Exception {
		String param = "";
		String query = "SELECT PARAMETERS FROM JMX_FILES WHERE UUID='" + uuid + "'";
		ResultSet rSet = executeStatement(query);
		param = rSet.getString("PARAMETERS");
		System.out.println("Getting");
		System.out.println("Param =" + param);
		return param;
	}

	public String getBreakpointType(String projectName, String scriptName, String scenarioName, String testType,
			String timeStamp, String uid) {
		// TODO Auto-generated method stub
		String testType2 = "";

		try {
			stmt = conn.createStatement();

			int projectId = getProjectId(projectName);
			String sql = "SELECT PERFORMANCE_TEST_TYPE FROM RUNNER WHERE PROJECT_ID=" + projectId
					+ "AND JMX_FILE_NAME='" + scriptName + "' AND SCENARIO_NAME='" + scenarioName
					+ "' AND HTML_REPORT_LOC='" + timeStamp + "'";
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				testType2 = rs.getString("PERFORMANCE_TEST_TYPE");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return testType2;

	}

	public List<String> getRunnerDetails(int runId) {
		List<String> runnerDetails = new ArrayList<String>();

		try {
			stmt = conn.createStatement();
			String sql = "SELECT PROJECT_ID, JMX_FILE_NAME,PERFORMANCE_TEST_TYPE, SCENARIO_NAME FROM RUNNER WHERE RUN_ID="
					+ runId;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int projectId = rs.getInt("PROJECT_ID");
				String projectName = getProjectName(projectId);
				String jmxFileName = rs.getString("JMX_FILE_NAME");
				String testType = rs.getString("PERFORMANCE_TEST_TYPE");
				String scenarioName = rs.getString("SCENARIO_NAME");
				runnerDetails.add(projectName);
				runnerDetails.add(jmxFileName);
				runnerDetails.add(testType);
				runnerDetails.add(scenarioName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return runnerDetails;
	}

	public boolean updateUserApprovalStatus(int requestId, String status) {
		int count = 0;
		int c = 0;
		boolean done = false;
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE REQUEST_FOR_APPROVAL SET APPROVAL_STATUS='" + status + "' WHERE REQUEST_ID='"
					+ requestId + "'";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		if (count == 1)
			done = true;
		return done;

	}

	public boolean updateProjectApprovalStatus(String projectName, String status) {

		int count = 0;
		int c = 0;
		boolean done = false;
		try {

			stmt = conn.createStatement();
			String sql = "UPDATE PROJECT SET APPROVAL_STATUS='" + status + "' WHERE PROJECT_NAME='" + projectName + "'";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

		if (count == 1)
			done = true;
		return done;
	}

	public boolean isUserAlreadyRegisteredInUsersDetails(String userName) throws Exception {
		boolean status = false;
		String query = "SELECT COUNT(*) FROM USERS_DETAILS WHERE REGISTER_MAIL = '" + userName.trim() + "'";
		ResultSet rSet = executeStatement(query);
		int rowCount = Integer.parseInt(rSet.getString(1));
		if (rowCount >= 1) {
			status = true;
		}
		return status;
	}

	public boolean updateUser(String projectId, String userEmailId) {
		int count = 0;
		int c = 0;
		boolean status = false;
		try {
			String projectIdList = getProjectIdList(userEmailId);
			String[] arrayList = projectIdList.split(",");
			for (int i = 0; i < arrayList.length; i++) {
				if (projectId.trim().equals(arrayList[i].trim())) {
					c++;
				}
			}
			if (c == 0) {
				projectIdList += "," + projectId;
			} else {
				return false;
			}
			stmt = conn.createStatement();
			String sql = "UPDATE USERS_DETAILS SET PROJECT_ID='" + projectIdList + "' WHERE REGISTER_MAIL='"
					+ userEmailId.trim() + "'";
			count = stmt.executeUpdate(sql);
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	private String getProjectIdList(String userEmailId) {
		String projectIdList = null;
		try {
			stmt = conn.createStatement();
			String sql = "SELECT PROJECT_ID FROM USERS_DETAILS WHERE REGISTER_MAIL='" + userEmailId.trim() + "'";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				projectIdList = rs.getString("PROJECT_ID");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return projectIdList;
	}

	public int addApprovalRequestInDB(String userMail, String managerMail, String date, String projectName,
			String userRole, String userPSId, String managerPSId, String gbgfName, String serviceLine)
			throws SQLException {
		int count = 0;

		int requestIdGenerated = -1;
		stmt = conn.createStatement();
		String sql = "INSERT INTO REQUEST_FOR_APPROVAL (REGISTER_MAIL, MANAGER_MAIL, PROJECT_NAME, REGISTER_DATE,USER_ROLE,"
				+ " USER_PS_ID,MANAGER_PS_ID,GBGF_NAME,SERVICE_LINE)" + " VALUES ('" + userMail + "','" + managerMail
				+ "','" + projectName + "','" + date + "','" + userRole + "','" + userPSId + "','" + managerPSId + "','"
				+ gbgfName + "','" + serviceLine + "')";

		count = stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
		ResultSet rSet = stmt.getGeneratedKeys();
		while (rSet.next()) {
			requestIdGenerated = rSet.getInt("REQUEST_ID");
			System.out.println("Request Id in db utils: " + rSet.getInt("REQUEST_ID") + "  " + rSet.getInt(1));
		}

		stmt.close();

		return requestIdGenerated;

	}

	public boolean checkUserAccessForProject(int projectId, int userId) throws SQLException {
		boolean status = false;

		int count = 0;
		stmt = conn.createStatement();
		String sql = "SELECT COUNT(*) FROM USER_PROJECT_MAPPING WHERE USER_ID=" + userId + " AND PROJECT_ID = "
				+ projectId;

		ResultSet rSet = stmt.executeQuery(sql);
		while (rSet.next()) {
			count = rSet.getInt(1);
		}
		if (count >= 1) {
			return true;
		}
		return status;
	}

	public Map<String, String> getApprovalRequestDetailsForId(int requestId) throws SQLException {
		Map<String, String> map = new HashMap<String, String>();
		stmt = conn.createStatement();
		String sql = "SELECT * FROM REQUEST_FOR_APPROVAL WHERE REQUEST_ID=" + requestId;
		ResultSet rs = stmt.executeQuery(sql);
		String userMail;
		String managerMail;
		String userPsId;
		String managerPsId;
		String userRole;
		String projectName;
		String registerDate;
		String approvalStatus;
		String gbgfName;
		String serviceLine;
		while (rs.next()) {
			userMail = rs.getString("REGISTER_MAIL");
			managerMail = rs.getString("MANAGER_MAIL");
			userPsId = rs.getString("USER_PS_ID");
			managerPsId = rs.getString("MANAGER_PS_ID");
			userRole = rs.getString("USER_ROLE");
			projectName = rs.getString("PROJECT_NAME");
			registerDate = rs.getString("REGISTER_DATE");
			approvalStatus = rs.getString("APPROVAL_STATUS");
			gbgfName = rs.getString("GBGF_NAME");
			serviceLine = rs.getString("SERVICE_LINE");
			map.put("userMail", userMail);
			map.put("managerMail", managerMail);
			map.put("userPsId", userPsId);
			map.put("managerPsId", managerPsId);
			map.put("userRole", userRole);
			map.put("projectName", projectName);
			map.put("registerDate", registerDate);
			map.put("approvalStatus", approvalStatus);
			map.put("gbgfName", gbgfName);
			map.put("serviceLine", serviceLine);
		}

		return map;
	}

	public boolean addUserProjectMapping(String userRole, int projectId, int userId) throws SQLException {
		int count = 0;
		boolean status = false;

		stmt = conn.createStatement();
		String sql = "INSERT INTO  USER_PROJECT_MAPPING (USER_ID,PROJECT_ID,USER_ROLE) VALUES ( " + userId + ","
				+ projectId + ",'" + userRole + "')";
		count = stmt.executeUpdate(sql);
		stmt.close();

		if (count == 1)
			status = true;
		return status;

	}

	public boolean updateUserGrafanaId(String registerMail, String grafanaId) throws SQLException {
		boolean updateDoneStatus = false;
		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE USERS_DETAILS SET GRAFANA_USER_ID = '" + grafanaId + "' WHERE REGISTER_MAIL = '"
				+ registerMail + "'";
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			updateDoneStatus = true;
		}
		stmt.close();
		return updateDoneStatus;

	}

	public boolean updateProjectFolderGrafanaId(int projectId, String folderId, String folderUid) throws SQLException {
		boolean updateDoneStatus = false;
		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE PROJECT SET GRAFANA_FOLDER_ID = '" + folderId + "' AND " + "GRAFANA_FOLDER_UID ='"
				+ folderUid + "'WHERE PROJECT_ID = " + projectId + "";
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			updateDoneStatus = true;
		}
		stmt.close();
		return updateDoneStatus;

	}

	public Map<String, String> getProjectFolderGrafanaIds(int projectId) throws SQLException {
		Map<String, String> map = new HashMap<String, String>();
		stmt = conn.createStatement();
		String sql = "SELECT * FROM PROJECT WHERE PROJECT_ID=" + projectId;
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {

			map.put("grafanaFolderId", rs.getString("GRAFANA_FOLDER_ID"));
			map.put("grafanaFolderUid", rs.getString("GRAFANA_FOLDER_UID"));

		}

		return map;

	}

	public boolean checkUserIsProjectAdminForAnyProject(int userId) throws SQLException {

		stmt = conn.createStatement();
		boolean status = false;
		int count = 0;

		String sql = "SELECT COUNT(*) FROM USER_PROJECT_MAPPING WHERE USER_ID=" + userId
				+ " AND USER_ROLE='Project_Admin'";

		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			count = rs.getInt(1);
			System.out.println(count);
		}
		if (count >= 1) {
			status = true;
		}

		return status;

	}

	public List<String> getAllProjectsForAdmin(int adminUserId) throws Exception {

		List<String> projectList = new ArrayList<>();

		List<Integer> projectIdList = new ArrayList<>();
		stmt = conn.createStatement();

		String sql = "SELECT PROJECT_ID  FROM USER_PROJECT_MAPPING WHERE USER_ID=" + adminUserId
				+ " AND USER_ROLE='Project_Admin'";

		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			projectIdList.add(rs.getInt("PROJECT_ID"));
		}

		for (Integer id : projectIdList) {
			projectList.add(getProjectName(id));
		}
		return projectList;

	}

	public Map<String, String> getDetailsOfAllUserForProject(int projectId) throws SQLException {
		Map<String, String> map = new HashMap<String, String>();

		stmt = conn.createStatement();

		String sql = "SELECT REGISTER_MAIL,USER_PS_ID FROM USERS_DETAILS U "
				+ "INNER JOIN USER_PROJECT_MAPPING M WHERE U.USER_ID = M.USER_ID AND M.PROJECT_ID=" + projectId;

		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			map.put(rs.getString("USER_PS_ID"), rs.getString("REGISTER_MAIL"));
		}

		return map;

	}

	public String getUserPSId(String managerMailId) throws SQLException {

		String userPsId = null;
		stmt = conn.createStatement();

		String sql = "SELECT * FROM USERS_DETAILS WHERE REGISTER_MAIL='" + managerMailId + "'";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			userPsId = rs.getString("USER_PS_ID");
		}

		return userPsId;
	}

	public List<String> getAllProjectsForParticularUser(int userId) throws SQLException {
		List<String> projectNameList = new ArrayList<>();
		stmt = conn.createStatement();

		String sql = "SELECT PROJECT_NAME FROM PROJECT P INNER JOIN "
				+ "USER_PROJECT_MAPPING M WHERE M.PROJECT_ID=P.PROJECT_ID AND M.USER_ID=" + userId;

		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			projectNameList.add(rs.getString("PROJECT_NAME"));
		}

		return projectNameList;

	}

	public Map<String, String> getProjectDetails(int projectId) throws SQLException {
		Map<String, String> map = new HashMap<String, String>();
		stmt = conn.createStatement();

		String sql = "SELECT * FROM PROJECT WHERE PROJECT_ID = " + projectId;
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			map.put("projectName", rs.getString("PROJECT_NAME"));
			map.put("gbgfName", rs.getString("GBGF_NAME"));
			map.put("serviceLine", rs.getString("SERVICE_LINE"));

		}

		return map;
	}

	public boolean updateAdminSessionId(String sessionId) throws SQLException {
		boolean status = false;

		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE SYSTEM_ADMIN SET SESSION_ID = '" + sessionId + "' WHERE ADMIN_ID = 1";
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			status = true;
		}
		stmt.close();
		return status;

	}

	public boolean checkSessionValid(String sessionId) throws SQLException {
		boolean status = false;
		int count = 0;
		stmt = conn.createStatement();
		String sql = "SELECT COUNT(*) FROM SYSTEM_ADMIN WHERE SESSION_ID =  '" + sessionId + "'";
		ResultSet rSet = stmt.executeQuery(sql);
		while (rSet.next()) {
			count = rSet.getInt(1);
		}
		System.out.println(count);
		if (count == 1) {
			status = true;
		}
		stmt.close();
		return status;

	}

	public boolean apiFile(String jmxFileName, int projectId, String uuid, String folderName, String method, String url,
			String payload, String parameters, String[] dataFiles) {
		boolean status = false;
		int count = -1;
		try {

			String sql = "INSERT INTO API_TEST (JMX_FILE_NAME, PROJECT_ID, UID, FILE_PATH, METHOD, URL, PAYLOAD, PARAMETERS, DATA_FILES) VALUES (?,?,?,?,?,?,?,?,?)";

			PreparedStatement insertPreparedStatement = conn.prepareStatement(sql);

			insertPreparedStatement.setString(1, jmxFileName);
			insertPreparedStatement.setInt(2, projectId);
			insertPreparedStatement.setString(3, uuid);
			insertPreparedStatement.setString(4, folderName);
			insertPreparedStatement.setString(5, method);
			insertPreparedStatement.setString(6, url);
			insertPreparedStatement.setString(7, payload);
			insertPreparedStatement.setString(8, parameters);
			insertPreparedStatement.setArray(9, conn.createArrayOf("VARCHAR", dataFiles));

			count = insertPreparedStatement.executeUpdate();
			insertPreparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 1)
			status = true;
		return status;

	}

	public boolean updateExecutionType(int runIdGenerated, String executionType) throws Exception {
		// TODO Auto-generated method stub
		boolean status = false;

		int count = 0;
		stmt = conn.createStatement();
		String sql = "UPDATE RUNNER SET EXECUTION_TYPE = '" + executionType + "' WHERE RUN_ID = " + runIdGenerated;
		count = stmt.executeUpdate(sql);
		if (count == 1) {
			status = true;
		}
		stmt.close();
		return status;

	}

	public boolean updateRemoteHostStatus(int remoteHostId) {
		// TODO Auto-generated method stub
		boolean status = false;

		int count = 0;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = "UPDATE REMOTE_HOST SET STATUS = 1 WHERE REMOTE_HOST_ID = " + remoteHostId;
		try {
			count = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (count == 1) {
			status = true;
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	public boolean updateRemoteHostStatus2(int remoteHostId) {
		// TODO Auto-generated method stub
		boolean status = false;

		int count = 0;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql = "UPDATE REMOTE_HOST SET STATUS = 0 WHERE REMOTE_HOST_ID = " + remoteHostId;
		try {
			count = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (count == 1) {
			status = true;
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	public List<Integer> getRemoteHostStatus() {
		List<Integer> remoteHost = new ArrayList<Integer>();
		int id = -1;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sql = "SELECT REMOTE_HOST_ID FROM RUNNER WHERE CURRENT_STATUS = 'RUNNING'";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			while (rs.next()) {
				id = rs.getInt("REMOTE_HOST_ID");
				if (id == 0)
					remoteHost.add(id);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return remoteHost;
	}

	public List<Integer> getAllRemoteHostAvailable() {

		List<Integer> remoteHostList = new ArrayList<Integer>();
		try {
			stmt = conn.createStatement();
			String sql = "SELECT REMOTE_HOST_ID FROM REMOTE_HOST WHERE STATUS=0";
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				int hostId = rs.getInt("REMOTE_HOST_ID");
				remoteHostList.add(hostId);

			}

			rs.close();
			stmt.close();
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return remoteHostList;

	}

	public List<String> getDataFileNames(String uuid) throws Exception {
		// TODO Auto-generated method stub
		List<String> dataFileList = new ArrayList<String>();
		String query = "SELECT DATA_FILES FROM PARK_FILE WHERE UID='" + uuid + "'";
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);

		Array dataFilesDBArray = null;
		Object[] dataFiles = null;
		while (rSet.next()) {
			dataFilesDBArray = rSet.getArray("DATA_FILES");
		}
		if (dataFilesDBArray != null) {
			dataFiles = (Object[]) dataFilesDBArray.getArray();

			for (Object dataFileName : dataFiles) {
				dataFileList.add((String) dataFileName);
			}
		}
		return dataFileList;
	}

	public List<String> getDataFileNamesForApi(String uuid) throws Exception {
		// TODO Auto-generated method stub
		List<String> dataFileList = new ArrayList<String>();
		String query = "SELECT DATA_FILES FROM API_TEST WHERE UID='" + uuid + "'";
		Statement executeStament = conn.createStatement();
		ResultSet rSet = executeStament.executeQuery(query);

		Array dataFilesDBArray = null;
		Object[] dataFiles = null;
		while (rSet.next()) {
			dataFilesDBArray = rSet.getArray("DATA_FILES");
		}
		if (dataFilesDBArray != null) {
			dataFiles = (Object[]) dataFilesDBArray.getArray();

			for (Object dataFileName : dataFiles) {
				dataFileList.add((String) dataFileName);
			}
		}
		return dataFileList;
	}

	public int fetchTotalUserLoad() {
		ResultSet rs = null;
		// String params = "";
		int numberOfUsers = 0;
		List<String> params = new ArrayList<String>();
		try {
			stmt = conn.createStatement();
			String sql = "SELECT PARAMETERS FROM RUNNER";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				params.add(rs.getString("PARAMETERS"));
			}
			// System.out.println(params.size());
			for (String param : params) {
				param = param.replaceAll("-G", "").replaceAll("-J", "").replaceAll(",", " ");
				String[] paramList = param.split(" ");
				for (String s : paramList) {
					if (s.toLowerCase().contains("numberofusers") || s.toLowerCase().contains("nousers")
							|| s.toLowerCase().contains("usercount")) {
						int value = 0;
						try {
							value = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));
						} catch (Exception e) {
							e.getLocalizedMessage();
						}
						numberOfUsers += value;
					}
				}
			}
			// System.out.println(numberOfUsers);
		} catch (Exception e) {

			e.printStackTrace();
			return numberOfUsers;

		}
		return numberOfUsers;
	}

	public int fetchMetricsPerProject(int projectId) {
		ResultSet rs = null;
		// String params = "";
		int max = 0;
		List<String> params = new ArrayList<String>();
		try {
			stmt = conn.createStatement();
			String sql = "SELECT PARAMETERS FROM RUNNER WHERE PROJECT_ID=" + projectId;
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				params.add(rs.getString("PARAMETERS"));
			}
			// System.out.println(params.size());
			for (String param : params) {
				param = param.replaceAll("-G", "").replaceAll("-J", "").replaceAll(",", " ");
				String[] paramList = param.split(" ");
				for (String s : paramList) {
					if (s.toLowerCase().contains("numberofusers") || s.toLowerCase().contains("nousers")
							|| s.toLowerCase().contains("usercount")) {
						int value = 0;
						try {
							value = Integer.parseInt(s.substring(s.lastIndexOf("=") + 1));
						} catch (Exception e) {
							e.getLocalizedMessage();
						}
						if (value > max) {
							max = value;
						}
					}
				}
			}
			// System.out.println("Users :"+max+" for Project
			// :"+getProjectName(projectId)+" having ProjectId :"+projectId);
			return max;
		} catch (Exception e) {
			e.printStackTrace();
			return max;
		}
	}

	public List<Integer> getAllDistinctProjects() throws SQLException {
		List<Integer> projectIdList = new ArrayList<>();
		stmt = conn.createStatement();

		String sql = "SELECT DISTINCT PROJECT_ID FROM PROJECT";

		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			projectIdList.add(rs.getInt("PROJECT_ID"));
		}

		return projectIdList;

	}

	public int fetchTotalExec() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM RUNNER";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalProjects() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM PROJECT";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalGBGF() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT( DISTINCT GBGF_NAME) FROM PROJECT";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalServiceLine() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT( DISTINCT SERVICE_LINE) FROM PROJECT";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalExecLastWeek() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM RUNNER WHERE PARSEDATETIME(EXEC_TIME, 'ddMMMyyyyHHmmss') > DATEADD('DAY',-7, now())";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalUsers() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM USERS_DETAILS WHERE REGISTER_MAIL NOT IN ('ariz.ahmad.usmani@noexternalmail.hsbc.com','srinivas1.ravuri@noexternalmail.hsbc.com','ajit.rathod@noexternalmail.hsbc.com','sahil.bhatia@noexternalmail.hsbc.com','sudhir.dattaram.chavan@hsbc.co.in','swapneel.shidhaye@noexternalmail.hsbc.com','shantanu.r.ramchandra.divekar@noexternalmail.hsbc.com','maya.arora@hsbc.co.in','abhijit.natu@noexternalmail.hsbc.com','ananda.ware@noexternalmail.hsbc.com','sandeep.sodi@noexternalmail.hsbc.com')";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

	public int fetchTotalUsersLastWeek() throws Exception {
		int rowCount = 0;
		String query = "SELECT COUNT(*) FROM USERS_DETAILS WHERE PARSEDATETIME(REGISTER_DATE, 'yyyy-MM-dd') > DATEADD('DAY',-7, now())";
		ResultSet rSet = execute(query);
		while (rSet.next()) {
			rowCount = Integer.parseInt(rSet.getString(1));
		}
		return rowCount;
	}

}
