package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

import frameworkConstants.FrameworkConstants;
import frameworkEnums.ConfigProperties;

public final class S3ReportUtils {

	static String bucketName = "";
	static AWSCredentials credentials = null;
	static AmazonS3 s3client = null;

	public static void uploadToS3(String suiteName) {

		String filepath="";
		if (ApplicationPropertyUtils.get(ConfigProperties.UPLOADRESULTSTOAWS).equalsIgnoreCase("yes")) {
			try {
				filepath = String.format(FrameworkConstants.getExtentReportsPath(), suiteName);
				bucketName = ApplicationPropertyUtils.get(ConfigProperties.AWSBUCKETNAME);
				credentials = new BasicAWSCredentials(ApplicationPropertyUtils.get(ConfigProperties.AWSACCESSKEY),
						ApplicationPropertyUtils.get(ConfigProperties.AWSSECRETKEY));

				AmazonS3 s3client = AmazonS3ClientBuilder.standard()
						.withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.US_EAST_1)
						.build();

				if (!s3client.doesBucketExist(bucketName)) 
					throw new Exception("Bucket is not Present");
				
				File file = new File(filepath);
				System.out.println("Uploading Test Results to S3 Bucket..."+bucketName+":"+file);

				upload(s3client, bucketName, file);

				System.out.println("Done! Reports Uploaded Successfully to S3 Bucket");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	public static boolean checkMonthExists(String key, AmazonS3 s3Client) {
		ListObjectsV2Result result = s3Client.listObjectsV2(bucketName, key);
		return result.getKeyCount() > 0;
	}

	public static void upload(AmazonS3 s3, String bucketName, File file) {
		try (InputStream stream = new FileInputStream(file)) {
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(file.length());

			s3.putObject(new PutObjectRequest(bucketName, createFilePath() + file.getName(), stream, metadata));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String createFilePath() {

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();

		LocalDate currentdate = LocalDate.now();
		return String.valueOf(
				currentdate.getYear() + "/" + StringUtils.capitalize(currentdate.getMonth().toString().toLowerCase())
						+ "/" + formatter.format(date) + "/" + System.getProperty("env") + "/" + System.getProperty("platform") +"/");

	}

}
