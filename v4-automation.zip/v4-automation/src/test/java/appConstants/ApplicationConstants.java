package appConstants;

import static appConstants.ApplicationConstants.PROOFS_CREATION_SUCCESS_MESSAGE;

public final class ApplicationConstants {

	public static final String CREATE_SUCCESS_MESSAGE = "created successfully!";
	public static final String UPDATE_SUCCESS_MESSAGE = "Changes saved successfully!";
	public static final String DEACTIVATION_MESSAGE = "deactivated successfully!";
	public static final String REACTIVATION_MESSAGE = "activated successfully!";
	public static final String DELETION_MESSAGE = "deleted successfully!";
	public static final String EXISTING_MESSAGE = "User already exists.";
	public static final String ADDRESSFORM_VALIDATION_MESSAGE = "Please fill the address form before proceeding!";
	public static final String INVALID_ADDRESS_VALIDATION_MESSAGE = "The address you entered is invalid!";
	public static final String ASSIGN_MANAGER_TO_CLIENT_MESSAGE = "Successfully assigned manager to the user!";
	public static final String UPDATE_MANAGER_TO_CLIENT_MESSAGE = "Manager Updated.";
	public static final String DEACTIVATED_USER_DISPLAY_MESSAGE = "This user has already been deactivated.";
	public static final String EMPTY_INVALID_MESSAGE = " <<>>?";
	public static final String PASSWORD_EMPTY_INVALID_MESSAGE = "Set the password";
	public static final String CONFIRMPASSWORD_EMPTY_INVALID_MESSAGE = "Confirm the password";
	public static final String CURRENT_PASSWORD_EMPTY_INVALID_MESSAGE = "Enter current password";
	public static final String SETNEW_PASSWORD_EMPTY_INVALID_MESSAGE = "Set the new password";
	public static final String CONFIRMNEW_PASSWORD_EMPTY_INVALID_MESSAGE = "Confirm the new password";
	public static final String SETTINGS_PASSWORD_INVALID_MESSAGE ="Invalid password";
	public static final String SETTINGS_SCHOOL_INVAILD_MESSAGE = "Add the CM's school";
	public static final String SETTINGS_ORGANIZATION_INVAILD_MESSAGE = "Add the CM's org";
	public static final String SETTINGS_BUSINESS_INVAILD_MESSAGE = "Enter your client's business name";
	public static final String SETTINGS_TITLE_INVAILD_MESSAGE = "Enter your client's title";
	



	public static final String FULLNAME_INVALID_MESSAGE = "What�s your full name?";
	public static final String EMPTYPHONE_INVALID_MESSAGE = "What�s your phone number?";
	public static final String EMPTYEMAIL_INVALID_MESSAGE = "What�s your email?";
	public static final String PHONE_INVALID_MESSAGE = "No spam calls, promise";
	public static final String EMAIL_INVALID_MESSAGE = "That's not a valid email, silly!";
	public static final String SCHOOL_ORG_INVALID_MESSAGE = " <<>>";
	public static final String BUSINESS_TITLE_INVALID_MESSAGE = " <<>>";
	public static final String PASSWORD_MISMATCH_MESSAGE = "Passwords don";
	public static final String SHIPPING_NAME_INVALID_MESSAGE = "Enter a shipping name";
	public static final String ADDRESS_INVALID_MESSAGE = "Enter a <<>>";
	public static final String STATE_INVALID_MESSAGE = "Select a state";

	public static final String QUOTERS_APPARELINFO_REQUIRED_MESSAGE = "Apparel Info is required!";
//	public static final String QUOTERS_INVALIDSTYLECODE_MESSAGE = "No style code found. Try a different style code or enter the blanks price directly.";
    /* Changes done by vidya - 04.25.2022*/
	public static final String QUOTERS_INVALIDSTYLECODE_MESSAGE = "No style code found. Try a different style code or enter the blank cost directly.";
	
	
	public static final String INVOICES_PAYMENTPAGEMESSAGE = "If you want to pay by check, send it to the address below with the invoice # in the memo";
	public static final String INVOICES_CLIENTNAME_VALIDATIONMESSAGE = "Select a client";
	public static final String INVOICES_MANAGERNAME_VALIDATIONMESSAGE = "Select a campus manager";
	public static final String INVOICES_DUEDATE_VALIDATIONMESSAGE = "Due date is invalid.";
	public static final String INVOICE_EMAIL_SENT_MESSAGE = "Email sent successfully";
	public static final String INVOICE_EDIT_MESSAGE = "Changes Saved";
	public static final String INVOICE_POST_COMMENTS_MESSAGE = "Successfully posted comments";
	public static final String INVOICES_PAYMENTPAGEMESSAGE_WIRETRANSFER = "Pay with the invoice # in the memo via Wire Transfer";
	public static final String INVOICES_PAYMENTPAGEMESSAGE_ZELLE = "Pay with the invoice # in the memo to finance@freshprints.com";
	
	public static final String PROMOCODES_INVALID_PROMOCODE = "This code already exists. Can you try another?";
//	public static final String PROMOCODES_DISABLEMULTIPLEPROMOCODES_MESSAGE = "Promo Codes Disabled!";
	public static final String PROMOCODES_DISABLEMULTIPLEPROMOCODES_MESSAGE = "Promo Group Order Codes Disabled!";

//	public static final String GIFTCARDS_DISABLEMULTIPLEGIFTCARDS_MESSAGE = "Gift Cards Disabled!";
	public static final String GIFTCARDS_DISABLEMULTIPLEGIFTCARDS_MESSAGE = "Group Order Gift Cards Disabled!";
	public static final String GIFTCARDS_INVALID_GIFTCARD = "This code already exists. Can you try another?";

	public static final String PROOFS_CREATION_SUCCESS_MESSAGE = "Proof Request Submitted";
	public static final String PROOFS_ASSIGNEMENT_SUCCESS_MESSAGE = "Successfully assigned proof request";
	public static final String PROOFS_PROOFTITLE_EMPTY_MESSAGE = "Enter proof title";
	public static final String PROOFS_CLIENT_EMPTY_MESSAGE = "Select a client";
	public static final String PROOFS_CAMPAIGN_EMPTY_MESSAGE = "Select a campaign";
	public static final String PROOFS_STYLECODE_EMPTY_MESSAGE = "Select a style code";
	public static final String PROOFS_COLOR_EMPTY_MESSAGE = "Select a color";
	public static final String PROOFS_COLLEGIATE_EMPTY_MESSAGE = "School is invalid";
	public static final String PROOFS_ORG_EMPTY_MESSAGE = "Organization is invalid";
//	public static final String PROOFS_EDITED_SUCCESS_MESSAGE = "Proof Details Changes Saved";
	public static final String PROOFS_EDITED_SUCCESS_MESSAGE = "Changes Saved";
//	public static final String PROOFS_EDITED_SUCCESS_MESSAGE = "Successfully assigned proof request";
	public static final String PROOFS_DELETION_SUCCESS_MESSAGE="Successfully deleted proof request:";
	public static final String PROOFS_ADDITION_SUCCESS_MESSAGE = "Successfully created a proof item";
//	public static final String PROOFS_ADDLOCATION_SUCCESS_MESSAGE = "Successfully updated the proof item";
	public static final String PROOFS_ADDLOCATION_SUCCESS_MESSAGE = "Changes saved";
	public static final String PROOFS_PRODUCTNAME_EMPTY_MESSAGE = "Please enter a product name";
	public static final String PROOFS_PRODUCTLINK_EMPTY_MESSAGE = "Please enter a product link";
	public static final String PROOFS_REQUESTREVISION_EMPTY_MESSAGE = "Successfully placed a revision request";
	public static final String PROOFS_NOSEARCH_FOUND = "No search results found";
	public static final String PROOFS_MANAGERNAME_EDITED_SUCCESS_MESSAGE = "Manager Updated";
	public static final String PROOFS_STYLECODE_CHANGE_MESSAGE = "The color of garment has changed";
	
	
	
	
	
	
	
	public static final String INVENTORY_STOCK_ADDED_MESSAGE = "Incoming Stock";
	public static final String INVENTORY_STOCK_UPDATED_MESSAGE = "Stock Updated";

	
	public static final String ORDER_NOSEARCH_FOUND = "No search results found";
	public static final String ORDERS_CREATION_SUCCESS_MESSAGE = "Order Submitted";
	
}
