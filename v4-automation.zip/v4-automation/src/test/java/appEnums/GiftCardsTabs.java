package appEnums;

public enum GiftCardsTabs {
	ALL,
	ACTIVE,
	DISABLED;
}
