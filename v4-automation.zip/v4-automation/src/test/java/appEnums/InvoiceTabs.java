package appEnums;

public enum InvoiceTabs {
	ALL_UNPAID,
	OPEN,
	CLOSED,
	OVERDUE;

}
