package appEnums;

public enum PromoCodesTabs {
	ALL,
	ACTIVE,
	DISABLED;

}
