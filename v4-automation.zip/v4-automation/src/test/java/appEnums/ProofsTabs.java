package appEnums;

public enum ProofsTabs {
	ALL,
	IN_PROGRESS,
	DONE;

}
