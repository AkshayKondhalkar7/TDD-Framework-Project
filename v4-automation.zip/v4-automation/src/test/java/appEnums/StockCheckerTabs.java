package appEnums;

public enum StockCheckerTabs {
	stockCheckerTab,
	ACTIVE,
	ALL,
	DISABLED
}
