package appEnums;

public enum UserOperation {
	VIEW,
	CREATE,
	UPDATE,
	IMPERSONATE,
	REACTIVATE,
	DEACTIVATE,
	DELETE;

}
