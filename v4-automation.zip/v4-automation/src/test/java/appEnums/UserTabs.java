package appEnums;

public enum UserTabs {
	
	ALL_ACTIVE,
	CLIENT,
	PRINTER,
	FULFILLMENT_CENTER,
	CAMPUS_MANAGER,
	ADMIN,
//	INACTIVE;
	Inactive;

}
