package appEnums;

public enum UserType {
	
	PRINTER,
	FULFILLMENT_CENTER,
	CAMPUS_MANAGER,
	ADMIN,
	CLIENT;

}
