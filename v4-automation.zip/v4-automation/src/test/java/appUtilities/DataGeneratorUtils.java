package appUtilities;

import java.util.HashMap;
import java.util.Random;
import org.apache.commons.lang3.RandomStringUtils;

public final class DataGeneratorUtils {

	public static String randName() {
		String[] names = new String[] { "Sam", "John", "Matt", "Joey", "Ross", "Ash", "Perry", "Gellar" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randFullName() {
		return randName() + " " + randName();
	}

	public static String randSchoolName() {
		String[] names = new String[] { "Ball State University", "Davenport University", "Millikin University",
				"Miami University", "Emerson College", "Central Michigan University" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randOrganizationName() {
		String[] names = new String[] { "Optimist Club", "Kendo Club", "Karate Club", "GlobeMed", "Fuse", "Outlaw" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randStreet() {
		String[] names = new String[] { "100 Wall Street" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randWrongStreet() {
		String[] names = new String[] { "123a" };
		return names[new Random().nextInt(names.length)];
	}
	public static String randSuite() {
		String[] names = new String[] { "ABC Apartments", "XYZ Building" };
		return names[new Random().nextInt(names.length)];
	}
	
	public static String randWrongSuite() {
		String[] names = new String[] { "123a" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randState() {
		String[] names = new String[] { "NY" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randCity() {
		String[] names = new String[] { "New York" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randWrongCity() {
		String[] names = new String[] { "city" };
		return names[new Random().nextInt(names.length)];
	}
	
	public static String randZipCode() {
		String[] names = new String[] { "10005" };
		return names[new Random().nextInt(names.length)];
	}
	
	public static String randWrongZipCode() {
		String[] names = new String[] { "1000000000000000000000000000000000000000000000000000300000000000000000000000000000000000456780000000000000000000000000000000000000000000045678" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randTimezone() {
		String[] names = new String[] { "PDT", "EST", "CDT", "MDT" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randGraduationYear() {
		String[] names = new String[] { "2023", "2024" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randBusiness() {
		String[] names = new String[] { "BusinessA", "BusinessB", "BusinessC" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randTitle() {
		String[] names = new String[] { "TitleA", "TitleB", "TitleC" };
		return names[new Random().nextInt(names.length)];
	}

	public static String randShipmentName() {
		return "Shipment" + RandomStringUtils.randomAlphabetic(2).toLowerCase();
	}

	public static String randAttentionName() {
		return "Attention" + RandomStringUtils.randomAlphabetic(2).toLowerCase();
	}

	public static String randString() {
		return randName() + RandomStringUtils.randomAlphabetic(8).toLowerCase();
	}

	public static String randEmail(String name) {
		return name.toString() + randString() + "@gmail.com";
	}

	public static String randPhoneNumber() {
		String[] phone = new String[] { "+1(917)987-1234", "98" + RandomStringUtils.randomNumeric(8).toString(),
				"99" + RandomStringUtils.randomNumeric(8).toString() };
		return phone[new Random().nextInt(phone.length)];
	}

	public static String randNumber() {
		return RandomStringUtils.randomNumeric(5).toString();
	}

	public static String randCompany() {
		String[] names = new String[] { "Test-CompanyA", "Test & CompaniesB", "Test CompanyC" };
		return names[new Random().nextInt(names.length)];
	}

	public static HashMap<String, String> generateContactDetails() {
		HashMap<String, String> contactDetails = null;
		try {
			contactDetails = new HashMap<>();
			String firstName = randName(), lastName = randName();
			contactDetails.put("FULLNAME", firstName + " " + lastName);
			contactDetails.put("PHONENUMBER", randPhoneNumber());
			contactDetails.put("EMAIL", randEmail(firstName).toLowerCase());
		} catch (Exception e) {
			// TODO: handle exception
		}
		return contactDetails;

	}

	public static HashMap<String, String> generateBasicDetails() {
		HashMap<String, String> basicDetails = null;
		try {
			basicDetails = new HashMap<>();
			String firstName = randName(), lastName = randName();
			basicDetails.put("FULLNAME", firstName + " " + lastName);
			basicDetails.put("COMPANY", randCompany());

		} catch (Exception e) {
			// TODO: handle exception
		}
		return basicDetails;

	}

	public static HashMap<String, String> generatePasswordDetails() {
		HashMap<String, String> passwordDetails = null;
		try {
			String firstName = randName();
			passwordDetails = new HashMap<>();
			passwordDetails.put("EMAIL", randEmail(firstName).toLowerCase());
			passwordDetails.put("PASSWORD", randString());

		} catch (Exception e) {
			// TODO: handle exception
		}
		return passwordDetails;

	}

	public static HashMap<String, String> generateSchoolAndOrgDetails() {
		HashMap<String, String> schoolAndBusinessDetails = null;
		try {
			schoolAndBusinessDetails = new HashMap<>();
			schoolAndBusinessDetails.put("SCHOOL", randSchoolName());
			schoolAndBusinessDetails.put("ORGANIZATION", randOrganizationName());
			schoolAndBusinessDetails.put("GRADYEAR", randGraduationYear());
			schoolAndBusinessDetails.put("BUSINESS", randBusiness());
			schoolAndBusinessDetails.put("TITLE", randTitle());

		} catch (Exception e) {
			// TODO: handle exception
		}
		return schoolAndBusinessDetails;

	}

	public static HashMap<String, String> generateShippingDetails(String type) {
		HashMap<String, String> shippingDetails = null;
		try {
			shippingDetails = new HashMap<>();
			shippingDetails.put("SHIPPINGNAME", randShipmentName());
			shippingDetails.put("ATTENTIONNAME", randAttentionName());

			shippingDetails.put("STREET", randStreet());
			shippingDetails.put("SUITE", randSuite());

			if (type.equalsIgnoreCase("valid")) {
				shippingDetails.put("CITY", randCity());
			} else {
				shippingDetails.put("CITY", randCity() + randString());
			}

			shippingDetails.put("STATE", randState());
			shippingDetails.put("ZIPCODE", randZipCode());
			shippingDetails.put("TIMEZONE", randTimezone());

		} catch (Exception e) {
			// TODO: handle exception
		}
		return shippingDetails;

	}
	
	public static HashMap<String, String> generateWrongShippingDetails(String type) {
		HashMap<String, String> shippingDetails = null;
		try {
			shippingDetails = new HashMap<>();
			shippingDetails.put("SHIPPINGNAME", randShipmentName());
			shippingDetails.put("ATTENTIONNAME", randAttentionName());

			shippingDetails.put("STREET", randWrongStreet());
			shippingDetails.put("SUITE", randWrongSuite());

			if (type.equalsIgnoreCase("valid")) {
				shippingDetails.put("CITY", randWrongCity());
			} else {
				shippingDetails.put("CITY", randWrongCity() + randString());
			}

			shippingDetails.put("STATE", randState());
			shippingDetails.put("ZIPCODE", randWrongZipCode());
			shippingDetails.put("TIMEZONE", randTimezone());

		} catch (Exception e) {
			// TODO: handle exception
		}
		return shippingDetails;

	}
	
	public static String randShippingDateAddOns() {
		String[] addOns = new String[] { "7to10", "11to13" };
		return addOns[new Random().nextInt(addOns.length)];
	}
	
	public static String randYesOrNo() {
		String[] randData = new String[] { "Yes", "No" };
		return randData[new Random().nextInt(randData.length)];
	}
	
	public static String randPrintingTypeForProofs() {
		String[] randData = new String[] { "Screen Print", "Digital Print", "Embroidery", "Applique" };
		return randData[new Random().nextInt(randData.length)];
	}

}
