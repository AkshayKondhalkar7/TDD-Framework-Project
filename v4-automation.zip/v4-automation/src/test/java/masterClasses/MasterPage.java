package masterClasses;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;

import appEnums.UserTabs;
import appEnums.UserType;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ConfigProperties;
import frameworkEnums.WaitStrategy;
import pageElements.MasterPageElements;
import pages.GiftCardsPage;
import pages.InventoryPage;
import pages.InvoicePage;
import pages.LoginPage;
import pages.OrdersPage;
import pages.OrdersPageNew;
import pages.PromoCodesPage;
import pages.ProofsPage;
import pages.QuotersPage;
import pages.SettingsPage;
import pages.StockCheckerPage;
import pages.UsersPage;
import reports.ExtentLogger;
import utilities.ApplicationPropertyUtils;

public class MasterPage extends MasterWrapper implements MasterPageElements {

	public UsersPage navigateToUsersPage(String platform) {
		try {
			
			if (platform.equalsIgnoreCase("desktop")) {
				getData(lnkUsersNavIcon);

				clickElement(lnkUsersNavIcon);
				sleepFor(10000);
				if (!DriverManager.getDriver().findElement(titleUsers).isDisplayed()) {
					throw new Exception("Not Navigated to Users Page");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElement(iconHamburger);
				sleepFor(5000);
				clickElement(lnkUsersNavIcon);
				sleepFor(5000);
				if (!DriverManager.getDriver().findElement(titleUsersMobile).isDisplayed()) {
					throw new Exception("Not Navigated to Users Page");
				}
			}

			ExtentLogger.pass("Navigated to Users Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Users Page. " + e.getMessage());
		}
		return new UsersPage();
	}

	public UsersPage navigateToClientsPage(String platform) {
		sleepFor(5000);
		try {
			sleepFor(5000);
			if (platform.equalsIgnoreCase("desktop")) {
				System.out.println(DriverManager.getDriver().findElement(lnkClientsNavIcon).getText() + " ***** ");
				clickElement(lnkClientsNavIcon);
				sleepFor(5000);
				System.out.println(DriverManager.getDriver().findElement(titleClients).getText());
				if (!DriverManager.getDriver().findElement(titleClients).isDisplayed()) {
					throw new Exception("Not Navigated to Clients Page");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElement(iconHamburger);
				sleepFor(5000);
				clickElement(lnkClientsNavIcon);
				sleepFor(5000);
				if (!DriverManager.getDriver().findElement(titleClientsMobile).isDisplayed()) {
					throw new Exception("Not Navigated to Clients Page");
				}
			}

			ExtentLogger.pass("Navigated to Clients Page");

		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Clients Page. " + e.getMessage());
		}
		return new UsersPage();
	}

	public QuotersPage navigateToQuotersPage(String platform) {

		try {
			clickElement(lnkQuotersNavIcon);
			sleepFor(10000);
			if (!DriverManager.getDriver().findElement(divQuotersPageIdentify).isDisplayed()) {
				throw new Exception("Quoters Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Quoters Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Quoters Page. " + e.getMessage());
		}
		return new QuotersPage();
	}

	public SettingsPage navigateToSettingsPage(String platform) {
		sleepFor(1000);
		try {

			if (platform.equalsIgnoreCase("desktop")) {
				clickElement(lnkSettingsNavIcon);
				sleepFor(1000);
				clickElement(lnkSettingsNavIcon);
				sleepFor(1000);
//				clickElement(lnkSettingsNavIcon);
				System.out.println(DriverManager.getDriver().getCurrentUrl());
				Thread.sleep(5000);

				if (!DriverManager.getDriver().findElement(titleSettings).isDisplayed()) {
					throw new Exception("Not Navigated to Settings Page");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElement(iconHamburger);
				clickElement(lnkSettingsNavIcon);
				if (!DriverManager.getDriver().findElement(titleUsersMobile).isDisplayed()) {
					throw new Exception("Not Navigated to Settings Page");
				}
			}
			sleepFor(2000);
			ExtentLogger.pass("Navigated to Settings Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Settings Page. " + e.getMessage());
		}

		return new SettingsPage();
	}

	//Changes done by vidya - added sleep time 2000
	public InvoicePage navigateToInvoicesPage(String platform) {

		try {
		//	clickElement(lnkUsersNavIcon);
			clickElementJS(lnkInvoicesNavIcon);
//			clickElement(lnkInvoicesNavIcon);
//			sleepFor(8000);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,titleInvoices);  //added akshay 5/01/2023
			if (!DriverManager.getDriver().findElement(titleInvoices).isDisplayed()) {
				throw new Exception("Invoices Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Invoices Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Invoices Page. " + e.getMessage());
		}
		return new InvoicePage();
	}

	public PromoCodesPage navigateToPromoCodesPage(String platform) {
		try {
			clickElement(lnkPromoCodesNavIcon);
			sleepFor(10000);
			if (!DriverManager.getDriver().findElement(titlePromoCodes).isDisplayed()) {
				throw new Exception("PromoCodes Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to PromoCodes Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to PromoCodes Page. " + e.getMessage());
		}
		return new PromoCodesPage();
	}

	public GiftCardsPage navigateToGiftCardsPage(String platform) {
		try {
		//	clickElement(lnkGiftCardsNavIcon);
			sleepFor(5000);
			clickElement(lnkGiftCardsNavIcon);
			sleepFor(5000);
			sleepFor(5000);
			if (!DriverManager.getDriver().findElement(titleGiftCards).isDisplayed()) {
				throw new Exception("Gift Cards Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Gift Cards Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Gift Cards Page. " + e.getMessage());
		}
		return new GiftCardsPage();
	}
 // changes done by vidya on 03.30.2022 //
	
	public ProofsPage navigateToProofsPage(String platform) {
		try {
			//clickElement(lnkProofsNavIcon);
			
			DriverManager.getDriver().navigate().to("http://localhost:4200/dashboard/proofs");
			
			sleepFor(5000);
			if (!DriverManager.getDriver().findElement(titleProofs).isDisplayed()) {
				throw new Exception("Proofs Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Proofs Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Proofs Page. " + e.getMessage());
		}
		return new ProofsPage();
	}

	public OrdersPage navigateToOrdersPage(String platform) {
		try {
			//clickElement(lnkOrdersNavIcon);
			
			
			DriverManager.getDriver().navigate().to("http://localhost:4200/dashboard/orders");

			sleepFor(5000);
			if (!DriverManager.getDriver().findElement(titleOrders).isDisplayed()) {
				throw new Exception("Orders Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Orders Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Orders Page. " + e.getMessage());
		}
		return new OrdersPage();
	}
	
	
	public OrdersPageNew navigateTocreateOrder(String platform) {
		try {
			clickElement(lnkCreateOrdersNavIcon);
			sleepFor(5000);
			if (!DriverManager.getDriver().findElement(titleCreateOrders).isDisplayed()) {
				throw new Exception("Orders creation Title Not Found.");
			}
			ExtentLogger.pass("Navigated to  create Orders Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to create Orders Page. " + e.getMessage());
		}
		return new OrdersPageNew();
	}

	
	
	
	
	

	public InventoryPage navigateToInventoryPage(String platform) {
		try {
			clickElement(lnkInventoryNavIcon);
			sleepFor(10000);
			if (!DriverManager.getDriver().findElement(titleInventory).isDisplayed()) {
				throw new Exception("Inventory Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Inventory Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Inventory Page. " + e.getMessage());
		}
		return new InventoryPage();
	}

	public LoginPage logOut() {
		try {

			System.out.println(DriverManager.getDriver().findElement(profileIconNew).getText());
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(profileIconNew));
			sleepFor(3000);
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(lnkLogoutMenu));

			ExtentLogger.pass("Logged Out of the Application");
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return new LoginPage();
	}

	public LoginPage logout() {
		try {
			navigateToLogin();
			ExtentLogger.pass("Logged Out of the Application");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new LoginPage();
	}

	public void navigateToLogin() throws Exception {
		DriverManager.getDriver().get(ApplicationPropertyUtils.get(ConfigProperties.APPURL));
	}

	public String getStringValue(UserType userType) {
		String userString = "";
		if (userType.equals(UserType.ADMIN)) {
			userString = "Admin";
		} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
			userString = "Campus Manager";
		} else if (userType.equals(UserType.CLIENT)) {
			userString = "Client";
		} else if (userType.equals(UserType.PRINTER)) {
			userString = "Printer";
		} else if (userType.equals(UserType.FULFILLMENT_CENTER)) {
			userString = "Fulfillment Center";
		}
		return userString;
	}

	public String getStringValue(UserTabs userTab) {
		String userString = "";
		if (userTab.equals(UserTabs.ADMIN)) {
			userString = "Admin";
		} else if (userTab.equals(UserTabs.CAMPUS_MANAGER)) {
			userString = "Campus Manager";
		} else if (userTab.equals(UserTabs.CLIENT)) {
			userString = "Client";
		} else if (userTab.equals(UserTabs.PRINTER)) {
			userString = "Printer";
		} else if (userTab.equals(UserTabs.FULFILLMENT_CENTER)) {
			userString = "Fulfillment Center";
		} else if (userTab.equals(UserTabs.ALL_ACTIVE)) {
			userString = "All Active";
	//	} else if (userTab.equals(UserTabs.INACTIVE)) {
		} else if (userTab.equals(UserTabs.Inactive)) {
			userString = "Inactive";
		}
		return userString;
	}

	public void moveToFirstPage() throws Exception {
		scrollToBottom();
		clickElementJS(By.xpath("//i[@class='datatable-icon-prev']"));
	}

	

	public String getTheSubString(String value) {
		
		String [] fragments = value.split(" ");
		String date = fragments[0].substring(0, 3);
		for(int i=1; i<fragments.length; i++) {
			date += " "+fragments[i];
			
		}
		return date;
	}
	
	public InvoicePage navigateToInvoicesPages(String platform) {

		try {
		
			clickElement(lnkInvoicesNavIcon);
			sleepFor(8000);
			
			ExtentLogger.pass("Navigated to Invoices Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Invoices Page. " + e.getMessage());
		}
		return new InvoicePage();
	}

		
	
	// Added By Akshay 09 Nov, 2022
	
	public StockCheckerPage navigateToStockCheckerPage(String platform) {

		try {
			clickElement(lnkStockCheckerNavIcon);
			sleepFor(2000);
			
			if (!DriverManager.getDriver().findElement(titleStockChecker).isDisplayed()) {
				throw new Exception("StockChecker Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to StockChecker Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to StockChecker Page. " + e.getMessage());
		}
		return new StockCheckerPage();
		}                              

}
    