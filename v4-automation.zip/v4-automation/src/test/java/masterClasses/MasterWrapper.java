package masterClasses;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.google.common.util.concurrent.Uninterruptibles;

import drivers.Driver;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import pages.LoginPage;
import utilities.DBSetupUtils;
import utilities.RunTimePropertyFileUtils;

public class MasterWrapper {

	protected LoginPage loginPage;
	protected SoftAssert softAssert;
	protected static ThreadLocal<String> testThread = new ThreadLocal<>();

	public String getTestCaseName() {
		return testThread.get();
	}

	public void setTestCaseName(String testcasename) {
		testThread.set(testcasename);
	}

	@BeforeSuite
	protected void suiteSetup() {
		try {
			DBSetupUtils.setupUserDatabase();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	@AfterSuite
	protected void suiteEnd() {
		try {
		  Driver.quitDriver();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Parameters("platform")
	@BeforeMethod
	protected void methodSetup(Method method, @Optional("desktop") String platform) throws InterruptedException {
		Driver.initDriver(platform);
		loginPage = new LoginPage();
		setTestCaseName(method.getName());
		System.out.println("Executing in " + System.getProperty("env") + " Environment and "
				+ System.getProperty("platform") + " Platform");
		RunTimePropertyFileUtils.createRunTimePropFile(getTestCaseName());
	}

	@AfterMethod
	protected void methodTearDown() {
		Driver.quitDriver();
		try {
			//RunTimePropertyFileUtils.deleteRuntimePropFile(getTestCaseName());
			System.out.println("Please uncomment the delete runtime *************************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterData(By elementLocator, String data) throws Exception {
		try {
 			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, elementLocator);
			clearData(elementLocator);
			DriverManager.getDriver().findElement(elementLocator).sendKeys(data);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to Enter Data in: " + elementLocator + ". " + e.getMessage());
		}
	}

	public void clearData(By elementLocator) throws Exception {
		try {
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, elementLocator);

			DriverManager.getDriver().findElement(elementLocator).clear();
			
			DriverManager.getDriver().findElement(elementLocator).sendKeys("");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to Clear Data in the locator" + elementLocator + ". " + e.getMessage());
		}
	}

	public String getData(By elementLocator) throws Exception {
		String data = null;
		try {
			findElementPresence(elementLocator);
			data = DriverManager.getDriver().findElement(elementLocator).getText().trim();
			System.out.println(data);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to Get Data from the Locator: " + elementLocator + ". " + e.getMessage());
		}
		return data;
	}

	public Boolean clickElement(By elementLocator) throws Exception {
		Boolean Flag = null;
		Flag = DriverManager.getDriver().findElement(elementLocator).isDisplayed();

		try {
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.CLICKABLE, elementLocator);
			DriverManager.getDriver().findElement(elementLocator).click();
			

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to click: " + elementLocator + ". " + e.getMessage());
		}
		return Flag;
	}

	public void clickTab(By elementLocator) throws Exception {
		try {
			DriverManager.getDriver().findElement(elementLocator).sendKeys(Keys.TAB);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to click Tab on: " + elementLocator + ". " + e.getMessage());
		}
	}

	public void clickHomeKey(By elementLocator) throws Exception {
		try {
			DriverManager.getDriver().findElement(elementLocator).sendKeys(Keys.HOME);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to click Home Key. " + e.getMessage());
		}
	}

	public boolean findElementPresence(By elementLocator) throws Exception {
		int size = 0;
		try {
			size = DriverManager.getDriver().findElements(elementLocator).size();

			//System.out.println("size in findelementpresence = "+size);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Unable to Find Element with Locator: " + elementLocator + ". " + e.getMessage());
		}
		return size > 0 ? true : false;
	}

	public boolean checkCondition(By elementLocator, ElementCheckStrategy checkCondition) throws Exception {
		try {
			if (checkCondition.equals(ElementCheckStrategy.DISPLAYED)) {
				return DriverManager.getDriver().findElement(elementLocator).isDisplayed();
			} else if (checkCondition.equals(ElementCheckStrategy.ENABLED)) {
				return DriverManager.getDriver().findElement(elementLocator).isEnabled();
			} else if (checkCondition.equals(ElementCheckStrategy.SELECTED)) {
				return DriverManager.getDriver().findElement(elementLocator).isSelected();
			} else {
				return false;
			}
		} catch (NoSuchElementException e) {
			return false;
		} catch (Exception e) {
			throw new Exception(
					"Unable to Verify " + elementLocator + " " + checkCondition.toString() + ". " + e.getMessage());
		}
	}

	public void sleepFor(long milliSec) {
		Uninterruptibles.sleepUninterruptibly(milliSec, TimeUnit.MILLISECONDS);
	}

	public void hoverOver(By elementLocator) {
		try {
			Actions action = new Actions(DriverManager.getDriver());
			action.moveToElement(DriverManager.getDriver().findElement(elementLocator)).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void hoverOverWithEnteringData(By elementLocator) {
		try {
			Actions action = new Actions(DriverManager.getDriver());
			action.moveToElement(DriverManager.getDriver().findElement(elementLocator));
			action.click().build().perform();
			action.sendKeys(Keys.chord(Keys.CONTROL, "a"));
			action.sendKeys(Keys.DELETE);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	

	public void scrollToElement(By locator) {
		WebElement element = DriverManager.getDriver().findElement(locator);
		((JavascriptExecutor) DriverManager.getDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public Boolean clickElementJS(By locator) throws Exception {
		Boolean flag = true;
		try {
			
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
			js.executeScript("arguments[0].click()", DriverManager.getDriver().findElement(locator));
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			throw new Exception("Unable to Click " + locator.toString());
		}
		return flag;
	}
	
	

	public void scrollToTop() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
	}

	public void scrollToBottom() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	}

	public void executeJS(String command, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript(command, element);
	}

	public void executeJS(String command) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript(command);
	}

	public void enterDataJs(By locator, String data) {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].value=" + data + ";", DriverManager.getDriver().findElement(locator));
	}

	public String readDataUsingJavascriptExecutor(String jsLocator) {
		String elementText = "";
		try {
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
			elementText = (String) js.executeScript("return document.querySelector('" + jsLocator + "').value");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(jsLocator + " is not a valid JS Locator");
		}

		return elementText;
	}

	public String readDataUsingJavascriptExecutorFromCSSLocator(String jsLocator) throws Exception {
		String elementText = "";
		try {
			scrollToElement(By.cssSelector(jsLocator));
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();

			elementText = (String) js.executeScript("return document.querySelector(\"" + jsLocator + "\").value");

			if (Objects.isNull(elementText) || elementText == "" || elementText.equalsIgnoreCase("")) {
				throw new Exception("No Data Found in the element with Locator: " + jsLocator);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return elementText;
	}

	public void setDataUsingJavascriptExecutor(String jsLocator, String data) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();

			js.executeScript("document.querySelector('" + jsLocator + "').click;");
			js.executeScript("document.querySelector('" + jsLocator + "').value=" + data + ";");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getAttributeValue(By locator, String attribute) {
		return DriverManager.getDriver().findElement(locator).getAttribute(attribute);
	}

	public void switchToFrame(String frameName) throws Exception {
		try {
			if (frameName.equalsIgnoreCase("parent")) {
				DriverManager.getDriver().switchTo().parentFrame();
			} else {
				DriverManager.getDriver().switchTo().frame(frameName);
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void openYopMail() {
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(DriverManager.getDriver().getWindowHandles());
		DriverManager.getDriver().switchTo().window(tabs.get(1));
		DriverManager.getDriver().get("https://yopmail.com/en/");
	}

	public void chooseAndUploadFile(String location) throws Exception {
		Robot rb = new Robot();
		StringSelection str = new StringSelection(location);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);

		if (System.getProperty("os.name").toLowerCase().contains("mac")) {
			rb.keyPress(KeyEvent.VK_META);
			rb.keyPress(KeyEvent.VK_V);

			rb.keyRelease(KeyEvent.VK_META);
			rb.keyRelease(KeyEvent.VK_V);

			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} else {
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);

			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);

			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		}

	}
}
