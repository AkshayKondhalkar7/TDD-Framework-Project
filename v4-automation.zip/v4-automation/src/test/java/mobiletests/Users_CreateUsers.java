package mobiletests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Users_CreateUsers extends MasterWrapper{
	
	@Test(enabled = true)
	public void AdminLogin_CreateAdminUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE)
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.ADMIN, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.verifyCardDetails(UserType.ADMIN)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateClientUserWithSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateClientUserWithoutSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("Business", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateCampusManagerUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.CAMPUS_MANAGER)
			.enterContactDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CAMPUS_MANAGER, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CAMPUS_MANAGER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.VIEW)
			.verifyCardDetails(UserType.CAMPUS_MANAGER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreatePrinterUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.PRINTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Mobile")
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.PRINTER, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.PRINTER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.PRINTER, UserOperation.VIEW)
			.verifyCardDetails(UserType.PRINTER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateFulfillmentCenterUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Mobile")
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.FULFILLMENT_CENTER, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.FULFILLMENT_CENTER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.FULFILLMENT_CENTER, UserOperation.VIEW)
			.verifyCardDetails(UserType.FULFILLMENT_CENTER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void CampusManagerLogin_CreateClientUserWithSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.clickAddUsersButton("Mobile")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void CampusManagerLogin_CreateClientUserWithoutSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.clickAddUsersButton("Mobile")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("Business", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateAdminUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE) 
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateClientUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateCampusManagerUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.CAMPUS_MANAGER)
			.enterContactDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
		
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreatePrinterUser_ExistingEmail() {
		 
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.PRINTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Mobile")
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateFulfillmentUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Mobile")
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test(enabled = true)
	public void CampusManagerLogin_CreateClientUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.clickAddUsersButton("Mobile")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test(enabled = true)
	public void AdminLogin_CreateUsers_FieldValidations() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.verifyFieldValidations(UserType.ADMIN, "Mobile")
			.verifyFieldValidations(UserType.CLIENT, "Mobile")
			.verifyFieldValidations(UserType.CAMPUS_MANAGER, "Mobile")
			.verifyFieldValidations(UserType.PRINTER, "Mobile")
			.verifyFieldValidations(UserType.FULFILLMENT_CENTER, "Mobile")
			.logout();
		
	}
	
	@Test(enabled = true)
	public void CampusManagerLogin_CreateUsers_FieldValidations() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.verifyFieldValidations(UserType.CLIENT, "Mobile")
			.logout();
		
	}
	

}
