package mobiletests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import org.testng.annotations.Test;

import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Users_DataFilterOperations extends MasterWrapper{
	
	@Test(enabled = true)
	public void AdminLogin_Users_SearchRecords_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.searchFullNameAndVerifyCard()
			.searchSchoolAndVerifyCard()
			.searchOrgAndVerifyCard()
			.searchCompanyAndVerifyCard()
			.logOut();
	}
	
	@Test(enabled = true)
	public void AdminLogin_Users_FilterRecords_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.verifyAvailableFilters()
			.filterOrgAndVerifyCard()
			.filterSchoolAndVerifyCard()
			.filterCompanyAndVerifyCard()
			.filterCampusManagerAndVerifyCard()
			.logOut();
	}
	
	@Test(enabled = true)
	public void ManagerLogin_Users_SearchRecords_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.searchFullNameAndVerifyCard()
			.searchSchoolAndVerifyCard()
			.searchOrgAndVerifyCard()
			.searchCompanyAndVerifyCard()
			.logOut();
	}
	
	@Test(enabled = true)
	public void ManagerLogin_Users_FilterRecords_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Mobile")
			.verifyAvailableFilters()
			.filterCompanyAndVerifyCard()
			.filterSchoolAndVerifyCard()			
			.filterOrgAndVerifyCard()
			.logOut();
	}
}
