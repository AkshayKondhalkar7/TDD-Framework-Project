package mobiletests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Users_DeActiveAndReActivateUsers extends MasterWrapper{
	
	@Test(enabled = true)
	public void AdminLogin_DeActivateAdminUser_VerifyLogin_ReActivateAdminUser_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Mobile")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Mobile")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_DeActivateClientUser_VerifyLogin_ReActivateClientUser_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Mobile")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Mobile")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_DeActivatePrinterUser_VerifyLogin_ReActivatePrinterUser_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Mobile")
			.clickAndSelectOption(UserType.PRINTER, UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Mobile")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Mobile")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Mobile")
			.clickAndSelectOption(UserType.PRINTER, UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_DeActivateFulfillmentCenterUser_VerifyLogin_ReActivateFulfillmentCenterUser_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Mobile")
			.clickAndSelectOption(UserType.FULFILLMENT_CENTER, UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Mobile")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Mobile")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Mobile")
			.clickAndSelectOption(UserType.FULFILLMENT_CENTER, UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_DeActivateCampusManagerUser_VerifyLogin_ReActivateCampusManagerUser_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Mobile")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Mobile")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Mobile")
			.logout();
	}

}
