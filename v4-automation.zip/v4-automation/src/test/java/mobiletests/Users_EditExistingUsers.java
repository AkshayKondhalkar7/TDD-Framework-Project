package mobiletests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Users_EditExistingUsers extends MasterWrapper{

	@Test(enabled = true)
	public void AdminLogin_EditExistingAdminUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.UPDATE)
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
			.verifyCardDetails(UserType.ADMIN)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_EditExistingClientUserWithSchool_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.UPDATE)
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_EditExistingCampusManagerUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.UPDATE)
			.editAccountSummary(UserType.CAMPUS_MANAGER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
			.verifyCardDetails(UserType.CAMPUS_MANAGER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_EditExistingPrinterUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Mobile")
			.clickAndSelectOption(UserType.PRINTER, UserOperation.UPDATE)
			.editAccountSummary(UserType.PRINTER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
			.verifyCardDetails(UserType.PRINTER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_EditExistingFulfillmentCenterUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Mobile")
			.clickAndSelectOption(UserType.FULFILLMENT_CENTER, UserOperation.UPDATE)
			.editAccountSummary(UserType.FULFILLMENT_CENTER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
			.verifyCardDetails(UserType.FULFILLMENT_CENTER)
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void ManagerLogin_EditExistingClientUserWithSchool_VerifyDashboard() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
				.navigateToClientsPage("Mobile")
				.filterUser(UserType.CLIENT, "Mobile")
				.clickAndSelectOption(UserType.CLIENT, UserOperation.UPDATE)
				.editAccountSummary(UserType.CLIENT)
				.navigateToUsersDashboard(UserOperation.UPDATE, "Mobile")
				.clickAndSelectOption(UserType.ADMIN, UserOperation.VIEW)
				.verifyCardDetails(UserType.CLIENT)
				.logOut()
				.loginToVerify("Mobile")
				.logout();
	}
}
