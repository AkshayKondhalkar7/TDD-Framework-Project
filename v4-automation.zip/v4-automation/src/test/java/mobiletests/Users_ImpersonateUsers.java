package mobiletests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Users_ImpersonateUsers extends MasterWrapper{
	
	@Test(enabled = true)
	public void AdminLogin_ImpersonateAdmin_CreateAdminUser_VerifyDashboard_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Mobile")
			.clickAndSelectOption(UserType.ADMIN, UserOperation.IMPERSONATE)
			.navigateToUsersPage("Mobile")
			.clickAddUsersButton("Mobile")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE)
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.ADMIN, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.ADMIN)
			.stopImpersonationAndVerifyLandingPage(UserType.ADMIN, "Mobile")
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_ImpersonateCampusManager_CreateClientUserWithSchool_VerifyDashboard_VerifyLogin() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.IMPERSONATE)
			.navigateToClientsPage("Mobile")
			.clickAddUsersButton("Mobile")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Mobile")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Mobile")
			.filterUserInDashboard(UserOperation.CREATE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.verifyCardDetails(UserType.CLIENT)
			.stopImpersonationAndVerifyLandingPage(UserType.CLIENT, "Mobile")
			.logOut()
			.loginToVerify("Mobile")
			.logout();
	}
	
	@Test(enabled = true)
	public void AdminLogin_ImpersonateManager_DeleteExistingClientUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Mobile")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Mobile")
			.clickAndSelectOption(UserType.CAMPUS_MANAGER, UserOperation.IMPERSONATE)
			.navigateToClientsPage("Mobile")
			.filterUser(UserType.CLIENT, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.DELETE)
			.enterConfirmation(UserOperation.DELETE, "Mobile")
			.verifySuccessMessage(UserOperation.DELETE)
			.filterUserInDashboard(UserOperation.DELETE, "Mobile")
			.stopImpersonationAndVerifyLandingPage(UserType.CLIENT, "Mobile")
			.filterUserInDashboard(UserOperation.DELETE, "Mobile")
			.clickAndSelectOption(UserType.CLIENT, UserOperation.VIEW)
			.logOut();
	}

}
