package pageElements;

import org.openqa.selenium.By;

public interface GiftCardPageElements {

	By btnCreateGiftCards = By.xpath("//span[contains(text(),'Create Gift Card')]//preceding-sibling::img");
//	By divCreateGiftCards = By.xpath("//label[contains(text(),'Create Gift Card')]");
	By divCreateGiftCards = By.xpath("//label[contains(text(),'Create Group Order Gift Card')]");
	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	By txtSearchGiftCard = By.xpath("//input[contains(@class,'search__input')]");
	By btnDisableGiftCard = By.xpath("//span[contains(text(),'Disable')]//preceding-sibling::img");
	By iconClearFilter = By.xpath("(//div[contains(@class,'search__close-icon')]/i)[1]");
	String tabTitleRecordsCount = "(//div[contains(@class,'tabs') and contains(text(),'%s')]//following::span)[1]";
	
	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";
	
	String txtFilterOption = "(//a[contains(text(),'%s')]//following::input[@role='combobox'])[1]";
	String drpdwnFilteredOption = "//span[contains(text(),'%s')]";
	
	String txtFilterTextBoxes = "(//a[contains(text(),'%s')]//following::input)[1]";
	String btnApply = "(//a[contains(text(),'%s')]//following::span[contains(text(),'Apply')])[1]";
	
	String radioFilterType = "//a[contains(text(),'%s')]//following::label[contains(text(),'%s')]";
	String txtDateFilter = "//label[contains(text(),'%s')]//following::input[@ng-reflect-name='dateSelect']";

	By txtGiftCard = By.xpath("//app-input//input[@placeholder='e.g. UCLA20384']");
	By txtDollerValue = By.xpath("(//app-input[@ng-reflect-name='cardValue']//input)[1]");
	By txtExpiryDate = By.xpath("(//app-datepicker[@ng-reflect-name='expiryDate']//input)[1]");

	By drpDwnClientName = By.xpath("//app-select[@ng-reflect-name='clientName']//ng-select");
	By txtClientName = By.xpath("//app-select[@ng-reflect-name='clientName']//ng-select//input");
//	String optionClientName = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";
//	String optionClientName = "//Span[contains(@class,'ng-option-label ng-star-inserted') and contains(text(),'%s')]";
	String optionClientName = "//div[contains(text(),'%s')]";
	

	By btnCreateClient = By.xpath("//span[text()='Create']//parent::button");

	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[2]");
//	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By btnSetPassword = By.xpath("//span[contains(text(),'Set Password')]");
	By btnSetEmailAndPassword = By.xpath("//span[contains(text(),'Set Email & Password')]");
	By txtCompany = By.xpath("(//input[@ng-reflect-name='company'])[1]");
	By btnAddInfo = By.xpath("//span[contains(text(),'Add Info')]");
	By btnUpdateAccount = By.xpath("//span[contains(text(),'Update Account')]");
	By btnAddContactInfo = By.xpath("//span[contains(text(),'Add Contact Info')]");
	String txtgraduationYear = "//div[contains(text(),'%s')]";

	By txtPassword = By.xpath("//input[@placeholder='Enter password']");
	By txtConfirmPassword = By.xpath("//input[@placeholder='Confirm password']");
	By btnCreateAccount = By.xpath("(//span[contains(text(),'Create Account')])[1]");
	By btnBackToWork = By.xpath("//span[contains(text(),'Back to Work')]");
	By btnDownloadInvoicePDF = By.xpath("//button[contains(@class,'download-invoice-item')]");

	By drpDwnSchool = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValue = "//span[contains(text(),'%s')]";

	By drpDwnOrganization = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValue = "//span[contains(text(),'%s')]";

//	By btnCreateGiftCard = By.xpath("//span[contains(text(),'Create Gift Card')]//parent::button");
	By btnCreateGiftCard = By.xpath("//span[contains(text(),'Create Group Order Gift Card')]//parent::button");
	
	By btnPosition = By.xpath("//input[@ng-reflect-name='position']"); /* added by vidya*/
	
	By btnCancelClient= By.xpath("(//div[contains(@class,'overlay-close')])[2]");
	By selectYes = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");

}
