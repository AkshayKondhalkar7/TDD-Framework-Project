package pageElements;

import org.openqa.selenium.By;

public interface InventoryPageElements extends MasterPageElements {

	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	By txtSearchInventoryItem = By.xpath("//input[contains(@class,'search__input')]");
	By divNextTab = By.xpath(
			"//div[contains(@class,'pill tabs__tab--active')]//following::div[contains(@class,'tabs__tab cursor-pointer')][1]");
	By divCurrentTab = By.xpath("//div[contains(@class,'pill tabs__tab--active')]");
	By btnAddIncomingStock = By.xpath("//img[contains(@src,'add-incoming-stock')]//parent::div");
	By labelAddIncomingStock = By.xpath("//label[contains(text(),'Add Incoming Stock')]");

	By btnEditIncomingStocks = By.xpath("//img[contains(@src,'edit-incoming-stock')]//parent::div");
	By labelEditStock = By.xpath("//label[contains(text(),'Editing Stock')]");
	By btnDeleteStock = By.xpath("//img[@class='incoming-stock__delete-icon']");
	By btnDeleteConfirm = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	By btnCloseEditStock = By.xpath("//div[@class='overlay-close']");

	String txtSQty = "(//input[@ng-reflect-name='sQuantity'])[%s]";
	String txtMQty = "(//input[@ng-reflect-name='mQuantity'])[%s]";
	String txtLQty = "(//input[@ng-reflect-name='lQuantity'])[%s]";
	
	String txtXLQty = "(//input[@ng-reflect-name='xlQuantity'])[%s]";
	String txt2XLQty = "(//input[@ng-reflect-name='2xlQuantity'])[%s]";
	String txtStockDate = "(//input[@ng-reflect-name='dateSelect'])[%s]";
	//String txtStockDate = "//input[@class='form-control ng-pristine ng-valid ng-touched']";
    //By datebutton =By.xpath("//div[@class='form-group w-100 dropdown-date-picker calender position-relative']");
	
	
	By btnAddStocks = By.xpath("//span[contains(text(),'Add')]//parent::button");
	By btnUpdateStocks = By.xpath("//span[contains(text(),'Update Changes')]//parent::button");

	String iconExpandArrow = "(//datatable-body-row//following::img[contains(@src,'dropdown_arrow')])[%s]";

	String divSQtyFromTable = "(//div[contains(@class,'incoming-stock__s')])[%s]";
	String divMQtyFromTable = "(//div[contains(@class,'incoming-stock__m')])[%s]";
	String divLQtyFromTable = "(//div[contains(@class,'incoming-stock__l')])[%s]";
	String divXLQtyFromTable = "(//div[contains(@class,'incoming-stock__xl')])[%s]";
	String div2XLQtyFromTable = "(//div[contains(@class,'incoming-stock__2xl')])[%s]";
	String divDateFromTable = "(//div[contains(@class,'incoming-stock__restock-date')])[%s]";
	By restockdate = By.xpath("(//div[@class='data-table__cell'])[5]");
//	By restockdate = By.xpath("(//div[@class='data-table__cell'])[6]");

	By selectButton = By.xpath("(//div[@class='position-absolute checkbox-wrapper'])[%s]");
//	By selectButton = By.xpath("(//div[@class='position-absolute checkbox-wrapper'])[1]");
	
	String txtIncomeSQty = "(//input[@ng-reflect-name='ssQuantity'])[%s]";
	String txtIncomeMQty = "(//input[@ng-reflect-name='msQuantity'])[%s]";
	String txtIncomeLQty = "(//input[@ng-reflect-name='lsQuantity'])[%s]";
	
	String txtIncomeXLQty = "(//input[@ng-reflect-name='xlsQuantity'])[%s]";
	String txtIncome2XLQty = "(//input[@ng-reflect-name='2xlsQuantity'])[%s]";
	String txtIncomeStockDate = "(//input[@ng-reflect-name='dateSelect'])[%s]";
	
	By singleColor = By.xpath("//*[@id='data-cell-color0']");
	By secColor = By.xpath("//*[@id='data-cell-color1']");
	By lastColor = By.xpath("//*[@id='data-cell-color2']");
	
	
	
	
}
