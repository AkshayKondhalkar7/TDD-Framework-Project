package pageElements;

import org.openqa.selenium.By;

public interface InvoicePageElements extends MasterPageElements {

	By titleInvoices = By.xpath("//label[contains(@class,'main__title') and text()='Invoices']");
	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	By txtSearchInvoice = By.xpath("//input[contains(@class,'search__input')]");

	By iconCreateInvoice = By.xpath("//span[contains(text(),'Create Invoice')]//preceding-sibling::img");
	By divCreateInvoices = By.xpath("//label[contains(text(),'Create Invoice')]");

	By drpDwnClientName = By.xpath("//app-select[@ng-reflect-name='clientName']//ng-select");
	By txtClientName = By.xpath("//app-select[@ng-reflect-name='clientName']//ng-select//input");
//	String optionClientName = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";
//	String optionClientName = "//Span[contains(@class,'ng-option-label ng-star-inserted') and contains(text(),'%s')]";
	String optionClientName = "//div[contains(text(),'%s')]";

	By drpDwnManagerName = By.xpath("//app-select[@ng-reflect-name='clientManager']//ng-select");
	By txtManagerName = By.xpath("//app-select[@ng-reflect-name='clientManager']//ng-select//input");
	String optionManagerName = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By btnCreateClient = By.xpath("//span[text()='Create']//parent::button");
	By txtClientEmail = By.name("");
	By lnkCustomerPO = By.xpath("//span[contains(text(),'Customer PO')]");

	By txtPaymentAmount = By.xpath("//app-input[@ng-reflect-name='dueAmountControl']//input");
	By txtCardNumber = By.xpath("//app-input[@ng-reflect-name='cardNumberControl']//input");
	By txtExpiryMonth = By.xpath("//app-input[@ng-reflect-name='expiryMonthControl']//input");
	By txtExpiryYear = By.xpath("//app-input[@ng-reflect-name='expiryYearControl']//input");
	By txtCVV = By.xpath("//app-input[@ng-reflect-name='cvvControl']//input");
	By txtZipcode = By.xpath("//app-input[@ng-reflect-name='zipCodeControl']//input");

	By txtPayerEmail = By.xpath("//input[@ng-reflect-name='email']");
//	By txtPayerEmail = By.xpath("(//input[@ng-reflect-name='email'])[2]");
//	String paymentOption = "(//a[contains(text(),'%s')]//following::span[contains(text(),'%s')])[1]//preceding::img[1]";
	String paymentOption = "(//*[contains(text(),'%s')]//following::span[contains(text(),'%s')])[1]//preceding::img[1]";
//	String paymentOption = "(//*[contains(text(),'%s')])[1]";
	By txtPayerEmailVenmo = By.xpath("(//input[@ng-reflect-name='email'])[2]");
//	By txtPayerEmailVenmo = By.xpath("(//input[@ng-reflect-name='email'])");
	String paymentOptionVenmo = "(//*[contains(text(),'%s')])[1]";

	By txtDueDate = By.name("dateSelect");

	By txtPaymentDate = By.xpath("//app-datepicker[@ng-reflect-name='paymentDateControl']//input[@name='dateSelect']");
	By btn14Days = By.xpath("//button[contains(text(),'In 14 days')]");
	By btn18Days = By.xpath("//button[contains(text(),'In 18 days')]");
	By btnTomorrow = By.xpath("//button[contains(text(),'Tomorrow')]");

	By txtNote = By.xpath("//app-text-area[@formcontrolname='noteControl']//textarea");

	By btnAddInvoiceItem = By.xpath("//i[@ng-reflect-ng-class='ft-plus']");
	By btnEmailInvoice = By.xpath("//button[contains(@class,'email-invoice-item')]");

	String txtItemName = "(//input[@ng-reflect-name='itemName'])[<>]";
	String txtItemQty = "(//input[@ng-reflect-name='quantity'])[<>]";
	String txtItemUnitPrice = "(//input[@ng-reflect-name='price'])[<>]";
	String txtItemTotalCost = "(//input[@ng-reflect-name='total'])[<>]";

	By txtSubTotal = By.xpath("//input[@ng-reflect-name='subtotal']");
	By txtShipping = By.xpath("//input[@ng-reflect-name='shipping']");
	By txtSalesTax = By.xpath("//input[@ng-reflect-name='tax']");
	By divTotal = By.xpath("//div[@class='total-amount']");
	By lnkAddDiscount = By.xpath("//span[contains(text(),'Add Discount')]");
	By txtDiscount = By.xpath("//input[@ng-reflect-name='discount']");
	By txtComments = By.xpath("//textarea[@placeholder='Add Comments']");

	By btnApplyPayment = By.xpath("//span[contains(text(), 'Apply Payment')]");
	By btnMakePayment = By.xpath("//span[contains(text(), 'Make Payment')]");

	By btnCreateInvoice = By.xpath("//span[contains(text(),'Create Invoice')]//parent::button");
	By btnSaveEdits = By.xpath("//span[contains(text(),'Save Edits')]//parent::button");
	By btnPostComments = By.xpath("//span[contains(text(),'Post Comments')]//parent::button");

//	String lnkInvoiceNumber = "//a[contains(text(),'%s')]";
	String lnkInvoiceNumber = "//*[contains(text(),'%s')]";
	By txtCustomerPO = By.xpath("//input[@ng-reflect-name='customerpo']");

	By txtEmailInPopUp = By.xpath("//app-input[@ng-reflect-name='recipientEmail']//input");
	By txtSubjectInPopUp = By.xpath("//app-input[@ng-reflect-name='subject']//input");
	By txtMessageBodyInPopUp = By.xpath("//div[contains(@class,'angular-editor-textarea')]");
	By btnSendInPopUp = By.xpath("//button[contains(text(),'Send')]");

	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";

	By txtFilterClient = By.xpath("//a[contains(text(),'Client')]//following-sibling::ul//input");
	String optionFilterClient = "//span[contains(@class,'ng-option-label') and contains(text(),'')]";

	By txtFilterManager = By.xpath("//a[contains(text(),'Manager')]//following-sibling::ul//input");
	String optionFilterManager = "//span[contains(@class,'ng-option-label') and contains(text(),'')]";

	By txtFilterDueOn = By.xpath("//a[contains(text(),'Due On')]//following-sibling::ul//input");
	String optionFilterDueOn = "//span[contains(@class,'ng-option-label') and contains(text(),'')]";

	By txtFilterCreatedOn = By.xpath("//a[contains(text(),'Created On')]//following-sibling::ul//input");
	String optionFilterCreatedOn = "//span[contains(@class,'ng-option-label') and contains(text(),'')]";

	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[2]");
//	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By btnSetPassword = By.xpath("//span[contains(text(),'Set Password')]");
	By btnSetEmailAndPassword = By.xpath("//span[contains(text(),'Set Email & Password')]");
	By txtCompany = By.xpath("(//input[@ng-reflect-name='company'])[1]");
	By btnAddInfo = By.xpath("//span[contains(text(),'Add Info')]");
	By btnAddContactInfo = By.xpath("//span[contains(text(),'Add Contact Info')]");
	String txtgraduationYear = "//div[contains(text(),'%s')]";

	By txtPassword = By.xpath("//input[@placeholder='Enter password']");
	By txtConfirmPassword = By.xpath("//input[@placeholder='Confirm password']");
	By btnCreateAccount = By.xpath("(//span[contains(text(),'Create Account')])[1]");
	By btnBackToWork = By.xpath("//span[contains(text(),'Back to Work')]");
	By btnDownloadInvoicePDF = By.xpath("//button[contains(@class,'download-invoice-item')]");

	By drpDwnSchool = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValue = "//span[contains(text(),'%s')]";

	By drpDwnOrganization = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValue = "//span[contains(text(),'%s')]";
	By btnPosition = By.xpath("//input[@ng-reflect-name='position']"); /* added by vidya*/

	By txtPaymentAmountCard = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[1]");
	By txtZeroPaymentCard = By.xpath("//input[@placeholder='e.g. $100']");
	
	By btnCancelClient= By.xpath("(//div[contains(@class,'overlay-close')])[2]");
	By selectYes = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	
	By negativeTC = By.xpath("(//*[contains(text(),'No search results found.')])[1]");
	By btnPayment = By.xpath("//*[@ng-reflect-ng-class=\"venmo-option\"]");
	By btnseachclose = By.xpath("//i[@class='ft-x']");
	
	String btnRemoveInvoiceItem = "(//*[@ng-reflect-ng-class='active-trash'])[<>]";
	
	//Added by Akshay
	
	By Invoice_Admin = By.xpath("//a[contains(text(),'49317')]");
	String txtoverdueamt_admin = "//div[contains(@id,'data-table__due-amount49317')]";
	
	By Invoice_Manager = By.xpath("//a[contains(text(),'49315')]");
	String txtoverdueamt_manager = "//div[contains(@id,'data-table__due-amount49315')]";
	By invoice_text = By.xpath("//div[contains(text(),'Inv')]");
	By invoice_title = By.xpath("(//label[contains(text(),'Invoices')])[2]");
}
