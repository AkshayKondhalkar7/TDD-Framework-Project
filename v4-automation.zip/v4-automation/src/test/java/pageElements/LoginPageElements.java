package pageElements;

import org.openqa.selenium.By;

public interface LoginPageElements extends MasterPageElements{


	By emailTxtBox=By.xpath("(//input[@id='form-email'])[1]");
	By passwordTxtBox=By.xpath("//input[@id='form-password']");
	By loginBtn=By.xpath("//button[text()='Sign in']");
	
}