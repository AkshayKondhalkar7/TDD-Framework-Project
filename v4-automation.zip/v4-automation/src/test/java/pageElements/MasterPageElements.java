package pageElements;

import org.openqa.selenium.By;

public interface MasterPageElements {
	
	


	By iconHamburger = By.xpath("//a[@class='sidebar-mobile-main-toggle']//i");
	By lnkUsersNavIcon = By.xpath("//span[text()='Users']/parent::a");
	//By lnkUsersNavIcon = By.xpath("//img[@class='ng-tns-c131-1 nav-user-icon']");


//	By lnkClientsNavIcon = By.xpath("//span[text()='Clients']/parent::a");
	By lnkClientsNavIcon = By.xpath("//span[contains(text(),'Clients')]/parent::a");
	
	By errorLabel = By.xpath("//label[@class='validation-error-label']");
	By pageLoader = By.xpath("//body[contains(@class,'pace-running')]");

	By profileIconNew = By.id("dropdownBasic2");
	By profileIconMoreMobileOld = By.xpath("//i[contains(@class,'icon-tree5')]");

	By profileIconOld = By.xpath("//img[contains(@src,\"profile_picture\")]");
//	By profileIconOld = By.xpath("//img[contains(@src,'profile_picture')]");
	By profileNameNew = By.xpath("//span[@id='userdropdown-info']");
	By profileNameOld = By.xpath("//img[contains(@src,\"profile_picture\")]//following::span[1]");
//	By profileNameOld = By.xpath("(//span[@class='ng-binding'])[1]");
	By lnkLogoutMenu = By.xpath("//span[contains(text(),'Logout')]");
	By divImpersonateTitle = By.xpath("//div[contains(text(),'Impersonating')]");
	By btnStopImpersonate = By.xpath("//div[contains(text(),'Stop')]");

	By titleUsers = By.xpath("//label[contains(@class,'main__title') and text()='Users']");
	By titleUsersMobile = By.xpath("//label[contains(@class,'active-page-title') and text()='Users']");

	By titleClients = By.xpath("//label[contains(@class,'main__title') and text()='Clients']");
	By titleClientsMobile = By.xpath("//label[contains(@class,'active-page-title') and text()='Clients']");

	By lnkQuotersNavIcon = By.xpath("//span[text()='Quoter']/parent::a");
	By divQuotersPageIdentify = By.xpath("//div[contains(text(),'Total Price')]");

	By lnkInvoicesNavIcon = By.xpath("//span[contains(text(),'Invoice')]/parent::a");
	By titleInvoices = By.xpath("//label[contains(@class,'main__title') and text()='Invoices']");

	By lnkPromoCodesNavIcon = By.xpath("//span[text()='Promo Codes for Group Orders']/parent::a");
//	By titlePromoCodes = By.xpath("//label[contains(@class,'main__title') and text()='Promo Codes']");
	By titlePromoCodes = By.xpath("//label[contains(@class,'main__title center-inner-div') and text()='Group Order Promo Codes']");  /* added by vidya on 07.07.2022 */

	//By lnkGiftCardsNavIcon = By.xpath("//span[text()='Gift Cards']/parent::a");
	//By titleGiftCards = By.xpath("//label[contains(@class,'main__title') and text()='Gift Cards']");
	By titleGiftCards = By.xpath("//label[contains(@class,'main__title') and text()='Group Order Gift Cards']"); /* added by vidya on 01.07.2022 */
	By lnkGiftCardsNavIcon = By.xpath("//span[contains(text(),'Gift Cards')]/parent::a"); /* added by vidya on 24.03.2022 */

	//By lnkProofsNavIcon = By.xpath("//span[text()='Proofs']/parent::a");
	By titleProofs = By.xpath("//label[contains(@class,'main__title') and text()='Proofs']");
	By lnkProofsNavIcon = By.xpath("//span[contains(text(),'Proofs')]/parent::a"); /* added by vidya on 24.03.2022 */

	By lnkOrdersNavIcon = By.xpath("//span[contains(text(),'Orders')]//parent::a");
	By titleOrders = By.xpath("//label[contains(@class,'main__title') and text()='Orders']");
	
	
	By lnkCreateOrdersNavIcon = By.xpath("//div[@class='navbar__order' and i[@class='ft-plus fw-bold']]");
	
	
	By titleCreateOrders= By.xpath("//div[contains(text(),'Order')]");

	
	By lnkInventoryNavIcon = By.xpath("//span[contains(text(),'Inventory')]//parent::a");
	By titleInventory = By.xpath("//label[contains(@class,'main__title') and text()='Inventory']");
	
	//Added By kirty (Feb 18 ,2021)

//	By lnkSettingsNavIcon = By.xpath("//span[text()='Settings']/parent::a");
	By lnkSettingsNavIcon =By.xpath("//span[contains(text(),'Settings')]/parent::a"); // added by Vidya & Kirty on 04.28.202
	By titleSettings = By.xpath("//*[contains(@class,'settings__head') and text()='Account Details']");
	
	

	By divNoRecordsFound = By.xpath("//div[contains(text(),'No search results found.')]");

	String sortIcon = "//span[contains(text(),'%s') and contains(@class,'header')]//following::span[contains(@class,'sort-btn')][1]";
	By drpDwnRecordsCount = By.xpath("(//span[contains(text(),'Rows')]//following::ng-select)[1]");
	String recordsCountValue = "//span[@ng-reflect-ng-item-label='%s']";
	
	//Added By Akshay (9 Nov, 2022)
	
	By lnkStockCheckerNavIcon = By.xpath("//span[contains(text(),'Stock Checker')]/parent::a");
	By titleStockChecker = By.xpath("//div[contains(@class,\"stock-checker-header__name\") and text()='Stock Checker']");
}

   
