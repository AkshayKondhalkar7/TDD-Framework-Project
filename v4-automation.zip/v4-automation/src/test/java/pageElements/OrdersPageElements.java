package pageElements;

import org.openqa.selenium.By;


public interface OrdersPageElements extends MasterPageElements{
	
	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	String tabTitleRecordsCount = "(//div[contains(@class,'tabs') and contains(text(),'%s')]//following::span)[1]";
	
	By txtSearchOrder = By.xpath("//input[contains(@class,'search__input')]");
	
	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";
	
	String txtFilterOption = "(//a[contains(text(),'%s')]//following::input[@role='combobox'])[1]";
	String drpdwnFilteredOption = "//span[contains(text(),'%s')]";
	
	String radioFilterType = "//a[contains(text(),'%s')]//following::label[contains(text(),'%s')]";
	String txtFilterValue = "(//label[contains(text(),'%s')]//following::input)[1]";
	By btnApplyFilter = By.xpath("//span[text()='Apply']//parent::button");
	String txtDateFilter = "//label[contains(text(),'%s')]//following::input[@ng-reflect-name='dateSelect']";
	
	
	By txtRegularOrder = By.xpath("//*[contains(text(),'Regular Order')]");
	By txtGroupOrder = By.xpath("//*[contains(text(),'Group Order')]");
	By txtSampleOrder =By.xpath("//*[contains(text(),'Sample Order')]");
	
	
//	By txtOrderTitle = By.xpath("(//*[contains(@class,'position-relative')]/input)[1]");
	
//	By txtClient =By.xpath("//*[contains(text(),'Regular Order')]");
	
// added by Kirty
	
    By txtOrderTitle = By.xpath("(//*[contains(@class,'position-relative')]/input)[1]");
	
	By txtClient =By.xpath("//*[contains(text(),'Regular Order')]");
//	By btnCreateClient =By.xpath("//*[contains(text(),'Regular Order')]");
	By btnCreateOrder= By.xpath("//div[@class='navbar__order' and i[@class='ft-plus fw-bold']]");
	By btnSampleOrderLestsGo = By.xpath("//span[contains(text(),'Let')]");
	By btnFirstQuestionFreshPrints= By.xpath("//div[contains(text(),'Fresh Prints')]");
	By btnwhatyourorderName= By.xpath("//input[@id ='short_text-b9004a2e5de28070-6NzKOU8d2EE3tn1e']");
	By btnokbutton = By.xpath("//*[contains(text(),'OK')]");
	By btnwhatyourName= By.xpath("//input[@id ='long_text-0dd565bf5e9bf3dc-6NzKOU8d2EE3tn1e']");
	By btnwhatyourEmail= By.xpath("//*[@name ='email']");
	By btnwhatyourClientName= By.xpath("//*[@name ='name']");
	By btnwhatyourClientEmailBy = By.xpath("//input[@id ='short_text-50d48a2633ca6256-6NzKOU8d2EE3tn1e']");
	By btnPhoneNumberBy =By.xpath("//*[@name ='off']");
	By btnContinue = By.xpath("//span[contains(text(),'Continue')]");
	By btnApprelstyleCodeBy = By.id("dropdown-8d9d58a3-3176-490d-b3ca-0577cf2109b5-EgP2IuYxjSTuLvBZ");
	By txtApprealCodeStyletextBy = By.cssSelector(".InputField-sc-__sc-26uh88-0.lkwQAX");
	By btnAoprealColorOptions = By.cssSelector("#dropdown-b426f321-b353-4f85-8627-86e51cf2cf40-EgP2IuYxjSTuLvBZ-option-1");
	By btnYesBy =By.xpath("(//div[@class= 'Root-sc-__sc-1iyh3rv-0 cnUTTh'])[1])");
	By btnNoBy =By.xpath("(//div[@class= 'Root-sc-__sc-1iyh3rv-0 cnUTTh'])[2])");
	By btnsizeBy =By.id("dropdown-f00dc147-480f-4af9-b511-ed394c58a31f-lUEhdAwGMxg7wYQ7");
	By textShipadd =By.xpath("//input[@id='short_text-fd75fbceae85b97e-EgP2IuYxjSTuLvBZ']");
	
	
	By textStreetaddBy =By.xpath("//*[@class='TextAreaWrapper-sc-__sc-eos9ho-0 iJXLbR']");
	By textCity =By.xpath("(//*[@class='InputField-sc-__sc-26uh88-0 fCJjlu'])[1]");
	By textStateBy =By.xpath("(//*[@class='InputField-sc-__sc-26uh88-0 fCJjlu'])[1]");
	By textZipCodeBy =By.name("postal-code");
	By btnSubmitBy = By.xpath("//span[contains(text(),'Submit')]");
	By txtCompletionBy = By.xpath("//span[contains(text(),\"You're so hot. Keep doing you and locking down clients.\")]");

//	added by Vidya
	
	By divEnterOrderDetails = By.xpath("//div[contains(text(),'Enter Order Details')]");
	
	By btnOrder = By.xpath("//div[@class='navbar__order']");
	
	By drpDwnClientName = By.xpath("//app-select[@ng-reflect-name='client']//ng-select");
	By txtClientName = By.xpath("//app-select[@ng-reflect-name='client']//ng-select//input");
	String optionClientName = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";
	By btnCreateClient = By.xpath("//span[text()='Create']//parent::button");
	
	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By btnSetPassword = By.xpath("//span[contains(text(),'Set Password')]");
	By btnSetEmailAndPassword = By.xpath("//span[contains(text(),'Set Email & Password')]");
	By txtCompany = By.xpath("(//input[@ng-reflect-name='company'])[1]");
	By btnAddInfo = By.xpath("//span[contains(text(),'Add Info')]");
	By btnUpdateAccount = By.xpath("//span[contains(text(),'Update Account')]");
	By btnAddContactInfo = By.xpath("//span[contains(text(),'Add Contact Info')]");
	String txtgraduationYear = "//div[contains(text(),'%s')]";

	By txtPassword = By.xpath("//input[@placeholder='Enter password']");
	By txtConfirmPassword = By.xpath("//input[@placeholder='Confirm password']");
	By btnCreateAccount = By.xpath("(//span[contains(text(),'Create Account')])[1]");
	By btnBackToWork = By.xpath("//span[contains(text(),'Back to Work')]");

	By drpDwnSchoolClient = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValueClient = "//span[contains(text(),'%s')]";

	By drpDwnOrganizationClient = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValueClient = "//span[contains(text(),'%s')]";
	
	By btnPosition = By.xpath("//input[@ng-reflect-name='position']"); 
	By btnDetails = By.xpath("//div[@class='proof-details-expand d-flex align-items-center justify-content-center cursor-pointer']");
	
	By drpDwnCampaign = By.xpath("//app-select[@formcontrolname='campaign']//ng-select");
	By txtCampaign = By.xpath("//app-select[@ng-reflect-name='campaign']//ng-select//input");
	String optionCampaign = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";
	
//	By txtDueDate = By.name("dateSelect");
	By txtDueDate = By.xpath("//input[@ng-reflect-name='dateSelect']");
	
	By btnCancelClient= By.xpath("(//div[contains(@class,'overlay-close')])[2]");
	By selectYes = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	
	By btnAddProof= By.xpath("//span[contains(text(),'Add Proof')]");
	
	By txtSearchProof=By.xpath("//input[@class='proof-search__input cursor-pointer ng-untouched ng-pristine ng-valid']");
	By selectProof = By.xpath("//div[@class='proofs__proof-items__proof-item-card__image-section d-flex']");
//	By selectProof = By.xpath("(//div[@class='proofs']//child::div//child::div//child::div//child::img)[1]");
	By clkProof = By.xpath("(//div[@class='proofs__proof-items__proof-item-card w-100']//child::div//child::img)[1]");
	By selectImage= By.xpath("(//div[@class='primary-image-picker__images-container__image'])[1]");
	
	By drpDwnStyleCode = By.xpath("//app-select[@ng-reflect-name='styleCode']//ng-select");
	By txtStyleCode = By.xpath("//app-select[@ng-reflect-name='styleCode']//ng-select//input");
	String optionStyleCode = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

//	By drpDwnColor = By.xpath("//app-select[@ng-reflect-name='color']//ng-select");
	By drpDwnColor = By.xpath("(//div[@class='ng-input'])[2]");
//	By drpDwnColor = By.xpath("(//span[@class='ng-arrow-wrapper'])[2]");
//	By txtColor = By.xpath("//app-select[@ng-reflect-name='color']//ng-select//input");
	By txtColor = By.xpath("(//input[@type='text'])[2]");
	By optionColor = By.xpath("(//div[contains(@class,'option__label')])[1]");
//	By optionColor = By.xpath("(//ng-dropdown-panel//child::div//child::div//following::div//child::div)[1]");
//	By optionColor = By.xpath("(//div[@class='custom-option__label ng-star-inserted'])[1]");
	
	
	By selectPrimaryImage=By.xpath("//div[@class='primary-image-picker__images-container__image selected-image']");
	By selectNextPrimaryImage = By.xpath("//div[@class='primary-image-picker__images-container__image']");
	
	By drpdwnCollegiateMark = By.xpath("//app-select[@ng-reflect-name='selectedSchoolC']/ng-select");
	By txtCollegiateMark = By.xpath("//app-select[@ng-reflect-name='selectedSchoolC']/ng-select//input");
	String optionCollegiateMark = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	By drpdwnOrganization = By.xpath("//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select");
	By txtOrganization = By.xpath("//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select//input");
	String optionOrganization = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	By txtComments = By.xpath("//textarea[@class='form-control ng-star-inserted']");
	
	By btnAddQtyandPrice= By.xpath("//span[contains(text(),'Add Quantity & Price')]");
	
//	By txtSQty = By.xpath("//input[@class='form-control ng-pristine ng-valid ng-star-inserted ng-touched']");
//	By txtMQty = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[1]");
//	By txtLQty = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[2]");
//	By txtXLQty = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[3]");
//	By txtXL2Qty = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[4]");
//	By txtXL3Qty = By.xpath("(//input[@class='form-control ng-untouched ng-pristine ng-valid ng-star-inserted'])[5]");
//	By txtPrice = By.xpath("//input[@class='form-control ng-pristine ng-valid ng-star-inserted input-error ng-touched']");

	By txtSQty = By.xpath("//*[@ng-reflect-name='sInput']");
	By txtMQty = By.xpath("//*[@ng-reflect-name='mInput']");
	By txtLQty = By.xpath("//*[@ng-reflect-name='lInput']");
	By txtXLQty = By.xpath("//*[@ng-reflect-name='xlInput']");
	By txtXL2Qty = By.xpath("//*[@ng-reflect-name='2xlInput']");
	By txtXL3Qty = By.xpath("//*[@ng-reflect-name='3xlInput']");
	By txtPrice = By.xpath("//*[@ng-reflect-name='price']");
	
	By btnAddShippingAddress= By.xpath("//span[contains(text(),'Add Shipping Address')]");
	
	By btnIndividualShip= By.xpath("//*[contains(text(),'Individual Ship')]");
	By btnBulkShip= By.xpath("//*[contains(text(),'Bulk Ship')]");
	
	By txtShippingName = By.xpath("(//input[@ng-reflect-name='shipping'])[1]");
	By txtAttentionName = By.xpath("(//input[@ng-reflect-name='attention'])[1]");
	By txtStreet = By.xpath("(//input[@ng-reflect-name='street'])[1]");
	By txtSuite = By.xpath("(//input[@ng-reflect-name='suite'])[1]");
	By txtCity = By.xpath("(//input[@ng-reflect-name='city'])[1]");
	By txtZipCode = By.xpath("(//input[@ng-reflect-name='zipcode'])[1]");
	By drpDwnState = By.xpath(
			"//div[contains(text(),'State') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnStateValue = "//div[contains(text(),'%s') and contains(@class,'custom-option')]";
	
	By btnReviewOrder= By.xpath("//span[contains(text(),'Review Order')]");
	
	By btnSkipforProof = By.xpath("//span[contains(text(),'Skip')]");
	
	By txtCustomColor = By.xpath("//input[@ng-reflect-name='color']");
	By txtCustomProductName = By.xpath("//input[@ng-reflect-name='apparelName']");
	By txtCustomProductLink = By.xpath("//input[@ng-reflect-name='apparelLink']");
	
	By btnAddDesignInfo = By.xpath("//span[contains(text(),'Add Design Info')]");
	
	By iconDownEditOrderDetails = By.xpath("(//div[contains(text(),'Order Details')]//following::img[contains(@src,'arrow')])[2]");
	By iconDownEditItemInfo = By.xpath("(//div[contains(text(),'Item Info')]//following::img[contains(@src,'arrow')])[1]");
	
	By btnAnotherItem =By.xpath("//span[contains(text(),'Another Item')]");
	
	By getStylecode = By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]");
	
	By getSqty = By.xpath("//input[@ng-reflect-name='sInput']");
	By getMqty = By.xpath("//input[@ng-reflect-name='mInput']");
	By getLqty = By.xpath("//input[@ng-reflect-name='lInput']");
	By getXLqty = By.xpath("//input[@ng-reflect-name='xlInput']");
	By getPrice = By.xpath("//input[@ng-reflect-name='price']");
	

	By btnSubnit = By.xpath("//span[contains(text(),'Confirm & Submit')]");
	
	By btnfPselect = By.xpath("(//div[@class='order-item-id cursor-pointer ng-star-inserted'])[1]");
	By btnAlphaselect = By.xpath("(//div[@class='order-item-id cursor-pointer ng-star-inserted'])[2]");
	By btnExternalselect = By.xpath("(//div[@class='order-item-id cursor-pointer ng-star-inserted'])[3]");
	
}