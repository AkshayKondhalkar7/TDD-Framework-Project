package pageElements;

import org.openqa.selenium.By;

public class PermissionPageElements {
	
	
	
	
	
	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By teamRoleBy = By.xpath("(//*[@formcontrolname ='selectedRoleC'])");
	By drpdwnteamroleBy = By.xpath("//*[contains(text(), '%s') and  contains(@class,'option-label')]");
	

}
