package pageElements;

import org.openqa.selenium.By;

public interface PromoCodesPageElements extends MasterPageElements {

	By btnCreatePromoCodes = By.xpath("//span[contains(text(),'Create Promo Code')]//preceding-sibling::img");
	By btnDisablePromoCodes = By.xpath("//span[contains(text(),'Disable')]//preceding-sibling::img");
//	By divCreatePromoCodes = By.xpath("//label[contains(text(),'Create Promo Code')]");
	By divCreatePromoCodes = By.xpath("//label[contains(text(),'Create Group Order Promo Code')]");
	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	String tabTitleRecordsCount = "(//div[contains(@class,'tabs') and contains(text(),'%s')]//following::span)[1]";

	By txtSearchPromoCode = By.xpath("//input[contains(@class,'search__input')]");
	By iconClearFilter = By.xpath("(//div[contains(@class,'search__close-icon')]/i)[1]");
	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";

//	String radioFilterType = "//label[contains(text(),'%s')]";
	String radioFilterType = "//a[contains(text(),'%s')]//following::label[contains(text(),'%s')]";
	String txtFilterValue = "(//label[contains(text(),'%s')]//following::input)[1]";
	By btnApplyFilter = By.xpath("//span[text()='Apply']//parent::button");
	
	String txtDateFilter = "//label[contains(text(),'%s')]//following::input[@ng-reflect-name='dateSelect']";

	By drpDwnOrder = By.xpath("//label[contains(text(),'Specific Group Order')]//following::ng-select[1]");
	By txtOrderNumber = By.xpath("//label[contains(text(),'Specific Group Order')]//following::ng-select[1]//input");
	String optionOrderNumber = "//label[contains(text(),'Specific Group Order')]//following::ng-select[1]//input//following::span[contains(@class,'option') and contains(text(),'%s')]";

	By txtPromoCode = By.xpath("//app-input//input[@placeholder='e.g. UCLA20384']");
	By btnPercentageType = By.xpath("//div[contains(text(),'Percentage')]");
	By btnFixedAmtType = By.xpath("//div[contains(text(),'Fixed Amount')]");
	By btnFreeShippingType = By.xpath("//div[contains(text(),'Free Shipping')]");
	By btnOrganizerPaysType = By.xpath("//div[contains(text(),'Organizer Pays')]");

	String btnPromoCodeType = "//div[contains(text(),'%s')]";
	By txtTypeValue = By.xpath("//app-input[@ng-reflect-name='promoCodeTypeValue']//input");

	By btnOnePerPersonLimit = By.xpath("//div[contains(text(),'1x per person')]");
	By btnSetTotalUsageLimit = By.xpath("//div[contains(text(),'1x per person')]");
	String btnLimitType = "//div[contains(text(),'%s')]";

	By txtLimitValue = By.xpath("//app-input[@ng-reflect-name='promoCodeLimitValue']//input");
	By chkBoxAppliesTo = By.xpath("//app-checkbox[@ng-reflect-name='appliesTo']//input");

	By drpDwnAppliesTo = By.xpath("//div[contains(text(),'Select Group Order')]//ancestor::ng-select");
//	By drpDwnAppliesTo = By.xpath("/html/body/app-half-overlay/div/div/div[3]/div[2]/div/app-promo-code-sub-details/div/div/form/div[1]/app-select/ng-select/div/div/div[1]");
	By txtAppliesTo = By.xpath("(//div[contains(text(),'Select Group Order')]//ancestor::ng-select//following::input)[1]");
//	By txtAppliesTo = By.xpath("/html/body/app-half-overlay/div/div/div[3]/div[2]/div/app-promo-code-sub-details/div/div/form/div[1]/app-select/ng-select/div/div/div[1]");
	String optionAppliesTo = "%s";
	String optionManagerName = "";

	By txtStartDate = By.xpath("//app-datepicker[@ng-reflect-name='startDate']//input");
	By drpDwnStartTime = By.xpath("//app-select[@ng-reflect-name='startTime']//ng-select");

	By txtEndDate = By.xpath("//app-datepicker[@ng-reflect-name='endDate']//input");
	By drpDwnEndTime = By.xpath("//app-select[@ng-reflect-name='endTime']//ng-select");

	By optionTime = By.xpath("(//ng-dropdown-panel//span[contains(@class,'ng-option-label')])[1]");
//	By btnCreatePromoCode = By.xpath("//span[contains(text(),'Create Promo Code')]//parent::button");
	By btnCreatePromoCode = By.xpath("//span[contains(text(),'Create Group Order Promo Code')]//parent::button");
	
	By selectAppliesToButton = By.xpath("//label[@for='all_group_orders']");
	
}
