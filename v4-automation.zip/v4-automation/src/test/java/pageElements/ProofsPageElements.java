package pageElements;

import org.openqa.selenium.By;

public interface ProofsPageElements extends MasterPageElements {

	By btnCreateProofss = By.xpath("//span[contains(text(),'Create Proof')]//preceding-sibling::img");

	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	By txtSearchProof = By.xpath("//input[contains(@class,'search__input')]");
	By iconClearFilter = By.xpath("(//div[contains(@class,'search__close-icon')]/i)[1]");
	String tabTitleRecordsCount = "(//div[contains(@class,'tabs') and contains(text(),'%s')]//following::span)[1]";

	By noRecordsDiv = By.xpath("//div[contains(text(),'No data to display')]");
	By divCreateProoof = By.xpath("(//div[contains(text(),'Proof Details')])[2]");

	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";

	String txtFilterOption = "(//a[contains(text(),'%s')]//following::input[@role='combobox'])[1]";
	String drpdwnFilteredOption = "//span[contains(text(),'%s')]";

	By txtProofTitle = By.xpath("//app-input[@formcontrolname='proofTitle']//input");
	By drpDwnClientName = By.xpath("//app-select[@ng-reflect-name='client']//ng-select");
	By txtClientName = By.xpath("//app-select[@ng-reflect-name='client']//ng-select//input");
	String optionClientName = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";

	By btnCreateClient = By.xpath("//span[text()='Create']//parent::button");

	By drpDwnCampaign = By.xpath("//app-select[@formcontrolname='campaign']//ng-select");
	By txtCampaign = By.xpath("//app-select[@ng-reflect-name='campaign']//ng-select//input");
	String optionCampaign = "//div[contains(@class,'custom-option__label') and contains(text(),'%s')]";

	By btnProductInfo = By.xpath("//span[contains(text(),'Product Info')]//parent::button");

	By drpDwnStyleCode = By.xpath("//app-select[@ng-reflect-name='styleCode']//ng-select");
	By txtStyleCode = By.xpath("//app-select[@ng-reflect-name='styleCode']//ng-select//input");
	String optionStyleCode = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By drpDwnColor = By.xpath("//app-select[@ng-reflect-name='color']//ng-select");
	By txtColor = By.xpath("//app-select[@ng-reflect-name='color']//ng-select//input");
	By optionColor = By.xpath("(//div[contains(@class,'option__label')])[1]");
	
	By txtCustomColor = By.xpath("//input[@ng-reflect-name='color']");
	By txtCustomProductName = By.xpath("//input[@ng-reflect-name='apparelName']");
	By txtCustomProductLink = By.xpath("//input[@ng-reflect-name='apparelLink']");

	String btnScreenPrint = "(//div[contains(text(),'Screen Print')])[%s]";
	String btnDigitalPrint = "(//div[contains(text(),'Digital Print')])[%s]";
	String btnEmbroidery = "(//div[contains(text(),'Embroidery')])[%s]";
	String btnApplique = "(//div[contains(text(),'Applique')])[%s]";
	String txtDescription = "(//div[contains(@class,'angular-editor-textarea')])[%s]";
	String toggleCustomName = "(//app-toggle[@ng-reflect-name='hasCustomNames']//input)[%s]";
	String toggleCustomNumber = "(//app-toggle[@ng-reflect-name='hasCustomNumbers']//input)[%s]";
	
	By btnAddAnotherProofItem = By.xpath("//span[contains(text(),'Another Proof Item')]");

	By btnAddLocAndDesign = By.xpath("//span[contains(text(),'Add Location & Design')]");
	By btnAddLocation = By.xpath("//div[contains(text(),'Add Location')]");
	
	String txtDescArt = "(//div[@class='angular-editor-textarea'])[%s]";
	String imgUploadImg = "(//div[contains(text(),'Upload Ref. Image')])[%s]";
	
	String iconColorPicker = "(//span[contains(text(),'%s')]//following::div[contains(@class,'color-picker')])[1]";
	
	By drpdwnCollegiateMark = By.xpath("//app-select[@ng-reflect-name='selectedSchoolC']/ng-select");
	By txtCollegiateMark = By.xpath("//app-select[@ng-reflect-name='selectedSchoolC']/ng-select//input");
	String optionCollegiateMark = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	By drpdwnOrganization = By.xpath("//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select");
	By txtOrganization = By.xpath("//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select//input");
	String optionOrganization = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	By btnSubmitProof = By.xpath("//span[contains(text(),'Submit')]");

	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By btnSetPassword = By.xpath("//span[contains(text(),'Set Password')]");
	By btnSetEmailAndPassword = By.xpath("//span[contains(text(),'Set Email & Password')]");
	By txtCompany = By.xpath("(//input[@ng-reflect-name='company'])[1]");
	By btnAddInfo = By.xpath("//span[contains(text(),'Add Info')]");
	By btnUpdateAccount = By.xpath("//span[contains(text(),'Update Account')]");
	By btnAddContactInfo = By.xpath("//span[contains(text(),'Add Contact Info')]");
	String txtgraduationYear = "//div[contains(text(),'%s')]";

	By txtPassword = By.xpath("//input[@placeholder='Enter password']");
	By txtConfirmPassword = By.xpath("//input[@placeholder='Confirm password']");
	By btnCreateAccount = By.xpath("(//span[contains(text(),'Create Account')])[1]");
	By btnBackToWork = By.xpath("//span[contains(text(),'Back to Work')]");

	By drpDwnSchoolClient = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValueClient = "//span[contains(text(),'%s')]";

	By drpDwnOrganizationClient = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValueClient = "//span[contains(text(),'%s')]";
	
	By iconDownEditProofDetails = By.xpath("(//div[contains(text(),'Proof Details')]//following::img[contains(@src,'arrow')])[1]");
	By iconDownEditProductDetails = By.xpath("(//div[contains(text(),'Product Info')]//following::img[contains(@src,'arrow')])[2]");
	
	/* added by vidya*/
	
//	By selectproof = By.xpath("//div[@class='data-table__copy ng-star-inserted']");
	By selectproof = By.xpath("((//div[contains(@class,'datatable-row-center')])[2]//div)[2]");
//	String lnkProofNumber = "//a[contains(text(),'%s')]";
	String lnkProofNumber = "//*[contains(text(),'%s')]";

	By btnPosition = By.xpath("//input[@ng-reflect-name='position']"); 
	By btnDetails = By.xpath("//div[@class='proof-details-expand d-flex align-items-center justify-content-center cursor-pointer']");
//	By btnThreeDots = By.xpath("(//div[@class='kebab cursor-pointer'])[2]");
	By btnThreeDots = By.xpath("//div[@class='kebab cursor-pointer']");
	By drpDownSubmittedBy = By.xpath("(//div[@class='ng-input'])[2]");
	By txtSubmittedby = By.xpath("(//input[@role='combobox'])[2]");
	String optionSubmittedby = "//span[contains(@class,'ng-option-label ng-star-inserted') and contains(text(),'%s')]";
	By btnedit = By.xpath("//img[@class='active-edit-btn ng-star-inserted']");
	
	By optionaDeleteProof = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	By btnThreeDotsforDelete = By.xpath("(//img[@src='assets/img/svg/proofs/kebab.svg'])[1]");
	By btnDelete = By.xpath("(//img[@class='active-delete-btn ng-star-inserted'])[1]");
			
	By btnEditSave = By.xpath("(//button[@class='btn gradient-purple-bliss ng-star-inserted'])[3]");
	By editTxtDescArt = By.xpath("(//div[@class='angular-editor-textarea'])");
	By editCustomNumber= By.xpath("//div[@class='selected-product-color ng-star-inserted']");
	
	By btnAddProofs = By.xpath("//button[@class='btn round add-proof-item ng-star-inserted']");
	By divAddProductInfo = By.xpath("(//div[contains(text(),'Product Info')])[3]");
	

	By txtAddColor = By.xpath("//input[@ng-reflect-name='color']");
	By txtProductName = By.xpath("//input[@ng-reflect-name='apparelName']");
	By txtProductLink = By.xpath("//input[@ng-reflect-name='apparelLink']");
	By txtorganizationname = By.xpath("//input[@ng-reflect-name='organization']");
//	By optionNewStyleCode = By.xpath("(//div[contains(@style,'transform:')])[2]");
	By optionNewStyleCode = By.xpath("(//div[contains(@role,'option')])");
	
	By clickProductLink = By.xpath("//a[@class='label apparel-label apparel-link d-block ng-star-inserted']");
	By checkOptionsInLink = By.xpath("//a[contains(@class,'font-raleway-bold') and contains(text(),'Store Locator')]");
	
	By btnOtherLocation = By.xpath("//div[@class='add-location-btn d-flex align-items-center cursor-pointer']");
	By referUploadImg = By.xpath("//label[@for='upload-ref-btn1']");
	By downArrowButton = By.xpath("//div[@class='scroll-down position-absolute cursor-pointer ng-star-inserted']");
	
	By btnCancel =By.xpath("(//button[@class='btn gradient-purple-bliss ng-star-inserted'])[2]");
	By btnYes = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	
	By textDescArt = By.xpath("//div[@class='angular-editor-textarea']");
	By btnLink = By.xpath("//i[@class='fa fa-link']");
	By selectProof = By.xpath("//div[@class='external-apparel-preview-container']");
//	By selectHyperLink = By.xpath("//div[@class='location-summary-view__description-summary']");
	By selectHyperLink = By.xpath("//a[@target='_blank']");
//	By selectHyperLink = By.xpath("//a[@target='_blank']//parent::div");
	
	String iconColorSelect = "(//span[contains(text(),'%s')]//following::div[contains(@class,'colors-container d-flex')])[2]";
	
	By btnRequestRevision = By.xpath("(//span[contains(text(),'Request Revision')])[2]");
	
	By btndeletelocation = By.xpath("(//div[@class='delete-location cursor-pointer ng-star-inserted'])[2]");
	
	By drpDwnStyleCodeforRR = By.xpath("(//app-select[@ng-reflect-name='styleCode']//ng-select)[2]");
	By txtStyleCodeForRR = By.xpath("(//app-select[@ng-reflect-name='styleCode']//ng-select//input)[2]");
	String optionStyleCodeForRR = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By drpDwnColorForRR = By.xpath("(//app-select[@ng-reflect-name='color']//ng-select)[2]");
	By txtColorForRR = By.xpath("(//app-select[@ng-reflect-name='color']//ng-select//input)[2]");
	By optionColorForRR = By.xpath("(//div[contains(@class,'option__label')])[1]");
	
	By drpdwnCollegiateMarkForRR = By.xpath("(//app-select[@ng-reflect-name='selectedSchoolC']/ng-select)[2]");
	By txtCollegiateMarkForRR = By.xpath("(//app-select[@ng-reflect-name='selectedSchoolC']/ng-select//input)[2]");
	String optionCollegiateMarkForRR = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	By drpdwnOrganizationForRR = By.xpath("(//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select)[2]");
	By txtOrganizationForRR = By.xpath("(//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select//input)[2]");
	String optionOrganizationForRR = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";
	
	String txtDescArtForRR = "(//div[@class='angular-editor-textarea'])[%s]";
	
	String uploadReferImg = "(//label[@class='upload-wrapper-edit-panel d-flex align-items-center cursor-pointer'])[%s]";
	By btnSubmitRR = By.xpath("//span[contains(text(),'Submit Revision Request')]");
	
	By btnOriginProof = By.xpath("(//div[contains(text(),'Original Proof')])[2]");
	By btnRevisionProof = By.xpath("(//div[contains(text(),'Revision 1')])[2]");
	
	By btnCloseProof = By.xpath("//i[@class='ft-x']");
	By clickProductInfo = By.xpath("(//div[contains(text(),'Product Info')])[2]"); 
	
	By btnCancelClient= By.xpath("(//div[contains(@class,'overlay-close')])[2]");
	By selectYes = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
	
	By scrollDownCheck = By.xpath("(//div[contains(text(),'Custom Names')])[2]");

	By selectProof1 = By.xpath("(//div[@class='proof-item-cards__item-card position-relative ng-star-inserted'])[1]");
	By selectProof2 = By.xpath("//div[@class='proof-item-cards__item-card position-relative external-apparel-item-card ng-star-inserted']");
	By selectProof3 = By.xpath("(//div[@class='proof-item-cards__item-card position-relative ng-star-inserted'])[2]");
	
	By valueStyleCode = By.className("//div[@class='label apparel-label ng-star-inserted']"); 
	
	By txtProofTi = By.xpath("//input[@ng-reflect-name='title']");
	
	By locDigitalPrint = By.xpath("(//div[contains(text(),'Digital Print')])[2]");
	By txtArt = By.xpath("(//div[@class='angular-editor-textarea'])[2]");
	
	By btnSaveleftPanel = By.xpath("//span[contains(text(),'Save Edits')]");

	By iconDownEditFPProduct = By.xpath("(//div[contains(text(),'Product Info')]//following::img[contains(@src,'arrow')])[3]");
	
	By locScreenPrint = By.xpath("(//div[contains(text(),'Screen Print')])[2]");

	By iconDownEditAlphaProduct = By.xpath("(//div[contains(text(),'Product Info')]//following::img[contains(@src,'arrow')])[4]");
	
	By btnImageChange = By.xpath("//label[contains(text(),'Change')]");
	
	By selectAlpha = By.xpath("(//div[@class='proof-item-cards__item-card position-relative ng-star-inserted'])[3]");
			
	By btnBackToProofsDetails = By.xpath("//i[@class='ft-chevron-left position-absolute cursor-pointer ng-star-inserted']");
	By btnBackToProductInfo = By.xpath("//i[@class='ft-chevron-left position-absolute cursor-pointer ng-star-inserted']");
	
	By dataManager = By.xpath("(//input[@role='combobox'])[3]");
	By selectManager= By.xpath("//div[contains(text(),'Testing Manager')]");
	
	String filteredUserDeactivateIcon = "(//span[contains(text(),'%s')]//following::i[contains(@class,'deactivate')])[1]";
	String filteredUserDeleteIcon = "(//span[contains(text(),'%s')]//following::i[contains(@class,'ft-user-x')])[1]";
	
	By btnClientDelete = By.xpath("//button[contains(text(),'Delete')]");
	
	By txtArtl = By.xpath("(//div[@class='angular-editor-textarea'])[1]");
	
	By btnSaveNotEnable = By.xpath("//button[@class='btn gradient-purple-bliss no-btn-animation ng-star-inserted']");
	
	By drpdwnleftpanelCollegiateMark = By.xpath("(//app-select[@ng-reflect-name='selectedSchoolC']/ng-select)[2]");
	By txtleftpanelCollegiateMark = By.xpath("(//app-select[@ng-reflect-name='selectedSchoolC']/ng-select//input)[2]");
	String optionleftpanelCollegiateMark = "(//span[contains(text(),'%s')])[2]";
	
	By drpdwnleftpanelOrganization = By.xpath("(//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select)[2]");
	By txtleftpanelOrganization = By.xpath("(//app-select[@ng-reflect-name='selectedOrganizationC']/ng-select//input)[2]");
	String optionleftpanelOrganization = "(//span[contains(text(),'%s')])[2]";
	
	By chkBoxClientTye = By.xpath("//input[@id='student' and @type='checkbox']");
	By txtBusiness = By.xpath("(//input[@ng-reflect-name='business'])[1]");
	By txtTitle = By.xpath("(//input[@ng-reflect-name='title'])[2]");
	
	By btnDeleteLocation = By.xpath("(//div[@class='delete-location cursor-pointer ng-star-inserted'])[1]");
	By btnlocation2 = By.xpath("//div[contains(text(),'Location #2')]");
	
			
}
