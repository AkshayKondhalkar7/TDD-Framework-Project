package pageElements;

import org.openqa.selenium.By;

public interface QuotersPageElements extends MasterPageElements {

	By divPerUnitCost = By.xpath("//div[contains(text(),'Per Unit')]//following-sibling::div");
	By divTotalPrice = By.xpath("//div[contains(text(),'Total Price')]//following-sibling::div");
	By divGPMPercentage = By.xpath("//div[contains(text(),'GPM')]//following-sibling::div");
	By imgApparelThumbnail = By.xpath("//img[@class='apparel__thumbnail']");
	By imgApparelPreviews = By.xpath("//img[contains(@class,'apparel__preview')]");
	By divStocksQty = By.xpath("//div[contains(@class,'stock-levels__container')]");

//	By lnkEnterBlankPrice = By.xpath("//div[contains(text(),' Enter Blanks Price')]");
	/* Xpath changes done by vidya - 04.25.2022 */
	By lnkEnterBlankPrice = By.xpath("//div[contains(text(),' Enter Blank Cost')]");
	By lnkEnterStyleCode = By.xpath("//div[contains(text(),' Enter Style Code')]");

	By drpDwnStyleCode = By.xpath("//ng-select[contains(@class,'apparel-dropdown')]");
	By txtStyleCode = By.xpath("//ng-select[contains(@class,'apparel-dropdown')]//input");
	String optionStyleCode = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By drpDwnColorCode = By.xpath("//app-select[@ng-reflect-name='color']//ng-select");
	By txtColorCode = By.xpath("//app-select[@ng-reflect-name='color']//ng-select//input");
//	By optionColorCode = By.xpath("(//span[contains(@class,'ng-option-label')])[1]");
	/* Xpath changes done by vidya & Kirty */
	By optionColorCode = By.xpath("(//div[contains(@class,'custom-option__label ng-star-inserted')])[1]"); 

	By txtBlankPrice = By.xpath("//input[@ng-reflect-name='blanksPrice']");
	By txtQuantity = By.xpath("//input[@ng-reflect-name='quantity']");

	By collegiateMarkYes = By.xpath(
			"//app-select-button[@ng-reflect-name='collegiateLicensing']//child::input[@ng-reflect-value='true']");
	By collegiateMarkNo = By.xpath(
			"//app-select-button[@ng-reflect-name='collegiateLicensing']//child::input[@ng-reflect-value='false']");

	By greekMarkYes = By
			.xpath("//app-select-button[@ng-reflect-name='greekLicensing']//child::input[@ng-reflect-value='true']");
	By greekMarkNo = By
			.xpath("//app-select-button[@ng-reflect-name='greekLicensing']//child::input[@ng-reflect-value='false']");

	By toggleWhiteGarment = By.xpath("//app-toggle[@ng-reflect-name='externalApparelColor']//child::input");

	By btnAddPrintLocation = By.xpath("(//p[contains(text(),'Print Locations')]//following::app-button)[1]/button");

	By drpdwnPrintType = By.xpath("//app-select[@ng-reflect-name='type']//ng-select");
	By txtPrintType = By.xpath("//app-select[@ng-reflect-name='type']/ng-select//input");
	String optionPrintType = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By drpdwnPrintSubType = By.xpath("//app-select[@ng-reflect-name='subType']/ng-select");
	By txtPrintSubType = By.xpath("//app-select[@ng-reflect-name='subType']/ng-select//input");
	String optionPrintSubType = "//span[contains(@class,'ng-option-label') and contains(text(),'%s')]";

	By btnAddNumberOfColors = By
			.xpath("//label[contains(text(),'# of Colors')]//following::app-button[@class='change-bg']/button");
	By btnDeleteNumberOfColors = By.xpath("(//label[contains(text(),'# of Colors')]//following::app-button)[2]");

	By toggleCustomName = By.xpath("//app-toggle[@ng-reflect-name='customNames']//input");
	By toggleCustomNumber = By.xpath("//app-toggle[@ng-reflect-name='customNumbers']//input");
	By toggleCustomDue7to10 = By.xpath("//app-toggle[@ng-reflect-name='due7Days']//input");
	By toggleCustomDue11to13 = By.xpath("//app-toggle[@ng-reflect-name='due11Days']//input");
	By toggleIndividualShipping = By.xpath("//app-toggle[@ng-reflect-name='individualShipping']//input");

	By txtApparel = By.xpath("//input[@ng-reflect-name='apparelPrice']");
	By txtGreekRoyalty = By.xpath("//input[@ng-reflect-name='greekRoyalties']");
	By txtCollegiateRoyalty = By.xpath("//input[@ng-reflect-name='collegiateRoyalties']");
	By txtCommission = By.xpath("//input[@ng-reflect-name='commission']");
	By txtLoc1Printing = By.xpath("//input[@ng-reflect-name='location1printing']");
	By txtShipping = By.xpath("//input[@ng-reflect-name='shipping']");
	By txtRushShipping = By.xpath("//input[@ng-reflect-name='rushShipping']");
	By individualShipping = By.xpath("//input[@ng-reflect-name='individualShipping']");
	By txtChargedPrice = By.xpath("//input[@ng-reflect-name='chargedPrice']");
	By txtCustomNames = By.xpath("//input[@ng-reflect-name='customNames']");
	By txtCustomNumers = By.xpath("//input[@ng-reflect-name='customNumbers']");
	By txtMiscellaneous = By.xpath("//input[@ng-reflect-name='miscellaneous']");

	By iconDownloadQuote = By.xpath("");
	By btnPerunit =By.xpath("//*[contains(text(),'Per Unit')]");

}
