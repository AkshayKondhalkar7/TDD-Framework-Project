package pageElements;

import org.openqa.selenium.By;

public interface SettingsPageElements extends MasterPageElements{
	
	
	//Edited By kirty 18 Feb 2022 - started edited by vidya  16.03.2022
	
	
	//span[contains(text(),'Settings')]
	
	By lnkSettingsNavIcon =By.xpath("span[contains(text(),'Settings')]/parent::a");
	
	//By lnkSettingsNavIcon = By.xpath("//span[text()='Settings']/parent::a");
	By FullNameTextBox = By.xpath("//*[@formcontrolname='fullNameC']/div/input");
	By PhoneNumberTextBox = By.xpath("//*[@formcontrolname='phoneC']/div/input");
	By EmailTextBox = By.xpath("//*[@formcontrolname='emailC']/div/input");
	By PassWordTextBox = By.xpath("//*[@formcontrolname='passwordC']/div/input");
	By EditDetailsButton = By.xpath("//span[contains(text(),'Edit Details')]");
	By btnSaveDetails = By.xpath("//*[contains(text(),'Save Details')]");
	By CancelButton = By.xpath("//a[contains(text(),'Cancel')]");
	By cancelYesBtn = By.xpath("//button[@class='btn btn-danger ng-star-inserted']");
    By EditPwdButton =By.xpath("//i[contains(text(),'Edit')]");
	//By UnsubscribeToMailingBox = By.xpath("//a[contains(text(),'Unsubscribe to Our Mailing List')]");
	By UnsubscribeToMailingBox = By.xpath("//a[@class='cancel-unsubscibe ng-star-inserted']");
	By rejoinourmail= By.xpath("//a[@class='cancel-unsubscibe user-rejoin ng-star-inserted']");
	By CurrentPwdTextBox = By.xpath("//input[@placeholder='Current password']");
	By NewPwdTextBox = By.xpath("//input[@placeholder='New Password']");
	By ConfirmNewPwdTextBox = By.xpath("//input[@placeholder='Confirm New Password']");
	By ShippingNameTextBox = By.xpath("//*[@formcontrolname='shipNameC']/div/input");
	By StreetNameTextBox = By.xpath("//*[@formcontrolname='street1C']/div/input");
	By ApartmentNameTextBox = By.xpath("//*[@formcontrolname='street2C']/div/input");
	By CityTextBox =By.xpath("//*[@formcontrolname='cityC']/div/input");	
	By StateTextBox =By.xpath("//*[@formcontrolname='selectedStateC']/div/input");
	By ZipCodeTextBox =By.xpath("//*[@formcontrolname='zipCodeC']/div/input");
	By drpDwnState = By.xpath("//div[contains(text(),'State') and contains(@class,'label')]//following::input[@role='combobox'][1]");
    By drpDwnOrganization = By.xpath("//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	By btnStopImpersonation = By.xpath("//div[contains(text(),'Stop')]");
	/* added by vidya */
	By drpDwnSchool = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	By txtBusiness = By.xpath("(//input[@ng-reflect-name='business'])[1]");
	By txtTitle = By.xpath("(//input[@ng-reflect-name='title'])[1]");
	
	By chkBoxClientTye = By.xpath("//input[@id='student' and @type='checkbox']");

	By drpDwnSchoolClient = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValueClient = "//span[contains(text(),'%s')]";

	By drpDwnOrganizationClient = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValueClient = "//span[contains(text(),'%s')]";
	
	By btnPosition = By.xpath("//input[@ng-reflect-name='position']");
	
	String txtgraduationYear = "//div[contains(text(),'%s')]";

}
