package pageElements;

import org.openqa.selenium.By;

public interface StockCheckerPageElements extends MasterPageElements {

	By titleStockChecker = By.xpath("//div[contains(@class,\"stock-checker-header__name\") and text()='Stock Checker']");
	//div[text()='Stock Checker']
	By txtSearchStock = By.xpath("//div[@class='ng-placeholder']");
	
	
	By btnAllColors = By.xpath("//div[contains(@class,'transparent-product-pill')]");
	
	// String tabSelection = "(//div[contains(text(),'%s')])[1]"; // Doubt: module containing tabs
	
	By styleCode = By.xpath("//div[@class=\"ng-dropdown-panel-items scroll-host\"]");
	
	By AnchorColorSelect = By.xpath("//div[@style='background: rgb(64, 70, 83);']");
	By AnchorWindSelect = By.xpath("//div[contains(@title,'Anchor Slate')]");
	
	By colorSelect = By.xpath("//div[@title='Anchor Slate']");
	
	// will be compared validations required 
	By stockCheckMSize = By.xpath("//span[text()='101']");
	By StockCheckBlankCost = By.xpath("//div[@id=\'data-cell-blankPrice0\']");
	
	By stockCheckDownarrow = By.xpath("(//img[contains(@class,'data-table__dropdown-arrow-icon')])[1]");
    By quotelink = By.xpath("//span[contains(@class,'quote-span')and text()='Quote']");
}
