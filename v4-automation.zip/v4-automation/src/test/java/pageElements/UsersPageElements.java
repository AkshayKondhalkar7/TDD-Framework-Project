package pageElements;

import org.openqa.selenium.By;

public interface UsersPageElements extends MasterPageElements {

	By iconCreateUser = By.xpath("//span[contains(text(),'Create User')]//preceding-sibling::img");
	By iconCreateClient = By.xpath("//span[contains(text(),'Create Client')]//preceding-sibling::img");

	By iconCreateUserForAdminMobile = By.xpath("(//span[contains(text(),'User')])[3]//parent::button");
	By iconCreateUserForManagerMobile = By.xpath("(//span[contains(text(),'Client')])[3]");

	By divCreateUserCheck = By.xpath("//div[contains(text(),'What type of user are you creating')]");

	By txtFilterData = By.xpath("(//input[contains(@placeholder,'Search by name, org, email etc')])[1]");
	By txtFilterDataMobile = By.xpath("(//input[contains(@placeholder,'Search by name')])[2]");

	By iconImpersonateUser = By.xpath("//div[contains(@class,'impersonate')]");
	By iconEditUser = By.xpath("//i[contains(@class,'ft-edit user')]");
	By iconClose = By.xpath("//div[contains(@class,'overlay-close')]/i");
	By iconCloseMoreOptionsMobile = By.xpath("//div[@class='close-icon']/i[@class='ft-x']");

	By iconMoreMobile = By.xpath("//img[contains(@class,'details__more__icon')]");
	By iconEditMobile = By.xpath("//i[contains(@class,'ft-edit details__more')]");
	By iconImpersonateMobile = By.xpath("//i[contains(@class,'ft-user details__more')]");
	By iconDeactivateMobile = By.xpath("//i[contains(@class,'ft-user-x details__more')]");
	By iconDeleteMobile = By.xpath("//i[contains(@class,'ft-user-x details__more')]");

	By btnStopImpersonation = By.xpath("//div[contains(text(),'Stop')]");
	By btnYes = By.xpath("//button[contains(text(),'Yes')]");
	By btnYesMobile = By.xpath("//div[contains(text(),'Yes')]");

	By btnNo = By.xpath("//button[contains(text(),'No')]");
	By btnNoMobile = By.xpath("//div[contains(text(),'No')]");

	By noRecordsDiv = By.xpath("//div[contains(text(),'No data to display')]");
	By noRecordsDivMobile = By.xpath("(//div[contains(text(),'No search results found')])[2]");

	By txtFullname = By.xpath("(//input[@ng-reflect-name='fname'])[1]");
	By txtPhone = By.xpath("(//input[@ng-reflect-name='phone'])[1]");
	By txtemail = By.xpath("(//input[@ng-reflect-name='email'])[1]");
	By btnSetPassword = By.xpath("//span[contains(text(),'Set Password')]");
	By btnSetEmailAndPassword = By.xpath("//span[contains(text(),'Set Email & Password')]");
	By txtCompany = By.xpath("(//input[@ng-reflect-name='company'])[1]");
	By btnAddInfo = By.xpath("//span[contains(text(),'Add Info')]");
	By btnUpdateAccount = By.xpath("//span[contains(text(),'Update Account')]");
	By btnAddContactInfo = By.xpath("//span[contains(text(),'Add Contact Info')]");
	By btnAddShippingInfo = By.xpath("//span[contains(text(),'Add Shipping Info')]");

	By txtPassword = By.xpath("//input[@placeholder='Enter password']");
	By txtConfirmPassword = By.xpath("//input[@placeholder='Confirm password']");
	By btnCreateAccount = By.xpath("//span[contains(text(),'Create Account')]");

	By txtShippingName = By.xpath("(//input[@ng-reflect-name='shipping'])[1]");
	By txtAttentionName = By.xpath("(//input[@ng-reflect-name='attention'])[1]");
	By btnNext = By.xpath("//span[contains(text(),'Next')]");

	By txtStreet = By.xpath("(//input[@ng-reflect-name='street'])[1]");
	By txtSuite = By.xpath("(//input[@ng-reflect-name='suite'])[1]");
	By txtCity = By.xpath("(//input[@ng-reflect-name='city'])[1]");
	By txtZipCode = By.xpath("(//input[@ng-reflect-name='zipcode'])[1]");

	By drpDwnState = By.xpath(
			"//div[contains(text(),'State') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnStateValue = "//div[contains(text(),'%s') and contains(@class,'custom-option')]";

	String txtTimezone = "//div[contains(text(),'Select Timezone')]//following::div[contains(text(),'%s')]";

	By btnSaveEdits = By.xpath("//span[contains(text(),'Save Edits')]");

	By divAccountCreated = By.xpath("//div[contains(text(),'Account Created!')]");
	By divAccountUpdated = By.xpath("//div[contains(text(),'Account Updated!')]");
	By divInvalidAddress = By.xpath("//div[contains(text(),'The address you entered is invalid!')]");

	By drpDwnSchool = By.xpath(
			"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnSchoolValue = "//span[contains(text(),'%s')]";
	By itemNoSchool = By.xpath("//div[contains(text(),'No school found')]");
	By itemNoOrg = By.xpath("//div[contains(text(),'No organization found')]");
	By txtOrganization = By.xpath("(//input[@ng-reflect-name='organization'])[1]");
	By txtSchool = By.xpath("(//input[@ng-reflect-name='school'])[1]");
	By addItemOrg = By.xpath("//span[contains(text(),'Add item')]");
	By noStateFoundOption = By.xpath("//div[contains(text(),'No state found')]");

	By drpDwnOrganization = By.xpath(
			"//div[contains(text(),'Organization') and contains(@class,'label')]//following::input[@role='combobox'][1]");
	String drpDwnOrganizationValue = "//span[contains(text(),'%s') and contains(@class,'option-label')]";

	By chkBoxClientTye = By.xpath("//input[@id='student' and @type='checkbox']");
	By txtBusiness = By.xpath("(//input[@ng-reflect-name='business'])[1]");
	By txtTitle = By.xpath("(//input[@ng-reflect-name='title'])[1]");
	By btnFilter = By.xpath("//label[contains(text(),'Filters')]");
	String drpdwnFilterOption = "//a[contains(text(),'%s')]";
	String txtFilterOption = "(//a[contains(text(),'%s')]//following::input[@role='combobox'])[1]";
	String drpdwnFilteredOption = "//span[contains(text(),'%s')]";
	String drpdwnFilteredOptionMobile = "//div[contains(@class,'filter-overlay')]//label[contains(text(),'%s')]";

	By btnBackToWork = By.xpath("//span[contains(text(),'Back to Work')]");

	By btnDeActivate = By.xpath("//button[contains(text(),'Deactivate')]");
	By btnCancel = By.xpath("//button[contains(text(),'Cancel')]");
	By btnDelete = By.xpath("//button[contains(text(),'Delete')]");
	By btnDeActivateMobile = By.xpath("//div[contains(text(),'Deactivate')]");
	By btnReActivateMobile = By.xpath("//div[contains(text(),'Reactivate')]");
	By btnCancelMobile = By.xpath("//div[contains(text(),'Cancel')]");
	By btnDeleteMobile = By.xpath("//div[contains(text(),'Delete')]");

	String drpDwnCampusManager = "(//span[contains(text(),'%s')]//preceding::datatable-body-cell//following::input)[1]";
	By drpDwnCampusManagerInput = By
			.xpath("(//div[contains(text(),'Select CM')]//following::div[@class='ng-input']//input)[1]");
//	String drpDwnCampusManagerValue = "//span[contains(text(),'%s')]";
	String drpDwnCampusManagerValue = "//div[contains(text(),'%s')]";

	String userTypeSelection = "//div[@class='card__title' and contains(text(),'%s')]";
	String txtgraduationYear = "//div[contains(text(),'%s')]";
	String tabSelection = "(//div[contains(text(),'%s')])[1]";
	String userRecordsCount = "(//div[contains(text(),'%s')]//following::span[contains(@class,'tabs__count')])[1]";
	String filteredUserDeactivateIcon = "(//span[contains(text(),'%s')]//following::i[contains(@class,'deactivate')])[1]";
	String filteredUserReactivateIcon = "(//span[contains(text(),'%s')]//following::div[contains(text(),'Reactivate')])[1]";
	String filteredUserImpersonateIcon = "(//span[contains(text(),'%s')]//following::div[contains(@class,'impersonate')])[1]";
	String filteredUserEditIcon = "(//span[contains(text(),'%s')]//following::i[contains(@class,'ft-edit')])[1]";
	String filteredUserDeleteIcon = "(//span[contains(text(),'%s')]//following::i[contains(@class,'ft-user-x')])[1]";
	String tabTitleRecordsCount = "(//div[contains(@class,'tabs') and contains(text(),'%s')]//following::span)[1]";

	By filteredUserNameMobileCard = By.xpath("(//app-table-card//child::div)[1]//label");
	By filteredUserSchoolMobileCard = By.xpath("//img[contains(@class,'details__school-icon')]//following::label[1]");
	By filteredUserOrgMobileCard = By
			.xpath("//img[contains(@class,'details__organization-icon')]//following::label[1]");
	By filteredUserCompanyMobileCard = By
			.xpath("//img[contains(@class,'details__business-icon')]//following::label[1]");
	By filteredUserCMNameMobileCard = By.xpath("(//div[contains(@class,'cm-wrapper')]/div)[1]");
	
	By btnPosition = By.xpath("//input[@ng-reflect-name='position']"); 
	/* added by vidya*/
	By teamRoleBy = By.xpath("(//*[@formcontrolname ='selectedRoleC'])");
	String drpdwnteamroleBy = "//*[contains(text(), '%s') and  contains(@class,'option-label')]";
	By btnFpteamroleBy =By.xpath("//*[contains(text(), 'FP Team')]");
	
	By btnSaveData = By.xpath("//button[contains(text(),'Yes')]");
	
}
