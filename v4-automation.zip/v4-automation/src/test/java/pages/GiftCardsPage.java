package pages;

import static appConstants.ApplicationConstants.GIFTCARDS_DISABLEMULTIPLEGIFTCARDS_MESSAGE;
import static appConstants.ApplicationConstants.GIFTCARDS_INVALID_GIFTCARD;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.GiftCardsTabs;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.GiftCardPageElements;
import reports.ExtentLogger;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class GiftCardsPage extends MasterPage implements GiftCardPageElements {

	public GiftCardsPage switchTo(GiftCardsTabs giftCardsTab) {
		try {
			scrollToTop();
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(giftCardsTab))));
			sleepFor(1000);
			ExtentLogger.pass("Switched to " + getStringValue(giftCardsTab) + " Tab.");
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(giftCardsTab) + " Tab. " + e.getMessage());
		}

		return this;
	}
	

	
	
	

	public GiftCardsPage clickCreateGiftCardButton() {
		try {
			clickElement(btnCreateGiftCards);
			if (!findElementPresence(divCreateGiftCards)) {
				throw new Exception("Gift Cards Page Title Not Found during Creation.");
			}
			ExtentLogger.pass("Clicked Click Gift Cards Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Add Gift Cards Button. " + e.getMessage());
		}

		return this;
	}

	public GiftCardsPage enterGiftCardCode() {
		String randCode = "";
		try {
			randCode = "GIFTCARD" + DataGeneratorUtils.randString().toUpperCase();
			enterData(txtGiftCard, randCode);
			
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GROUPORDERGIFTCARD", randCode);
		//	RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GIFTCARDCODE", randCode);
			ExtentLogger.pass("Entered the Gift Card Code: " + randCode + " Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Gift Card Code. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage enterDollerValue() {
		String dollerValue = "";
		try {
			dollerValue = String.valueOf(ThreadLocalRandom.current().nextInt(2, 15));
			enterData(txtDollerValue, dollerValue);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALVALUE", "$" + dollerValue);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "REMAININGVALUE", "$" + dollerValue);
			ExtentLogger.pass("Entered the Gift Card Doller Value: " + dollerValue + " Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Gift Card Doller Value. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage enterExpiryDate() {
		 LocalDate date;
		//LocalDateTime date;
		try {
			clickElementJS(txtExpiryDate);
			date = selectRandDate(5);

			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EXPIRYDATE", StringUtils
					.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3) + " " + date.getDayOfMonth()));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EXPIRYYEAR", String.valueOf(date.getYear()));
			ExtentLogger.pass("Selected Expiry Date for Gift Card Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Selecting Expiry Date. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage enterClientDetails(String type) {
		String clientName = "";
		try {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_GIFTCARD");
			if (type.equalsIgnoreCase("existing")) {
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			} else if (type.equalsIgnoreCase("new")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			ExtentLogger.pass("Entered Client Details Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Client Details. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage createClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);

			clickElementJS(drpDwnSchool);
			sleepFor(200);
			enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganization);
			sleepFor(200);
			enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(200);
			
			/* added by vidya on 03.28.2022 */
			
			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);
			
			
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

			clickElementJS(btnCreateAccount);
			ExtentLogger.pass("Created Client for Invoice Successfully");
			clickElementJS(btnBackToWork);
			sleepFor(1000);

		} catch (Exception e) {
			Assert.fail("Failed in Creating Client for Invoice. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage verifySummary() {
		String code = "", dollerValue = "", expiryDate = "", clientName = "";
		try {
			sleepFor(2000);
			softAssert = new SoftAssert();

			code = getData(By.xpath("//div[contains(text(),'Code')]//span"));
			dollerValue = getData(By.xpath("//div[contains(text(),'Value')]//span"));
			clientName = getData(By.xpath("//div[contains(text(),'Client')]//span"));
			expiryDate = getData(By.xpath("//div[contains(text(),'Expires')]//span"));
			
			expiryDate = getTheSubString(expiryDate);

//			softAssert.assertEquals(code,
//					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GIFTCARDCODE"),
//					"Unexpected Gift Card Code in Summary");
			
			softAssert.assertEquals(code,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDERGIFTCARD"),
					"Unexpected Gift Card Code in Summary");

			softAssert.assertEquals(dollerValue,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALVALUE"),
					"Unexpected Doller Value in Summary");

			softAssert.assertEquals(clientName,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME"),
					"Unexpected Client Name in Summary");

			softAssert.assertEquals(expiryDate,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EXPIRYDATE"),
					"Unexpected Expiry Date in Summary");

			softAssert.assertAll();
			ExtentLogger.pass("Successfully Verified GiftCards Summary");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Gift Card Summary. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage createGiftCard() {
		try {
			clickElementJS(btnCreateGiftCard);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//div[contains(text(),'Gift Card "
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDERGIFTCARD") + " Created')]"));
			ExtentLogger.pass("Gift Card is created Successfully");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STATUS", "Active");

		} catch (Exception e) {
			Assert.fail("Failed in Creating Gift Card. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage filterGiftCard() {
	//	String giftCardCode = "";
		String groupordergiftcard = "";
		try {
		//	giftCardCode = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GIFTCARDCODE");
			groupordergiftcard = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDERGIFTCARD");
			enterData(txtSearchGiftCard, groupordergiftcard);
			ExtentLogger.pass("Filtered " + groupordergiftcard + " Gift Card Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Filtering Gift Card. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage verifyDashboard(String operationType) {
	//	ArrayList<HashMap<String, String>> completeData = null;
	//	String giftCard = "", status = "", client = "", totalAmt = "", remainingAmt = "", expired = "";
		String groupordergiftcard = "", status = "", client = "", totalAmt = "", remainingAmt = "", expired = "";
		try {
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = readCurrentTable();

			if (operationType.equalsIgnoreCase("create")) {
//				giftCard = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GIFTCARDCODE");
				groupordergiftcard = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDERGIFTCARD");
				status = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STATUS");
				client = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME");
				totalAmt = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALVALUE");
				remainingAmt = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "REMAININGVALUE");
				expired = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EXPIRYDATE") + ", "
						+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EXPIRYYEAR");
				
				expired = getTheSubString(expired);
				System.out.println("expired = "+expired);

				if (completeData.size() != 1) {
					throw new Exception("Searched Record is not filtered Correctly.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
					//	if (!eachRow.get("Gift Card").equalsIgnoreCase(giftCard)) 
//							if (!eachRow.get("group order gift card").equalsIgnoreCase(groupordergiftcard)){
//							throw new Exception("Filtered Records doesn't have the expected Gift Card: " + groupordergiftcard);
//						}
						if (!eachRow.get("Status").equalsIgnoreCase(status)) {
							throw new Exception("Filtered Records doesn't have the expected Status: " + status);
						}
						if (!eachRow.get("Client").equalsIgnoreCase(client)) {
							throw new Exception("Filtered Records doesn't have the expected Client Name: " + client);
						}
						if (!eachRow.get("Total Amount").contains(totalAmt)) {
							throw new Exception("Filtered Records doesn't have the expected Total Amount: " + totalAmt);
						}
						if (!eachRow.get("Remaining Amount").contains(remainingAmt)) {
							throw new Exception(
									"Filtered Records doesn't have the expected Remaining Amount: " + remainingAmt);
						}
						if (!eachRow.get("Expired").equalsIgnoreCase(expired)) {
							System.out.println(eachRow.get("Expired")+" "+expired);
							throw new Exception("Filtered Records doesn't have the expected Expired Date: " + expired);
						}
					}
				}
			} else if (operationType.equals("disable")) {
				if (completeData.size() != 1) {
					throw new Exception("Searched Record is not filtered Correctly.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						if (!eachRow.get("Status").equalsIgnoreCase("Disabled")) {
							throw new Exception("Filtered Records doesn't have the expected Status: Disabled");
						}
					}
				}
			}
			ExtentLogger.pass("Verified Records after Filter");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Filtered Records. " + e.getMessage());
		}
		return this;
	}

	public void printMap(ArrayList<HashMap<String, String>> fullData) {
		for (HashMap<String, String> rows : fullData) {
			for (Map.Entry<String, String> entry : rows.entrySet()) {
				System.out.println(entry.getKey() + ": " + entry.getValue());
			}
			System.out.println("-----------");
		}
	}
	
	// changes done by vidya
	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		try {
		 	for (int i = 2; i <= 8; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
				header.add(colData);
				
			}
			
			
			for (int i = 2; i <= rowCount; i++) {
				HashMap<String, String> eachRow = new HashMap<>();
			//	int temp = 4;
				
				/* temp= 4 changed to temp = 5*/
			//	int temp = 5; 
				int temp = 6;
				for (int j = 1; j <= 7; j++) {
					String data = "";
					String dataaftergetTheSubString = "";

					data = getData(By
							.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp + "]"));
					System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp + "]");
					System.out.println("data = "+data);
					temp += 3;
					
					if (j < 7) {
						
						System.out.println("data j > 7 = "  +data);
					} else {
						
						data = getTheSubString(data);
						System.out.println("data else " +data);
					}
					
					
					System.out.println("before condition temp = "+ temp);
					
				//	temp = temp < 10 ? temp + 5 : temp <= 10 ? temp + 3 : temp + 5;
					
				//	temp = temp < 7 ? temp + 3 : temp <= 8 ? temp + 5 : temp + 3;
					
					System.out.println("After condition temp = "+ temp);
					
					
					
					eachRow.put(header.get(j - 1), data);			
					
					
				}
				fullData.add(eachRow);
				System.out.println("eachRow "+ eachRow);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;
	}

	public GiftCardsPage disableOneGiftCardAndVerify() {
		String giftCard = "";
		try {
			clickElementJS(By.xpath("(//datatable-body-row)[1]//datatable-body-cell[2]"));
			giftCard = getAttributeValue(By.xpath("//datatable-body-cell//input[@value='true']"), "id");
			clickElement(btnDisableGiftCard);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'is disabled')]"));

			ExtentLogger.pass("Successfully Disabled " + giftCard + " GiftCard");

			enterData(txtSearchGiftCard, giftCard);
			verifyDashboard("Disable");
			clickElement(iconClearFilter);
			sleepFor(2000);
			ExtentLogger.pass("Verified that Status is Updated for " + giftCard + " GiftCard");
		} catch (Exception e) {
			Assert.fail("Failed in Disabling Gift Card and Verifying it. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage disableMultipleGiftCardsAndVerify(int rowCount) {
		List<WebElement> elements;
		List<String> giftCardsList = new ArrayList<>();
		try {
			for (int i = 1; i <= rowCount; i++) {
				clickElementJS(By.xpath("(//datatable-body-row)[" + i + "]//datatable-body-cell[2]"));
			}
			elements = DriverManager.getDriver().findElements(By.xpath("//datatable-body-cell//input[@value='true']"));

			for (WebElement element : elements)
				giftCardsList.add(element.getAttribute("id"));

			ExtentLogger.pass("Successfully Disabled Multiple GiftCards");
			clickElement(btnDisableGiftCard);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + GIFTCARDS_DISABLEMULTIPLEGIFTCARDS_MESSAGE + "')]"));

			for (String giftCard : giftCardsList) {
				enterData(txtSearchGiftCard, giftCard);
				verifyDashboard("Disable");
				clickElement(iconClearFilter);
			}
			ExtentLogger.pass("Verified that Status is Updated for all Disabled GiftCards.");
		} catch (Exception e) {
			Assert.fail("Failed in Disabling Multiple Gift Cards and Verifying it. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage invalidGiftCardAndVerify(String giftCardType) {
		String giftCard = "";
		try {
			switch (giftCardType.toLowerCase()) {
			case "existing":
				giftCard = InputPropertyUtils.get("EXISTING_ACTIVE_GIFTCARD");
				break;
			case "disabled":
				giftCard = InputPropertyUtils.get("EXISTING_DISABLED_GIFTCARD");
				break;
			case "promocode":
				giftCard = InputPropertyUtils.get("EXISTING_ACTIVE_PROMOCODE");
				break;

			default:
				throw new Exception("Invalid Type: " + giftCardType);
			}
			enterData(txtGiftCard, giftCard);
			clickTab(txtGiftCard);

			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ GIFTCARDS_INVALID_GIFTCARD + "')]")),
					true, "Validation for GiftCards is not displayed");

			ExtentLogger.pass(
					"Verified that a new GiftCard cannot be Created using Existing Code String that is " + giftCard);
		} catch (Exception e) {
			Assert.fail("Failed in Providing Invalid GiftCard and Verifying Validations. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage verifyRecordsCount(GiftCardsTabs giftCardsTab) {
		try {
			sleepFor(300);
			int rowCount = 0, recordsPerPage = 0, totRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(By.xpath(
							DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(giftCardsTab))))
					.getText());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(giftCardsTab))));
			sleepFor(500);

			if (findElementPresence(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))) {
				recordsPerPage = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
			} else {
				recordsPerPage = totRecords;
			}

			if (totRecords < recordsPerPage) {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount + " for " + getStringValue(giftCardsTab));
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount + " for "
							+ getStringValue(giftCardsTab));
				}
			} else {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				while (checkCondition(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"),
						ElementCheckStrategy.DISPLAYED)) {
					clickElement(By.xpath("//i[@class='datatable-icon-right']"));

					rowCount = rowCount
							+ DriverManager.getDriver()
									.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size()
							- 1;
				}
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount);
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount);
				}
			}
		} catch (Exception e) {
			Assert.fail("Unable to Verify Records Count. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage sortAndVerifyAllColumns(GiftCardsTabs giftCardsTab) {
	//	String[] colnames = { "Gift Card", "Client", "Total Amount", "Remaining Amount" };
		String[] colnames = { "Group Order Gift Card", "Client", "Total Amount", "Remaining Amount" };
		ArrayList<String> actualColData = null;
		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), giftCardsTab));

				if (column.equalsIgnoreCase("applies to")) {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(giftCardsTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(giftCardsTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				} else {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(giftCardsTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(giftCardsTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			}
		} catch (Exception e) {
			Assert.fail(
					"Failed During Sorting and Verification in " + giftCardsTab.toString() + " Tab." + e.getMessage());
		}
		return this;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, GiftCardsTabs giftCardsTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, giftCardsTab));
				columnData.removeAll(Arrays.asList("", null, " "));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
	//				scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					scrollToElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(2000);
	//				clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					clickElementJS(By.xpath("//i[@class='datatable-icon-skip']//parent::a"));
					sleepFor(2000);
					columnData.addAll(readColumnData(colIdx, giftCardsTab));
					columnData.removeAll(Arrays.asList("", null," "));

					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, giftCardsTab));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx, GiftCardsTabs giftCardsTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				scrollToElement(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));


				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));
				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
				columnData.removeAll(Arrays.asList("", null, " "));
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}
		return columnData;
	}

	public void getSortedDataAndCompare(GiftCardsTabs giftCardsTab, String colName, ArrayList<String> actualColData,
			String order) throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), giftCardsTab));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is Sorted in " + order + " Order Correctly in "
						+ getStringValue(giftCardsTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Order Correctly in "
						+ getStringValue(giftCardsTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;
		try {
			if (colName.equalsIgnoreCase("total amount") || colName.equalsIgnoreCase("remaining amount")) {
				Collections.sort(dataList, new Comparator<String>() {

					public int compare(String num1, String num2) {
						Double n1 = Double.parseDouble(num1.replace("$", ""));
						Double n2 = Double.parseDouble(num2.replace("$", ""));
						return (n1.compareTo(n2) * ord);
					}
				});
			} else {
				Collections.sort(dataList, new Comparator<String>() {
					public int compare(String data1, String data2) {
						return (data1.compareTo(data2) * ord);
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataList;
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i).split(" ")[0] + " / "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}
		return match;
	}

	public GiftCardsPage filterAndVerifyAllColumns(GiftCardsTabs giftCardsTab) {
		try {
			sleepFor(1000);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

	//		filterAndVerifyGiftCard(giftCardsTab, rowCount);
			filterAndVerifyClient(giftCardsTab, rowCount);
			filterAndVerifyTotalAmount(giftCardsTab, rowCount);
			filterAndVerifyRemainingAmount(giftCardsTab, rowCount);
		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public void filterAndVerifyGiftCard(GiftCardsTabs giftCardsTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[4]"));
			enterData(txtSearchGiftCard, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Gift Card is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Gift Card").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Gift Card: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Gift Card Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(giftCardsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// changes done by vidya on 04.04.2022
	public void filterAndVerifyClient(GiftCardsTabs giftCardsTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(1, rowCount);
			//filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);

		//	filterData = getData(
		//			By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[10]"));
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[13]"));
			enterData(txtSearchGiftCard, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Gift Card is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Client Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(giftCardsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyTotalAmount(GiftCardsTabs giftCardsTab, int rowCount) throws Exception {
		try {
			String filterData = "15";
			ArrayList<HashMap<String, String>> completeData = null;
			try {
				enterData(txtSearchGiftCard, filterData);
				sleepFor(1500);
				completeData = readCurrentTable();
				if (completeData.size() == 0) {
					throw new Exception("Searched Gift Card is not filtered.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						if (!eachRow.get("Total Amount").contains(filterData)) {
							throw new Exception(
									"Filtered Records doesn't have the expected Total Amount: " + filterData);
						}
					}
				}
				ExtentLogger.pass("Searching Functionality is Verifed for Total Amount Column");
				clickElement(By.xpath("//i[@class='ft-x']"));
				sleepFor(700);
				switchTo(giftCardsTab);
				sleepFor(700);
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyRemainingAmount(GiftCardsTabs giftCardsTab, int rowCount) throws Exception {
		try {
			String filterData = "10";
			ArrayList<HashMap<String, String>> completeData = null;
			try {
				enterData(txtSearchGiftCard, filterData);
				sleepFor(1500);
				completeData = readCurrentTable();
				if (completeData.size() == 0) {
					throw new Exception("Searched Gift Card is not filtered.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						if (!eachRow.get("Remaining Amount").contains(filterData)) {
							throw new Exception(
									"Filtered Records doesn't have the expected Remaining Amount: " + filterData);
						}
					}
				}
				ExtentLogger.pass("Searching Functionality is Verifed for Remaining Amount Column");
				clickElement(By.xpath("//i[@class='ft-x']"));
				sleepFor(700);
				switchTo(giftCardsTab);
				sleepFor(700);
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public GiftCardsPage clickAndChooseFilter(String filterType) {
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			ExtentLogger.pass("Successfully Selected as " + filterType + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}

		return this;
	}

	public GiftCardsPage applyFilter(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("client")) {

				filterValue = InputPropertyUtils.get("EXISTING_CLIENT_FOR_GIFTCARD");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} else if (filterType.equalsIgnoreCase("total amount") || filterType.equalsIgnoreCase("remaining amount")) {

				filterValue = "10.00";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterTextBoxes, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(btnApply, filterType)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} else {
				throw new Exception(filterType + " is not supported.");
			}
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}
		return this;
	}

	public GiftCardsPage verifyDashboard() {
		String filterType = "", filterValue = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDVALUE");

			completeData = readCurrentTable();
			if (filterType.equalsIgnoreCase("client")) {

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Client");
					}
				}
			} else if (filterType.equalsIgnoreCase("total amount")) {
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Total Amount").contains(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Total Amount");
					}
				}
			}

			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass(
					"Found " + completeData.size() + " matches after applying Filter. Verified all Matched Records has "
							+ filterType + " as " + filterValue + ".");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Dashboard after filtering. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage verifyStatusColumn(GiftCardsTabs giftCardsTab) {
		HashSet<String> colData;
		try {
			sleepFor(2000);
			colData = new HashSet<>(readCompleteColumnData(getColumntempIndex("Status"), giftCardsTab));
			for (String data : colData) {
				if (!data.trim().equalsIgnoreCase(getStringValue(giftCardsTab))) {
					throw new Exception("Status does not match");
				}
			}
			ExtentLogger.pass("Verify Data Present in Status Column in " + getStringValue(giftCardsTab) + " tab for "
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS"));
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Data in Status Column. " + e.getMessage());
		}
		return this;
	}

	public GiftCardsPage applyDateFilterAndVerify(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			// issued
			
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(txtDateFilter, filterSubType)));
			
			selectDate("15", "Dec", "2021");
			sleepFor(2000);
	    	DriverManager.getDriver().findElement(profileIconNew).click();
			sleepFor(1000);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				ExtentLogger.log("No Records Found for the Filter");
			} else {   

				if (filterType.equalsIgnoreCase("issued")) {
					for (HashMap<String, String> eachRow : completeData) {
				

						if (filterSubType.equalsIgnoreCase("on")) {
							if (!eachRow.get("Issued").contains("Dec 15, 2021")) {

								ExtentLogger.fail("Applied " + filterSubType + " SubFilter and Verified Filtered Record");


								throw new Exception(
										"Filtered Records doesn't have the expected Issued Date On: " + "Dec 15");
								

								
								
							}
							
							sleepFor(5000);
						} else if (filterSubType.equalsIgnoreCase("after")) {
							if (compareDate("after", "Dec 15, 2021", eachRow.get("Issued").trim())) {
								throw new Exception("Filtered Records doesn't have Issued Date After: " + "Dec 15");
							}
						} else if (filterSubType.equalsIgnoreCase("before")) {
							if (compareDate("before", "Dec 15, 2021", eachRow.get("Issued").trim())) {
								throw new Exception("Filtered Records doesn't have Issued Date Before: " + "Dec 15");
							}
						}
					}
				} else if (filterType.equalsIgnoreCase("expired")) {
					for (HashMap<String, String> eachRow : completeData) {

						
						if (filterSubType.equalsIgnoreCase("on")) {
							if (!eachRow.get("Expired").contains("Dec 15, 2021")) {
								throw new Exception("Filtered Records doesn't have the expected Expired Date On: " + "Dec 15");
							}
						} else if (filterSubType.equalsIgnoreCase("after")) {
							if (compareDate("after", "Dec 15, 2021", eachRow.get("Expired").trim())) {
								throw new Exception("Filtered Records doesn't have Expired Date After: " + "Dec 15");
							}
						} else if (filterSubType.equalsIgnoreCase("before")) {
							if (compareDate("before", "Dec 15, 2021", eachRow.get("Expired").trim())) {
								throw new Exception("Filtered Records doesn't have Expired Date Before: " + "Dec 15");
							}
						}
					}
				}

			}
			ExtentLogger.pass("Applied " + filterSubType + " SubFilter and Verified Filtered Record");
		} catch (Exception e) {
			Assert.fail("Failed in Applying Date Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public LocalDate selectRandDate(long daysAfter) throws Exception {
		int i = 0;
		LocalDate date;
		try {
			date = LocalDate.now().plusDays(daysAfter);
			selectDate(String.valueOf(date.getDayOfMonth()),
					StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
					String.valueOf(date.getYear()));

		} catch (Exception e) {
			throw new Exception("Unable to select date of " + i + " days from Today");
		}
		return date;
	}

	public void selectDate(String day, String month, String year) {
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			clickElement(By.xpath("//div[text()='" + day + "' and @class='btn-light ng-star-inserted']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// index values changes done by Vidya on 04.07.2022
	public int getColumntempIndex(String colName) throws Exception {
		int index = 0;
	//	if (colName.equalsIgnoreCase("gift card"))
			if (colName.equalsIgnoreCase("group order gift card"))	
			//index = 4;
			index = 5;
		else if (colName.equalsIgnoreCase("status"))
			index = 7;
		//	index = 10;
		else if (colName.equalsIgnoreCase("client"))
			//index = 10;
			index = 13;
		else if (colName.equalsIgnoreCase("total amount"))
			 index = 15;
		//	index =18;
		else if (colName.equalsIgnoreCase("remaining amount"))
			index = 18;
		//	index = 23;
		else if (colName.equalsIgnoreCase("issued"))
			index = 21;
		//	index  = 28;
		else if (colName.equalsIgnoreCase("expired"))
			index = 24;
		//	index = 33;

		return index;
	}

	public String getStringValue(GiftCardsTabs giftCardsTab) {
		String tabString = "";
		if (giftCardsTab.equals(GiftCardsTabs.ACTIVE)) {
			tabString = "Active";
		} else if (giftCardsTab.equals(GiftCardsTabs.ALL)) {
			tabString = "All";
		} else if (giftCardsTab.equals(GiftCardsTabs.DISABLED)) {
			tabString = "Disabled";
		}
		return tabString;
	}

	public void compareDate() {
		try {
			LocalDate date1 = LocalDate.of(getInt("2021"), getNumericMonth("Dec"), getInt("3"));
			LocalDate date2 = LocalDate.of(getInt("2021"), getNumericMonth("Dec"), getInt("4"));

			System.out.println(date1.isAfter(date2));
			System.out.println(date1.isBefore(date2));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public boolean compareDate(String type, String dateString1, String dateString2) {

		LocalDate date1 = LocalDate.of(getInt(dateString1.split(" ")[2]), getNumericMonth(dateString1.split(" ")[0]),
				getInt(dateString1.split(" ")[1].replace(",", "")));
		LocalDate date2 = LocalDate.of(getInt(dateString2.split(" ")[2]), getNumericMonth(dateString2.split(" ")[0]),
				getInt(dateString2.split(" ")[1].replace(",", "")));

		if (type.equalsIgnoreCase("after")) {
			return date1.isAfter(date2);
		} else if (type.equalsIgnoreCase("before")) {
			return date1.isBefore(date2);
		}

		return false;
	}

	public int getInt(String data) {
		return Integer.parseInt(data);
	}

	public int getNumericMonth(String month) {
		switch (month.toLowerCase()) {
		case "jan":
			return 1;
		case "feb":
			return 2;
		case "mar":
			return 3;
		case "apr":
			return 4;
		case "may":
			return 5;
		case "jun":
			return 6;
		case "jul":
			return 7;
		case "aug":
			return 8;
		case "sep":
			return 9;
		case "oct":
			return 10;
		case "nov":
			return 11;
		case "dec":
			return 12;

		default:
			return 0;
		}
	}

	
	public GiftCardsPage enterCancelNewClient(String type) {
		String clientName = "";
		try {
			
			if (type.equalsIgnoreCase("existing")) {
				clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_GIFTCARD");
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			} else if (type.equalsIgnoreCase("new")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createAndCanelClient();
				sleepFor(1000);
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				sleepFor(1000);
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			ExtentLogger.pass("Entered Client Details Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Client Details. " + e.getMessage());
		}
		return this;
	}
	
	public GiftCardsPage createAndCanelClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);
			clickElementJS(drpDwnSchool);
			sleepFor(200);
			enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganization);
			sleepFor(200);
			enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(200);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));

			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

			clickElementJS(btnCancelClient);
			sleepFor(500);
			clickElement(selectYes);
			
			sleepFor(1000);
			ExtentLogger.pass("Closed Client for Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Failed to close Client for Proof. " + e.getMessage());
		}
		return this;
	}	
	
	public GiftCardsPage connectdb() {

		try {

			DBSetupUtils.setupUserDatabase();
			sleepFor(500);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return this;
	}
	
}
