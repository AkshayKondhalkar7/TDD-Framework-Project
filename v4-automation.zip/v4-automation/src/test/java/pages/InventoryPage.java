package pages;

import static appConstants.ApplicationConstants.INVENTORY_STOCK_ADDED_MESSAGE;
import static appConstants.ApplicationConstants.INVENTORY_STOCK_UPDATED_MESSAGE;

import java.text.SimpleDateFormat;
//import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.InventoryPageElements;
import reports.ExtentLogger;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class InventoryPage extends MasterPage implements InventoryPageElements {

	ArrayList<Object> dateVerify = new ArrayList<Object>();

	public boolean switchToNextTab() {
		try {
			if (findElementPresence(divNextTab)) {
				clickElementJS(divNextTab);
				return true;
			}
		} catch (Exception e) {
			Assert.fail("Failed in Switching to Next Tab");
		}
		return false;
	}

	public InventoryPage switchTo(String tabName) {
		try {
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, tabName)));

			ExtentLogger.pass("Switched to " + tabName + " Tab.");

		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + tabName + " Tab. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage filterDataAndVerify(String type) {
		int rowCount = 0;
		try {
			sleepFor(1000);
			rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			System.out.println(rowCount);

			if (type.equalsIgnoreCase("Product Name"))
				filterAndVerifyProductName(rowCount);
			else if (type.equalsIgnoreCase("Style Code"))
				filterAndVerifyStyleCode(rowCount);

		} catch (Exception e) {
			Assert.fail("Failed in Filtering Data. " + e.getMessage());
		}
		return this;
	}

	public void filterAndVerifyProductName(int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "";
		int filterIdx = 0;
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			System.out.println("filterIdx = " + filterIdx);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[9]"));
//			filterData = getData(
//					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[12]"));
			System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[9]");
			enterData(txtSearchInventoryItem, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Product Name is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Product Name").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Product Name: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Product Name");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyStyleCode(int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "";
		int filterIdx = 0;
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[5]"));
			enterData(txtSearchInventoryItem, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Style Code is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Style Code").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Style Code: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Style Code");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// changes done by Vidya
	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		String loggedInAs = "";
		try {
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");

//			if (loggedInAs.equalsIgnoreCase("admin")) {
			for (int i = 2; i <= 11; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
				header.add(colData);
			}
			header.add("Restock Date");
			for (int i = 2; i <= rowCount; i++) {
				HashMap<String, String> eachRow = new HashMap<>();
				int temp1 = 3, temp2 = 20;
				// int temp1 = 5, temp2 = 26;
				// for (int j = 2; j <= 12; j++)
				for (int j = 2; j <= 11; j++) {
					String data = "";
					// if (j <= 7)
					if (j <= 7) {
						System.out.println("if");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]"));

						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]");
						temp1 += 3;
						// temp1 += 5;
					} else {
						System.out.println("else");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]");
						temp2 += 2;
					}
					eachRow.put(header.get(j - 2), data);
				}
				fullData.add(eachRow);
				System.out.println(eachRow);
			}
//			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;
	}

	// changes done by Vidya //
	public InventoryPage sortAndVerifyAllTabs() {
		// String[] colnames = { "Style Code", "Product Name", "Blank Price","Restock
		// Date" };
		String[] colnames = { "Style Code", "Product Name", "Blank Cost", "Restock Date" };
		ArrayList<String> actualColData = null;
		try {
			sleepFor(2000);
			do {
				for (String column : colnames) {
					actualColData = new ArrayList<>();
					actualColData.addAll(readCompleteColumnData(getColumntempIndex(column)));

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column in "
							+ getData(By.xpath("//div[contains(@class,'pill tabs__tab--active')]")) + " Tab.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			} while (switchToNextTab());
			sleepFor(500);
		} catch (Exception e) {
			Assert.fail("Failed in Sorting and Verifying Columns. " + e.getMessage());
		}
		return this;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
				System.out.println("maxRow = " + maxRow);

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));
				System.out.println("records = " + records);

				columnData.addAll(readColumnData(colIdx));

				int tempCount = records - maxRow;

				while (tempCount > 0) {

					// scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					scrollToElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(2000);
					// clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					clickElementJS(By.xpath("//i[@class='datatable-icon-skip']//parent::a"));
					sleepFor(2000);

					columnData.addAll(readColumnData(colIdx));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));

				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}
		return columnData;
	}

	public void getSortedDataAndCompare(String colName, ArrayList<String> actualColData, String order)
			throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName)));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Correctly in Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;

		if (colName.equalsIgnoreCase("blank cost")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String num1, String num2) {
					Double n1 = Double.parseDouble(num1.replace("$", ""));
					Double n2 = Double.parseDouble(num2.replace("$", ""));
					return (n1.compareTo(n2) * ord);
				}
			});
		} else {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String data1, String data2) {
					return (data1.compareTo(data2) * ord);
				}

			});
		}

		return dataList;
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).equalsIgnoreCase(actualList.get(i)))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i) + " / " + actualList.get(i));
				match = false;
				break;
			}
		}

		return match;
	}

	public InventoryPage filterProduct() {
		String existingProduct = "";
		try {
			existingProduct = InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS");
			enterData(txtSearchInventoryItem, existingProduct);

			sleepFor(6000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", existingProduct);
			ExtentLogger.pass("Successfully Filtered the Product: " + existingProduct);

		} catch (Exception e) {
			Assert.fail("Unable to Filter Product. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage chooseProducts(int count) {
		try {
			for (int i = 1; i <= count; i++) {

				// scrollToElementBy.xpath("(//div[@class='position-absolute
				// checkbox-wrapper'])[" + i + "]"));
				// sleepFor(3000);
				clickElement(By.xpath("(//datatable-body-row)[" + i + "]"));
				sleepFor(3000);
				By selectCheckBox = By.xpath("(//div[@class='position-absolute checkbox-wrapper'])[" + i + "]");
				// clickElement(By.xpath("(//div[@class='position-absolute checkbox-wrapper'])["
				// + i +"]"));
				clickElementJS(selectCheckBox);
				clickElementJS(selectCheckBox);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COUNT", String.valueOf(count));
			ExtentLogger.pass("Successfully Choosed " + count + " Products");
		} catch (Exception e) {
			Assert.fail("Unable to Choose Products. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage chooseProducts(String productType) {
		String product1 = null, product2 = null;
		try {
			product1 = InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS");
			product2 = InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS_MULTITAB");

			switchTo(product1);
			sleepFor(1000);
			// clickElement(By.xpath("(//datatable-body-row)[1]"));
			By selectCheckBox = By.xpath("(//div[@class='position-absolute checkbox-wrapper'])[1]");
			clickElementJS(selectCheckBox);

			switchTo(product2);
			sleepFor(1000);
			// clickElement(By.xpath("(//datatable-body-row)[1]"));
			clickElementJS(selectCheckBox);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COUNT", "2");
			ExtentLogger.pass("Successfully Choosed Products from Multiple Tabs");
		} catch (Exception e) {
			Assert.fail("Unable to Choose Products from Multiple Tabs. " + e.getMessage());
		}
		return this;

	}

	public InventoryPage clickAddIncomingStocksButton(int iteration) {

		try {
			sleepFor(6000);
			clickElement(btnAddIncomingStock);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, labelAddIncomingStock);

			ExtentLogger.pass("Successfully Clicked Add Incoming Stocks Button");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ITERATION", String.valueOf(iteration));
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Add Incoming Stocks Button. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage clickEditStocksButton(int iteration) {
		try {

			sleepFor(3000);
			clickElementJS(btnEditIncomingStocks);

			// ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
			// btnEditIncomingStocks);

			ExtentLogger.pass("Successfully Clicked Edit Stocks Button");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ITERATION", String.valueOf(iteration));
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Edit Stocks Button. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage enterStockDetails() {
		int count = 0;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null, color = null, stylecode = null; // xl2qty
																													// =
																													// null,//
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			for (int i = 1; i <= count; i++) {
				sleepFor(2000);
				sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtSQty, String.valueOf(i))), sqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtMQty, String.valueOf(i))), mqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtLQty, String.valueOf(i))), lqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtXLQty, String.valueOf(i))), xlqty);
				
				
				
				
				
				
				
				
				System.out.println("sqty = " + sqty);
				System.out.println("mqty = " + mqty);
				System.out.println("lqty = " + lqty);
				System.out.println("lqty = " + lqty);

				// clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtStockDate,
				// String.valueOf(i))));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(txtStockDate, String.valueOf(i))));

				System.out.println("String.valueOf(i) =" + String.valueOf(i));
				date = selectRandDate(ThreadLocalRandom.current().nextInt(2, 5));
				sleepFor(5000);
				System.out.println("date =" + date);
				date = getTheSubString(date);

				getStyleCodeAndColor();
	
				
				

				
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" + i, sqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" + i, mqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" + i, lqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY" + i, xlqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE" + i, date);

			}
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Failed in Adding Stock Details. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage enterStockDetailsforNextmonth() {
		int count = 0;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null, color = null, stylecode = null; // xl2qty
																													// =
																													// null,//
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			for (int i = 1; i <= count; i++) {
				sleepFor(2000);
				sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtSQty, String.valueOf(i))), sqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtMQty, String.valueOf(i))), mqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtLQty, String.valueOf(i))), lqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtXLQty, String.valueOf(i))), xlqty);
			

				System.out.println("sqty = " + sqty);
				System.out.println("mqty = " + mqty);
				System.out.println("lqty = " + lqty);
				System.out.println("lqty = " + lqty);
				System.out.println("date =" + date);

				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtStockDate, String.valueOf(i))));

				System.out.println("String.valueOf(i) =" + String.valueOf(i));
				date = selectRandomDate(ThreadLocalRandom.current().nextInt(29, 32));
				System.out.println("date =" + date);
				date = getTheSubString(date);
				getStyleCodeAndColor();
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" + i, sqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" + i, mqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" + i, lqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY" + i, xlqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE" + i, date);
			
			}
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Failed in Adding Stock Details. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage enterStockDetailsforCurrentDate() {
		int count = 0;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null; // xl2qty = null,//
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			for (int i = 1; i <= count; i++) {
				sleepFor(2000);
				sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtSQty, String.valueOf(i))), sqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtMQty, String.valueOf(i))), mqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtLQty, String.valueOf(i))), lqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtXLQty, String.valueOf(i))), xlqty);

				System.out.println("sqty = " + sqty);
				System.out.println("mqty = " + mqty);
				System.out.println("lqty = " + lqty);
				System.out.println("lqty = " + lqty);
				System.out.println("date =" + date);

				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtStockDate, String.valueOf(i))));

				System.out.println("String.valueOf(i) =" + String.valueOf(i));
				date = selectRandDate(0);
				System.out.println("date =" + date);
				date = getTheSubString(date);
				getStyleCodeAndColor();
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" + i, sqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" + i, mqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" + i, lqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY" + i, xlqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE" + i, date);
			}
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Failed in Adding Stock Details. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage saveStocks(String operationType) {
		try {
			if (operationType.equalsIgnoreCase("Add")) {
				clickElement(btnAddStocks);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + INVENTORY_STOCK_ADDED_MESSAGE + "')]"));

				ExtentLogger.pass("Added Stocks Successfully");
			} else if (operationType.equalsIgnoreCase("Update")) {
				clickElement(btnUpdateStocks);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + INVENTORY_STOCK_UPDATED_MESSAGE + "')]"));

				ExtentLogger.pass("Updated Stocks Successfully");
			}
		} catch (Exception e) {
			Assert.fail("Failed in Saving Stocks. " + e.getMessage());
		}
		return this;
	}

	/**
	 * @param tabType
	 * @return
	 */
	
	public InventoryPage expandProductDetailsAndVerifyStocks(String tabType) {
		
		
		sleepFor(3000);

		int count = 0;
		String iteration = null;
		Integer externalCounter = DriverManager.getDriver().findElements(By.xpath("//*[contains(@id,'data-cell-style_code')]")).size();
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null; // xl2qty = null,//
		ArrayList<String> products = new ArrayList<>();

		List<WebElement> stylelist = DriverManager.getDriver()
				.findElements(By.xpath("//*[contains(@id,'data-cell-style_code')]"));
		List<WebElement> colorlist = DriverManager.getDriver().findElements(By.xpath("//*[contains(@id,'data-cell-color')]"));
		List<String> colorArrayList = mapcolorStyleMap.get("colorCode");
		List<String> styleArrayList = mapcolorStyleMap.get("styleCode");


		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));
			iteration = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ITERATION");
			products.add(InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS"));
			products.add(InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS_MULTITAB"));

			if (tabType.equalsIgnoreCase("Single Tab")) {

				for (int j = colorArrayList.size()-1; j > -1; j--) {

					for (int i = 0; i < externalCounter; i++) {
						if (colorlist.get(i).getText().contains(colorArrayList.get(j)) && stylelist.get(i).getText().contains(styleArrayList.get(j))) {
							System.out.println("coming inside if condition");
							System.out.println("count = " + count);
							System.out.println("i = " + i);
							System.out.println("products = " + products);
							sleepFor(5000);
							
							
							
							
					sleepFor(4000);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i+1))));
					sleepFor(5000);
					
					
					
					sqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(1))));
					mqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(1))));
					lqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(1))));
					xlqty = getData(
							By.xpath(DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(1))));

					date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(1))))
							.split("  ")[0];
					date = getTheSubString(date);

					Assert.assertEquals(sqty,	RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + (j+1)), "UnExpected S Qty");
					
					Assert.assertEquals(mqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + (j+1)),
							"UnExpected M Qty");
					Assert.assertEquals(lqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + (j+1)),
							"UnExpected L Qty");
					Assert.assertEquals(xlqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + (j+1)),
							"UnExpected XL Qty");

					Assert.assertEquals(date,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + (j+1)),
							"UnExpected Date");
					
					

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i+1))));
					sleepFor(500);
					break;
					
						}
					}
				}
				}
			 else if (tabType.equalsIgnoreCase("Multiple ProductSingle_Tab")) {
				int temp = 0;

				
				
				if(colorArrayList !=null)
				
				for (int j = colorArrayList.size()-1; j > -1; j--) {

					for (int i = 0; i < externalCounter; i++) {
						if (colorlist.get(i).getText().contains(colorArrayList.get(j))
								&& stylelist.get(i).getText().contains(styleArrayList.get(j))) {
							System.out.println("coming inside if condition");
							System.out.println("count = " + count);
							System.out.println("i = " + i);
							System.out.println("products = " + products +colorArrayList.get(j) +"assert " +colorlist.get(i).getText() );
							sleepFor(5000);
							clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow,String.valueOf(i+1))));

//							clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow,String.valueOf(count - temp))));
							sleepFor(5000);
							sqty = getData(	By.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(1))));
							System.out.println("sty = " + sqty);
							System.out.println("iteration =" + iteration);
							System.out.println("String.valueOf(i) =" + String.valueOf(i));
							mqty = getData(
									By.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(1))));
							lqty = getData(
									By.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(1))));
							xlqty = getData(By
									.xpath(DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(1))));
							date = getData(
									By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(1))))
											.split("  ")[0];
							date = getTheSubString(date);

							Assert.assertEquals(sqty,
									RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + (j+1)),
									"UnExpected S Qty");
							Assert.assertEquals(mqty,
									RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + (j+1)),
									"UnExpected M Qty");
							Assert.assertEquals(lqty,
									RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + (j+1)),
									"UnExpected L Qty");
							Assert.assertEquals(xlqty,
									RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + (j+1)),
									"UnExpected XL Qty");

							Assert.assertEquals(date,
									RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + (j+1)),
									"UnExpected Date");

						//	clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow,String.valueOf(count - temp))));
							
							
							clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow,String.valueOf(i+1))));
							
							
							temp++;
							sleepFor(500);
							break;
							
						}
						
						

					}

				}

			} else if (tabType.equalsIgnoreCase("Different Product")) {

				int temp = 1;
				for (int i = 1; i <= count; i++) {

					// for (int i = count - 1; i >= 1; i--) {
					System.out.println("count = " + count);
					System.out.println("i = " + i);
					System.out.println("products = " + products);
					sleepFor(3000);

					switchTo(products.get(products.size() - temp));
					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(1))));
					sleepFor(5000);

					sqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(1))));
					System.out.println("sty = " + sqty);
					System.out.println("iteration =" + iteration);
					System.out.println("String.valueOf(i) =" + String.valueOf(i));

					mqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(1))));
					lqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(1))));
					xlqty = getData(
							By.xpath(DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(1))));
					date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(1))))
							.split("  ")[0];
					date = getTheSubString(date);

					Assert.assertEquals(sqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + i),
							"UnExpected S Qty");
					Assert.assertEquals(mqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + i),
							"UnExpected M Qty");
					Assert.assertEquals(lqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + i),
							"UnExpected L Qty");
					Assert.assertEquals(xlqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + i),
							"UnExpected XL Qty");

					Assert.assertEquals(date,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + i),
							"UnExpected Date");

					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(1))));
					temp++;
					sleepFor(500);
				}

			} else if (tabType.equalsIgnoreCase("Restock Date")) {

				// ArrayList<String> dateVerify= new ArrayList<String>();
				for (int i = 1; i <= count; i++) {
					sleepFor(4000);
					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i))));
					sleepFor(5000);
					date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(i))))
							.split("  ")[0];
					date = getTheSubString(date);

					Assert.assertEquals(date,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + i),
							"UnExpected Date");

					System.out.println("date = " + date);
					dateVerify.add(date);
					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i))));
					sleepFor(500);
				}
				System.out.println("dateVerify = " + dateVerify);
			} else if (tabType.equalsIgnoreCase("Delete")) {

				int tablecount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'incoming-stock__s')]")).size();
				if (tablecount == 0) {
					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(1))));
					int columncount = DriverManager.getDriver()
							.findElements(By.xpath("//div[@class='incoming-stock__title position-absolute']")).size();
					if (columncount == 0) {
						ExtentLogger.pass("Successfully deleted");
					} else {
						ExtentLogger.fail(" deletion unsuccessfull");
					}

				} else {

					for (int i = 1; i <= count; i++) {
						
						
						sleepFor(4000);
						clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i))));
						sleepFor(5000);
						sqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(i))));
						mqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(i))));
						lqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(i))));
						xlqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(i))));
						date = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(i))))
										.split("  ")[0];
						date = getTheSubString(date);

						Assert.assertEquals(sqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + i),
								"UnExpected S Qty");
						Assert.assertEquals(mqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + i),
								"UnExpected M Qty");
						Assert.assertEquals(lqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + i),
								"UnExpected L Qty");
						Assert.assertEquals(xlqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + i),
								"UnExpected XL Qty");
						Assert.assertEquals(date,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + i),
								"UnExpected Date");

						clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i))));
						sleepFor(500);

					}
				}

			} else {
				int temp = 0;
				int rowCheck = 0;
				int temp1 = 2;

				if(colorArrayList !=null)
					
					for (int j = colorArrayList.size()-1; j > -1; j--) {

				for (int i = 0; i <=count;) {
				//	for (int i = 1; i < count; i++) {


					// for (int i = count - 1; i >= 1; i--) {
					System.out.println("count = " + count);
					System.out.println("i = " + i);
					System.out.println("products = " + products);
					sleepFor(3000);
					
					sleepFor(3000);

					rowCheck = DriverManager.getDriver().findElements(By.xpath("(//div[contains(@class,'incoming-stock__s')])")).size();
					System.out.println("rowCheck = " + rowCheck);

					if (rowCheck < 2) {
						System.out.println(" temp " + temp);


						System.out.println(" color "+colorlist.get(i).getText()+ colorArrayList.get(j)
								
								
								
								+stylelist.get(i).getText().contains(styleArrayList.get(j)));

						if (colorlist.get(i).getText().contains(colorArrayList.get(j))
								&& stylelist.get(i).getText().contains(styleArrayList.get(j))) {
							clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i+1))));
							System.out.println("countandtemp = " +String.valueOf(count - temp));


						
							/*
							 * sqty = getData(By.xpath(
							 * DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(i -
							 * temp))));
							 * 
							 * System.out.println("sty = " + sqty); System.out.println("iteration =" +
							 * iteration); System.out.println("String.valueOf(i) =" + String.valueOf(i));
							 * mqty = getData(By.xpath(
							 * DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(i -
							 * temp)))); lqty = getData(By.xpath(
							 * DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(i -
							 * temp)))); xlqty = getData(By.xpath(
							 * DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(i -
							 * temp))));
							 * 
							 * date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable,
							 * String.valueOf(i - temp)))).split("  ")[0];
							 * 
							 * date = getTheSubString(date);
							 */
						
						
						
						sqty = getData(By.xpath(
								DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf((i+1)-temp))));

						System.out.println("sty = " + sqty);
						System.out.println("iteration =" + iteration);
						System.out.println("String.valueOf(i) =" + String.valueOf(1));
						mqty = getData(By.xpath(
								DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf((i+1)-temp))));
						lqty = getData(By.xpath(
								DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf((i+1)-temp))));
						xlqty = getData(By.xpath(
								DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf((i+1)-temp))));

						date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf((i+1)-temp)))).split("  ")[0];

						date = getTheSubString(date);

					}
						
					}
					if (rowCheck >= 2) {
						
						for (int val = 0; val <= rowCheck; val++) {
							if (colorlist.get(i).getText().contains(colorArrayList.get(val))
									&& stylelist.get(i).getText().contains(styleArrayList.get(val))) {
							
							System.out.println("val =" + val);
							System.out.println(getData(By.xpath(
									DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(val+2)))));
							sqty = getData(By
									.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(val+2))));

							System.out.println("sty = " + sqty);
							System.out.println("iteration =" + iteration);
							mqty = getData(By
									.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(val+2))));
							System.out.println("mqty = " + mqty);
							lqty = getData(By
									.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(val+2))));
							System.out.println("lqty = " + lqty);
							xlqty = getData(By.xpath(
									DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(val+2))));
							System.out.println("xlqty = " + xlqty);

							date = getData(By
									.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(val+2))))
											.split("  ")[0];
							date = getTheSubString(date);

						}
							
					}
					}

					/*
					 * String s = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),
					 * "SQTY" + (i+1)); String m =
					 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" +
					 * (i+1)); String L =
					 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" +
					 * (i+1)); String x =
					 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" +
					 * (i+1)); String D =
					 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" +
					 * (i+1));
					 * 
					 * System.out.println(s+":"+m+":" +L+":"+x+":"+D );
					 */

					Assert.assertEquals(sqty, RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + (j+1) ), "UnExpected S Qty");				
					Assert.assertEquals(mqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + (j+1)),
							"UnExpected M Qty");
					Assert.assertEquals(lqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + (j+1)),
							"UnExpected L Qty");
					Assert.assertEquals(xlqty,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + (j+1)),
							"UnExpected XL Qty");

					Assert.assertEquals(date,
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + (j+1)),
							"UnExpected Date");
					
					

				//	clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(count - temp))));
					clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(i+1))));


					sleepFor(500);
									temp++;
									i++;
									break;

					}
					}
			

			}
			ExtentLogger.pass("Successfully Verified Stocks for " + tabType);
		} catch (Exception e) {
			Assert.fail("Failed in Expanding Product Details and Verify Stocks. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage expandProductDetailsAndVerifyRestockDate(int iteration) {

		String date = null;
		try {
			sleepFor(4000);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(1))));
		} catch (Exception e) {
			Assert.fail("Failed in Expanding Stock Details " + e.getMessage());
		}

		try {
			for (int i = 1; i <= iteration; i++) {
				sleepFor(5000);
				date = getData(By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(i))))
						.split("  ")[0];

				System.out.println("date = " + date);
				dateVerify.add(date);
				sleepFor(500);

			}

			System.out.println("dateVerify = " + dateVerify);
			ArrayList<Date> rawdates = new ArrayList<Date>();
			for (Object s : dateVerify) {
				Date date1 = new SimpleDateFormat("MMM dd").parse(s.toString());
				rawdates.add(date1);
			}

			Collections.sort(rawdates, new sortCompare());
			System.out.println(" after sort = " + rawdates);

			Date expectedDate = new SimpleDateFormat("MMM dd").parse(getData(restockdate).toString());

			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(1))));

			if (expectedDate.equals(rawdates.get(0)))
				ExtentLogger.pass("Dates are displayed in ascending Order");
			else
				ExtentLogger.fail("Dates are not displayed in ascending Order");

		} catch (Exception e) {
			Assert.fail("Failed in Expanding Product Details and Verify ReStock Date. " + e.getMessage());
		}

		return this;
	}

	class sortCompare implements Comparator<Date> {

		@Override
		public int compare(Date a, Date b) {
			/* Returns sorted data in ascending order */
			return a.compareTo(b);
		}
	}

	public InventoryPage verifyEditedStocks() {
		ArrayList<HashMap<String, String>> completeData = null;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null, iteration = "1"; // xl2qty = null,//
		int count = 0;
		HashMap<String, String> eachRow = null;
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));
			completeData = readCurrentTableforEdit();
			for (int i = 1; i <= count; i++) {
				sqty = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + i);
				mqty = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + i);
				lqty = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + i);
				xlqty = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + i);
				// xl2qty = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),
				// "XL2QTY" + i);
				// date = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE"
				// + i);

				eachRow = completeData.get(i - 1);

				for (HashMap<String, String> eachRow1 : completeData) {
					if (!eachRow1.get("S").trim().equalsIgnoreCase(sqty)) {
						System.out.println(eachRow1.get("S"));
						throw new Exception("Filtered Records doesn't have the expected S Quantity: " + sqty);
					}
					if (!eachRow1.get("M").trim().equalsIgnoreCase(mqty)) {
						System.out.println("M" + eachRow1.get("M"));
						throw new Exception("Filtered Records doesn't have the expected M Quantity: " + mqty);
					}
					if (!eachRow1.get("L").trim().equalsIgnoreCase(lqty)) {
						System.out.println("L" + eachRow1.get("L"));
						throw new Exception("Filtered Records doesn't have the expected L Quantity: " + lqty);
					}
					if (!eachRow1.get("XL").trim().equalsIgnoreCase(xlqty)) {
						System.out.println("XL" + eachRow1.get("XL"));
						throw new Exception("Filtered Records doesn't have the expected XL Quantity: " + xlqty);
					}
//					if (!eachRow1.get("Restock Date").trim().equalsIgnoreCase(date)) {
//						System.out.println(eachRow1.get("Date"));
//						throw new Exception("Filtered Records doesn't have the expected Date: " + date);
//					}
					break;
				}
			}
			ExtentLogger.pass("Successfully Verified Edited Stocks");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Verifying Edited Stocks. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage verifyMenuAbsence() {

		DBSetupUtils.setupUserDatabase();
		sleepFor(3000);
		try {

			if (findElementPresence(
					By.xpath("//div[@class='inventory-table__add-button']//parent::div[contains(@class,' visible')]")))
				throw new Exception("Add Incoming Stocks Icon & Edit stock Button is displayed without any selection");

			ExtentLogger.pass("Verified that Edit and Add Stocks Menu are not displayed by Default");
		} catch (Exception e) {
			ExtentLogger.fail("Failed in Verifying Menus. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage verifyProductNamesInAllTabs() {
		String currentTab = null;
		HashSet<String> actualColData = null;

		try {
			switchToNextTab();
			do {
				sleepFor(1000);
				currentTab = getData(divCurrentTab);
				actualColData = new HashSet<>(readCompleteColumnData(getColumntempIndex("Product Name")));

				for (String data : actualColData) {
					if (!data.equalsIgnoreCase(currentTab)) {
						throw new Exception("Product Name doesnot Match in" + currentTab + " tab");
					}
				}

				ExtentLogger.pass("Veirifed Product Name displayed in " + currentTab + " Tab");
			} while (switchToNextTab());

		} catch (Exception e) {
			Assert.fail("Failed in Verifying Product Name. " + e.getMessage());
		}
		return this;
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	// Changes done by Vidya
	public int getColumntempIndex(String column) {
		switch (column.toLowerCase()) {
		case "image":
			return 4;

		case "style code":
			return 6;

		case "product name":
			return 9;
		// return 11;

		case "color":
			return 12;
		// return 16;

//		case "blank price":
		case "blank cost":
			return 15;
		// return 21;

		case "retail cost":
			return 18;

		case "s":
			return 21;
		// return 18;
		// return 26;

		case "m":
			return 23;
		// return 20;
		// return 28;

		case "l":
			return 25;
		// return 22;
		// return 30;

		case "xl":
			return 27;
		// return 24;
		// return 32;

//		case "2xl":
//			return 26;

		case "restock date":
			return 29;
		// return 28;
		// return 34;

		default:
			break;
		}

		return 0;
	}

	public String selectRandDate(long daysAfter) throws Exception {
		int i = 0;
		// LocalDate date;
		LocalDateTime date;

		try {
			// date = LocalDate.now().plusDays(daysAfter);
			date = LocalDateTime.now().plusDays(daysAfter);
			selectDate(String.valueOf(date.getDayOfMonth()),
					StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
					String.valueOf(date.getYear()));

		} catch (Exception e) {
			throw new Exception("Unable to select date of " + i + " days from Today");
		}
		return StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)) + " "
				+ String.valueOf(date.getDayOfMonth());
	}

	public String selectRandomDate(long daysAfter) throws Exception {
		int i = 0;
		// LocalDate date;
		LocalDateTime date;

		try {
			// date = LocalDate.now().plusDays(daysAfter);
			date = LocalDateTime.now().plusDays(daysAfter);
			selectDate(String.valueOf(1),
					StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
					String.valueOf(date.getYear()));

		} catch (Exception e) {
			throw new Exception("Unable to select date of " + i + " days from Today");
		}
		return StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)) + " "
				+ String.valueOf(1);
	}

	public void selectDate(String day, String month, String year) {
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			sleepFor(2000);
			clickElementJS(By.xpath("(//div[text()='" + day + "' and contains(@class,'btn-light')]//parent::div)[1]"));
//			clickElementJS(By.xpath("//div[text()='" + day + "' and @class='btn-light ng-star-inserted']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public InventoryPage clickDeleteButton() {
		try {

			clickElementJS(btnDeleteStock);
			System.out.println("clicked Delete stock button");
			sleepFor(4000);
			clickElementJS(btnDeleteConfirm);
			System.out.println("Deleted Stock");
			sleepFor(2000);
			// ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
			// labelDeleteStock);

			ExtentLogger.pass("Successfully Clicked Delete Stocks Button");
			// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ITERATION",
			// String.valueOf(iteration));
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Delete Stocks Button. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage clickCloseEditButton() {
		try {

			clickElementJS(btnCloseEditStock);
			System.out.println("clicked close edit button");
			sleepFor(4000);

			ExtentLogger.pass("Successfully Clicked Close Edit Stocks Button");
			// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),
			// "ITERATION",String.valueOf(iteration));
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Close Edit Button. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage verifyDeletedStocks() {

		String existingProduct = "";
		try {
			existingProduct = InputPropertyUtils.get("EXISTING_PRODUCTNAME_FOR_ADDINGSTOCKS");
			enterData(txtSearchInventoryItem, existingProduct);
			sleepFor(6000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", existingProduct);
			sleepFor(2000);
			int count = 1;
			for (int i = 1; i <= count; i++) {
				sleepFor(300);
				clickElement(By.xpath("(//datatable-body-row)[" + i + "]"));
				sleepFor(5000);
			}
			sleepFor(5000);
			ExtentLogger.pass("Successfully to Verified Deleted Stocks");
		} catch (Exception e) {
			Assert.fail("Failed to Verify Deleted Stocks. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage deleteMultipleStock(int count) {
		try {

			for (int i = 1; i <= count; i++) {

				clickElementJS(btnDeleteStock);
				System.out.println("clicked Delete stock button");
				sleepFor(4000);
				clickElementJS(btnDeleteConfirm);
				System.out.println("Deleted Stock");
				sleepFor(2000);

			}

			ExtentLogger.pass("Successfully Delete Multiple  Stocks Button");

		} catch (Exception e) {
			Assert.fail("Failed in Clicking Delete Multiple Stocks Button. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage EditExistingStocks() {
		int count = 0;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null; // xl2qty = null,//
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			for (int i = 1; i <= count; i++) {
				sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
				// xl2qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtSQty, String.valueOf(i))), sqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtMQty, String.valueOf(i))), mqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtLQty, String.valueOf(i))), lqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtXLQty, String.valueOf(i))), xlqty);
				// enterData(By.xpath(DynamicXpathUtils.getXpathForString(txt2XLQty,
				// String.valueOf(i))), xl2qty);

				// clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtStockDate,
				// String.valueOf(i))));

				System.out.println(String.valueOf(i));
				// date = selectRandDate(ThreadLocalRandom.current().nextInt(2, 5));
				// date = selectRandDate(2);

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" + i, sqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" + i, mqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" + i, lqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY" + i, xlqty);
				// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XL2QTY" + i,
				// xl2qty);
				// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE" + i,
				// date);
			}
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Failed in Adding Stock Details. " + e.getMessage());
		}
		return this;
	}

	/* added by vidya on 03.29.2022 */
	public InventoryPage logOutInv() {

		DBSetupUtils.setupUserDatabase();
		sleepFor(2000);
		try {

			System.out.println(DriverManager.getDriver().findElement(profileIconNew).getText());
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(profileIconNew));
			sleepFor(3000);
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(lnkLogoutMenu));

			ExtentLogger.pass("Logged Out of the Application");
			// DBSetupUtils.setupUserDatabase();

		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return new InventoryPage();
	}

	// Added by vidya
	public ArrayList<HashMap<String, String>> readCurrentTableforEdit() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		String loggedInAs = "";
		try {
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");

//			if (loggedInAs.equalsIgnoreCase("admin")) {
			for (int i = 2; i <= 11; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
				header.add(colData);
			}
			header.add("Restock Date");
			for (int i = 2; i <= rowCount; i++) {
				HashMap<String, String> eachRow = new HashMap<>();
				int temp1 = 3, temp2 = 23;
				// int temp1 = 3, temp2 = 20;
				// int temp1 = 5, temp2 = 26;
				// for (int j = 2; j <= 12; j++)
				for (int j = 2; j <= 12; j++) {
					String data = "";
					// if (j <= 7)
					if (j <= 8) {
						System.out.println("if");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]"));

						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]");
						temp1 += 3;
						// temp1 += 5;
					} else {
						System.out.println("else");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]");
						temp2 += 2;
					}
					eachRow.put(header.get(j - 2), data);
				}
				fullData.add(eachRow);
				System.out.println(eachRow);
			}
//			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;
	}

	public InventoryPage EditIncomingStocks() {
		int count = 0;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null;
		try {
			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			for (int i = 1; i <= count; i++) {
				sqty = String.valueOf(ThreadLocalRandom.current().nextInt(5, 15));
				mqty = String.valueOf(ThreadLocalRandom.current().nextInt(5, 15));
				lqty = String.valueOf(ThreadLocalRandom.current().nextInt(5, 15));
				xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(5, 15));

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtIncomeSQty, String.valueOf(i))), sqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtIncomeMQty, String.valueOf(i))), mqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtIncomeLQty, String.valueOf(i))), lqty);
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtIncomeXLQty, String.valueOf(i))), xlqty);

				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtIncomeStockDate, String.valueOf(i))));

				System.out.println(String.valueOf(i));
				// date = selectRandDate(ThreadLocalRandom.current().nextInt(7, 9));
				date = selectRandDate(2);

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" + i, sqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" + i, mqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" + i, lqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY" + i, xlqty);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE" + i, date);
			}
			ExtentLogger.pass("Successfully Edited Incoming Stock Details");
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Failed in Edit Incoming Stock Details. " + e.getMessage());
		}
		return this;
	}

	public InventoryPage expandProductDetails(String tabType) {

		String color = "";
		String[] colnames = { "color" };
		ArrayList<String> actualColData = null;
		int count = 0;
		try {
			for (String column : colnames) {
				actualColData = new ArrayList<>();

				if (tabType.equalsIgnoreCase("Single Tab")) {
					count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));
					color = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLOR");
					clickElement(
							By.xpath(DynamicXpathUtils.getXpathForString("(//div[contains(text(),'%s')])[1]", color)));
				}

				if (tabType.equalsIgnoreCase("Multiple Product_MultiStock_Single_Tab")) {
					int temp = 0;
					count = 3;
					for (int i = 1; i <= count; i++) {
						int a = count - temp;
						if (a == 3) {
							color = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLOR");
							clickElement(By.xpath(
									DynamicXpathUtils.getXpathForString("(//div[contains(text(),'%s')])[1]", color)));
						}
						if (a == 2) {
							color = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "2COLOR");
							clickElement(By.xpath(
									DynamicXpathUtils.getXpathForString("(//div[contains(text(),'%s')])[1]", color)));
						}
						if (a == 1) {
							color = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "3COLOR");
							clickElement(By.xpath(
									DynamicXpathUtils.getXpathForString("(//div[contains(text(),'%s')])[1]", color)));
						}
						temp++;
					}
				}
			}

		} catch (Exception e) {
			Assert.fail("Failed in expand Product Details. " + e.getMessage());
		}

		return this;
	}

	public InventoryPage getColor(String tabType) {

		int count = 0;
		String color = "", color2 = "", color3 = "";
		try {

			count = Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COUNT"));

			if (tabType.equalsIgnoreCase("Single Tab")) {
				color = getData(singleColor);
				System.out.println("color = " + color);

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
			}

			if (tabType.equalsIgnoreCase("Multiple Product_MultiStock_Single_Tab")) {

				for (int i = 1; i <= count; i++) {

					if (i == 1) {
						color = getData(singleColor);
						RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
					}
					if (i == 2) {
						color2 = getData(secColor);
						RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "2COLOR", color2);
					}
					if (i == 3) {
						color3 = getData(lastColor);
						RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "3COLOR", color3);
					}
				}
			}

			ExtentLogger.pass("Successfully to got Color");

		} catch (Exception e) {
			Assert.fail("Failed in get Color . " + e.getMessage());
		}

		return this;
	}

	public InventoryPage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}
		return this;
	}

	Map<String, List<String>> mapcolorStyleMap = new HashMap<>();

	public Map<String, List<String>> getStyleCodeAndColor() {
		ArrayList<String> colorArrayList = new ArrayList<String>();
		ArrayList<String> styleArrayList = new ArrayList<String>();

		List<WebElement> stylelist = DriverManager.getDriver()
				.findElements(By.xpath("//*[contains(@id,'data-cell-style_code')]"));
		List<WebElement> colorlist = DriverManager.getDriver()
				.findElements(By.xpath("//*[contains(@id,'data-cell-color')]"));

		for (int i = 0; i < colorlist.size(); i++) {

			colorArrayList.add(colorlist.get(i).getText());
			styleArrayList.add(stylelist.get(i).getText());
		}
		System.out.println(colorArrayList + ":" + styleArrayList);

		Map<String, List<String>> map = new HashMap();
		map.put("colorCode", colorArrayList);
		map.put("styleCode", styleArrayList);
		mapcolorStyleMap = map;
		return map;
	}

	public InventoryPage getStyleColorAndClick() {
		String iteration = null;
		String sqty = null, mqty = null, lqty = null, xlqty = null, date = null; // xl2qty = null,//
		Map<String, List<String>> mapcolorStyleMap = this.mapcolorStyleMap;
		List<String> colorArrayList = mapcolorStyleMap.get("colorCode");
		List<String> styleArrayList = mapcolorStyleMap.get("styleCode");
		System.out.println("arraylist is executing:" + colorArrayList + styleArrayList);

		int i = 0;
		while (i < colorArrayList.size()) {

			int j = 0;
			List<WebElement> stylelist = DriverManager.getDriver()
					.findElements(By.xpath("//*[contains(@id,'data-cell-style_code')]"));
			List<WebElement> colorlist = DriverManager.getDriver()
					.findElements(By.xpath("//*[contains(@id,'data-cell-color')]"));

			while (j < colorlist.size()) {
				if (colorlist.get(j).getText().contains(colorArrayList.get(i))
						&& stylelist.get(j).getText().contains(styleArrayList.get(i))) {
					System.out.println("coming inside if condition");

					try {
						clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow, String.valueOf(j))));

						sleepFor(5000);
						sqty = getData(By.xpath(DynamicXpathUtils.getXpathForString(divSQtyFromTable, String.valueOf(1))));
						System.out.println("sty = " + sqty);
						System.out.println("iteration =" + iteration);
						System.out.println("String.valueOf(i) =" + String.valueOf(1));
						mqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divMQtyFromTable, String.valueOf(1))));
						lqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divLQtyFromTable, String.valueOf(1))));
						xlqty = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divXLQtyFromTable, String.valueOf(1))));
						date = getData(
								By.xpath(DynamicXpathUtils.getXpathForString(divDateFromTable, String.valueOf(1))))
										.split("  ")[0];
						date = getTheSubString(date);
						System.out.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + i));

						Assert.assertEquals(sqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY" + i),
								"UnExpected S Qty");
						Assert.assertEquals(mqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY" + i),
								"UnExpected M Qty");
						Assert.assertEquals(lqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY" + i),
								"UnExpected L Qty");
						Assert.assertEquals(xlqty,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY" + i),
								"UnExpected XL Qty");

						Assert.assertEquals(date,
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE" + i),
								"UnExpected Date");

						clickElement(By.xpath(DynamicXpathUtils.getXpathForString(iconExpandArrow,
								String.valueOf(String.valueOf(j)))));
						sleepFor(500);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				j++;

			}
			i++;

		}
		return this;
	}
}
