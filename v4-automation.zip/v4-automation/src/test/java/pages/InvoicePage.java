package pages;

import static appConstants.ApplicationConstants.*;

import java.io.File;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.math3.util.Precision;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.InvoiceTabs;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkConstants.*;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.InvoicePageElements;
import reports.ExtentLogger;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class InvoicePage extends MasterPage implements InvoicePageElements {

	public InvoicePage clickAddInvoiceButton() {

		try {
			clickElement(btnCreateInvoice);
			if (!findElementPresence(divCreateInvoices)) {
				throw new Exception("Invoices Page Title Not Found during Creation.");
			}
			ExtentLogger.pass("Clicked Add Invoices Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Add Invoices Button. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage enterClientDetails(String type) {
		String clientName = "", managerName = "";
		try {

			managerName = InputPropertyUtils.get("MANAGER_EXISTING_CLIENT_INVOICE");

			if (type.equalsIgnoreCase("existing")) {
				sleepFor(1000);


				clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_INVOICE");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(1000);

				clickElement(drpDwnManagerName);
				enterData(txtManagerName, managerName);
				sleepFor(1000);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionManagerName, managerName)));

				sleepFor(1000);
				clickElement(txtDueDate);
				sleepFor(1000);

				selectRandDate();

			} else if (type.equalsIgnoreCase("new")) {

				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);

				clickElement(drpDwnManagerName);
				enterData(txtManagerName, managerName);
				sleepFor(1000);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionManagerName, managerName)));

				sleepFor(1000);
				clickElement(txtDueDate);
				sleepFor(500);

				selectRandDate();
			} else if (type.equalsIgnoreCase("New Cancel New")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createAndCanelClient();
				sleepFor(1000);
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				sleepFor(1000);
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);

				clickElement(drpDwnManagerName);
				enterData(txtManagerName, managerName);
				sleepFor(1000);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionManagerName, managerName)));

				sleepFor(500);
				clickElement(txtDueDate);
				sleepFor(1000);

				selectRandDate();
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTTYPE", type);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MANAGERNAME", managerName);
			ExtentLogger.pass("Entered Client Details Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Enter Client Details. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage createClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);

			clickElementJS(drpDwnSchool);
			sleepFor(2000);
			enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganization);
			sleepFor(2000);
			enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(2000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(2000);

			/* added by vidya on 03.25.2022 */

			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			sleepFor(2000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));
			sleepFor(2000);
			clickElementJS(btnCreateAccount);
			sleepFor(2000);
			clickElementJS(btnBackToWork);
			sleepFor(1000);
			ExtentLogger.pass("Created Client for Invoice Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Creating Client for Invoice. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage addInvoiceItems(int count) {
		String quantity = "", unitPrice = "", salesTax = "", shipping = "";
		double subtotal = 0, total = 0;
		try {
			scrollToElement(btnAddInvoiceItem);

			for (int i = 2; i <= count; i++)
				clickElementJS(btnAddInvoiceItem);

			for (int i = 1; i <= count; i++) {
				quantity = String.valueOf(ThreadLocalRandom.current().nextInt(2, 200));
				unitPrice = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
				subtotal += (Double.parseDouble(unitPrice) * Double.parseDouble(quantity));

				enterData(By.xpath(txtItemName.replace("<>", String.valueOf(i))), "Item " + i);
				enterData(By.xpath(txtItemQty.replace("<>", String.valueOf(i))), quantity);
				enterData(By.xpath(txtItemUnitPrice.replace("<>", String.valueOf(i))), "");
				enterData(By.xpath(txtItemUnitPrice.replace("<>", String.valueOf(i))), unitPrice);
				sleepFor(1000);
//				clickElementJS(By.xpath("//label[contains(text(),'Create Invoice')]"));

			}

			shipping = String.valueOf(ThreadLocalRandom.current().nextInt(2, 50));
			enterData(txtShipping, shipping);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPING", String.valueOf(shipping));
			total += Double.parseDouble(shipping);
			ExtentLogger.pass("Added Shipping Charges: " + shipping);

			salesTax = String.valueOf(ThreadLocalRandom.current().nextInt(2, 50));
			// scrollToElement(txtSalesTax);
			enterData(txtSalesTax, salesTax);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SALESTAX", String.valueOf(salesTax));
			total += Double.parseDouble(salesTax);
			ExtentLogger.pass("Added Sales Tax Charges: " + salesTax);

			total += subtotal;

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTAL", String.valueOf(total));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUBTOTAL", String.valueOf(subtotal));
			ExtentLogger.pass("Added Invoice Items Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Add Invoice Items and Verify it. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage verifySubTotalAndTotal() {
		String subTotalLocator = "app-input[formcontrolname='invoiceItemsSubTotal'] > div > input";
		double subtotal = 0, total = 0, discount = 0, shipping = 0, salesTax = 0;
		try {
			sleepFor(2000);
			subtotal = Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUBTOTAL"));
			System.out.println("SubTotal: " + subtotal);
			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SALESTAX"))) {
				salesTax = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SALESTAX"));
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPING"))) {
				shipping = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPING"));
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DISCOUNT"))) {
				discount = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DISCOUNT"));
			}
			sleepFor(2000);
			total = subtotal + shipping + salesTax - discount;

			Assert.assertEquals(Double.parseDouble(
					readDataUsingJavascriptExecutorFromCSSLocator(subTotalLocator).replace(",", "").replace("$", "")),
					subtotal, "Subtotal is not displyed Correctly");

			Assert.assertEquals(Double.parseDouble(getData(divTotal).replace(",", "").replace("$", "")), total,
					"Total is not displyed Correctly");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTAL", String.valueOf(total));

			ExtentLogger.pass("Verifed Total and Subtotal Successfully");

		} catch (Exception e) {
			Assert.fail("Unable to Verify SubTotal and Total. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage addComments() {
		try {
			enterData(txtComments, "This is Test Comment");
			ExtentLogger.pass("Entered Invoice Comments Successfully.");
		} catch (Exception e) {
			Assert.fail("Failed in Adding Comments. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage applyDiscounts() {
		String discount = "";
		try {
			discount = String.valueOf(ThreadLocalRandom.current().nextInt(2, 15));
			scrollToElement(lnkAddDiscount);
			clickElement(lnkAddDiscount);
			enterData(txtDiscount, discount);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DISCOUNT", String.valueOf(discount));
			sleepFor(500);
			ExtentLogger.pass("Applied Discount Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Apply Discounts. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage removeDiscounts() {
		try {
			scrollToElement(By.xpath("//button[contains(@class,'cancel-discount')]"));
			clickElement(By.xpath("//button[contains(@class,'cancel-discount')]"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DISCOUNT", "0");
			sleepFor(500);
			ExtentLogger.pass("Removed Discount Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Removing Discounts. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage saveInvoice(String type) {

		try {
			sleepFor(500);
			if (type.equalsIgnoreCase("new")) {
				clickElementJS(btnCreateInvoice);
			} else if (type.equalsIgnoreCase("edit")) {
				clickElementJS(btnSaveEdits);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + INVOICE_EDIT_MESSAGE + "')]"));
			} else if (type.equalsIgnoreCase("comments")) {
				clickElement(btnPostComments);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + INVOICE_POST_COMMENTS_MESSAGE + "')]"));
			}
			// sleepFor(5000);
			ExtentLogger.pass("Saved Invoice Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Invoices. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage editClientDetails() {
		String clientName = "", managerName = "";
		try {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_INVOICE");
			managerName = InputPropertyUtils.get("MANAGER_EXISTING_CLIENT_INVOICE");

			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);

			// clickElement(By.xpath("//div[@class='ng-input'])[2]"));
			clickElement(drpDwnManagerName);
			enterData(txtManagerName, managerName);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionManagerName, managerName)));

			sleepFor(500);
			clickElement(txtDueDate);
			sleepFor(500);
			selectRandDate();

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTTYPE", "Existing");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MANAGERNAME", managerName);
			ExtentLogger.pass("Edited Client Details in Invoice Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Editing Client Details. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage addCustomerPO(String type) {
		try {
			clickElement(lnkCustomerPO);
			if (type.equalsIgnoreCase("numeric")) {
				enterData(txtCustomerPO, "12345");
			} else if (type.equalsIgnoreCase("alphanumeric")) {
				enterData(txtCustomerPO, "123abc");
			}

			ExtentLogger.pass("Successfully Added Customer Po #");
		} catch (Exception e) {
			Assert.fail("Failed in Adding Customer PO #. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifySuccessMessage() {
		String invoiceID = "";
		try {
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(), 'Created.')]"));
			invoiceID = getData(By.xpath("//div[contains(text(), 'Created.')]")).split(" ")[1].replace("#", "");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INVOICEID", invoiceID);
			ExtentLogger.pass("Verifed Success Toaster Message Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Success Message. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage filterAndVerifyDashboard(String status) {
		ArrayList<HashMap<String, String>> completeData = null;
		String invoiceID = "", clientName = "", managerName = "";
		try {
			invoiceID = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME");
			managerName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MANAGERNAME");

			enterData(txtSearchInvoice, invoiceID);
			sleepFor(2000);
			completeData = readCurrentTable();
			if (completeData.size() != 1) {
				throw new Exception("Searched Record is not filtered Correctly.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Invoice #").equalsIgnoreCase(invoiceID)) {
						throw new Exception("Filtered Records doesn't have the expected Invoice ID: " + invoiceID);
					}
					if (!eachRow.get("Status").equalsIgnoreCase(status)) {
						throw new Exception("Filtered Records doesn't have the expected Status: " + status);
					}
					if (!eachRow.get("Client").equalsIgnoreCase(clientName)) {
						throw new Exception("Filtered Records doesn't have the expected Client Name: " + clientName);
					}
					if (!eachRow.get("Manager").equalsIgnoreCase(managerName)) {
						throw new Exception("Filtered Records doesn't have the expected Manager Name: " + managerName);
					}
				}
			}
			ExtentLogger.pass("Filtered Invoice and Verified it Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Filter and Verify Invoice in Dashboard. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage openInvoice() {
		String invoiceId = "";
		try {
			invoiceId = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(lnkInvoiceNumber, invoiceId)));
			sleepFor(1000);
			ExtentLogger.pass("Opened Invoice " + invoiceId + " Successfully");

		} catch (Exception e) {
			Assert.fail("Unable to Open Invoice. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage verifyData() {
		String subtotalLoc = "", shippingLoc = "", salestaxLoc = "", discountLoc = "", clientNameLoc = "",
				managerNameLoc = "";
		double total = 0, discount = 0;
		try {
			softAssert = new SoftAssert();
			subtotalLoc = "input[ng-reflect-name='subtotal']";
			shippingLoc = "input[ng-reflect-name='shipping']";
			salestaxLoc = "input[ng-reflect-name='tax']";
			discountLoc = "input[ng-reflect-name='discount']";
			clientNameLoc = "(//app-select[@ng-reflect-name='clientName']//following::span[contains(@class,'ng-value-label')])[1]";
			managerNameLoc = "(//app-select[@ng-reflect-name='clientManager']//following::span[contains(@class,'ng-value-label')])[1]";

			softAssert.assertEquals(getData(By.xpath(clientNameLoc)),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME"),
					"Unexpected Client Name.");

			softAssert.assertEquals(getData(By.xpath(managerNameLoc)),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MANAGERNAME"),
					"Unexpected Manager Name.");

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUBTOTAL"))) {
				softAssert.assertEquals(
						Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(subtotalLoc).replace("$", "")
								.replace(",", "")),
						Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUBTOTAL")),
						"Unexpected Subtotal Value");
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPING"))) {
				softAssert.assertEquals(
						Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(shippingLoc).replace("$", "")
								.replace(",", "")),
						Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPING")),
						"Unexpected Shipping Value");
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SALESTAX"))) {
				softAssert.assertEquals(
						Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(salestaxLoc).replace("$", "")
								.replace(",", "")),
						Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SALESTAX")),
						"Unexpected SalesTax Value");
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DISCOUNT"))) {
				discount = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DISCOUNT"));

				softAssert.assertEquals(
						String.valueOf(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(discountLoc)
								.replace("$", "").replace(",", ""))).trim(),
						"-" + String
								.valueOf(Double.parseDouble(
										RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DISCOUNT")))
								.trim(),
						"Unexpected Discount Value");
			}

			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTAL"))) {
				total = Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTAL"));
				softAssert.assertEquals(Double.parseDouble(getData(divTotal).replace("$", "").replace(",", "")), total,
						"Unexpected Total Value");
			}

			softAssert.assertEquals(findElementPresence(lnkCustomerPO), true, "Customer PO # link is not visible");
			softAssert.assertAll();
			ExtentLogger.pass("Verified Values Displayed in Invoices Page.");

		} catch (Exception e) {
			Assert.fail("Failed during verifying data in Invoices Page. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage downloadInvoicePDFAndVerify() {
		String downloadPath = "";
		boolean tempFlag = false;
		try {
			downloadPath = FrameworkConstants.getDownloadPath();

			clickElement(btnDownloadInvoicePDF);
			sleepFor(5000);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.INVISIBLE, pageLoader);
			sleepFor(5000);
			File file = new File(downloadPath);
			if (Objects.nonNull(file.listFiles())) {
				for (File name : file.listFiles()) {
					if (name.getName()
							.startsWith(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID"))) {
						tempFlag = true;
					}
				}
			}

			if (!tempFlag)
				throw new Exception("Invoice PDF Not Downloaded");

			ExtentLogger.pass("Verified that Invoice PDF is getting Downloaded");
		} catch (Exception e) {
			Assert.fail("Failed in Invoice PDF Verification. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage assignInvoiceToExistingOrder() {

		try {

		} catch (Exception e) {
			Assert.fail("Unable to Assign Invoice to Existing Order. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage clickAndChooseFilter(String filterType) {
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			ExtentLogger.pass(
					"Successfully Selected as " + filterType.split(" ")[filterType.split(" ").length - 1] + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage applyFilter(String filterType) {
		String filterData = "";
		try {
			switch (filterType.toLowerCase()) {
			case "client":
				filterData = InputPropertyUtils.get("EXISTING_CLIENT_FOR_INVOICE");
				enterData(txtFilterClient, filterData);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionFilterClient, filterData)));
				break;

			case "manager":
				filterData = InputPropertyUtils.get("MANAGER_EXISTING_CLIENT_INVOICE");
				enterData(txtFilterManager, filterData);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionFilterManager, filterData)));
				break;

			case "due on":
				filterData = InputPropertyUtils.get("INVOICE_DUE_DATE");
				clickElementJS(txtFilterDueOn);
				selectDate(filterData);
				break;

			case "created on":
				filterData = InputPropertyUtils.get("INVOICE_CREATED_ON_DATE");
				clickElementJS(txtFilterCreatedOn);
				selectDate(filterData);
				break;

			default:
				throw new Exception("Unsupported Filter Type: " + filterType);
			}
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterData);
			ExtentLogger.pass("Applied " + filterType + " Filter Successfully");
		} catch (Exception e) {
			Assert.fail("Failed Applying Filter. " + e.getMessage());
		}
		sleepFor(2000);
		return this;
	}

	public InvoicePage verifyDashboard() {
		String filterType = "", filterValue = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDVALUE");

			if (filterType.equalsIgnoreCase("client")) {
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Client Name: " + filterValue);
					}
				}
			} else if (filterType.equalsIgnoreCase("manager")) {
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Manager").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Manager Name: " + filterValue);
					}
				}
			} else if (filterType.equalsIgnoreCase("due on")) {
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!(eachRow.get("Due On").equalsIgnoreCase(filterValue)
							|| eachRow.get("Due On").equalsIgnoreCase("n/a"))) {
						System.out.println(eachRow.get("Due On"));
						throw new Exception("Filtered Records doesn't have the expected Due Date: " + filterValue);
					}
				}
			} else if (filterType.equalsIgnoreCase("created on")) {
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Created On").equalsIgnoreCase(filterValue)) {
						System.out.println(eachRow.get("Created On"));
						throw new Exception(
								"Filtered Records doesn't have the expected Created On Date: " + filterValue);
					}
				}
			}
			ExtentLogger.pass("Verified DataTable after Filtering " + filterValue + " as " + filterType + " Filter");
		} catch (Exception e) {
			Assert.fail("Failed During Dashboard Verification. " + e.getMessage());
		}
		return this;
	}

	// changes done by vidya on 04.12.2022
	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		try {
//			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
//					.equalsIgnoreCase("admin")) {
			for (int i = 1; i <= 8; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));

				header.add(colData);
			}
			for (int i = 2; i <= rowCount; i++) {
				HashMap<String, String> eachRow = new HashMap<>();
				// int temp1 = 2, temp2 = 13, temp3 = 23;
				// int temp1 = 2, temp2 = 12, temp3 = 26;
				int temp1 = 2, temp2 = 12, temp3 = 22;
				for (int j = 1; j <= 8; j++) {
					String data = "";
					if (j <= 3) {
						System.out.println("(j <= 3)");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]");
						// temp1 *= temp1;
						temp1 = temp1 + 3;
					} else if (j <= 6) {
						System.out.println("(j <= 6)");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]");
						// temp2 += 2;
						// temp2 += 5;
						temp2 += 3;

					} else {
						System.out.println(" ......else...... ");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp3 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp3 + "]");
						// temp3 += 2;
						temp3 += 4;
					}
					eachRow.put(header.get(j - 1), data);
				}
				fullData.add(eachRow);
				System.out.println("eachRow" + eachRow);
			}
//			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

		return fullData;
	}

	public InvoicePage switchTo(InvoiceTabs invoiceTab) {
		
		String tabInvoicetab = invoiceTab.toString();
		try {
			scrollToTop();
			
			if (tabInvoicetab.equalsIgnoreCase("OVERDUE") && RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin")) {
			
				sleepFor(1000);
				//String data = getData(By.xpath("//div[contains(text(),'" + getStringValue(invoiceTab) + "')]//span")	.replace("$", "").replace(",", "").trim();
				
				
				String data=getAttributeValue(By.xpath("(//div[contains(text(),'Overdue')])[1]/span"), "innerText").replace("$", "").replace(",", "").trim();
				
				
				System.out.println("Overdue attribute approach "+data);
				
				sleepFor(1000);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATA", data);
				
			}
				
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(invoiceTab))));
			ExtentLogger.pass("Switched to " + getStringValue(invoiceTab) + " Tab.");
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(invoiceTab) + " Tab. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage filterAndVerifyAllColumns(InvoiceTabs invoiceTab) {
		try {
//			sleepFor(1500);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			System.out.println("rowCount = " + rowCount);

//			if (InvoiceTabs.equalsIgnoreCase("OVERDUE")) {
//				
//				filterAndVerifyInvoiceID(invoiceTab, rowCount);
////				sleepFor(1500);
//				filterAndVerifyClientName(invoiceTab, rowCount);
////				sleepFor(1500);
//				}
			filterAndVerifyInvoiceID(invoiceTab, rowCount);
//			sleepFor(1500);
			filterAndVerifyClientName(invoiceTab, rowCount);
//			sleepFor(1500);
//			filterAndVerifyManagerName(invoiceTab, rowCount);

		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public void filterAndVerifyInvoiceID(InvoiceTabs invoiceTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[1]"));
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Invoice # is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Invoice #").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Invoice ID: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Invoice #");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public InvoicePage openInvoiceForEdit(String type) {
		String invoiceId = "";
		try {
			if (type.equalsIgnoreCase("existing")) {
				invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_EDIT");
			} else if (type.equalsIgnoreCase("existing for edit")) {
				invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_EDITING");
			}
			else {
				invoiceId = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			}

			enterData(txtSearchInvoice, invoiceId);
			sleepFor(2000);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(lnkInvoiceNumber, invoiceId)));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INVOICEID", invoiceId);
			ExtentLogger.pass("Opened Invoice " + invoiceId + " for Editing");
		} catch (Exception e) {
			Assert.fail("Failed in Opening Invoice " + invoiceId + " for Edit." + e.getMessage());
		}
		return this;
	}

	public InvoicePage clickEmailInvoiceButton() {
		try {
			clickElement(btnEmailInvoice);
			ExtentLogger.pass("Clicked Email Invoice Button");
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Mail Invoice Button. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage enterMailBody() {
		try {
			enterData(txtEmailInPopUp, "testclient36@yopmail.com");
			enterData(txtSubjectInPopUp, "Test");
			enterData(txtMessageBodyInPopUp, "Message Body");

			ExtentLogger.pass("Filled Email Body Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Mail Body. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage sendEmail() {
		try {
			clickElement(btnSendInPopUp);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + INVOICE_EMAIL_SENT_MESSAGE + "')]"));
			sleepFor(1000);
			ExtentLogger.pass("Email Sent Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Sending Invoices Mail. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage launchYopMail() {
		openYopMail();

		return this;
	}

	public InvoicePage openInbox() {
		try {
			enterData(By.id("login"), "testclient36@yopmail.com");
			clickElement(By.xpath("//button[contains(@title,'Check Inbox')]"));
			switchToFrame("ifinbox");
			ExtentLogger.pass("Succssfully Opened Inbox");
		} catch (Exception e) {
			Assert.fail("Failed in Opening Inbox. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyEmailReceived() {
		try {
			for (int i = 1; i < 5; i++) {
				if (!findElementPresence(By.xpath("//span[contains(text(),'Fresh Prints')]"))) {
					clickElement(By.xpath("//button[@id='refresh']"));
				} else {
					break;
				}
				sleepFor(1000);
			}
			ExtentLogger.pass("Verfied that the Email is Received");
			deleteEmail();
		} catch (Exception e) {
			ExtentLogger.log("Failed in Verifying Email. " + e.getMessage());
		}
		return this;
	}

	public void deleteEmail() throws Exception {
		try {
			clickElement(By.xpath("//input[@type='checkbox']"));
			switchToFrame("parent");
			clickElement(By.xpath("//button[@id='delsel']"));
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'Message deleted')]"));
		} catch (Exception e) {
			throw new Exception("Unable to delete Email after Verification");
		}
	}

	public void filterAndVerifyOrderName(InvoiceTabs invoiceTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[7]"));
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Order Name is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Order Name").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Order Name: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Order Name");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyClientName(InvoiceTabs invoiceTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
//			sleepFor(1000);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[12]"));
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			if (!findElementPresence(By.xpath("//div[contains(text(),'No search results found')]"))) {
				throw new Exception("No Record Found Div is not Displayed.");
			}

			ExtentLogger.pass(
					"Searching Functionality is Verifed for Client Name. No Records Found Division is displayed.");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyManagerName(InvoiceTabs invoiceTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
//			sleepFor(1000);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[15]"));
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			if (!findElementPresence(By.xpath("//div[contains(text(),'No search results found')]"))) {
				throw new Exception("No Record Found Div is not Displayed.");
			}
			ExtentLogger.pass(
					"Searching Functionality is Verifed for Manager Name. No Records Found Division is displayed.");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public InvoicePage sortAndVerifyAllColumns(InvoiceTabs invoiceTab) {
		String[] colnames = { "Invoice #", "Order Name", "Client", "Manager", "Due Amount" };
		ArrayList<String> actualColData = null;

		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), invoiceTab));

				if (column.equalsIgnoreCase("invoice #")) {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					getSortedDataAndCompare(invoiceTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(invoiceTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				} else {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(2000);
					getSortedDataAndCompare(invoiceTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(invoiceTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			}
		} catch (Exception e) {
			Assert.fail(
					"Failed During Sorting and Verification in " + invoiceTab.toString() + " Tab." + e.getMessage());
		}
		return this;
	}

	public InvoicePage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}

		return this;
	}

	public void getSortedDataAndCompare(InvoiceTabs invoiceTab, String colName, ArrayList<String> actualColData,
			String order) throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), invoiceTab));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
						+ getStringValue(invoiceTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Correctly in "
						+ getStringValue(invoiceTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;

		if (colName.equalsIgnoreCase("invoice #")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String num1, String num2) {
					Integer n1 = Integer.parseInt(num1);
					Integer n2 = Integer.parseInt(num2);
					return (n1.compareTo(n2) * ord);
				}
			});
		} else if (colName.equalsIgnoreCase("due amount")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String data1, String data2) {
					Double n1 = Double.parseDouble(data1.replace("$", "").replace(",", "").trim());
					Double n2 = Double.parseDouble(data2.replace("$", "").replace(",", "").trim());
					return (n1.compareTo(n2) * ord);
				}
			});
		} else if (colName.equalsIgnoreCase("due date")) {
			Collections.sort(dataList, new Comparator<String>() {
				public int compare(String data1, String data2) {
					return (LocalDate
							.of(Integer.parseInt(data1.split(" ")[2]), Integer.parseInt(data1.split(" ")[0]),
									Integer.parseInt(data1.split(" ")[1].replace(",", "")))
							.compareTo(LocalDate.of(Integer.parseInt(data2.split(" ")[2]),
									Integer.parseInt(data2.split(" ")[0]),
									Integer.parseInt(data2.split(" ")[1].replace(",", ""))))
							* ord);
				}
			});
		} else {
			Collections.sort(dataList, new Comparator<String>() {
				public int compare(String data1, String data2) {
					return (data1.compareTo(data2) * ord);
				}
			});
		}

		return dataList;
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i).split(" ")[0] + " / "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}

		return match;
	}

	public boolean compareDateLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).equalsIgnoreCase(actualList.get(i)))) {
				System.out.println("Difference: " + i + ": " + sortedColData.get(i) + " " + actualList.get(i));
				match = false;
				break;
			}
		}

		return match;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, InvoiceTabs invoiceTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
//			boolean multiplePages = findElementPresence(
//					By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, invoiceTab));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
					// scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					scrollToElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(1000);
					// clickElement(By.xpath("//i[@class='datatable-icon-right']"));
					clickElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(1000);
					columnData.addAll(readColumnData(colIdx, invoiceTab));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, invoiceTab));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx, InvoiceTabs invoiceTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				
				
				scrollToElement(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));


				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));
				System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]");
				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}
		return columnData;
	}

	public InvoicePage verifyTabTotalAmount(InvoiceTabs invoiceTab) {
		String datas = "";
		double totalAmount = 0;
		String tabInvoicetab = invoiceTab.toString();
		try {
			sleepFor(1000);
			ArrayList<String> columnData = readCompleteColumnData(getColumntempIndex("Due Amount"), invoiceTab);
			for (String data : columnData)
				totalAmount += Double.parseDouble(data.replace("$", "").replace(",", "").trim());
			sleepFor(1000);
			
			if (tabInvoicetab.equalsIgnoreCase("OVERDUE") && RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin")) {
				System.out.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATA")+ "dfdjfgsdjfgsjgfjsa" );

				datas = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATA");
				
				
				
			} else {
				datas = getData(By.xpath("//div[contains(text(),'" + getStringValue(invoiceTab) + "')]//span"))
					.replace("$", "").replace(",", "").trim();
			sleepFor(1000);

			}
			System.out.println("data with gettext approach = " +datas);
			System.out.println(Precision.round((totalAmount), 2) + ": " + datas);
			Assert.assertEquals(String.valueOf(Precision.round(Double.parseDouble(datas), 2)),
					String.valueOf(Precision.round(totalAmount, 2)),
					"Total Amount doesn't Match for " + getStringValue(invoiceTab) + " tab.");
			ExtentLogger.pass("Verified Total Amount in the Tab Title for " + getStringValue(invoiceTab) + " Tab");
		} catch (Exception e) {
			Assert.fail("Failed During Verification of Amount displayed in Tab. " + e.getMessage());
		}
		return this;
	}

	public String getStringValue(InvoiceTabs invoiceTab) {
		String invoiceString = "";
		if (invoiceTab.equals(InvoiceTabs.ALL_UNPAID)) {
			invoiceString = "All Unpaid";
		} else if (invoiceTab.equals(InvoiceTabs.CLOSED)) {
			invoiceString = "Closed";
		} else if (invoiceTab.equals(InvoiceTabs.OPEN)) {
			invoiceString = "Open";
		} else if (invoiceTab.equals(InvoiceTabs.OVERDUE)) {
			invoiceString = "Overdue";
		}
		return invoiceString;
	}

	// changes done by vidya
	public int getColumntempIndex(String colName) throws Exception {
		int index = 0;
		if (colName.equalsIgnoreCase("invoice #"))
			index = 2;
		else if (colName.equalsIgnoreCase("status"))
			// index = 4;
			index = 5;
		else if (colName.equalsIgnoreCase("order name"))
			index = 8;
		else if (colName.equalsIgnoreCase("client"))
			// index = 13;
			index = 12;
		else if (colName.equalsIgnoreCase("manager"))
			index = 15;
		// index = 17;
		else if (colName.equalsIgnoreCase("due amount"))
			index = 18;
		// index = 22;
		else if (colName.equalsIgnoreCase("due on"))
			// index = 23;
			// index = 26;
			index = 22;
		else if (colName.equalsIgnoreCase("created on"))
			// index = 25;
			// index = 30;
			index = 26;

		if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("manager")
				&& index > 2)
			index--;

		return index;

	}

	public InvoicePage filterInvoice(String paymentType) {
		String invoiceId = "", loggedInAs = "";
		int rowCount = 0;
		try {
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");
			switch (loggedInAs.toLowerCase()) {
			case "admin":
				if (paymentType.equalsIgnoreCase("check"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_ADMIN");
				else if (paymentType.equalsIgnoreCase("credit card"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CREDITCARD_ADMIN");
				else if (paymentType.equalsIgnoreCase("venmo"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_VENMO_ADMIN");
				else if (paymentType.equalsIgnoreCase("Transfer"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_ADMIN");
				else if (paymentType.equalsIgnoreCase("zelle"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_ADMIN");
				break;
			case "manager":
				if (paymentType.equalsIgnoreCase("check"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_MANAGER");
				else if (paymentType.equalsIgnoreCase("credit card"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CREDITCARD_MANAGER");
				else if (paymentType.equalsIgnoreCase("zelle"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_MANAGER");
				else if (paymentType.equalsIgnoreCase("Transfer"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_MANAGER");
				break;
			case "client":
				if (paymentType.equalsIgnoreCase("check"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_CLIENT");
				else if (paymentType.equalsIgnoreCase("credit card"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CREDITCARD_CLIENT");
				else if (paymentType.equalsIgnoreCase("zelle"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_CLIENT");
				else if (paymentType.equalsIgnoreCase("Transfer"))
					invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_CASH_CLIENT");
				break;

			default:
				throw new Exception("Unsupported UserType");
			}

			if (getTestCaseName().toLowerCase().contains("partialpayment")) {
				invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_FOR_PARTIALPAYMENTS");
			}

			enterData(txtSearchInvoice, invoiceId);
			sleepFor(1000);
			rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			if (rowCount != 2)
				throw new Exception("Searched Invoice with ID: " + invoiceId + " is not filtered");

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INVOICEID", invoiceId);
			ExtentLogger.pass("Filtered Invoice with ID: " + invoiceId + " Successfully.");
		} catch (Exception e) {
			Assert.fail("Failed during Filtering Invoice. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyStatus(String status) {
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("No Records are filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Status").equalsIgnoreCase(status)) {
						throw new Exception("Filtered Records doesn't have the expected Status: " + status);
					}
				}
			}
			clickElement(By.xpath("(//div[contains(@class,'search__close-icon')]//i)[1]"));
			sleepFor(2000);
			ExtentLogger.pass("Verified that the Status is " + status + " for the Filtered Records");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying " + status + " Status of Filtered Records. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyStatusColumn(InvoiceTabs invoiceTab) {

		String[] colnames = { "Invoice #", "Order Name", "Client", "Manager" };
		HashSet<String> colData;
		ArrayList<String> actualColData = null;

		try {
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), invoiceTab));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
				sleepFor(2000);
				colData = new HashSet<>(readCompleteColumnData(getColumntempIndex("Status"), invoiceTab));
				for (String data : colData) {
					if (!data.trim().equalsIgnoreCase(getStringValue(invoiceTab))) {
						throw new Exception("Status does not match");
					}
				}
				ExtentLogger.pass("Verify Data Present in Status Column in " + getStringValue(invoiceTab) + " tab for "
						+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS"));
			}
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Data in Status Column. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage hoverAndChoosePaymentType(String paymentType) {
		try {
			System.out
					.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID") + " Invoice");
			hoverOver(By.xpath("(//*[contains(text(),'"
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID")
					+ "')]//following::datatable-body-cell)[1]"));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(paymentOption,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID"), paymentType)));

			sleepFor(1000);
			ExtentLogger.pass("Hovered and Selected " + paymentType + " Payment Successfully");
		} catch (Exception e) {
			Assert.fail("Failed during Choosing Payment Type. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyAvailablePaymentMethods() {
		try {
//			hoverOver(By.xpath("(//a[contains(text(),'"
//					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID")
//					+ "')]//following::datatable-body-cell)[1]"));
			hoverOver(By.xpath("(//*[contains(text(),'"
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID")
					+ "')]//following::datatable-body-cell)[1]"));
			sleepFor(1000);
			// verifyPaymentTypes();
		} catch (Exception e) {
			Assert.fail("Failed during Verifying Available Payment Modes. " + e.getMessage());
		}
		return this;
	}

	public void verifyPaymentTypes() {
		String invoiceId = "", userType = "";
		try {
			invoiceId = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			userType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");
			if (userType.equalsIgnoreCase("admin")) {
				if (!checkCondition(By.xpath(DynamicXpathUtils.getXpathForString(paymentOption, invoiceId, "Check")),
						ElementCheckStrategy.DISPLAYED)) {
					throw new Exception("Check Menu is not Displayed");
				}
				if (!checkCondition(
						By.xpath(DynamicXpathUtils.getXpathForString(paymentOption, invoiceId, "Credit Card")),
						ElementCheckStrategy.DISPLAYED)) {
					throw new Exception("Credit Card Menu is not Displayed");
				}
				if (!checkCondition(By.xpath(DynamicXpathUtils.getXpathForString(paymentOption, invoiceId, "Venmo")),
						ElementCheckStrategy.DISPLAYED)) {
					throw new Exception("Venmo Menu is not Displayed");
				}
			} else {
				if (!checkCondition(By.xpath(DynamicXpathUtils.getXpathForString(paymentOption, invoiceId, "Check")),
						ElementCheckStrategy.DISPLAYED)) {
					throw new Exception("Check Menu is not Displayed");
				}
				if (!checkCondition(
						By.xpath(DynamicXpathUtils.getXpathForString(paymentOption, invoiceId, "Credit Card")),
						ElementCheckStrategy.DISPLAYED)) {
					throw new Exception("Credit Card Menu is not Displayed");
				}
			}
			ExtentLogger.pass("Verified Payments Menu displayed for " + userType + " UserType");
		} catch (Exception e) {
			e.printStackTrace();
			ExtentLogger.fail("Payment Icons doesnt match for the " + userType + " UserType. " + e.getMessage());
		}
	}

	public InvoicePage openInvoicePage() {
		try {
			clickElementJS(lnkInvoicesNavIcon);
			sleepFor(500);
			ExtentLogger.pass("Navigated to Invoices Dashboard.");
		} catch (Exception e) {
			Assert.fail("Failed in Navigating to Invoices Dashboard. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyMessageInPaymentPage() {
		try {
			sleepFor(1000);
			if (!findElementPresence(By.xpath("//*[contains(text(),'" + INVOICES_PAYMENTPAGEMESSAGE + "')]")))
				throw new Exception("Expected Message is not Displayed in the UI");

			ExtentLogger.pass("Verified the Message displayed in Payments Page For Check Payments");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Message displayed in Payments Page For Check Payments. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage fillPaymentDetails(String paymentType) {
		String totalAmtLocator = "app-input[ng-reflect-name='paymentAmountControl'] > div > input";
		try {
			sleepFor(2000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALAMOUNT",
					readDataUsingJavascriptExecutorFromCSSLocator(totalAmtLocator));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTTYPE", paymentType);

			enterData(txtPayerEmail, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));

			if (paymentType.equalsIgnoreCase("credit card")) {
				enterData(txtCardNumber, "5424000000000015");
				enterData(txtCVV, "123");
				enterData(txtExpiryMonth, "12");
				enterData(txtExpiryYear, "2030");
				enterData(txtZipcode, DataGeneratorUtils.randZipCode());
			} else {
				clickElementJS(txtPaymentDate);
//				clickElementJS(btnTomorrow);
				selectRandDate();
			}

			enterData(txtNote, DataGeneratorUtils.randName() + " " + DataGeneratorUtils.randString());
			ExtentLogger.pass("Filled Payment Details Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Filling Payment Details for Payment Type: " + paymentType + ". " + e.getMessage());
		}
		return this;
	}

	public InvoicePage fillPartialPaymentDetails() {
		String[] aggregateAmounts = { "500", "500", "525" };
		String dueAmtLocator = "app-input[ng-reflect-name='paymentAmountControl'] > div > input";
		double paidAmount = 0;
		try {
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAIDAMOUNT", "0");
			for (String amount : aggregateAmounts) {
				sleepFor(1000);
				hoverAndChoosePaymentType("Check");
				sleepFor(1000);
				Assert.assertEquals(
						Double.parseDouble(getData(By.xpath("//div[contains(@class,'paid-amount')]")).replace("$", "")
								.replace(",", "").replace("-", "")),
						Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PAIDAMOUNT")),
						"Paid Amount is not Reflected Correctly in the UI");

				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALAMOUNT"))) {
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALAMOUNT",
							readDataUsingJavascriptExecutorFromCSSLocator(dueAmtLocator));
				}

				enterData(txtPayerEmail, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));
				enterData(txtPaymentAmount, amount);
				clickElementJS(txtPaymentDate);
				selectRandDate();
				enterData(txtNote, DataGeneratorUtils.randName() + " " + DataGeneratorUtils.randString());

				paidAmount = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PAIDAMOUNT"))
						+ Double.parseDouble(amount);
				System.out.println("After Partial Payment: " + String.valueOf(paidAmount));
				clickElementJS(btnApplyPayment);
				sleepFor(1000);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAIDAMOUNT", String.valueOf(paidAmount));

				verifyDueAmount(paidAmount);
				sleepFor(1000);
				clickElement(By.xpath("(//i[@class='ft-x'])[1]"));
				sleepFor(4000);
				switchTo(InvoiceTabs.OPEN);
				sleepFor(2000);
				verifyTabTotalAmount(InvoiceTabs.OPEN);
				filterInvoice("Check");
				sleepFor(2000);
			}
			ExtentLogger.pass("Verifed Making a series of Partial Payments");
		} catch (Exception e) {
			Assert.fail("Failed in Making Partial Payments. " + e.getMessage());
		}
		return this;
	}

	public void verifyDueAmount(double paidAmount) throws Exception {
		try {
			String displayedDueAmount = getData(By.xpath("//div[contains(@id,'data-table__due-amount')]"));
			Double totalAmount = Double
					.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALAMOUNT"));

			Double expectedDue = totalAmount - paidAmount;
			if (Double.parseDouble(displayedDueAmount.replace("$", "").replace(",", "")) != expectedDue) {
				throw new Exception(
						"DueAmount is not Updated in the table Correctly. Expected [" + expectedDue + "] Actual ["
								+ Double.parseDouble(displayedDueAmount.replace("$", "").replace(",", "")) + "]");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public InvoicePage completePaymentAndVerifySuccessMessage() {
		try {
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PAYMENTTYPE")
					.equalsIgnoreCase("credit card"))
				clickElementJS(btnMakePayment);
			else
				clickElementJS(btnApplyPayment);

			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[@role='alertdialog' and contains(text(),'Invoice #"
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID")
							+ " Paid.')]"));
			ExtentLogger.pass("Completed Payment and Verified Success Message");
		} catch (Exception e) {
			Assert.fail("Failed in Completing Payment and Verifying Success Message. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage captureTotalAmountsFromTabTitle() {
		try {
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPENTOTALAMOUNT",
					getData(By.xpath("//div[contains(text(),'Open')]//span")).replace("$", "").replace(",", "").trim());
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPENTOTALAMOUNT",
					getData(By.xpath("//div[contains(text(),'Overdue')]//span")).replace("$", "").replace(",", "")
							.trim());
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPENTOTALAMOUNT",
					getData(By.xpath("//div[contains(text(),'Closed')]//span")).replace("$", "").replace(",", "")
							.trim());
			ExtentLogger.pass("Successfully Captured total amounts from all tab titles");
		} catch (Exception e) {
			Assert.fail("Failed in Capturing Total Amounts from Tab Title. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage invoiceDetailsValidations() {
		try {
			clickElement(drpDwnClientName);
			clickTab(txtClientName);
			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ INVOICES_CLIENTNAME_VALIDATIONMESSAGE + "')]")),
					true, "Validation for Client Name is not displayed");

			clickElement(drpDwnManagerName);
			clickTab(txtManagerName);
			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ INVOICES_MANAGERNAME_VALIDATIONMESSAGE + "')]")),
					true, "Validation for Manager Name is not displayed");

			clickElement(txtDueDate);
			clickElement(lnkCustomerPO);
			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ INVOICES_DUEDATE_VALIDATIONMESSAGE + "')]")),
					true, "Validation for Manager Name is not displayed");
			enterClientDetails("Existing");
			ExtentLogger.pass("Verified Validations in Invoice Details Section");
		} catch (Exception e) {
			Assert.fail("Failed in Invoice Details Validations. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage invoiceItemValidations() {
		try {
			addInvoiceItems(1);
			applyDiscounts();
			verifySubTotalAndTotal();
			removeDiscounts();
			verifySubTotalAndTotal();
			ExtentLogger.pass("Verified Totals after Adding and Removing Discounts");

			addInvoiceItems(2);
			verifySubTotalAndTotal();
			ExtentLogger.pass("Verified Totals after Modifying Existing Invoice Items");
		} catch (Exception e) {
			Assert.fail("Failed in Invoice Items Validations. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyPaymentHistory() {
		double totAmountFromUI = 0;
		try {
			scrollToBottom();
			List<WebElement> payedAmounts = new ArrayList<>();
			payedAmounts = DriverManager.getDriver().findElements(By.xpath("//td[@class='item-total text-right']"));

			for (WebElement amount : payedAmounts) {
				totAmountFromUI += Double.parseDouble(amount.getText().replace("$", "").replace(",", ""));
			}
			System.out.println("Amount Total From Payment History: " + totAmountFromUI);
			Assert.assertEquals(
					Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALAMOUNT")),
					totAmountFromUI, "Unexpected Amount found in Payment History");
			ExtentLogger.pass("Verified Payment History Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Payment History. " + e.getMessage());
		}
		return this;
	}

	public void selectRandDate() throws Exception {
		int i = 0;
		try {
			LocalDate today = LocalDate.now();
			selectDate(String.valueOf(today.plusDays(15).getDayOfMonth()),
					StringUtils.capitalize(today.plusDays(15).getMonth().toString().toLowerCase().substring(0, 3)),
					String.valueOf(today.plusDays(15).getYear()));

		} catch (Exception e) {
			throw new Exception("Unable to select date of " + i + " days from Today");
		}
	}

	public void selectDate(String day, String month, String year) {
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			clickElementJS(By.xpath("//div[text()='" + day + "' and @class='btn-light ng-star-inserted']"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void selectDate(String fullDate) {
		// Nov 10, 2021

		String day = fullDate.split(" ")[1].replace(",", ""), month = fullDate.split(" ")[0],
				year = fullDate.split(" ")[2];
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			clickElementJS(By.xpath("(//div[text()='" + day + "'])[1]"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// added by vidya

	public InvoicePage fillZeroPaymentDetails(String paymentType) {
		String paymentAmount = "0";
		try {
			sleepFor(2000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTTYPE", paymentType);

			enterData(txtPayerEmail, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));

			if (paymentType.equalsIgnoreCase("credit card")) {

				clickElementJS(txtPaymentAmountCard);
				clearData(txtPaymentAmountCard);
				enterData(txtZeroPaymentCard, "0");
				sleepFor(1000);

				enterData(txtCardNumber, "5424000000000015");
				enterData(txtCVV, "123");
				enterData(txtExpiryMonth, "12");
				enterData(txtExpiryYear, "2030");
				enterData(txtZipcode, DataGeneratorUtils.randZipCode());
			} else {

				clickElementJS(txtPaymentAmount);
				clearData(txtPaymentAmount);
				enterData(txtPaymentAmount, "0");
				sleepFor(1000);
				clickElementJS(txtPaymentDate);
				selectRandDate();
			}

			enterData(txtNote, DataGeneratorUtils.randName() + " " + DataGeneratorUtils.randString());

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTAMOUNT", paymentAmount);
			ExtentLogger.pass("Filled Zero Payment Details Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(
					"Failed in Filling Zero Payment Details for Payment Type: " + paymentType + ". " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyZeroPaymentHistory() {
		double totAmountFromUI = 0;
		try {
			scrollToBottom();
			List<WebElement> payedAmounts = new ArrayList<>();
			payedAmounts = DriverManager.getDriver().findElements(By.xpath("//td[@class='item-total text-right']"));
			System.out.println("payedAmounts = " + payedAmounts);

			for (WebElement amount : payedAmounts) {
				totAmountFromUI += Double.parseDouble(amount.getText().replace("$", "").replace(",", ""));
			}
			System.out.println("Amount Total From Payment History: " + totAmountFromUI);
			Assert.assertEquals(
					Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PAYMENTAMOUNT")),
					totAmountFromUI, "Unexpected Amount found in Payment History");
			ExtentLogger.pass("Verified Payment History Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Payment History. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage connectdb() {

		try {

			DBSetupUtils.setupUserDatabase();
			sleepFor(500);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return this;
	}

	public InvoicePage createAndCanelClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);
			clickElementJS(drpDwnSchool);
			sleepFor(2000);
			enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganization);
			sleepFor(2000);
			enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(2000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(2000);

			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

			clickElementJS(btnCancelClient);
			sleepFor(500);
			clickElement(selectYes);
			;
			sleepFor(1000);
			ExtentLogger.pass("Closed Client for Invoice Successfully");
		} catch (Exception e) {
			Assert.fail("Failed to close Client for Invoice. " + e.getMessage());
		}
		return this;

		
		
	}	

	public void filterAndVerifyInvoiceNumber(InvoiceTabs invoiceTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = "49318";
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Invoice # is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Invoice #").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Invoice ID: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Invoice #");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);

			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = "49310";
			enterData(txtSearchInvoice, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				ExtentLogger.pass(" Filtered Wrong Invoice #" + filterData);
			} else {
				Assert.fail("Failed to filter wrong Invoice# " + filterData);
			}
			if (findElementPresence(negativeTC)) {
				ExtentLogger.pass("Searching Functionality is Verifed for Wrong Invoice #" + filterData);
			} else {
				Assert.fail("Failed to filter wrong Invoice# " + filterData);
			}

			ExtentLogger.pass("Searching Functionality is Verifed for Invoice #");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(invoiceTab);
			sleepFor(700);

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public InvoicePage filterAndVerifyAllColumn(InvoiceTabs invoiceTab) {
		try {
//			sleepFor(1500);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			System.out.println("rowCount = " + rowCount);

			filterAndVerifyInvoiceNumber(invoiceTab, rowCount);
			sleepFor(1500);

		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage hoverAndChoosePaymentTypes(String paymentType) {
		try {
			System.out
					.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID") + " Invoice");
			clickElement(btnPayment);
			sleepFor(1000);
			ExtentLogger.pass("Hovered and Selected " + paymentType + " Payment Successfully");
		} catch (Exception e) {
			Assert.fail("Failed during Choosing Payment Type. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage fillZeroPaymentDetailsVenmo(String paymentType) {
		String paymentAmount = "0";
		try {
			sleepFor(2000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTTYPE", paymentType);

			enterData(txtPayerEmailVenmo, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));

			if (paymentType.equalsIgnoreCase("credit card")) {

				clickElementJS(txtPaymentAmountCard);
				clearData(txtPaymentAmountCard);
				enterData(txtZeroPaymentCard, "0");
				sleepFor(1000);

				enterData(txtCardNumber, "5424000000000015");
				enterData(txtCVV, "123");
				enterData(txtExpiryMonth, "12");
				enterData(txtExpiryYear, "2030");
				enterData(txtZipcode, DataGeneratorUtils.randZipCode());
			} else {

				clickElementJS(txtPaymentAmount);
				clearData(txtPaymentAmount);
				enterData(txtPaymentAmount, "0");
				sleepFor(1000);
				clickElementJS(txtPaymentDate);
				selectRandDate();
			}

			enterData(txtNote, DataGeneratorUtils.randName() + " " + DataGeneratorUtils.randString());

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTAMOUNT", paymentAmount);
			ExtentLogger.pass("Filled Zero Payment Details Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(
					"Failed in Filling Zero Payment Details for Payment Type: " + paymentType + ". " + e.getMessage());
		}
		return this;
	}

	public InvoicePage hoverAndChoosePaymentTypeVenmo(String paymentType) {
		try {
			System.out
					.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID") + " Invoice");
			hoverOver(By.xpath("(//*[contains(text(),'"
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID")
					+ "')]//following::datatable-body-cell)[1]"));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(paymentOptionVenmo, paymentType)));

			sleepFor(1000);
			ExtentLogger.pass("Hovered and Selected " + paymentType + " Payment Successfully");
		} catch (Exception e) {
			Assert.fail("Failed during Choosing Payment Type. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage clearfilter() {

		try {

			clickElement(btnseachclose);

		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return this;
	}

	public InvoicePage navigateToInvoicesPages(String platform) {

		try {

			clickElement(lnkInvoicesNavIcon);
			sleepFor(2000);

			ExtentLogger.pass("Navigated to Invoices Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Invoices Page. " + e.getMessage());
		}
		return new InvoicePage();
	}

	public InvoicePage fillPaymentDetailsVenmo(String paymentType) {
		String totalAmtLocator = "app-input[ng-reflect-name='paymentAmountControl'] > div > input";
		try {
			sleepFor(2000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALAMOUNT",
					readDataUsingJavascriptExecutorFromCSSLocator(totalAmtLocator));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PAYMENTTYPE", paymentType);

			enterData(txtPayerEmailVenmo, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));

			if (paymentType.equalsIgnoreCase("credit card")) {
				enterData(txtCardNumber, "5424000000000015");
				enterData(txtCVV, "123");
				enterData(txtExpiryMonth, "12");
				enterData(txtExpiryYear, "2030");
				enterData(txtZipcode, DataGeneratorUtils.randZipCode());
			} else {
				clickElementJS(txtPaymentDate);
//				clickElementJS(btnTomorrow);
				selectRandDate();
			}

			enterData(txtNote, DataGeneratorUtils.randName() + " " + DataGeneratorUtils.randString());
			ExtentLogger.pass("Filled Payment Details Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Filling Payment Details for Payment Type: " + paymentType + ". " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyMessageInPaymentsPage(String paymentType) {
		try {
			sleepFor(1000);

			if (paymentType.equalsIgnoreCase("Transfer")) {
				if (!findElementPresence(
						By.xpath("//*[contains(text(),'" + INVOICES_PAYMENTPAGEMESSAGE_WIRETRANSFER + "')]")))
					throw new Exception("Expected Message is not Displayed in the UI");
			} else if (paymentType.equalsIgnoreCase("Zelle")) {
				if (!findElementPresence(By.xpath("//*[contains(text(),'" + INVOICES_PAYMENTPAGEMESSAGE_ZELLE + "')]")))
					throw new Exception("Expected Message is not Displayed in the UI");
			}

			ExtentLogger.pass("Verified the Message displayed in Payments Page For Check Payments");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Message displayed in Payments Page For Check Payments. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage removeInvoiceItems(int count) {
		int a = 3;
		try {
			for (int i = 1; i <= count; i++) {

				System.out.println("i = " + i);

				clickElementJS(By.xpath("(//*[@ng-reflect-ng-class='active-trash'])[" + a + "]"));
				// clickElement(By.xpath("(//*[@ng-reflect-ng-class='active-trash'])["+ a
				// +"]"));
				a--;
			}

			getInvoiceItems();
			ExtentLogger.pass("Added Invoice Items Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Remove Invoice Items and Verify it. " + e.getMessage());
		}

		return this;
	}

	public InvoicePage getInvoiceItems() {
		String quantity = "", unitPrice = "", salesTax = "", shipping = "";
		double subtotal = 0, total = 0;

		try {

			quantity = getAttributeValue(By.xpath("//input[@ng-reflect-name='quantity']"), "value");
			unitPrice = getAttributeValue(By.xpath("//input[@ng-reflect-name='price']"), "value");
			System.out.println("quantity = " + quantity);
			System.out.println("unitPrice = " + unitPrice);
			subtotal += (Double.parseDouble(unitPrice) * Double.parseDouble(quantity));
			System.out.println("subtotal = " + subtotal);
			shipping = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPING");
			System.out.println("shipping = " + shipping);
			total += Double.parseDouble(shipping);
			salesTax = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SALESTAX");
			System.out.println("salesTax = " + salesTax);
			total += Double.parseDouble(salesTax);
			total += subtotal;
			System.out.println("total " + total);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPING", String.valueOf(shipping));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SALESTAX", String.valueOf(salesTax));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTAL", String.valueOf(total));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUBTOTAL", String.valueOf(subtotal));
			ExtentLogger.pass("Got Invoice Items values Successfully");

		} catch (Exception e) {
			Assert.fail("Unable to get Invoice Items values . " + e.getMessage());
		}

		return this;

	}

	// Added by Akshay 9/12/2022

	public InvoicePage enterID_admin(String type) {
		String invoiceId = "";
		try {
			if (type.equalsIgnoreCase("existing")) {
				invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_ADMIN");
			} else {
				invoiceId = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			}
			sleepFor(2000);
			enterData(txtSearchInvoice, invoiceId);
			sleepFor(2000);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(lnkInvoiceNumber, invoiceId)));
			sleepFor(2000);
			ExtentLogger.pass("Opened Invoice " + invoiceId);
		} catch (Exception e) {
			Assert.fail("Failed in Opening Invoice " + invoiceId + e.getMessage());
		}

		try {
			sleepFor(1000);
			if (!DriverManager.getDriver().findElement(invoice_text).isDisplayed()) {
				throw new Exception("Unable to open invoice and fetch text.");
			}
			ExtentLogger.pass("Opened invoice");
		} catch (Exception e) {
			Assert.fail("Unable to fetch the invoice text. " + e.getMessage());
		}

		try {
			DriverManager.getDriver().navigate().back();
			sleepFor(2000);
			if (!DriverManager.getDriver().findElement(invoice_title).isDisplayed()) {
				throw new Exception("Invoices Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Invoices Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Invoices Page. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage enterID_manager(String type) throws Exception {
		String invoiceId = "";

		try {
			if (type.equalsIgnoreCase("existing")) {
				invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_MANAGER");
			} else {
				invoiceId = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
			}

			enterData(txtSearchInvoice, invoiceId);
			sleepFor(2000);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(lnkInvoiceNumber, invoiceId)));
			sleepFor(2000);
			// DriverManager.getDriver().navigate().back();
			ExtentLogger.pass("Opened Invoice " + invoiceId);
		} catch (Exception e) {
			Assert.fail("Failed in Opening Invoice " + invoiceId + e.getMessage());
		}

		try {
			sleepFor(1000);
			if (!DriverManager.getDriver().findElement(invoice_text).isDisplayed()) {
				throw new Exception("Unable to open invoice and fetch text.");
			}
			ExtentLogger.pass("Opened invoice");
		} catch (Exception e) {
			Assert.fail("Unable to fetch the invoice text. " + e.getMessage());
		}

		try {
			DriverManager.getDriver().navigate().back();
			sleepFor(2000);
			if (!DriverManager.getDriver().findElement(invoice_title).isDisplayed()) {
				throw new Exception("Invoices Page Title Not Found.");
			}
			ExtentLogger.pass("Navigated to Invoices Page");
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Invoices Page. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyTabs_admin(InvoiceTabs invoiceTab) {
		String tabtitle = "";
		String admin_invoiceId = "";
		try {
			sleepFor(1000);

			// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),
			// "INVOICE_ID","49317");

			admin_invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_ADMIN");

			tabtitle = getData(By.xpath("//div[contains(text(),'" + getStringValue(invoiceTab) + "')]//span"));
			System.out.println(tabtitle);
			sleepFor(2000);
			String actualamount = String
					.valueOf(DriverManager.getDriver().findElement(By.xpath(txtoverdueamt_admin)).getText());
			System.out.println(actualamount);
			sleepFor(2000);
			Assert.assertEquals((tabtitle), (actualamount),
					"Tab Title doesn't Match for " + getStringValue(invoiceTab) + " tab.");

			ExtentLogger.pass("Verified Tab Title for " + getStringValue(invoiceTab) + " Tab");
		} catch (Exception e) {
			Assert.fail("Failed During Verification of Tab Title. " + e.getMessage());
		}
		return this;
	}

	public InvoicePage verifyTabs_manager(InvoiceTabs invoiceTab) {
		String tabtitle = "";
		String manager_invoiceId = "";
		try {
			sleepFor(1000);

			manager_invoiceId = InputPropertyUtils.get("EXISTING_INVOICE_ID_MANAGER");
			// RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),
			// "INVOICE_ID","49317");

			tabtitle = getData(By.xpath("//div[contains(text(),'" + getStringValue(invoiceTab) + "')]//span"));
			System.out.println(tabtitle);
			sleepFor(2000);
			String actualamount = String
					.valueOf(DriverManager.getDriver().findElement(By.xpath(txtoverdueamt_manager)).getText());
			System.out.println(actualamount);
			sleepFor(2000);
			Assert.assertEquals((tabtitle), (actualamount),
					"Tab Title doesn't Match for " + getStringValue(invoiceTab) + " tab.");

			ExtentLogger.pass("Verified Tab Title for " + getStringValue(invoiceTab) + " Tab");
		} catch (Exception e) {
			Assert.fail("Failed During Verification of Tab Title. " + e.getMessage());
		}
		return this;
	}
}

	//Other logic for VerifyTabs
/*
 * // String tabtitle = ""; String[] tabtitles = { "Open", "Overdue", "Closed"
 * }; String tabamount=""; String expectedamount = ""; try { sleepFor(1000);
 * 
 * // RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),
 * "INVOICE_ID",// "49317");
 * 
 * if (tabtitles.equals(invoiceTab)) { tabamount =
 * getData(By.xpath("//div[contains(text(),'" + getStringValue(invoiceTab) +
 * "')]//span")); System.out.println(tabamount); } else { tabamount
 * =RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INVOICEID");
 * } System.out.println(tabtitles);
 * 
 * 
 * if(tabtitles.equals(invoiceTab)) { expectedamount = getData(Invoice_Admin);
 * // By.xpath("//div[contains(@id,'data-table__total-amount')]")); } else if
 * (tabtitles.equals(invoiceTab)) {
 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),"INVOICEID"); }
 * System.out.println(expectedamount);
 * 
 * Assert.assertEquals((tabamount), (expectedamount),
 * "Tab Title doesn't Match for " + getStringValue(invoiceTab) + " tab.");
 * ExtentLogger.pass("Verified Tab Title for " + getStringValue(invoiceTab) +
 * " Tab"); } catch (Exception e) {
 * Assert.fail("Failed During Verification of Tab Title. " + e.getMessage()); }
 * return this; }
 */
	
	
	
	/*
	 * public InvoicePage verifyCountInTabs() { try { sleepFor(1000); if
	 * (!findElementPresence(By.xpath("//*[contains(text(),'" +
	 * INVOICES_PAYMENTPAGEMESSAGE + "')]"))) throw new
	 * Exception("Expected Message is not Displayed in the UI");
	 * 
	 * ExtentLogger.
	 * pass("Verified the Message displayed in Payments Page For Check Payments"); }
	 * catch (Exception e) { Assert.
	 * fail("Failed in Verifying Message displayed in Payments Page For Check Payments. "
	 * + e.getMessage()); } return this; }
	 */

