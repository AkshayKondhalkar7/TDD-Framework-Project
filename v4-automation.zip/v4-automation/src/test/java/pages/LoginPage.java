package pages;

import static appConstants.ApplicationConstants.DEACTIVATED_USER_DISPLAY_MESSAGE;

import java.util.Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;

import appEnums.UserOperation;
import appEnums.UserType;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.LoginPageElements;
import reports.ExtentLogger;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class LoginPage extends MasterPage implements LoginPageElements {

	private static String passwordReuse = "";

	static Long datetime = System.currentTimeMillis();

	public static String getPasswordreuse() {
		return passwordReuse;
	}

	public LoginPage userLogin(UserType userType){
		String email = "";
		String password = "";

		try {
			if (userType == UserType.ADMIN) {
				email = InputPropertyUtils.get("MASTER_ADMIN_LOGIN_EMAIL");
				password = InputPropertyUtils.get("MASTER_ADMIN_LOGIN_PASSWORD");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");

			} else if (userType == UserType.CAMPUS_MANAGER) {

				email = InputPropertyUtils.get("MASTER_MANAGER_LOGIN_EMAIL");
				password = InputPropertyUtils.get("MASTER_MANAGER_LOGIN_PASSWORD");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");

			} else if (userType == UserType.CLIENT) {
				email = InputPropertyUtils.get("EXISTING_CLIENT_INVOICE_EMAIL");
				password = InputPropertyUtils.get("EXISTING_CLIENT_INVOICE_PASSWORD");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");
			}

			if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE"))) {
				String type = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE");
				if (type.equalsIgnoreCase("reassign") && userType.equals(UserType.CAMPUS_MANAGER)) {
					email = InputPropertyUtils.get("VERIFY_MANAGER_LOGIN_EMAIL");
					password = InputPropertyUtils.get("VERIFY_MANGER_LOGIN_PASSWORD");
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");
				} else if (type.equalsIgnoreCase("impersonate") && userType.equals(UserType.CAMPUS_MANAGER)) {
					email = InputPropertyUtils.get("EXISTING_MANAGER_EMAIL");
					password = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORD");
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");
				}
			} else if (getTestCaseName().equalsIgnoreCase("ManagerLogin_EditExistingClientUser_VerifyDashboard")) {
				email = InputPropertyUtils.get("EXISTING_MANAGER_EMAIL");
				password = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORD");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");
			}
			System.out.println(email + ":" + password + ":" + userType);
			// email="adamhpan@gmail.com";
			// password ="$2a$10$3ofmkK5DUfn2UALqe2zrC.mk7pty.ZiPBHs2nuhO7PU3bkHvNagk.";

			logIn(email, password);
			if (!findElementPresence(profileIconOld)) {

				String getError = DriverManager.getDriver().findElement(By.cssSelector("label.validation-error-label"))
						.getText();
				System.out.println(getError);

				throw new Exception("Unable to Login");

			}
			ExtentLogger.pass("Logged In Successfully as " + getStringValue(userType));
		} catch (Exception e) {

			Assert.fail("Unable to Login. " + e.getMessage());
		}

		return this;
	}

	public LoginPage logIn(String emailId, String password) {
		try {

			System.out.println("Login with: " + emailId + " and " + password);

			if (DriverManager.getDriver().findElements(By.xpath("(//input[@id='form-email'])[1]")).size() > 0) {

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, emailTxtBox);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, passwordTxtBox);
				System.out.println(
						DriverManager.getDriver().findElement(By.xpath("(//input[@id='form-email'])[1]")).getText()
								+ ": check the text");

			} else {
				System.out.println("false no result");
			}

			if (DriverManager.getDriver().findElements(By.xpath("(//input[@id='form-email'])[1]")).size() > 0) 
				System.out.println("true data is showing");

				DriverManager.getDriver().findElements(By.xpath("(//input[@id='form-email'])[1]")).get(0)
						.sendKeys(emailId);
				DriverManager.getDriver().findElement(By.xpath("//input[@id='form-password']")).sendKeys(password);
				DriverManager.getDriver().findElement(By.xpath("//button[text()='Sign in']")).sendKeys(Keys.ENTER);
				DriverManager.getDriver().findElements(By.xpath("//button[text()='Sign in']"));

			
				// enterData(emailTxtBox, emailId);

				// enterData(emailTxtBox, emailId);

				// enterData(passwordTxtBox, password);

			
		} catch (Exception e) {
			Assert.fail("Unable to Login with: \" + emailId + \" and \" + password" + e.getMessage());

		}

		return this;
	}
	

	public LoginPage loginToVerify(String platform) {
		try {
			logIn(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL"),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD"));

			if (platform.equalsIgnoreCase("desktop")) {
				if (!findElementPresence(profileIconOld)) {
					throw new Exception("Cannot Login using the User's Credentials: "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL") + " and "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD"));
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				if (!findElementPresence(profileIconMoreMobileOld)) {
					throw new Exception("Cannot Login using the User's Credentials: "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL") + " and "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD"));
				}
			}

			ExtentLogger.pass("Login Verified for the User");
		} catch (Exception e) {
			Assert.fail("Unable to Login for the User. " + e.getMessage());
		}

		return this;
	}

	public LoginPage loginToVerifyDeActivationAndReActivation(UserOperation userOperations, String platform) {
		try {
			logIn(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL"),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD"));

			if (platform.equalsIgnoreCase("desktop")) {
				if (userOperations.equals(UserOperation.DEACTIVATE)) {
					ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, errorLabel);
					Assert.assertEquals(getData(errorLabel), DEACTIVATED_USER_DISPLAY_MESSAGE);
					ExtentLogger.pass("Verfied that User is DeActivated");

				} else if (userOperations.equals(UserOperation.REACTIVATE)) {

					if (!findElementPresence(profileIconOld)) {
						throw new Exception("Cannot Login After Activation");
					}
					ExtentLogger.pass("Verified that User is Activated");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {

				if (userOperations.equals(UserOperation.DEACTIVATE)) {
					ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, errorLabel);

					Assert.assertEquals(getData(errorLabel), DEACTIVATED_USER_DISPLAY_MESSAGE);
					ExtentLogger.pass("Verfied that User is DeActivated");
				} else if (userOperations.equals(UserOperation.REACTIVATE)) {
					if (!findElementPresence(profileIconMoreMobileOld)) {
						throw new Exception("Cannot Login After Activation");
					}

					ExtentLogger.pass("Verified that User is Activated");
				}
			}

		} catch (Exception e) {
			Assert.fail("Unable to Verify whether the User is DeActivated/ReActivated. " + e.getMessage());
		}

		return this;
	}

	public LoginPage loginToVerifyInvoiceDashboard(UserType userType) {
		String email = "", password = "";
		try {
			if (userType.equals(UserType.CLIENT)) {

				if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTTYPE"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTTYPE")
							.equalsIgnoreCase("existing")) {
						email = InputPropertyUtils.get("EXISTING_CLIENT_INVOICE_EMAIL");
						password = InputPropertyUtils.get("EXISTING_CLIENT_INVOICE_PASSWORD");
					} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTTYPE")
							.equalsIgnoreCase("new")) {
						email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
						password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD");
					}
				}
			} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
				email = InputPropertyUtils.get("EXISTING_MANAGER_INVOICE_EMAIL");
				password = InputPropertyUtils.get("EXISTING_MANAGER_INVOICE_PASSWORD");
			}
			logIn(email, password);
			sleepFor(1000);
			ExtentLogger.pass("Logged in Successfully as " + getStringValue(userType));
		} catch (Exception e) {
			Assert.fail("Failed in Login to Verify Invoice Dashboard. " + e.getMessage());
		}
		return this;
	}

	public LoginPage loginAsClientToVerifyProofs(String userType) {
		String email = "", password = "";
		try {
			if (userType.equalsIgnoreCase("new")) {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD");
			} else if (userType.equalsIgnoreCase("existing")) {
				email = InputPropertyUtils.get("EXISTING_CLIENT_EMAIL");
				password = InputPropertyUtils.get("EXISTING_CLIENT_PASSWORD");
			} else if (userType.equalsIgnoreCase("Existing RequestRevision")) {
				email = InputPropertyUtils.get("EXISTING_CLIENT_EMAIL_REQUESTREVISION");
				password = InputPropertyUtils.get("EXISTING_CLIENT_PASSWORD_REQUESTREVISION");
			}
			logIn(email, password);
			sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");
			ExtentLogger.pass("Logged in Successfully as a Client");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return this;
	}

	// added by vidya
	public LoginPage loginAsClientToVerifyProofsEdit(String userType) {
		String email = "", password = "";
		try {
			if (userType.equalsIgnoreCase("ADMIN")) {
				email = InputPropertyUtils.get("ADMIN_PROOFS_EDIT_CLIENT_EMAIL");
				password = InputPropertyUtils.get("ADMIN_PROOFS_EDIT_CLIENT_PASSWORD");
			} else if (userType.equalsIgnoreCase("MANAGER")) {
				email = InputPropertyUtils.get("PROOFS_EDIT_CLIENT_EMAIL");
				password = InputPropertyUtils.get("PROOFS_EDIT_CLIENT_PASSWORD");
			}

			logIn(email, password);
			sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");
			ExtentLogger.pass("Logged in Successfully as a Client");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return this;
	}

	// added by vidya
	public LoginPage loginAsManagerToVerifyProofsEdit(String userType) {
		String email = "", password = "";
		try {
			if (userType.equalsIgnoreCase("new")) {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD");
			} else if (userType.equalsIgnoreCase("existing")) {
				email = InputPropertyUtils.get("PROOFS_EDIT_MANAGER_EMAIL");
				password = InputPropertyUtils.get("PROOFS_EDIT_MANAGER_PASSWORD");
			}

			logIn(email, password);
			sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");
			ExtentLogger.pass("Logged in Successfully as a Client");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return this;
	}

	public LoginPage userLoginForSettings(UserType userType) throws Exception {
		String email = "";
		String password = "";

		switch (userType) {
		case ADMIN:

			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("EXISTING_ADMIN_EMAILFORSETTINGS");
				password = InputPropertyUtils.get("EXISTING_ADMIN_PASSWORDFORSETTINGS");
			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");

			break;

		case CAMPUS_MANAGER:
			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("EXISTING_MANAGER_EMAILFORSETTINGS");
				password = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORDFORSETTINGS");

			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");

			break;

		case CLIENT:
			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("EXISTING_CLIENT_EMAILFORSETTINGS");
				password = InputPropertyUtils.get("EXISTINGS_CLIENT_PASSWORDFORSETTINGS");
			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");

			break;

		case FULFILLMENT_CENTER:

			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("EXISTING_FULLFILLMENT_EMAILFORSETTINGS");
				password = InputPropertyUtils.get("EXISTING_FULLFILLMENT_PASSWORDFORSETTINGS");

			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");

			break;

		case PRINTER:
			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("EXISTING_PRINTER_EMAILFORSETTINGS");
				password = InputPropertyUtils.get("EXISTING_PRINTER_PASSWORDFORSETTINGS");

			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");

			break;

		default:

			System.out.println("No Role has been defined clearly");

		}
		
		

		try {
			/*
			 * if (userType == UserType.ADMIN) {
			 * if(Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName
			 * (), "EDITEDEMAIL"))){
			 * 
			 * 
			 * email = InputPropertyUtils.get("EXISTING_ADMIN_EMAILFORSETTINGS"); password =
			 * InputPropertyUtils.get("EXISTING_ADMIN_PASSWORDFORSETTINGS"); } else{ email =
			 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),"EDITEDEMAIL");
			 * password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName()
			 * ,"EDITEDPASSWORD"); }
			 * 
			 * 
			 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS",
			 * "Admin");
			 * 
			 * 
			 * } else if (userType == UserType.CAMPUS_MANAGER) {
			 * if(Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName
			 * (), "EDITEDEMAIL"))){
			 * 
			 * 
			 * email = InputPropertyUtils.get("EXISTING_MANAGER_EMAILFORSETTINGS"); password
			 * = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORDFORSETTINGS");
			 * 
			 * } else { email =
			 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),"EDITEDEMAIL");
			 * password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName()
			 * ,"EDITEDPASSWORD"); }
			 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS",
			 * "Manager");
			 * 
			 * } else if (userType == UserType.CLIENT) {
			 * if(Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName
			 * (), "EDITEDEMAIL"))){
			 * 
			 * 
			 * email = InputPropertyUtils.get("EXISTING_CLIENT_EMAILFORSETTINGS"); password
			 * = InputPropertyUtils.get("EXISTINGS_CLIENT_PASSWORDFORSETTINGS"); } else {
			 * email =
			 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),"EDITEDEMAIL");
			 * password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName()
			 * ,"EDITEDPASSWORD"); }
			 * 
			 * 
			 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS",
			 * "Client"); }
			 * 
			 * else if (userType == UserType.FULFILLMENT_CENTER) {
			 * if(Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName
			 * (), "EDITEDEMAIL"))){
			 * 
			 * email = InputPropertyUtils.get("EXISTING_FULLFILLMENT_EMAILFORSETTINGS");
			 * password =
			 * InputPropertyUtils.get("EXISTING_FULLFILLMENT_PASSWORDFORSETTINGS");
			 * 
			 * } else { email =
			 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),"EDITEDEMAIL");
			 * password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName()
			 * ,"EDITEDPASSWORD"); }
			 * 
			 * 
			 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS",
			 * "Manager");
			 * 
			 * } else if (userType == UserType.PRINTER) {
			 * 
			 * if(Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName
			 * (), "EDITEDEMAIL"))){
			 * 
			 * 
			 * 
			 * email = InputPropertyUtils.get("EXISTING_PRINTER_EMAILFORSETTINGS"); password
			 * = InputPropertyUtils.get("EXISTING_PRINTER_PASSWORDFORSETTINGS");
			 * 
			 * } else { email =
			 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),"EDITEDEMAIL");
			 * password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName()
			 * ,"EDITEDPASSWORD"); }
			 * 
			 * 
			 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS",
			 * "Client"); }
			 * 
			 * 
			 */

			passwordReuse = password;
			logIn(email, password);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);

			if (!findElementPresence(profileIconOld)) {
				throw new Exception("Unable to Login or cannot login using the User's credentials:");
			}
			ExtentLogger.pass("Logged In Successfully as " + getStringValue(userType));
		} catch (Exception e) {
			Assert.fail("Unable to Login. " + e.getMessage());
		}

		return this;

	}

	// added by vidya //

	public LoginPage loginForSettings(UserType userType) throws Exception {

		String email = "";
		String password = "";

		if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

			email = InputPropertyUtils.get("SETTINGS_EXISTING_ADMIN_EMAIL_ONETESTCASE");
			password = InputPropertyUtils.get("SETTINGS_EXISTING_ADMIN_PASSWORD_ONETESTCASE");
		} else {
			email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
			password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
		}

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");

		try {

			passwordReuse = password;
			logIn(email, password);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);

			if (!findElementPresence(profileIconOld)) {
				throw new Exception("Unable to Login or cannot login using the User's credentials:");
			}
			ExtentLogger.pass("Logged In Successfully as " + getStringValue(userType));
		} catch (Exception e) {
			Assert.fail("Unable to Login. " + e.getMessage());
		}

		return this;
	}
	
	
	public LoginPage userLoginForSetting(UserType userType) throws Exception {
		String email = "";
		String password = "";
	
		try {
			
			if (userType == UserType.CLIENT) {
			
			if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL"))) {

				email = InputPropertyUtils.get("SETTINGS_EXISTING_CILENT_SCHOOL_ID");
				password = InputPropertyUtils.get("SETTINGS_EXISTING_CILENT_SCHOOL_PASSWORD");
			} else {
				email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAIL");
				password = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDPASSWORD");
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Client");
			
			}
			
			
			passwordReuse = password;
			logIn(email, password);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);

			if (!findElementPresence(profileIconOld)) {
				throw new Exception("Unable to Login or cannot login using the User's credentials:");
			}
			ExtentLogger.pass("Logged In Successfully as " + getStringValue(userType));
			
			
			
		} catch (Exception e) {
			Assert.fail("Unable to Login. " + e.getMessage());
		}
		
		return this;
		
	}

}
