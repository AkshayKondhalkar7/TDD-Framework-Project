package pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class OrderExcel {

	private static OrderExcel instance = new OrderExcel();

	/**
	 * 
	 * @return ExcelReader
	 */
	public static OrderExcel getInstance() {
		
		return instance;
	}

	/**
	 * 
	 * 
	 * @param File
	 * @return void
	 * @throws IOException
	 */
	public ArrayList<HashMap<Integer, Object>> readXls(File input) throws IOException {
		return readXls(new FileInputStream(input));
	}

	/**
	 * 
	 * @param InputStream
	 * @return void
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	public ArrayList<HashMap<Integer, Object>> readXls(InputStream input) throws IOException {
		FileInputStream fis = (FileInputStream) input;
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);
		ArrayList<HashMap<Integer, Object>> result = new ArrayList<>();
		for (int rowindex = 1; rowindex < sheet.getPhysicalNumberOfRows(); rowindex++) {
			HSSFRow row = sheet.getRow(rowindex);
			HashMap<Integer, Object> map = new HashMap<>();
			if (row != null) {
				for (int columnindex = 0; columnindex <= row.getPhysicalNumberOfCells(); columnindex++) {
					HSSFCell cell = row.getCell(columnindex);
					if (cell != null)
						map.put(columnindex, cell.getCellFormula().toString());
				}
			}
			result.add(map);
		}
		return result;

	}

	/**
	 * 
	 * @param File
	 * @return void
	 * @throws IOException
	 */
	public ArrayList<HashMap<Integer, Object>> readXlsx(File input) throws IOException {
		return readXlsx(new FileInputStream(input));
	}
	
	

	/**
	 * 
	 * @param InputStream
	 * @return void
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	public ArrayList<HashMap<Integer, Object>> readXlsx(InputStream input) throws IOException {
		FileInputStream fis = (FileInputStream) input;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);

		printXSSFSheet(sheet);

		ArrayList<HashMap<Integer, Object>> result = new ArrayList<>();
		for (int rowindex = 1; rowindex < sheet.getPhysicalNumberOfRows(); rowindex++) {
			XSSFRow row = sheet.getRow(rowindex);
			HashMap<Integer, Object> map = new HashMap<>();
			if (row != null) {
				for (int columnindex = 0; columnindex <= row.getPhysicalNumberOfCells(); columnindex++) {
					// 셀값을 읽는다
					XSSFCell cell = row.getCell(columnindex);
					if (cell != null)
						map.put(columnindex, cell.getRawValue().toString());
				}
				result.add(map);
			}
		}
		return result;
	}

	public void printHSSFSheet(HSSFSheet sheet) {
		int rowindex = 0;
		int columnindex = 0;
		int rows = sheet.getPhysicalNumberOfRows();
		for (rowindex = 1; rowindex < rows; rowindex++) {
			HSSFRow row = sheet.getRow(rowindex);
			if (row != null) {
				int cells = row.getPhysicalNumberOfCells();
				System.out.println(rowindex + "row");
				for (columnindex = 0; columnindex <= cells; columnindex++) {
					HSSFCell cell = row.getCell(columnindex);
					String value = "";
					
					if (cell == null) {
						continue;
					} else {
					
						switch (cell.getCellType()) {
						case FORMULA:
							value = cell.getCellFormula();
							break;
						case NUMERIC:
							value = cell.getNumericCellValue() + "";
							break;
						case STRING:
							value = cell.getStringCellValue() + "";
							break;
						case BLANK:
							value = cell.getBooleanCellValue() + "";
							break;
						case ERROR:
							value = cell.getErrorCellValue() + "";
							break;
						default:
							break;
						}
					}
					System.out.println("\t" + columnindex + "results: " + value);
				}
			}
		}
	}

	/**
	 * 
	 * @return void
	 * @throws IOException
	 */
	public void printXSSFSheet(XSSFSheet sheet) {
		int rowindex = 0;
		int columnindex = 0;

		int rows = sheet.getPhysicalNumberOfRows();
		for (rowindex = 1; rowindex < rows; rowindex++) {
			XSSFRow row = sheet.getRow(rowindex);
			if (row != null) {
				int cells = row.getPhysicalNumberOfCells();
				System.out.println(rowindex + "row");
				for (columnindex = 0; columnindex <= cells; columnindex++) {
					XSSFCell cell = row.getCell(columnindex);
					String value = "";
					if (cell == null) {
						continue;
					} else {
						switch (cell.getCellType()) {
						case FORMULA:
							value = cell.getCellFormula();
							break;
						case NUMERIC:
							value = cell.getNumericCellValue() + "";
							break;
						case STRING:
							value = cell.getStringCellValue() + "";
							break;
						case BLANK:
							value = cell.getBooleanCellValue() + "";
							break;
						case ERROR:
							value = cell.getErrorCellValue() + "";
							break;
						case BOOLEAN:
							break;
						case _NONE:
							break;
						default:
							break;
						}
					}
					System.out.println("\t" + columnindex + "results: " + value);
				}
			}
		}
	}
	
	
	public static void convertFilesCSVtoxlsx(String File) throws IOException {
		
		
		BufferedReader br = new BufferedReader(new FileReader(File));
		//create sheet
		Workbook wb = new XSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = wb.createSheet();
		//read from file
		String line = br.readLine();
		for (int rows=0; line != null; rows++) {
		    //create one row per line
		    Row row = sheet.createRow(rows);
		    //split by semicolon
		    String[] items = line.split(";");
		    System.out.println(items[1]+"hgj");

		    //ignore first item
		    for (int i=1, col=0; i<items.length; i++) {
		        //strip quotation marks
		        String item = items[i].substring(1, items[i].length()-1);
		        Cell cell = row.createCell(col++);
		        //set item
		        cell.setCellValue(item);
			    System.out.println(item +"hgj");

		    }
		    //read next line
		    line = br.readLine();
		}
		//write to xlsx
		FileOutputStream out = new FileOutputStream("Output.xlsx");
		wb.write(out);
		//close resources
		br.close();
		out.close();
		
		
	}
	
	public static void main(String[] args) throws IOException {
		
		
		convertFilesCSVtoxlsx("/Users/kirtysharma/Desktop/FreshPrints_Automation/v4-automation/src/test/resources/orders/input.csv");
		
	}
	
	
	
	
	
	
	
	
}
