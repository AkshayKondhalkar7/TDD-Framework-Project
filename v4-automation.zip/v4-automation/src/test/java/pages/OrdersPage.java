package pages;

import static appConstants.ApplicationConstants.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.OrdersTabs;
import appUtilities.DataGeneratorUtils;
import drivers.Driver;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.OrdersPageElements;
import reports.ExtentLogger;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class OrdersPage extends MasterPage implements OrdersPageElements {

	public OrdersPage switchTo(OrdersTabs ordersTab) {
		try {
			scrollToTop();
			sleepFor(1000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(ordersTab))));
			sleepFor(1000);
			ExtentLogger.pass("Switched to " + getStringValue(ordersTab) + " Tab.");
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(ordersTab) + " Tab. " + e.getMessage());
		}

		return this;
	}

	public OrdersPage sortAndVerifyAllColumns(OrdersTabs ordersTab) {
	//	String[] colnames = { "Order #", "Order Name", "Client", "Campus Manager" };
		String[] colnames = { "Order #", "Order Name", "Client", "Manager" };
		String loggedInAs = "";
		ArrayList<String> actualColData = null;
		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");
			for (String column : colnames) {
				if (loggedInAs.equalsIgnoreCase("manager") && column.contains("Manager")) {
					break;
				}
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), ordersTab));

				if (column.equalsIgnoreCase("applies to")) {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(ordersTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(ordersTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				} else {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(ordersTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(ordersTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			}
		} catch (Exception e) {
			Assert.fail("Failed During Sorting and Verification in " + ordersTab.toString() + " Tab." + e.getMessage());
		}
		return this;
	}

	public void getSortedDataAndCompare(OrdersTabs ordersTab, String colName, ArrayList<String> actualColData,
			String order) throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), ordersTab));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
						+ getStringValue(ordersTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Correctly in "
						+ getStringValue(ordersTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;
		try {
			if (colName.equalsIgnoreCase("order #")) {
				Collections.sort(dataList, new Comparator<String>() {

					public int compare(String num1, String num2) {
						Integer n1 = Integer.parseInt(num1);
						Integer n2 = Integer.parseInt(num2);
						return (n1.compareTo(n2) * ord);
					}
				});
			} else {
				Collections.sort(dataList, new Comparator<String>() {
					public int compare(String data1, String data2) {
						return (data1.compareTo(data2) * ord);
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return dataList;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, OrdersTabs ordersTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, ordersTab));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
					scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					sleepFor(2000);
					clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					sleepFor(2000);
					columnData.addAll(readColumnData(colIdx, ordersTab));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, ordersTab));
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx, OrdersTabs ordersTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));
				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}	
		return columnData;
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i).split(" ")[0] + " / "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}
		return match;
	}

	public OrdersPage filterAndVerifyAllColumns(OrdersTabs ordersTab) {
		try {
			sleepFor(1000);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			filterAndVerifyOrderId(ordersTab, rowCount);
			filterAndVerifyOrderName(ordersTab, rowCount);
			filterAndVerifyClient(ordersTab, rowCount);
			filterAndVerifyManager(ordersTab, rowCount);
		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public OrdersPage filterAndVerifyAllColumn(OrdersTabs ordersTab) {
		try {
			sleepFor(1000);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			filterAndVerifyOrderNumber(ordersTab, rowCount);
			filterAndVerifyOrderNames(ordersTab, rowCount);
			filterAndVerifyClientName(ordersTab, rowCount);
			filterAndVerifyCampusManager(ordersTab, rowCount);
		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public void filterAndVerifyOrderNumber(OrdersTabs ordersTab, int rowCount) throws Exception {
		String filterData = "51850";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Order #").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Order #: " + filterData);
					}
				}
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));
				
			ExtentLogger.pass("Searching Functionality is Verifed for Order # Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyOrderNames(OrdersTabs ordersTab, int rowCount) throws Exception {
		String filterData = "Automation Order";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Order Name").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Order Name: " + filterData);
					}
				}
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));
				
			ExtentLogger.pass("Searching Functionality is Verifed for Order Name Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyClientName(OrdersTabs ordersTab, int rowCount) throws Exception {
		String filterData = "Robert Downey";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterData);
					}
				}
			
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));
			ExtentLogger.pass("Searching Functionality is Verifed for Client Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyCampusManager(OrdersTabs ordersTab, int rowCount) throws Exception {
		String filterData = "john ash";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Campus Manager").contains(filterData.split(" ")[0])) {
						System.out.println(eachRow.get("Campus Manager"));
						throw new Exception("Filtered Records doesn't have the expected Manager: " + filterData);
					}
				}
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));	
			
			ExtentLogger.pass("Searching Functionality is Verifed for Manager Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void filterAndVerifyOrderId(OrdersTabs ordersTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			System.out.println("filterIdx = "+filterIdx);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[2]"));
			System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[2]");
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Order # is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Order #").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Order #: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Order # Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyOrderName(OrdersTabs ordersTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[8]"));
			System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[8]");
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Order Name is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Order Name").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Order Name: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Order Name Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyClient(OrdersTabs ordersTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
		//	filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[12]"));
			filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[13]"));
			System.out.println("filterData = " +filterData);
			System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[12]");
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Client is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Client Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyManager(OrdersTabs ordersTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[16]"));
			enterData(txtSearchOrder, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Manager is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Campus Manager").contains(filterData.split(" ")[0])) {
						System.out.println(eachRow.get("Campus Manager"));
						throw new Exception("Filtered Records doesn't have the expected Manager: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Manager Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(ordersTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		try {
			for (int i = 1; i <= 8; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
				header.add(colData);
			}
			for (int i = 2; i <= rowCount; i++) {
				HashMap<String, String> eachRow = new HashMap<>();
				int temp1 = 2, temp2 = 12;
				for (int j = 1; j <= 8; j++) {
					String data = "";
					if (j <= 3) {
						data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]"));
						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]");
						temp1 += 3;
					} else {
						data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]"));
						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]");
						temp2 += 3;
					}
					eachRow.put(header.get(j - 1), data);
				}
				fullData.add(eachRow);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;
	}

	public OrdersPage clickAndChooseFilter(String filterType) {
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			ExtentLogger.pass("Successfully Selected as " + filterType + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}

	public OrdersPage applyFilter(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("client")) {
				filterValue = "Virat Kohli";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} 
		//	else  if (filterType.equalsIgnoreCase("campus manager")) 
				else  if (filterType.equalsIgnoreCase("manager")) 
			{
				filterValue = "Testing Manager";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} else if (filterType.equalsIgnoreCase("indiv ship")) {
				
				clickElement(By.xpath("//input[@id='individual']//ancestor::app-radio-button"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterType);
			} else if (filterType.equalsIgnoreCase("bulk ship")) {
				
				clickElement(By.xpath("//input[@id='bulk']//ancestor::app-radio-button"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterType);
			} else {
				throw new Exception(filterType + " is not supported.");
			}
			sleepFor(5000);
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}
		return this;
	}
	
	public OrdersPage applyFilterValues(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("client")) {
				filterValue = "Robert Downey";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} 
		//	else if (filterType.equalsIgnoreCase("campus manager"))
				else if (filterType.equalsIgnoreCase("manager"))
			{
				filterValue = "John Ash";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} 
			 else {
				throw new Exception(filterType + " is not supported.");
			}
			
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));
			sleepFor(5000);
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}
		return this;
	}
	
	public OrdersPage applyDateFilterAndVerify(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(txtDateFilter, filterSubType)));
			selectDate("11", "Nov", "2021");
			sleepFor(500);
			completeData = readCurrentTable();

			if (completeData.size() == 0) {
				if(findElementPresence(divNoRecordsFound)) {
					throw new Exception("No Records Found Message is not Displyed when no match is found.");
				}
				ExtentLogger.fail("No Records Found for the Filter");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if(filterType.equalsIgnoreCase("created date")) {
						if (!eachRow.get("Created On").equalsIgnoreCase("Nov 11")) {
							throw new Exception("Filtered Records doesn't have the expected Starts Date: " + "Nov 11");
						}
					} else if(filterType.equalsIgnoreCase("due date")) {
						if (!eachRow.get("Due On").equalsIgnoreCase("Nov 11")) {
							throw new Exception("Filtered Records doesn't have the expected Due Date: " + "Nov 11");
						}
					}
					
				}
			}
			sleepFor(1000);
			clickElement(By.xpath("//i[contains(@class,'ft-x cursor')]"));
			ExtentLogger.pass("Applied " + filterSubType + " SubFilter and Verified Filtered Record");
		} catch (Exception e) {
			Assert.fail("Failed in Applying Date Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public OrdersPage applyDateFilterAndVerifyValues(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(txtDateFilter, filterSubType)));
			selectDate("19", "Nov", "2025");
			sleepFor(500);
			completeData = readCurrentTable();

			
				for (HashMap<String, String> eachRow : completeData) {
					if(filterType.equalsIgnoreCase("created date")) {
						if (!eachRow.get("Created On").equalsIgnoreCase("Nov 11")) {
							throw new Exception("Filtered Records doesn't have the expected Starts Date: " + "Nov 11");
						}
					} else if(filterType.equalsIgnoreCase("due date")) {
						if (!eachRow.get("Due On").equalsIgnoreCase("Nov 11")) {
							throw new Exception("Filtered Records doesn't have the expected Due Date: " + "Nov 11");
						}
					}
					
				}
				
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + ORDER_NOSEARCH_FOUND + "')]"));	
			sleepFor(1000);
			clickElement(By.xpath("//i[contains(@class,'ft-x cursor')]"));
			ExtentLogger.pass("Applied " + filterSubType + " SubFilter and Verified Filtered Record");
		} catch (Exception e) {
			Assert.fail("Failed in Applying Date Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}
	
	public OrdersPage verifyDashboard() {
		String filterType = "", filterValue = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDVALUE");
			sleepFor(2000);
			completeData = readCurrentTable();
			if (filterType.equalsIgnoreCase("client")) {

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Client");
					}
				}
			} else if (filterType.equalsIgnoreCase("campus manager")) {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Campus Manager").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Campus Manager");
					}
				}
			} else if (filterType.equalsIgnoreCase("type")) {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Type").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Type");
					}
				}
			}
			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass(
					"Found " + completeData.size() + " matches after applying Filter. Verified all Matched Records has "
							+ filterType + " as " + filterValue + ".");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Dashboard after filtering. " + e.getMessage());
		}
		return this;
	}
	
	public OrdersPage verifyRecordsCount(OrdersTabs ordersTab) {
		try {
			sleepFor(300);
			int rowCount = 0, recordsPerPage = 0, totRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(By
							.xpath(DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(ordersTab))))
					.getText());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(ordersTab))));
			sleepFor(500);	

			if (findElementPresence(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))) {
				recordsPerPage = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
			} else {
				recordsPerPage = totRecords;
			}

			if (totRecords < recordsPerPage) {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount + " for " + getStringValue(ordersTab));
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount + " for "
							+ getStringValue(ordersTab));
				}
			} else {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				while (checkCondition(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"),
						ElementCheckStrategy.DISPLAYED)) {
					clickElement(By.xpath("//i[@class='datatable-icon-right']"));

					rowCount = rowCount
							+ DriverManager.getDriver()
									.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size()
							- 1;
				}
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount);
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount);
				}
			}
		} catch (Exception e) {
			Assert.fail("Unable to Verify Records Count. " + e.getMessage());
		}
		return this;
	}

	public int getColumntempIndex(String colName) throws Exception {
		int index = 0;
		if (colName.equalsIgnoreCase("order #"))
			index = 2;
		else if (colName.equalsIgnoreCase("status"))
			index = 5;
		else if (colName.equalsIgnoreCase("order name"))
			index = 9;
		else if (colName.equalsIgnoreCase("client"))
			index = 12;
	//	else if (colName.equalsIgnoreCase("campus manager"))
			else if (colName.equalsIgnoreCase("manager"))
			index = 15;
		else if (colName.equalsIgnoreCase("type"))
			index = 18;
		else if (colName.equalsIgnoreCase("due on"))
			index = 21;
		else if (colName.equalsIgnoreCase("created on"))
			index = 24;
		
		if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("manager") ) {
			
			if (colName.equalsIgnoreCase("client"))
				index = 12;
			else if (colName.equalsIgnoreCase("type"))
				index = 15;
			else if (colName.equalsIgnoreCase("due on"))
				index = 28;
			else if (colName.equalsIgnoreCase("created on"))
				index = 21;
			
		}

		if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("client")) {
			
			 if (colName.equalsIgnoreCase("type"))
				index = 13;
			else if (colName.equalsIgnoreCase("due on"))
				index = 16;
			else if (colName.equalsIgnoreCase("created on"))
				index = 19;
		}
		return index;
	}

	public String getStringValue(OrdersTabs ordersTab) {
		String tabString = "";
		if (ordersTab.equals(OrdersTabs.ALL_ACTIVE)) {
			tabString = "All Active";
		} else if (ordersTab.equals(OrdersTabs.AT_FULFILLMENT)) {
			tabString = "At Fulfillment";
		} else if (ordersTab.equals(OrdersTabs.AT_PRINTER)) {
			tabString = "At Printer";
		} else if (ordersTab.equals(OrdersTabs.DELIVERED)) {
			tabString = "Delivered";
		} else if (ordersTab.equals(OrdersTabs.DRAFT)) {
			tabString = "Draft";
		} else if (ordersTab.equals(OrdersTabs.FAILED_GROUP_ORDER)) {
			tabString = "Failed Group Order";
		} else if (ordersTab.equals(OrdersTabs.OPEN_GROUP_ORDER)) {
			tabString = "Open Group Order";
		} else if (ordersTab.equals(OrdersTabs.SHIPPED)) {
			tabString = "Shipped";
		} else if (ordersTab.equals(OrdersTabs.UNPROCESSED)) {
			tabString = "Unprocessed";
		}
		return tabString;
	}
	
	public void selectDate(String day, String month, String year) {
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			clickElementJS(By.xpath("(//div[text()='" + day + "'])[1]"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

// Added by Vidya	
	
public OrdersPage clickOrderButton() {
	
	try {
		
		clickElement(btnOrder);
		sleepFor(500);
		
		ExtentLogger.pass("Clicked Order Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to click Order Button. " + e.getMessage());
	}
	
	return this;
}	
	

public OrdersPage selectOrderType(String orderType) {
	
	
	try {
		
		if (orderType.equalsIgnoreCase("Regular Order")) { 
			
			clickElement(txtRegularOrder);
			sleepFor(500);
		}
		if (orderType.equalsIgnoreCase("Group Order")) { 
			
			clickElement(txtGroupOrder);
			sleepFor(500);
		}
		if (orderType.equalsIgnoreCase("Sample Order")) { 
			
			clickElement(txtSampleOrder);
			sleepFor(500);
		}
	
		ExtentLogger.pass("Selected Order Type Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to select Order Type. " + e.getMessage());
	}
	 
	return this;
}

public OrdersPage fillOrderDetails(String clientType) {
	
	String orderTitle = "", clientName = "", dueDate = "", campaign = "";
	String date = null;
	try {
		
		if (!findElementPresence(divEnterOrderDetails)) {
			throw new Exception("Enter Order Details Not Found during Add Order.");
		}
		
		orderTitle = "Order " + DataGeneratorUtils.randString();
		campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_ORDERS");
		enterData(txtOrderTitle, orderTitle);
		
		if (clientType.equalsIgnoreCase("Existing")) {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_ORDERS");
			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		} else if (clientType.equalsIgnoreCase("New")) {
			clickElement(btnCreateClient);
			sleepFor(1000);
			createClient();
			clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

	
			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		}
		
		clickElement(txtDueDate);
		sleepFor(500);
		date = selectRandDate(ThreadLocalRandom.current().nextInt(2, 5));
		sleepFor(500);
		date = getTheSubString(date);
		System.out.println("date = " +date);
		
		clickElement(drpDwnCampaign);
		enterData(txtCampaign, campaign);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
		sleepFor(500);
		
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORDERTITLE", orderTitle);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE", date);
		
		ExtentLogger.pass("Filled Order Details Successfully.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Orders Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage createClient() {
	try {
		HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
		HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
		HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

		enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

		enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
				contactDetailsMap.get("PHONENUMBER"));
		
		clickElementJS(btnSetEmailAndPassword);

		enterData(txtemail, passwordDetailsMap.get("EMAIL"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

		enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
		enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
				passwordDetailsMap.get("PASSWORD"));

		clickElementJS(btnAddInfo);
		clickElementJS(drpDwnSchoolClient);
		sleepFor(200);
		enterData(drpDwnSchoolClient, schoolDetailsMap.get("SCHOOL"));
		sleepFor(200);
		clickElementJS(By.xpath(
				DynamicXpathUtils.getXpathForString(drpDwnSchoolValueClient, schoolDetailsMap.get("SCHOOL"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

		clickElementJS(drpDwnOrganizationClient);
		sleepFor(200);
		enterData(drpDwnOrganizationClient, schoolDetailsMap.get("ORGANIZATION"));
		sleepFor(200);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValueClient,
				schoolDetailsMap.get("ORGANIZATION"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
				schoolDetailsMap.get("ORGANIZATION"));

		clickElementJS(btnPosition);
		enterData(btnPosition, "Apparel 123");
		sleepFor(2000);

		clickElementJS(
				By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

		clickElementJS(btnCreateAccount);
		clickElementJS(btnBackToWork);
		sleepFor(1000);
		ExtentLogger.pass("Created Client for Order Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Creating Client for Order. " + e.getMessage());
	}
	return this;
}

public OrdersPage createAndCanelClient() {
	try {
		HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
		HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
		HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

		enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

		enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
				contactDetailsMap.get("PHONENUMBER"));

		clickElementJS(btnSetEmailAndPassword);
		enterData(txtemail, passwordDetailsMap.get("EMAIL"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

		enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
		enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
				passwordDetailsMap.get("PASSWORD"));

		clickElementJS(btnAddInfo);
		clickElementJS(drpDwnSchoolClient);
		sleepFor(200);
		enterData(drpDwnSchoolClient, schoolDetailsMap.get("SCHOOL"));
		sleepFor(200);
		clickElementJS(By.xpath(
				DynamicXpathUtils.getXpathForString(drpDwnSchoolValueClient, schoolDetailsMap.get("SCHOOL"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

		clickElementJS(drpDwnOrganizationClient);
		sleepFor(200);
		enterData(drpDwnOrganizationClient, schoolDetailsMap.get("ORGANIZATION"));
		sleepFor(200);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValueClient,
				schoolDetailsMap.get("ORGANIZATION"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
				schoolDetailsMap.get("ORGANIZATION"));

		clickElementJS(btnPosition);
		enterData(btnPosition, "Apparel 123");
		sleepFor(2000);

		clickElementJS(
				By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

		clickElementJS(btnCancelClient);
		sleepFor(500);
		clickElement(selectYes);
		
		sleepFor(1000);
		ExtentLogger.pass("Closed Client for Order Successfully");
	} catch (Exception e) {
		Assert.fail("Failed to close Client for Order. " + e.getMessage());
	}
	return this;
}

public void selectRandDate() throws Exception {
	int i = 0;
	try {
		LocalDate today = LocalDate.now();
		selectDate(String.valueOf( today.plusDays(15).getDayOfMonth()),
				StringUtils.capitalize(today.plusDays(15).getMonth().toString().toLowerCase().substring(0, 3)),
				String.valueOf(today.plusDays(15).getYear()));

	} catch (Exception e) {
		throw new Exception("Unable to select date of " + i + " days from Today");
	}
}

public String selectRandomDate(long daysAfter) throws Exception {
	int i = 0;
	// LocalDate date;
	LocalDateTime date;

	try {
		// date = LocalDate.now().plusDays(daysAfter);
		date = LocalDateTime.now().plusDays(daysAfter);
		selectDate(String.valueOf(1),
				StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
				String.valueOf(date.getYear()));

	} catch (Exception e) {
		throw new Exception("Unable to select date of " + i + " days from Today");
	}
	return StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)) + " "
			+ String.valueOf(1);
}

public OrdersPage clickAddProofButton() {
	
	try {
		
		sleepFor(500);
		clickElement(btnAddProof);
		
		ExtentLogger.pass("Clicked Add Proof Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to Click Add Proof Button. " + e.getMessage());
	}
	
	return this;
	
}

public String selectRandDate(long daysAfter) throws Exception {
	int i = 0;
//	 LocalDate date;
	LocalDateTime date;

	try {
	//	 date = LocalDate.now().plusDays(daysAfter);
		date = LocalDateTime.now().plusDays(daysAfter);
		selectDate(String.valueOf(date.getDayOfMonth()),
				StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
				String.valueOf(date.getYear()));

	} catch (Exception e) {
		throw new Exception("Unable to select date of " + i + " days from Today");
	}
	return StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)) + " "
			+ String.valueOf(date.getDayOfMonth());
}

public OrdersPage closeBrowser() {
	
	Driver.quitDriver();
	try {
	//	RunTimePropertyFileUtils.deleteRuntimePropFile(getTestCaseName());
		System.out.println("Please uncomment the delete runtime *************************");
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	
	return this;
}

public OrdersPage fillProofDetails() {
	
     String styleCode="", color ="Black" ;
     String collegiateMark = "", organization ="";
	
	try {
		
		clickElement(txtSearchProof);
		enterData(txtSearchProof, "115048");
		sleepFor(1000);
		
		clickElementJS(selectProof);
		sleepFor(250);
//		clickElementJS(selectProof);
//		sleepFor(250);
		clickElement(selectImage);
		sleepFor(250);
		
		styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_ORDERS");
		clickElementJS(drpDwnStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);

		clickElement(drpDwnColor);
//		clickElementJS(drpDwnColor);
//		clearData(txtColor);
//		enterData(txtColor , "Black");
//		sleepFor(300);
		clickElement(optionColor);
		sleepFor(500);
		
		clickElement(selectPrimaryImage);
		sleepFor(500);
		clickElement(selectNextPrimaryImage);
		sleepFor(500);
		
		collegiateMark = DataGeneratorUtils.randSchoolName();
		
		
		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
		sleepFor(500);
		
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
		sleepFor(500);
		
		clickElementJS(txtComments);
		enterData(txtComments, "Sample");
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "Color", color);
		
		ExtentLogger.pass("Filled Proof Details Successfully.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Proof Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage fillProofDetails(String type) {
	
	String styleCodeExternal = "" , styleCodeFP = "" , styleCodeAlpha = "";
	String colorExternal = "Blue", colorFP = "Beige" ;
	String productName = "Shirts" , productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html" ;
    String collegiateMark = "", organization ="";
	
	try {
		
		clickElement(txtSearchProof);
		enterData(txtSearchProof, "115048");
		sleepFor(1000);
		
		clickElementJS(selectProof);
		sleepFor(250);
//		clickElementJS(selectProof);
//		sleepFor(250);
		clickElement(selectImage);
		sleepFor(250);

		if (type.equalsIgnoreCase("External")) {

			styleCodeExternal = "New Custom Code";

			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeExternal);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString("//span[contains(text(),'%s')]", styleCodeExternal)));
			sleepFor(5000);

			enterData(txtCustomColor, "Blue");
			enterData(txtCustomProductName, "Shirts");
			enterData(txtCustomProductLink, "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
			selectOrganizationandCollegiateMarksforExternal();
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEEXTERNAL", styleCodeExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOREXTERNAL", colorExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", productName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTLINK", productLink);
			
		} else if (type.equalsIgnoreCase("FP")) {
			styleCodeFP = "Fresh Prints Madison Shorts FP16";
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeFP);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeFP)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);
			selectOrganizationandCollegiateMarksforFP();

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEFP", styleCodeFP);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORFP", colorFP);
			
			if (!findElementPresence(By.xpath("//img[@class='apparel__preview']"))) {
				ExtentLogger.fail("Apparel Previews are not displayed for FP Style Codes");
			}

		} else if (type.equalsIgnoreCase("Alpha")) {
			styleCodeAlpha = "Gildan G800";
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeAlpha);
			sleepFor(1000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeAlpha)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEALPHA", styleCodeAlpha);
			selectOrganizationandCollegiateMarksforAlpha();
		}
		
		clickElement(selectPrimaryImage);
		sleepFor(500);
		clickElement(selectNextPrimaryImage);
		sleepFor(500);
		
//		collegiateMark = DataGeneratorUtils.randSchoolName();
//		
//		
//		clickElementJS(drpdwnCollegiateMark);
//		clearData(txtCollegiateMark);
//		enterData(txtCollegiateMark, collegiateMark);
//		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
//		sleepFor(500);
//		
//		organization = DataGeneratorUtils.randOrganizationName();
//
//		clickElementJS(drpdwnOrganization);
//		clearData(txtOrganization);
//		enterData(txtOrganization, organization);
//		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
//		sleepFor(500);
		
		clickElementJS(txtComments);
		enterData(txtComments, "Sample");
		sleepFor(500);
		
//		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
//		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);
		
		ExtentLogger.pass("Filled Proof Details Successfully.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Proof Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage selectOrganizationandCollegiateMarksforFP() {
	
	 String collegiateMark = "", organization ="";
	
	try {
		
		collegiateMark = DataGeneratorUtils.randSchoolName();
		
		
		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
		sleepFor(500);
		
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARKFP", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATIONFP", organization);
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Organization and CollegiateMarks Details for FP. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage selectOrganizationandCollegiateMarksforAlpha() {
	
	 String collegiateMark = "", organization ="";
	
	try {
		
		collegiateMark = DataGeneratorUtils.randSchoolName();
		
		
		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
		sleepFor(500);
		
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARKALPHA", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATIONALPHA", organization);
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Organization and CollegiateMarks Details for ALPHA. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage selectOrganizationandCollegiateMarksforExternal() {
	
	 String collegiateMark = "", organization ="";
	
	try {
		
		collegiateMark = DataGeneratorUtils.randSchoolName();
		
		
		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
		sleepFor(500);
		
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARKEXTERNAL", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATIONEXTERNAL", organization);
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Organization and CollegiateMarks Details for External. " + e.getMessage());
	}
	
	return this;
}
public OrdersPage editleftPanelOrderDetails(String clientType) {
	
	String orderTitle = "", clientName = "", dueDate = "", campaign = "";
	String date = null;
	try {
		
		clickElementJS(iconDownEditOrderDetails);
		
		orderTitle = "Order " + DataGeneratorUtils.randString();
		campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_ORDERS");
		clearData(txtOrderTitle);
		enterData(txtOrderTitle, orderTitle);
		
		if (clientType.equalsIgnoreCase("Existing")) {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_ORDERS");
			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		} 
		clickElement(txtDueDate);
	//	clearData(txtDueDate);
		sleepFor(1000);
		date = selectRandDate(ThreadLocalRandom.current().nextInt(2, 5));
		sleepFor(500);
		
		clickElement(drpDwnCampaign);
		clearData(drpDwnCampaign);
		enterData(txtCampaign, campaign);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
		sleepFor(500);
		
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORDERTITLE", orderTitle);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DATE", date);
		
		ExtentLogger.pass("Filled Order Details Successfully.");
		clickElementJS(iconDownEditOrderDetails);
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Orders Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage clickAddQuantityandPrice() {
	
	try {
		
		clickElement(btnAddQtyandPrice);
		sleepFor(200);
		ExtentLogger.pass("Clicked Add Quantity & Price Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Add Quantity & Price Button " + e.getMessage());
	}

	
	return this;
} 

public OrdersPage fillQuantityandPrice() {
	
	
	String sqty = null, mqty = null, lqty = null, xlqty = null, xl2qty = null , xl3qty = null ;
	String price = null;
	
	try {
		
		
			sleepFor(1000);
			sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl2qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl3qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			price = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
			
			
			clickElement(txtSQty);
			enterData(txtSQty, sqty);
			sleepFor(200);
			clickElement(txtMQty);
			enterData(txtMQty, mqty);
			sleepFor(200);
			clickElement(txtLQty);
			enterData(txtLQty, lqty);
			sleepFor(200);
			clickElement(txtXLQty);
			enterData(txtXLQty, xlqty);
			sleepFor(200);
//			clickElement(txtXL2Qty);
//			enterData(txtXL2Qty, xl2qty);
//			sleepFor(200);
//			clickElement(txtXL3Qty);
//			enterData(txtXL3Qty, xl3qty);
//			sleepFor(200);
			
			clickElement(txtPrice);
			enterData(txtPrice, price);
			sleepFor(200);
			
			
			System.out.println("sqty = " + sqty);
			System.out.println("mqty = " + mqty);
			System.out.println("lqty = " + lqty);
			System.out.println("xlqty = " + xlqty);
//			System.out.println("xl2qty = " + xl2qty);
//			System.out.println("xl3qty = " + xl3qty);
			System.out.println("PRICE = " + price);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTY" , sqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTY" , mqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTY" , lqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTY", xlqty);
//			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XL2QTY", xl2qty);
//			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XL3QTY", xl3qty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICE", price);
			
		ExtentLogger.pass("Filled Quantity and Price Successfully.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Quantity and Price. " + e.getMessage());
	}
	
	
	return this;
}

public OrdersPage clickAddShippingAddress() {
	
	try {
		
		clickElement(btnAddShippingAddress);
		sleepFor(200);
		ExtentLogger.pass("Clicked Add Shipping Address Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Add Shipping Address " + e.getMessage());
	}
	
	return this;
} 

public OrdersPage selectShipmentType(String shipmentType) {
	
	try {
		
		if (shipmentType.equalsIgnoreCase("Bulk Ship")) { 
			
			clickElement(btnBulkShip);
			sleepFor(500);
		}
		if (shipmentType.equalsIgnoreCase("Individual Ship")) { 
			
			clickElement(btnIndividualShip);
			sleepFor(500);
		}
		
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TYPEVALUE", shipmentType);
		ExtentLogger.pass("Selected Shipment Type Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to select Shipment Type. " + e.getMessage());
	}
	
	return this;
}


public OrdersPage fillBulkShipmentAddress() {
	
	try {
		
		HashMap<String, String> shippingDetailsMap = null;
		
		if (getTestCaseName().toLowerCase().contains("invalidaddress")) {
			shippingDetailsMap = DataGeneratorUtils.generateShippingDetails("Invalid");
		} else {
			shippingDetailsMap = DataGeneratorUtils.generateShippingDetails("Valid");
		}
		
		enterData(txtShippingName, shippingDetailsMap.get("SHIPPINGNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPINGNAME",
				shippingDetailsMap.get("SHIPPINGNAME"));

		enterData(txtAttentionName, shippingDetailsMap.get("ATTENTIONNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ATTENTIONNAME",
				shippingDetailsMap.get("ATTENTIONNAME"));
		
		enterData(txtStreet, shippingDetailsMap.get("STREET"));	
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STREET", shippingDetailsMap.get("STREET"));

		enterData(txtSuite, shippingDetailsMap.get("SUITE"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUITE", shippingDetailsMap.get("SUITE"));

		enterData(txtCity, shippingDetailsMap.get("CITY"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CITY", shippingDetailsMap.get("CITY"));

		clickElement(drpDwnState);
		enterData(drpDwnState, shippingDetailsMap.get("STATE"));
		clickElementJS(
				By.xpath(DynamicXpathUtils.getXpathForString(drpDwnStateValue, shippingDetailsMap.get("STATE"))));
		
		enterData(txtZipCode, shippingDetailsMap.get("ZIPCODE"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ZIPCODE", shippingDetailsMap.get("ZIPCODE"));
		
		ExtentLogger.pass("Entered Bulk Shipping Address Fields Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Enter Bulk Shipping Address . " + e.getMessage());
	}	
	
	return this;
}

public OrdersPage clickReviewOrder() {
	
	try {
		
		clickElement(btnReviewOrder);
		sleepFor(200);
		ExtentLogger.pass("Clicked Review Order Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Review Order " + e.getMessage());
	}
	
	return this;
} 

public OrdersPage clickProofSkip() {
	
	try {
		
		clickElement(btnSkipforProof);
		ExtentLogger.pass("Clicked Proof Skip Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Proof Skip " + e.getMessage());
	}
	
	return this;
}

public OrdersPage fillItemDetails() {
	String styleCode = "Russell Athletic 596HBM";
	String color = "Black";
	try {
		
		clickElementJS(drpDwnStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);

		clickElement(drpDwnColor);
		clickElementJS(optionColor);


		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		
		System.out.println("styleCode = "+styleCode);
		System.out.println("color = " +color);
		
		ExtentLogger.pass("Filled Item Details Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Filling Item Details. " + e.getMessage());
	}
	return this;
}

public OrdersPage fillItemDetails(String type) {
	String styleCodeExternal = "" , styleCodeFP = "" , styleCodeAlpha = "";
	String colorExternal = "Blue", colorFP = "Beige" ;
	String productName = "Shirts" , productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html" ;
	try {
		if (type.equalsIgnoreCase("External")) {

			styleCodeExternal = "New Custom Code";

			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeExternal);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString("//span[contains(text(),'%s')]", styleCodeExternal)));
			sleepFor(5000);

			enterData(txtCustomColor, "Blue");
			enterData(txtCustomProductName, "Shirts");
			enterData(txtCustomProductLink, "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEEXTERNAL", styleCodeExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOREXTERNAL", colorExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", productName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTLINK", productLink);
			
		} else if (type.equalsIgnoreCase("FP")) {
			styleCodeFP = "Fresh Prints Madison Shorts FP16";
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeFP);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeFP)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEFP", styleCodeFP);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORFP", colorFP);
			
			if (!findElementPresence(By.xpath("//img[@class='apparel__preview']"))) {
				ExtentLogger.fail("Apparel Previews are not displayed for FP Style Codes");
			}

		} else if (type.equalsIgnoreCase("Alpha")) {
			styleCodeAlpha = "Gildan G800";
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCodeAlpha);
			sleepFor(1000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeAlpha)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEALPHA", styleCodeAlpha);
		}


		ExtentLogger.pass("Filled Item Details Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Filling Item Details. " + e.getMessage());
	}
	return this;
}

public OrdersPage ClickAddDesignInfo () {
	
	try {
		
		clickElement(btnAddDesignInfo);
		ExtentLogger.pass("Clicked Add Design Info Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Add Design Info. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage fillDesignDetails() {
	
	 String collegiateMark = "", organization ="";
	 
	try {
		
		collegiateMark = DataGeneratorUtils.randSchoolName();
		
		
		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));
		sleepFor(500);
		
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
		sleepFor(500);
		
		clickElementJS(txtComments);
		enterData(txtComments, "Sample test");
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);
		
		ExtentLogger.pass("Filled Proof Details Successfully.");
		
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Proof Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage editleftPanelItemDetails() {
	
	String styleCode = "Russell Athletic 25843M";
	String color = "Black";
	try {
		
		clickElementJS(iconDownEditItemInfo);
		
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);

		clickElement(drpDwnColor);
		clearData(txtColor);
		enterData(txtColor, color);
		clickElementJS(optionColor);


		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		
		
		ExtentLogger.pass("Filled Item Details Successfully");
		clickElementJS(iconDownEditItemInfo);
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Item Details. " + e.getMessage());
	}
	return this;
}

public OrdersPage addAnotherItem() {
	
	try {
		
		clickElement(btnAnotherItem);
		ExtentLogger.pass("Clicked Another Item Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Another Item. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage getOrderNumber () {
	
	String orderNo = "";
	
	try {
		
		sleepFor(100);
		orderNo = getData(By.xpath("//div[@class='order-item-id cursor-pointer active-order-item-id ng-star-inserted']"));
		
		String ordernumber = orderNo.substring(1, 6);
		System.out.println("ordernumber = "+ordernumber);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORDERNUMBER", ordernumber);
		
		ExtentLogger.pass("Successfully Got Order Number ");
		
	} catch (Exception e) {
		Assert.fail("Unable to get Order Number. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage verifyReviewOrderDetails() {
	
	String orderTitle = "", clientName = "", dueDate = "", getcampaign = "";
	
	
	try {
		
		sleepFor(1000);
		getOrderNumber();
		softAssert = new SoftAssert();
		
		orderTitle = getData(By.xpath("//div[@class='order-title']"));
		clientName = getData(By.xpath("//div[@class='order-client']"));
		getcampaign = getData(By.xpath("//div[@class='order-campaign']"));
		
		String campaign = getcampaign.substring(10);
		
//		dueDate = getData(By.xpath("//div[@class='form-group w-100 dropdown-date-picker calender position-relative']"));
		
		softAssert.assertEquals(orderTitle,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORDERTITLE"),
				"Unexpected Order Title in Summary");
		
		softAssert.assertEquals(clientName,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME"),
				"Unexpected Client Name in Summary");
		
		softAssert.assertEquals(campaign,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CAMPAIGN"),
				"Unexpected Campaign in Summary");
		
//		softAssert.assertEquals(dueDate,
//				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE"),
//				"Unexpected Doller Value in Summary");
		
		softAssert.assertAll();
		ExtentLogger.pass("Successfully Verified Review Order Details");
		
	} catch (Exception e) {
		Assert.fail("Failed in Verifying Review Order Details. " + e.getMessage());
	}

	return this;
}


public OrdersPage reviewItemDetails() {
	
	String styleCode = "" , color = "" ;
	String collegiateMarks ="" , greekMarks = "";	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCode = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		color = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		collegiateMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		greekMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[4]"));
		
		softAssert.assertEquals(styleCode,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODE"),
				"Unexpected StyleCode in Summary");
		softAssert.assertEquals(color,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "Color"),
				"Unexpected Color in Summary");
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK"),
				"Unexpected COLLEGIATEMARK in Summary");
		softAssert.assertEquals(greekMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
				"Unexpected GreekMarks in Summary");
		
		
		ExtentLogger.pass("Successfully Reviewed Item Details");
		
	} catch (Exception e) {
		Assert.fail("Failed in Review Item Details. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewQuantityandPrice() {
	
	String sqty = "", mqty = "", lqty = "", xlqty = "";
	String price = "";
	try {
		
	
		sqty = getAttributeValue(getSqty, "value");
		mqty = getAttributeValue(getMqty, "value");
		lqty = getAttributeValue(getLqty, "value");
		xlqty = getAttributeValue(getXLqty, "value");
		price = getAttributeValue(getPrice, "value");
		
		
		softAssert.assertEquals(sqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTY"),
				"Unexpected sqty in Summary");
		softAssert.assertEquals(mqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTY"),
				"Unexpected MQTY in Summary");
		softAssert.assertEquals(lqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTY"),
				"Unexpected LQTY in Summary");
		softAssert.assertEquals(xlqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTY"),
				"Unexpected XLQTY in Summary");
		softAssert.assertEquals(price,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICE"),
				"Unexpected PRICE in Summary");
		
		ExtentLogger.pass("Successfully Reviewed Quantity and Price");
		
	} catch (Exception e) {
		Assert.fail("Failed in Quantity and Price. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage clickSubmit() {
	
	try {
		
		clickElement(btnSubnit);
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
				By.xpath("//div[contains(text(),'" + ORDERS_CREATION_SUCCESS_MESSAGE + "')]"));
		
		ExtentLogger.pass("Order Submitted Successfully");
	} catch (Exception e) {
		Assert.fail("Unable to Submit Order. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage filterOrder() {
	String ordernumber = "";
	try {
		ordernumber = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORDERNUMBER");
		System.out.println("ordernumber = " + ordernumber);
		enterData(txtSearchOrder, ordernumber);
		ExtentLogger.pass("Filtered " + ordernumber + " Order Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Filtering " + ordernumber + " Order. " + e.getMessage());
	}
	return this;
}

public OrdersPage verifyOrderDashboard() {
	
	ArrayList<HashMap<String, String>> completeData = null;
	String orderNumber = "", type = "", orderName = "", client = "", dueDate = "";
	
	try {
		
		sleepFor(2000);
		completeData = readCurrentTable();
		
		orderNumber = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORDERNUMBER");
		orderName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORDERTITLE");
		client = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME");
		dueDate = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DATE");
		type = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPEVALUE");
	
	
		if (completeData.size() != 1) {
			throw new Exception("Searched Record is not filtered Correctly.");
		} else {
			
			for (HashMap<String, String> eachRow : completeData) {
				orderNumber = eachRow.get("Order #");
				if (!eachRow.get("Type").equalsIgnoreCase(type)) {
					System.out.println(eachRow.get("Type") + ": " + type);
					throw new Exception("Filtered Records doesn't have the expected Type: " + type);
				}
				if (!eachRow.get("Order #").equalsIgnoreCase(orderNumber)) {
					System.out.println(eachRow.get("Order #") + ": " + orderNumber);
					throw new Exception("Filtered Records doesn't have the expected Order Number: " + orderNumber);
				}
				if (!eachRow.get("Order Name").equalsIgnoreCase(orderName)) {
					System.out.println(eachRow.get("Order Name") + ": " + orderName);
					throw new Exception("Filtered Records doesn't have the expected Order Name: " + orderName);
				}
				if (!eachRow.get("Due On").equalsIgnoreCase(dueDate)) {
					System.out.println(eachRow.get("Due On") + ": " + dueDate);
					throw new Exception("Filtered Records doesn't have the expected Due On: " + dueDate);
				}
				if (!RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("client")) {
					if (!eachRow.get("Client").equalsIgnoreCase(client)) {
						System.out.println(eachRow.get("Client") + ": " + client);
						throw new Exception("Filtered Records doesn't have the expected Client: " + client);
					}
				}
				
				
			}
		}
		
		ExtentLogger.pass("Verfied Dashboard after Filtering the Created Order");
	} catch (Exception e) {
		Assert.fail("Unable to Verify Dashboard after filtering. " + e.getMessage());
	}
	return this;
}


public OrdersPage fillQuantityandPriceforFP() {
	
	String sqty = null, mqty = null, lqty = null, xlqty = null, xl2qty = null , xl3qty = null ;
	String price = null;
	
	try {
			sleepFor(1000);
			sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl2qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl3qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			price = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
				
			clickElement(txtSQty);
			enterData(txtSQty, sqty);
			sleepFor(200);
			clickElement(txtMQty);
			enterData(txtMQty, mqty);
			sleepFor(200);
			clickElement(txtLQty);
			enterData(txtLQty, lqty);
			sleepFor(200);
			clickElement(txtXLQty);
			enterData(txtXLQty, xlqty);
			sleepFor(200);

			clickElement(txtPrice);
			enterData(txtPrice, price);
			sleepFor(200);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTYFP" , sqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTYFP" , mqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTYFP" , lqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTYFP", xlqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICEFP", price);
			
		ExtentLogger.pass("Filled Quantity and Price Successfully for FP Product.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Quantity and Price for FP Product. " + e.getMessage());
	}
	return this;
}

public OrdersPage fillQuantityandPriceforAlpha() {
	
	String sqty = null, mqty = null, lqty = null, xlqty = null, xl2qty = null , xl3qty = null ;
	String price = null;
	
	try {
			sleepFor(1000);
			sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl2qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl3qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			price = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
				
			clickElement(txtSQty);
			enterData(txtSQty, sqty);
			sleepFor(200);
			clickElement(txtMQty);
			enterData(txtMQty, mqty);
			sleepFor(200);
			clickElement(txtLQty);
			enterData(txtLQty, lqty);
			sleepFor(200);
			clickElement(txtXLQty);
			enterData(txtXLQty, xlqty);
			sleepFor(200);

			clickElement(txtPrice);
			enterData(txtPrice, price);
			sleepFor(200);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTYALPHA" , sqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTYALPHA" , mqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTYALPHA" , lqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTYALPHA", xlqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICEALPHA", price);
			
		ExtentLogger.pass("Filled Quantity and Price Successfully for ALPHA Product.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Quantity and Price for ALPHA Product. " + e.getMessage());
	}
	return this;
}

public OrdersPage fillQuantityandPriceforExternal() {
	
	String sqty = null, mqty = null, lqty = null, xlqty = null, xl2qty = null , xl3qty = null ;
	String price = null;
	
	try {
			sleepFor(1000);
			sqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			mqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			lqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xlqty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl2qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			xl3qty = String.valueOf(ThreadLocalRandom.current().nextInt(1, 10));
			price = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
				
			clickElement(txtSQty);
			enterData(txtSQty, sqty);
			sleepFor(200);
			clickElement(txtMQty);
			enterData(txtMQty, mqty);
			sleepFor(200);
			clickElement(txtLQty);
			enterData(txtLQty, lqty);
			sleepFor(200);
			clickElement(txtXLQty);
			enterData(txtXLQty, xlqty);
			sleepFor(200);

			clickElement(txtPrice);
			enterData(txtPrice, price);
			sleepFor(200);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SQTYEXTERNAL" , sqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MQTYEXTERNAL" , mqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LQTYEXTERNAL" , lqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "XLQTYEXTERNAL", xlqty);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICEEXTERNAL", price);
			
		ExtentLogger.pass("Filled Quantity and Price Successfully for EXTERNAL Product.");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Quantity and Price for EXTERNAL Product. " + e.getMessage());
	}
	return this;
}

public OrdersPage selectFPDetails() {
	
	
	try {
		
		clickElement(btnfPselect);
		ExtentLogger.pass("Selected FP product details Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to Select FP product details" + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewItemDetailsforFP() {
	
	String styleCode = "" , color = "" ;
	String collegiateMarks ="" , greekMarks = "";	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCode = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		color = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		collegiateMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		greekMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[4]"));
		
		softAssert.assertEquals(styleCode,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEFP"),
				"Unexpected StyleCode in Summary");
		softAssert.assertEquals(color,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLORFP"),
				"Unexpected Color in Summary");
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARKFP"),
				"Unexpected COLLEGIATEMARK in Summary");
		softAssert.assertEquals(greekMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATIONFP"),
				"Unexpected GreekMarks in Summary");
		
		
		ExtentLogger.pass("Successfully Reviewed Item Details for FP");
		
	} catch (Exception e) {
		Assert.fail("Failed in Review Item Details for FP. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewQuantityandPriceforFP() {
	
	String sqty = "", mqty = "", lqty = "", xlqty = "";
	String price = "";
	try {
		
		sqty = getAttributeValue(getSqty, "value");
		mqty = getAttributeValue(getMqty, "value");
		lqty = getAttributeValue(getLqty, "value");
		xlqty = getAttributeValue(getXLqty, "value");
		price = getAttributeValue(getPrice, "value");
		
		softAssert.assertEquals(sqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTYFP"),
				"Unexpected sqty in Summary");
		softAssert.assertEquals(mqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTYFP"),
				"Unexpected MQTY in Summary");
		softAssert.assertEquals(lqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTYFP"),
				"Unexpected LQTY in Summary");
		softAssert.assertEquals(xlqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTYFP"),
				"Unexpected XLQTY in Summary");
		softAssert.assertEquals(price,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEFP"),
				"Unexpected PRICE in Summary");
		
		ExtentLogger.pass("Successfully Reviewed Quantity and Price for FP");
		
	} catch (Exception e) {
		Assert.fail("Failed in Quantity and Price FOR FP. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage selectAlphaDetails() {
	
	try {
		
		clickElement(btnAlphaselect);
		ExtentLogger.pass("Selected FP product details Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to Select FP product details" + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewItemDetailsforAlpha() {
	
	String styleCode = "" , color = "" ;
	String collegiateMarks ="" , greekMarks = "";	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCode = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		color = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		collegiateMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		greekMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[4]"));
		
		softAssert.assertEquals(styleCode,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEALPHA"),
				"Unexpected StyleCode in Summary");
		softAssert.assertEquals(color,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLORALPHA"),
				"Unexpected Color in Summary");
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARKALPHA"),
				"Unexpected COLLEGIATEMARK in Summary");
		softAssert.assertEquals(greekMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATIONALPHA"),
				"Unexpected GreekMarks in Summary");
		
		
		ExtentLogger.pass("Successfully Reviewed Item Details for Alpha");
		
	} catch (Exception e) {
		Assert.fail("Failed in Review Item Details for Alpha. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewQuantityandPriceforAlpha() {
	
	String sqty = "", mqty = "", lqty = "", xlqty = "";
	String price = "";
	try {
		
		sqty = getAttributeValue(getSqty, "value");
		mqty = getAttributeValue(getMqty, "value");
		lqty = getAttributeValue(getLqty, "value");
		xlqty = getAttributeValue(getXLqty, "value");
		price = getAttributeValue(getPrice, "value");
		
		softAssert.assertEquals(sqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTYALPHA"),
				"Unexpected sqty in Summary");
		softAssert.assertEquals(mqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTYALPHA"),
				"Unexpected MQTY in Summary");
		softAssert.assertEquals(lqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTYALPHA"),
				"Unexpected LQTY in Summary");
		softAssert.assertEquals(xlqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTYALPHA"),
				"Unexpected XLQTY in Summary");
		softAssert.assertEquals(price,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEALPHA"),
				"Unexpected PRICE in Summary");
		
		ExtentLogger.pass("Successfully Reviewed Quantity and Price for Alpha");
		
	} catch (Exception e) {
		Assert.fail("Failed in Quantity and Price FOR Alpha. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage selectExternalDetails() {
	
	try {
		
		clickElement(btnExternalselect);
		ExtentLogger.pass("Selected FP product details Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to Select FP product details" + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewItemDetailsforExternal() {
	
	String styleCode = "" , color = "" ;
	String collegiateMarks ="" , greekMarks = "";	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCode = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		color = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		collegiateMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		greekMarks = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[4]"));
		
		softAssert.assertEquals(styleCode,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEEXTERNAL"),
				"Unexpected StyleCode in Summary");
		softAssert.assertEquals(color,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLOREXTERNAL"),
				"Unexpected Color in Summary");
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARKEXTERNAL"),
				"Unexpected COLLEGIATEMARK in Summary");
		softAssert.assertEquals(greekMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATIONEXTERNAL"),
				"Unexpected GreekMarks in Summary");
		
		
		ExtentLogger.pass("Successfully Reviewed Item Details for External");
		
	} catch (Exception e) {
		Assert.fail("Failed in Review Item Details for External. " + e.getMessage());
	}
	
	return this;
}

public OrdersPage reviewQuantityandPriceforExternal() {
	
	String sqty = "", mqty = "", lqty = "", xlqty = "";
	String price = "";
	try {
		
		sqty = getAttributeValue(getSqty, "value");
		mqty = getAttributeValue(getMqty, "value");
		lqty = getAttributeValue(getLqty, "value");
		xlqty = getAttributeValue(getXLqty, "value");
		price = getAttributeValue(getPrice, "value");
		
		softAssert.assertEquals(sqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SQTYEXTERNAL"),
				"Unexpected sqty in Summary");
		softAssert.assertEquals(mqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MQTYEXTERNAL"),
				"Unexpected MQTY in Summary");
		softAssert.assertEquals(lqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LQTYEXTERNAL"),
				"Unexpected LQTY in Summary");
		softAssert.assertEquals(xlqty,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "XLQTYEXTERNAL"),
				"Unexpected XLQTY in Summary");
		softAssert.assertEquals(price,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEEXTERNAL"),
				"Unexpected PRICE in Summary");
		
		ExtentLogger.pass("Successfully Reviewed Quantity and Price for External");
		
	} catch (Exception e) {
		Assert.fail("Failed in Quantity and Price FOR External. " + e.getMessage());
	}
	
	return this;
}


}