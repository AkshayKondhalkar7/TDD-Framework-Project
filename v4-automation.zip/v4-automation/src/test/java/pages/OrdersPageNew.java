package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;


import org.testng.Assert;

import drivers.Driver;
import drivers.DriverManager;
import masterClasses.MasterPage;
import pageElements.OrdersPageElements;
import reports.ExtentLogger;
import utilities.RunTimePropertyFileUtils;

public class OrdersPageNew extends MasterPage implements OrdersPageElements {

	public OrdersPageNew orderCategory(String orderCat) throws Exception {

		switch (orderCat) {
		case "RegularOrder":

			clickElement(txtRegularOrder);

			// code to be executed;
			break; // optional
		case "GroupOrder":
			clickElement(txtGroupOrder);

			// code to be executed;
			break; // optional
		case "SampleOrder":
			clickElement(txtSampleOrder);

			Thread.sleep(5000);


			break;

		}

		return this;

	}
	
	public OrdersPageNew closeBrowser() {
		
		Driver.quitDriver();
		try {
			//RunTimePropertyFileUtils.deleteRuntimePropFile(getTestCaseName());
			System.out.println("Please uncomment the delete runtime *************************");
			ExtentLogger.pass(" Successfully Closed the Browser");
		} catch (Exception e) {
			Assert.fail("Unable to Close the Browser . " + e.getMessage());
		}
		
		
		return this;
	}

	public OrdersPageNew createNewOrderButton() throws Exception {

		clickElement(btnCreateOrder);

		return this;

	}

	public OrdersPageNew createRegularOrder() throws Exception {
		clickElement(btnStopImpersonate);

		return this;
	}

	public OrdersPageNew createGroupOrder() {

		return this;

	}

	public OrdersPageNew createSampleOrder() {

		sleepFor(3000);
		
		if (!DriverManager.getDriver().getTitle().contains("Orders")) {
			
			System.out.println(DriverManager.getDriver().getTitle());

			try {

				sleepFor(5000);

				System.out.println(DriverManager.getDriver().findElement(By.xpath("//span[contains(text(),'Let')]")).getText());
			   // DriverManager.getDriver().findElement(By.xpath("//span[contains(text(),'Let')]")).sendKeys(Keys.ENTER);
				clickElementJS(btnSampleOrderLestsGo);
				clickElementJS(btnFirstQuestionFreshPrints);
				enterData(btnwhatyourorderName, "Trying new Sample order");
				DriverManager.getDriver().findElement(By.xpath("//*[contains(text(),'OK')]")).sendKeys(Keys.RETURN);

				System.out.println(getData(btnokbutton));

			//	clickElement(btnokbutton);
//				enterDataJs(btnwhatyourName, "John Doe");
//				clickElementJS(btnokbutton);
//				enterDataJs(btnwhatyourEmail, "John@gmail.com");
//				clickElementJS(btnokbutton);
//				enterDataJs(btnwhatyourClientName, "Harris gildan");
//				clickElementJS(btnokbutton);
//				enterDataJs(btnwhatyourClientEmailBy, "kirty02@gmail.com");
//				clickElementJS(btnokbutton);
//				enterDataJs(btnPhoneNumberBy, "12344677");
//				clickElementJS(btnokbutton);
//				clickElementJS(btnContinue);
//				enterDataJs(btnApprelstyleCodeBy, "FP16");
//				enterDataJs(btnAoprealColorOptions, "BEIGE");
//				enterDataJs(btnsizeBy, "S");
//				clickElementJS(btnNoBy);
//				enterDataJs(textShipadd, "2-01 ,avenue");
//				clickElementJS(btnokbutton);
//				clickElementJS(btnokbutton);
//				enterDataJs(textStreetaddBy, "hp labe");
//				clickElementJS(btnokbutton);
//				enterDataJs(textCity, "Florida");
//				clickElementJS(btnokbutton);
//				enterDataJs(textStateBy, "Newyork");
//				clickElementJS(btnokbutton);
//				enterDataJs(textZipCodeBy, "220024");
//				clickElementJS(btnokbutton);
//				getData(txtCompletionBy);

			
				ExtentLogger.pass(" Successfully redirected to Sample Order");
			} catch (Exception e) {
				Assert.fail("Not redirected to Sample Order" +e.getMessage());
			}		
				
				
//				clickElement(btnSampleOrderLestsGo);
//				clickElement(btnFirstQuestionFreshPrints);
//				enterData(btnwhatyourorderName, "Trying new Sample order");
//				clickElement(btnokbutton);
//				enterData(btnwhatyourName, "John Doe");
//				clickElement(btnokbutton);
//				enterData(btnwhatyourEmail, "John@gmail.com");
//				clickElement(btnokbutton);
//				enterData(btnwhatyourClientName, "Harris gildan");
//				clickElement(btnokbutton);
//				enterData(btnwhatyourClientEmailBy, "kirty02@gmail.com");
//				clickElement(btnokbutton);
//				enterData(btnPhoneNumberBy, "12344677");
//				clickElement(btnokbutton);
//				clickElement(btnContinue);
//				enterData(btnApprelstyleCodeBy, "FP16");
//				enterData(btnAoprealColorOptions, "BEIGE");
//				enterData(btnsizeBy, "S");
//				clickElement(btnNoBy);
//				enterData(textShipadd, "2-01 ,avenue");
//				clickElement(btnokbutton);
//				clickElement(btnokbutton);
//				enterData(textStreetaddBy, "hp labe");
//				clickElement(btnokbutton);
//				enterData(textCity, "Florida");
//				clickElement(btnokbutton);
//				enterData(textStateBy, "Newyork");
//				clickElement(btnokbutton);
//				enterData(textZipCodeBy, "220024");
//				clickElement(btnokbutton);
//				getData(txtCompletionBy);
//			}
//			catch (Exception e) {
//				e.printStackTrace();
//			}

		}

		return this;

	}

	/*
	 * public OrdersPageNew enterClientDetails(String type) { String clientName =
	 * "", managerName = ""; try { clientName =
	 * InputPropertyUtils.get("EXISTING_CLIENT_FOR_INVOICE"); managerName =
	 * InputPropertyUtils.get("MANAGER_EXISTING_CLIENT_INVOICE"); if
	 * (type.equalsIgnoreCase("existing")) {
	 * 
	 * clickElement(drpDwnClientName); enterData(txtClientName, clientName);
	 * clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName,
	 * clientName))); sleepFor(1000); clickElement(txtDueDate); sleepFor(1000);
	 * 
	 * selectRandDate();
	 * 
	 * } else if (type.equalsIgnoreCase("new")) {
	 * 
	 * clickElement(btnCreateClient); sleepFor(1000); createClient(); clientName =
	 * RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");
	 * 
	 * clickElement(drpDwnClientName); enterData(txtClientName, clientName);
	 * clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName,
	 * clientName))); sleepFor(500);
	 * 
	 * clickElement(drpDwnManagerName); enterData(txtManagerName, managerName);
	 * sleepFor(500);
	 * clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionManagerName,
	 * managerName)));
	 * 
	 * sleepFor(500); clickElement(txtDueDate); sleepFor(500);
	 * 
	 * selectRandDate(); }
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTTYPE",
	 * type); RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(),
	 * "CLIENTNAME", clientName);
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MANAGERNAME",
	 * managerName); ExtentLogger.pass("Entered Client Details Successfully"); }
	 * catch (Exception e) { Assert.fail("Unable to Enter Client Details. " +
	 * e.getMessage()); } return this; }
	 * 
	 * 
	 * 
	 * public OrdersPageNew createClient() { try { HashMap<String, String>
	 * contactDetailsMap = DataGeneratorUtils.generateContactDetails();
	 * HashMap<String, String> passwordDetailsMap =
	 * DataGeneratorUtils.generatePasswordDetails(); HashMap<String, String>
	 * schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();
	 * 
	 * enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
	 * contactDetailsMap.get("FULLNAME"));
	 * 
	 * enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
	 * contactDetailsMap.get("PHONENUMBER"));
	 * 
	 * clickElementJS(btnSetEmailAndPassword);
	 * 
	 * enterData(txtemail, passwordDetailsMap.get("EMAIL"));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL",
	 * passwordDetailsMap.get("EMAIL"));
	 * 
	 * enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
	 * enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
	 * passwordDetailsMap.get("PASSWORD"));
	 * 
	 * clickElementJS(btnAddInfo);
	 * 
	 * clickElementJS(drpDwnSchool); sleepFor(2000); enterData(drpDwnSchool,
	 * schoolDetailsMap.get("SCHOOL")); sleepFor(200); clickElementJS(
	 * By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue,
	 * schoolDetailsMap.get("SCHOOL"))));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL",
	 * schoolDetailsMap.get("SCHOOL"));
	 * 
	 * clickElementJS(drpDwnOrganization); sleepFor(2000);
	 * enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
	 * sleepFor(2000); clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(
	 * drpDwnOrganizationValue, schoolDetailsMap.get("ORGANIZATION"))));
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
	 * schoolDetailsMap.get("ORGANIZATION")); sleepFor(2000);
	 * 
	 * added by vidya on 03.25.2022
	 * 
	 * clickElementJS(btnPosition); enterData(btnPosition, "Apparel 123");
	 * sleepFor(2000);
	 * 
	 * 
	 * 
	 * clickElementJS(
	 * By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear,
	 * schoolDetailsMap.get("GRADYEAR")))); sleepFor(2000);
	 * RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR",
	 * schoolDetailsMap.get("GRADYEAR")); sleepFor(2000);
	 * clickElementJS(btnCreateAccount); sleepFor(2000);
	 * clickElementJS(btnBackToWork); sleepFor(1000);
	 * ExtentLogger.pass("Created Client for Invoice Successfully"); } catch
	 * (Exception e) { Assert.fail("Failed in Creating Client for Invoice. " +
	 * e.getMessage()); } return this; }
	 * 
	 * 
	 * public void selectRandDate() throws Exception { int i = 0; try { LocalDate
	 * today = LocalDate.now();
	 * selectDate(String.valueOf(today.plusDays(15).getDayOfMonth()),
	 * StringUtils.capitalize(today.plusDays(15).getMonth().toString().toLowerCase()
	 * .substring(0, 3)), String.valueOf(today.plusDays(15).getYear()));
	 * 
	 * } catch (Exception e) { throw new Exception("Unable to select date of " + i +
	 * " days from Today"); } }
	 * 
	 * 
	 * public void selectDate(String day, String month, String year) { try { Select
	 * yearDrpdown = new Select( DriverManager.getDriver().findElement(By.
	 * xpath("//select[@title='Select year']")));
	 * yearDrpdown.selectByVisibleText(year);
	 * 
	 * Select monthDrpdown = new Select( DriverManager.getDriver().findElement(By.
	 * xpath("//select[@title='Select month']")));
	 * monthDrpdown.selectByVisibleText(month);
	 * 
	 * clickElementJS(By.xpath("//div[text()='" + day +
	 * "' and @class='btn-light ng-star-inserted']")); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

}



