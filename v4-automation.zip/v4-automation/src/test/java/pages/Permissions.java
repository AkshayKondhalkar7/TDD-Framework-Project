package pages;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.Test;
import org.openqa.selenium.By;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import masterClasses.MasterPage;
import pageElements.UsersPageElements;
import reports.ExtentLogger;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class Permissions extends MasterPage implements UsersPageElements {
	LoginPage loginpage = new LoginPage();
	UsersPage usersPage = new UsersPage();
	static String loginTokenString = "";
	static String teamRole="";
	static String accessLevelString="";
	@SuppressWarnings("unused")

	public  void disableSSLCertCheck() throws NoSuchAlgorithmException, KeyManagementException {
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub

			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub

			}
		} };
	}

	public void ApiCall() 
			throws IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		String responseString = new String();
		disableSSLCertCheck();

		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());
		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		HttpGet httpGet = new HttpGet(
				"http://localhost:8080/api/v4/login?"+loginTokenString+ "&noRedirect=true");
		httpGet.addHeader("X-PrettyPrint", "1");

		CloseableHttpResponse response = httpclient.execute(httpGet);
		try {
			System.out.println(response.getStatusLine());
			HttpEntity entity = response.getEntity();

			String inputLine = null;

			// EntityUtils.consume(entity);
			if (entity != null) {

				String retSrc = EntityUtils.toString(entity);
				// parsing JSON

				Gson gson = new GsonBuilder().create();

				JsonObject job = gson.fromJson(retSrc, JsonObject.class);

				 accessLevelString = job.getAsJsonObject("data").getAsJsonObject("user").get("access_level")
						.getAsString();

				// jsonResp.getAsJsonArray();
				// toString returns quoted values!

				if (job.has("status"))

					job.getAsJsonObject("data").getAsJsonObject("user").get("access_level").getAsString();

				 teamRole = job.getAsJsonObject("data").getAsJsonObject("user").get("team_role").getAsString();

				// String ele=
				// job.getAsJsonObject("data").getAsJsonObject("user").getAsJsonObject("permissions").getAsJsonObject("Users").toString();
				// // toString returns quoted values!

				Set<String> ele = job.getAsJsonObject("data").getAsJsonObject("user").getAsJsonObject("permissions")
						.keySet();

				Set<String> propSet = new HashSet<String>();

				Iterator<?> i = ele.iterator();
				do {
					String feature = i.next().toString();
					propSet = job.getAsJsonObject("data").getAsJsonObject("user").getAsJsonObject("permissions")
							.getAsJsonObject(feature).keySet();
					System.out.println(feature + "%" + propSet);

					Iterator<?> j = propSet.iterator();
					do {
						String perKey = j.next().toString();

						String perValue = job.getAsJsonObject("data").getAsJsonObject("user")
								.getAsJsonObject("permissions").getAsJsonObject(feature).get(perKey).toString();
						
						permissionValidation(perKey, perValue, accessLevelString, teamRole, feature);

					} while (j.hasNext());

				} while (i.hasNext());

				String g = job.getAsJsonObject("data").getAsJsonObject("user").getAsJsonObject("permissions")
						.getAsJsonObject("Users").toString();
				System.out.println(g);

				// toString returns quoted values!

				/*
				 * System.out.println( teamRole+accessLevelString +ele); ObjectMapper mapper =
				 * new ObjectMapper();
				 * 
				 * Map<String, Boolean> map = mapper.readValue(ele, Map.class);
				 * 
				 * 
				 * 
				 * System.out.println( map);
				 * 
				 * 
				 * for (Entry<String, Boolean> entry : map.entrySet()) { if
				 * (entry.getValue().equals(true)) { System.out.println(entry.getKey()); } }
				 * 
				 * 
				 * 
				 * 
				 * 
				 * 
				 * map.forEach((key, value) -> { if (value.equals(false)) {
				 * System.out.print(key); } });
				 */

				/*
				 * if (response.getStatusLine().getStatusCode() == HttpURLConnection.HTTP_OK) {
				 * 
				 * StringBuffer res = new StringBuffer();
				 * 
				 * BufferedReader br = new BufferedReader(new
				 * InputStreamReader(response.getEntity().getContent())); try { while
				 * ((inputLine = br.readLine()) != null) {
				 * 
				 * res.append(inputLine); } br.close(); System.out.println(res);
				 * 
				 * } catch (IOException e) { e.printStackTrace(); }
				 * 
				 * }
				 * 
				 * else {
				 * 
				 * System.out.println("1123123123131312");
				 * 
				 * }
				 */

			}

		} finally {
			response.close();
		}

	}

	public  void permissionValidation(String key, String value, String access, String teamRole, String feature) {

	//public  void permissionValidation(String key, String value, String access, String teamRole, String feature) {

		System.out.println(feature + ": " + key + ":" + value + ":" + teamRole + ":" + access);

		switch (feature.toUpperCase()) {

		case "USERS":

			userCheck(key, value);

			break;

		case "PROOFS":

			break;

		case "INVENTORY":

			break;

		case "EXPORTS":
			break;

		case "ORDERS":

			break;

		case "PROMO CODES":

			break;

		case "INVOICES":

			break;

		case "GIFTS CARDS":

			break;

		default:
			break;
		}

	}

	public  void userCheck(String key, String value) {

		
		
		
		
		
		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {
				// yes permision for view module is true 

			} else {

			}

			break;

		case "view_adminTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "view_clientTab":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "view_printerTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "view_fcTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "view_cmTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "view_fpTeamTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "create_admin":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "create_client":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "create_printer":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "create_fc":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "create_cm":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "create_fpTeam":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "impersonate_admin":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "impersonate_client":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "impersonate_printer":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "impersonate_fc":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "impersonate_cm":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_admin":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_client":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_printer":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "edit_fc":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_cm":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "reassign_client":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case " deactivate_admin":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "deactivate_client":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "deactivate_printer":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "deactivate_fc":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "deactivate_cm":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		default:
			break;

		}
	}

	public  void ProofsCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "create_proofsReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "create_proofsItem":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "create_revisionReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "edit_proofsReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_proofsItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_revisionReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "upload_proofs":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "replace_proofs":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "delete_proofsReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "delete_proofsItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "delete_revisionReq":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "reassign_proofs":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		default:
			break;

		}

	}

	public static void PromoCodesCheck(String key, String value) {
		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "create_promoCodes":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "disable_promoCodes":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "view_printerTab":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

		default:
			break;

		}

	}

	public  void GiftCardsCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "create_giftCards":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "disable_giftCards":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		default:
			break;

		}

	}

	public static void InventoryCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "edit_inventory":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "add_restockData":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		default:
			break;

		}

	}

	public static void InvoicesCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "create_invoices":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "edit_invoices":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "delete_invoices":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "email_invoices":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "apply_payment":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		default:
			break;

		}

	}

	public  void OrdersCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "view_module":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "create_orders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "create_groupOrders":

			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "edit_orders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;
		case "edit_ordersItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "edit_groupOrders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}
			break;

		case "edit_groupOrdersItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "edit_groupOrdersParticipants":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "force_groupOrders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "assign_allOrders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "modify_allOrders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "delete_orders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "delete_ordersItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;
		case "delete_groupOrders":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		case "delete_groupOrdersItem":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		default:
			break;

		}
	}

	public  void ExportCheck(String key, String value) {

		switch (key.toLowerCase()) {
		case "download_withFilter":

			Boolean testResult = true;
			if (value.equalsIgnoreCase("true") && testResult) {

			} else {

			}

			break;

		case "download_ownData":
			if (value.equalsIgnoreCase("true")) {

			} else {

			}

			break;

		default:
			break;

		}

	}

	
	String[] arrayRoleStrings = {"Licence Manager", "Super Admin" ,"Art associate", "Art Manager" ,"Custom Roles,",
            "BDM", "CX","Finance Associate","Finance Manager","HR Associate","HR Manager", "Licensing Associate","Licensing Manager","Marketing Associate",
           "Marketing Manager","Ops Associate","Ops Manager","Orders Processor","Production Artists","Sales Associate","Sales Manager",
           "SDR","Licensing Manager","Marketing Associate","Marketing Manager","Ops Associate","Ops Manager","Orders Processor",
           "Production Artists","Sales Associate","Sales Manager"};

	String roleString = "Licence Manager";
	String pwString = "123";

	public Permissions CreateNewFPTeam(String roleString) {
			
			String email = null, password = null;
			try {
			
		email = InputPropertyUtils.get("EXISTING_ADMIN_EMAIL");
	    password = InputPropertyUtils.get("EXISTING_ADMIN_PASSWORD");	
	    loginPage.logIn(email, password);
	    loginPage.navigateToUsersPage("desktop");
		usersPage.clickAddUsersButton("desktop");
		clickElement(btnFpteamroleBy);
		HashMap<String, String> basicDetailsMap = DataGeneratorUtils.generateBasicDetails();
		enterData(txtFullname, basicDetailsMap.get("FULLNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", basicDetailsMap.get("FULLNAME"));
		clickElement(teamRoleBy);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnteamroleBy, roleString)));
		clickElement(btnSetEmailAndPassword);
		enterData(txtemail, roleString.replaceAll("\\s","")+"@xyz.com");
		enterData(txtPassword, "123");
		enterData(txtConfirmPassword, "123");
		clickTab(txtConfirmPassword);
		clickElement(btnCreateAccount);
		clickElement(btnBackToWork);
		usersPage.logout();
		
		}
		catch(Exception exp) {
		}
		return this;

	}

	public  boolean TrueFalseResult() {
		boolean res = true;
		if (DriverManager.getDriver().findElements(By.xpath("Whoopsie Daisy!")).size() > 0) {
			System.out.println("Page access is restricted :" +DriverManager.getDriver().getTitle());
			ExtentLogger.fail("Restricted page:-" + DriverManager.getDriver().getTitle());

			return false;

		}
		ExtentLogger.pass("No restrictions");

		return true;

	}

	
	public  void LoginAndgenerateToken() {
		
		try {
			loginPage.logIn(roleString.replaceAll("\\s","")+"@xyz.com", pwString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String urlString = DriverManager.getDriver().getCurrentUrl();
		String[] tokenStrings =urlString.split("?");
		loginTokenString = tokenStrings[1];

		
	}
	
	
	public Permissions methosChain() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException {
		for (String role: arrayRoleStrings) {
		    System.out.println(role); 
			CreateNewFPTeam(role).LoginAndgenerateToken();
			ApiCall();
			TrueFalseResult();
		}
		
		TrueFalseResult();

		return this;

	}

}
