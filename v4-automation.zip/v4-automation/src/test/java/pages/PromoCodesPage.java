package pages;

import static appConstants.ApplicationConstants.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.PromoCodesTabs;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.PromoCodesPageElements;
import reports.ExtentLogger;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;


public class PromoCodesPage extends MasterPage implements PromoCodesPageElements {

	public PromoCodesPage switchTo(PromoCodesTabs promoCodesTab) {
		try {
			scrollToTop();
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(promoCodesTab))));
			ExtentLogger.pass("Switched to " + getStringValue(promoCodesTab) + " Tab.");
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(promoCodesTab) + " Tab. " + e.getMessage());
		}

		return this;
	}

	public PromoCodesPage clickCreatePromoCodeButton() {
		try {
			clickElement(btnCreatePromoCodes);
			if (!findElementPresence(divCreatePromoCodes)) {
				throw new Exception("PromoCodes Page Title Not Found during Creation.");
			}
			ExtentLogger.pass("Clicked Create PromoCodes Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Create Add PromoCodes Button. " + e.getMessage());
		}

		return this;
	}

	public PromoCodesPage enterPromoCode() {
		String randCode = "";
		try {
			randCode = "PROMO" + DataGeneratorUtils.randString().toUpperCase();
			enterData(txtPromoCode, randCode);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROMOCODE", randCode);
			
			ExtentLogger.pass("Entered the PromoCode: " + randCode + " Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Promo Code. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage invalidPromoCodeAndVerify(String promocodeType) {
		String promoCode = "";
		try {
			switch (promocodeType.toLowerCase()) {
			case "existing":
				promoCode = InputPropertyUtils.get("EXISTING_ACTIVE_PROMOCODE");
				break;
			case "disabled":
				promoCode = InputPropertyUtils.get("EXISTING_DISABLED_PROMOCODE");
				break;
			case "giftcard":
				promoCode = InputPropertyUtils.get("EXISTING_GIFTCARD");
				break;

			default:
				throw new Exception("Invalid Type: " + promocodeType);
			}
			enterData(txtPromoCode, promoCode);
			clickTab(txtPromoCode);

			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ PROMOCODES_INVALID_PROMOCODE + "')]")),
					true, "Validation for PromoCode is not displayed");

			ExtentLogger.pass(
					"Verified that a new PromoCode cannot be Created using Existing Code String that is " + promoCode);

		} catch (Exception e) {
			Assert.fail("Failed in Providing Invalid PromoCode and Verifying Validations" + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage selectPromoCodeType(String promoCodeType) {
		String value = "0", loggedInAs = "";
		try {
			value = String.valueOf(ThreadLocalRandom.current().nextInt(2, 10));
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");
			sleepFor(1000);
			hoverOver(By.xpath(DynamicXpathUtils.getXpathForString(btnPromoCodeType, promoCodeType)));
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(btnPromoCodeType, promoCodeType)));

			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin")) {
				if ((!promoCodeType.equalsIgnoreCase("free shipping"))) {
					enterData(txtTypeValue, value);
				}
			} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("manager")) {
				if (!promoCodeType.equalsIgnoreCase("percentage")) {
					enterData(txtTypeValue, value);
				}
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TYPE", promoCodeType);
			if (promoCodeType.equalsIgnoreCase("percentage")) {
				if (loggedInAs.equalsIgnoreCase("manager")) {
					value = "10";
				}
				value = value + "%";
			} else if (promoCodeType.equalsIgnoreCase("fixed amount")) {
				value = "$" + value;
			} else if (promoCodeType.equalsIgnoreCase("organizer pays")) {
				value = value + "%";
			} else if (promoCodeType.equalsIgnoreCase("free shipping")) {
				value = "Free Shipping";
			}
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TYPEVALUE", value);
			ExtentLogger.pass("Selected PromoCode Type as " + promoCodeType + " and Provided Value if Applicable");
		} catch (Exception e) {
			Assert.fail("Failed in Selecting PromoCode Type and Entering Value. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage selectLimit(String limit) {
		String value = "0";
		try {
			value = String.valueOf(ThreadLocalRandom.current().nextInt(2, 10));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(btnLimitType, limit)));
			if (limit.equalsIgnoreCase("Set Total Usage Limit")) {
				scrollToElement(txtLimitValue);
				enterData(txtLimitValue, value);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LIMITTYPE", limit);
			if (limit.equalsIgnoreCase("1x per person")) {
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LIMITVALUE", "1x pp");
			} else {
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LIMITVALUE", value + " times");
			}

			ExtentLogger.pass("Selected Limit Type as " + limit);
		} catch (Exception e) {
			Assert.fail("Failed in Selecting PromoCode Limit. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage selectGroupOrder(String groupOrderType) {
		String groupOrder = "";
		sleepFor(1000);
		try {
			if (groupOrderType.equalsIgnoreCase("all")) {
				scrollToElement(chkBoxAppliesTo);
				clickElementJS(chkBoxAppliesTo);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GROUPORDER", "All Group Orders");
				ExtentLogger.pass("Seleted Group Order. Applies To All Group Orders");
			} else if (groupOrderType.equalsIgnoreCase("specific")) {

				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin")) {
					groupOrder = InputPropertyUtils.get("EXISTING_GROUP_ORDER_FOR_ADMIN");
				} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("manager")) {
					groupOrder = InputPropertyUtils.get("EXISTING_GROUP_ORDER_FOR_MANAGER");
				}
				
				System.out.println("groupOrder =" +groupOrder);
				Actions action = new Actions(DriverManager.getDriver());
				action.moveToElement(DriverManager.getDriver().findElement(drpDwnAppliesTo));
				action.click().build().perform();				
				action.moveToElement(DriverManager.getDriver().findElement(txtAppliesTo));
				action.click().build().perform();
				enterData(txtAppliesTo, groupOrder);
				action.moveToElement(DriverManager.getDriver().findElement(optionTime));
				action.click().build().perform();
				
//				clickElementJS(drpDwnAppliesTo);
//				enterData(txtAppliesTo, groupOrder);
//				sleepFor(500);
//				clickElementJS(optionTime);

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORDERTYPE", groupOrderType);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GROUPORDER", "#" + groupOrder);
				ExtentLogger.pass("Selected Group Order. Applies to " + groupOrder + " Group Order");
			}
		} catch (Exception e) {
			Assert.fail("Failed in Selecting Group Order. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage selectStartDateAndTime() {
		String time = "";
		LocalDate date;
		try {
			clickElement(txtStartDate);
//			date = selectToday();
			date = selectRandDate(2);
			clickElement(drpDwnStartTime);
			sleepFor(1000);
			time = getData(optionTime);
			clickElementJS(optionTime);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STARTDATE", StringUtils
					.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3) + " " + date.getDayOfMonth()));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STARTTIME", time);
			ExtentLogger.pass("Selected Start Date as " + date + " and Starts Time as " + time);
		} catch (Exception e) {
			Assert.fail("Failed in Selecting Start Date and Time");
		}
		return this;
	}

	public PromoCodesPage selectEndDateAndTime() {
		String time = "";
		LocalDate date;
		try {
			clickElement(txtEndDate);
			sleepFor(500);
			date = selectRandDate(12);
			clickElement(drpDwnEndTime);
			sleepFor(500);
			time = getData(optionTime);
			clickElementJS(optionTime);
			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ENDDATE",
					StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)) + " "
							+ date.getDayOfMonth());
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ENDTIME", time);
			ExtentLogger.pass("Selected End Date as " + date + " and End Time as " + time);
		} catch (Exception e) {
			Assert.fail("Failed in Selecting End Date and Time");
		}
		return this;
	}

	public PromoCodesPage verifySummary() {
		String code = "", totalLimit = "", appliesTo = "", starts = "", ends = "", type = "", percentage = "",
				fixedAmt = "", organizerPays = "";
		String promoCodetype = "", typeValue = "";
		try {
			sleepFor(2000);
			softAssert = new SoftAssert();
			code = getData(By.xpath("//div[contains(text(),'Code')]//span"));
			totalLimit = getData(By.xpath("//div[contains(text(),'Total limit')]//span"));
			appliesTo = getData(By.xpath("//div[contains(text(),'Applies to')]//span"));
			starts = getData(By.xpath("//div[contains(text(),'Starts')]//span"));
			ends = getData(By.xpath("//div[contains(text(),'Ends')]//span"));
			//ends = June 23 ,12:00 am";
			
			
			starts = getTheSubString(starts);	
			ends = getTheSubString(ends);
					

			promoCodetype = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE");
			typeValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPEVALUE");

			softAssert.assertEquals(code, RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROMOCODE"),
					"Unexpected Promocode in Summary");

			if (promoCodetype.equalsIgnoreCase("percentage")) {
				percentage = getData(By.xpath("//div[contains(text(),'Percentage')]//span"));
				softAssert.assertEquals(percentage, typeValue + " Off", "Unexpected Percentage in Summary");
			} else if (promoCodetype.equalsIgnoreCase("fixed amount")) {
				fixedAmt = getData(By.xpath("//div[contains(text(),'Fixed Amount')]//span"));
				softAssert.assertEquals(fixedAmt, typeValue + " Off", "Unexpected Fixed Amount in Summary");
			} else if (promoCodetype.equalsIgnoreCase("free shipping")) {
				type = getData(By.xpath("//div[contains(text(),'Type')]//span"));
				softAssert.assertEquals(type, typeValue, "Unexpected Type in Summary");
			} else if (promoCodetype.equalsIgnoreCase("organizer pays")) {
				organizerPays = getData(By.xpath("//div[contains(text(),'Organizer Pays')]//span"));
				softAssert.assertEquals(organizerPays, typeValue + " Off", "Unexpected Fixed Amount in Summary");
			}

			softAssert.assertEquals(starts,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STARTDATE") + ", "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STARTTIME"),
					"Unexpected Start Date in Summary");

			softAssert.assertEquals(ends,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ENDDATE") + ", "
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ENDTIME"),
					"Unexpected End Date in Summary");

			softAssert.assertAll();

			ExtentLogger.pass("Verified the Promo Code Summary Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Summary. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage createPromoCode() {
		try {
			clickElement(btnCreatePromoCode);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//div[contains(text(),'Promo Code "
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROMOCODE") + " Created')]"));
			ExtentLogger.pass("Clicked on Create Promo Code Button");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STATUS", "Active");
		} catch (Exception e) {
			Assert.fail("Failed in Creating PromoCode. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage filterPromoCode() {
		String promoCode = "";
		try {
			promoCode = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROMOCODE");
			enterData(txtSearchPromoCode, promoCode);
			ExtentLogger.pass("Filtered " + promoCode + " PromoCode Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Filtering " + promoCode + " Promocode. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage verifyDashboard(String operationType) {
//		ArrayList<HashMap<String, String>> completeData = null;
		String grouporderpromoCode = "", status = "", type = "", value = "", appliesTo = "", usageLimit = "", start = "",
				ends = "", create = "Create" ;
		try {
			sleepFor(5000);

			System.out.println(DriverManager.getDriver().findElement(profileIconNew).getText());
			DriverManager.getDriver().findElement(profileIconNew).click();
			sleepFor(5000);

			ArrayList<HashMap<String, String>> completeData = readCurrentTable();
			System.out.println(completeData);
			sleepFor(2000);

			if (operationType.equalsIgnoreCase("create")) {
	//			if (operationType.equalsIgnoreCase(create)) {
		//		promoCode = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROMOCODE");
				grouporderpromoCode = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDERPROMOCODE");
				status = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STATUS");
				type = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE");
				System.out.println(type);
				value = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPEVALUE");
				appliesTo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GROUPORDER");
				usageLimit = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LIMITVALUE");
				start = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STARTDATE");
				ends = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ENDDATE");
				
				start = getTheSubString(start);	
				ends = getTheSubString(ends);
				
				printMap(completeData);
				if (completeData.size() != 1) {
					throw new Exception("Searched Record is not filtered Correctly.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						
					//	if (!eachRow.get("Promo Code").equalsIgnoreCase(promoCode)) 
//							if (!eachRow.get("Group Order Promo Code").equalsIgnoreCase(grouporderpromoCode)) {
//							throw new Exception("Filtered Records doesn't have the expected Group Order Promo Code: " + grouporderpromoCode);
//						}
						if (!eachRow.get("Status").equalsIgnoreCase(status)) {
							throw new Exception("Filtered Records doesn't have the expected Status: " + status);
						}
						if (!eachRow.get("Type").equalsIgnoreCase(type)) {
							System.out.println(eachRow.get("Type").equalsIgnoreCase(type));
							throw new Exception("Filtered Records doesn't have the expected Type: " + type);
						}

						if (type.equalsIgnoreCase("fixed amount")) {
							if (!eachRow.get("Value").equalsIgnoreCase(value + ".00")) {
								throw new Exception("Filtered Records doesn't have the expected Value: " + value);
							}
						} else {
							if (!eachRow.get("Value").equalsIgnoreCase(value)) {
								throw new Exception("Filtered Records doesn't have the expected Value: " + value);
							}
						}

						if (!eachRow.get("Applies To").equalsIgnoreCase(appliesTo)) {
							throw new Exception("Filtered Records doesn't have the expected Applies To: " + appliesTo);
						}
						if (!eachRow.get("Usage Limit").equalsIgnoreCase(usageLimit)) {
							throw new Exception(
									"Filtered Records doesn't have the expected Usage Limit: " + usageLimit);
						}
						if (!eachRow.get("Starts").equalsIgnoreCase(start)) {
							throw new Exception("Filtered Records doesn't have the expected Starts Date: " + start);
						}
						if (!eachRow.get("Ends").equalsIgnoreCase(ends)) {
							throw new Exception("Filtered Records doesn't have the expected Ends Date: " + ends);
						}
					}
				}
			} else if (operationType.equals("disable")) {
				if (completeData.size() != 1) {
					throw new Exception("Searched Record is not filtered Correctly.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						if (!eachRow.get("Status").equalsIgnoreCase("Disabled")) {
							throw new Exception("Filtered Records doesn't have the expected Status: Disabled");
						}
					}
				}
			}
			ExtentLogger.pass("Verified Data present in the Dashboard");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Verifying Dashboard. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage sortAndVerifyAllColumns(PromoCodesTabs promoCodesTab) {
		String[] colnames = { "Promo Code", "Type", "Applies To" };
		ArrayList<String> actualColData = null;
		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), promoCodesTab));

				if (column.equalsIgnoreCase("applies to")) {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(promoCodesTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(promoCodesTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				} else {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(promoCodesTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(promoCodesTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			}
		} catch (Exception e) {
			Assert.fail("Failed During Sorting and Verification in " + getStringValue(promoCodesTab) + " Tab. "
					+ e.getMessage());
		}
		return this;
	}

	public void getSortedDataAndCompare(PromoCodesTabs promoCodesTab, String colName, ArrayList<String> actualColData,
			String order) throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), promoCodesTab));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
						+ getStringValue(promoCodesTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " Column is not Sorted in " + order + " Order Correctly in "
						+ getStringValue(promoCodesTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Failed in Sorting and Comparing Records. " + e.getMessage());
		}
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i).split(" ")[0] + " / "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}

		return match;
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;
		try {
			if (colName.equalsIgnoreCase("applies to")) {
				ArrayList<String> numList = new ArrayList<>();
				ArrayList<String> charList = new ArrayList<>();
				for (String data : dataList) {
					if (NumberUtils.isDigits(data.replace("#", "")))
						numList.add(data);
					else
						charList.add(data);
				}
				Collections.sort(numList, new Comparator<String>() {
					public int compare(String data1, String data2) {
						return (data1.replace("#", "").compareTo(data2.replace("#", "")) * ord);
					}
				});
				if (order.equals("asc")) {
					dataList.clear();
					dataList.addAll(charList);
					dataList.addAll(numList);
				} else {
					dataList.clear();
					dataList.addAll(numList);
					dataList.addAll(charList);
				}
			} else {
				Collections.sort(dataList, new Comparator<String>() {
					public int compare(String data1, String data2) {
						return (data1.compareTo(data2) * ord);
					}
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return dataList;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, PromoCodesTabs promoCodesTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
//			boolean multiplePages = findElementPresence(
//					By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, promoCodesTab));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
		//			scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					scrollToElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(2000);
		//			clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					clickElementJS(By.xpath("//i[@class='datatable-icon-skip']//parent::a"));
					sleepFor(2000);
					columnData.addAll(readColumnData(colIdx, promoCodesTab));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, promoCodesTab));
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx, PromoCodesTabs promoCodesTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));
				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}
		return columnData;
	}

	
	//Changes that have been made by vidya on 03.28.2022
	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		try {
			for (int i = 2; i <= 9; i++) {

				String colData = getData(
						By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
				header.add(colData);
				System.out.println("colData = " + colData);
			}
			//for (int i = 2; i < rowCount; i++)
			for (int i = 2; i <= rowCount; i++)
			{
				HashMap<String, String> eachRow = new HashMap<>();
				// int temp1 = 4, temp2 = 22;
			//	int temp1 = 4, temp2 = 28;
			//	int temp1 = 5, temp2 = 34;
				int temp1 = 5, temp2 = 28;
				for (int j = 1; j <= 8; j++) {
					String data = "";
					if (eachRow.size() <= 6) {

						System.out.println("-----if------");
						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]"));
						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp1 + "]");
						System.out.println("eachRow.size() <= 6 data =" + data);
						
						
						temp1 = temp1 < 17 ? temp1 + 4 : (temp1 >= 17)&&(temp1 <21) ? temp1 + 2 : temp1 + 4;
					//	temp1 = temp1 < 7 ? temp1 + 4 : (temp1 >= 17)&&(temp1 <22) ? temp1 + 5 : temp1 + 4;
					//	 temp1 = temp1 < 7 ? temp1 + 3 : temp1 >= 18 ? temp1 + 3 : temp1 + 4;
					//	 temp1 = temp1 < 7 ? temp1 + 3 : temp1 >= 19 ? temp1 + 3 : temp1 + 4;
						// temp1 = temp1<=7? temp1+3:temp1+4;
						// temp1 = temp1>=7? temp1+3:temp1+4;
						System.out.println("After inc " + "((//div[contains(@class,'datatable-row-center')])[" + i
								+ "]//div)[" + temp1 + "]");

						// temp1 += 3;

					}
 
					else {
						System.out.println("------else-----");
						

						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2 + "]"));
						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + temp2+ "]");

						temp2 += 3;
					}
					
					if (j < 7) {
						
						System.out.println("data j > 6 = "  +data);
					} else {
						
						data = getTheSubString(data);
						System.out.println("data else " +data);
					}
					
					eachRow.put(header.get(j - 1), data);
					System.out.println("eachRow =" + eachRow);

				}
				fullData.add(eachRow);

				System.out.println("fullData =" + fullData);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;

	}

	public void printMap(ArrayList<HashMap<String, String>> fullData) {
		for (HashMap<String, String> rows : fullData) {
			for (Map.Entry<String, String> entry : rows.entrySet()) {
				System.out.println(entry.getKey() + ": " + entry.getValue());
			}
			System.out.println("-----------");
		}
	}

	// Changes done by vidya on 04.26.2022
	public PromoCodesPage disableOnePromoCodeAndVerify() {
		String promoCode = "";
		switchTo(PromoCodesTabs.ACTIVE);
		try {
		
			clickElementJS(By.xpath("(//datatable-body-row)[1]//datatable-body-cell[2]"));
			promoCode = getAttributeValue(By.xpath("//datatable-body-cell//input[@value='true']"), "id");
			clickElement(btnDisablePromoCodes);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'is disabled')]"));

			ExtentLogger.pass("Successfully Disabled " + promoCode + " PromoCode");

			enterData(txtSearchPromoCode, promoCode);
			verifyDashboard("Disable");
			clickElement(iconClearFilter);
//			switchTo(PromoCodesTabs.ALL);
			sleepFor(2000);
			ExtentLogger.pass("Verified that Status is Updated for " + promoCode + " PromoCode");
		} catch (Exception e) {
			Assert.fail("Failed in Disabling PromoCode and Verifying it. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage disableMultiplePromoCodesAndVerify(int rowCount) {
		switchTo(PromoCodesTabs.ACTIVE);
		sleepFor(500);
		List<WebElement> elements;
		List<String> promoCodeList = new ArrayList<>();
		try {
			for (int i = 1; i <= rowCount; i++) {
				clickElementJS(By.xpath("(//datatable-body-row)[" + i + "]//datatable-body-cell[2]"));
			}
			elements = DriverManager.getDriver().findElements(By.xpath("//datatable-body-cell//input[@value='true']"));

			for (WebElement element : elements)
				promoCodeList.add(element.getAttribute("id"));

			ExtentLogger.pass("Successfully Disabled Multiple PromoCodes");
			clickElement(btnDisablePromoCodes);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROMOCODES_DISABLEMULTIPLEPROMOCODES_MESSAGE + "')]"));

			for (String promoCode : promoCodeList) {
				enterData(txtSearchPromoCode, promoCode);
				verifyDashboard("Disable");
				clickElement(iconClearFilter);
			}
			ExtentLogger.pass("Verified that Status is Updated for all Disabled PromoCodes.");
		} catch (Exception e) {
			Assert.fail("Failed in Selecting PromoCodes for Disabling and Verifying it. " + e.getMessage());
		}
		return this;
	}

	public LocalDate selectToday() {

		LocalDate today = LocalDate.now();
		selectDate(String.valueOf(today.getDayOfMonth()),
				StringUtils.capitalize(today.getMonth().toString().toLowerCase().substring(0, 3)),
				String.valueOf(today.getYear()));
		return today;
	}

	public LocalDate selectRandDate(long daysAfter) throws Exception {
		int i = 0;
		LocalDate date;
		try {
			date = LocalDate.now().plusDays(daysAfter);
			selectDate(String.valueOf(date.getDayOfMonth()),
					StringUtils.capitalize(date.getMonth().toString().toLowerCase().substring(0, 3)),
					String.valueOf(date.getYear()));

		} catch (Exception e) {
			throw new Exception("Unable to select date of " + i + " days from Today");
		}
		return date;
	}

	public void selectDate(String day, String month, String year) {
		try {
			Select yearDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select year']")));
			yearDrpdown.selectByVisibleText(year);

			Select monthDrpdown = new Select(
					DriverManager.getDriver().findElement(By.xpath("//select[@title='Select month']")));
			monthDrpdown.selectByVisibleText(month);

			sleepFor(2000);
			clickElementJS(
					By.xpath("(//div[text()='" + day + "' and @class='btn-light ng-star-inserted']//parent::div)[1]"));
//			clickElementJS(By.xpath("//div[text()='" + day + "' and @class='btn-light ng-star-inserted']"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public PromoCodesPage filterAndVerifyAllColumns(PromoCodesTabs promoCodesTab) {
		try {
			sleepFor(1000);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
System.out.println(rowCount);
		//	filterAndVerifyPromoCode(promoCodesTab, rowCount);
			filterAndVerifyValue(promoCodesTab, rowCount);
			filterAndVerifyOrder(promoCodesTab, rowCount);
		} catch (Exception e) {
			Assert.fail("Failed During Filter and Verifying Data. " + e.getMessage());
		}
		return this;
	}

	public void filterAndVerifyPromoCode(PromoCodesTabs promoCodesTab, int rowCount) throws Exception {
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
//			switchTo(promoCodesTab);
			sleepFor(700);
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[4]"));
			enterData(txtSearchPromoCode, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Promo Code is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Promo Code").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Promo Code: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Promo Code Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(promoCodesTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyValue(PromoCodesTabs promoCodesTab, int rowCount) throws Exception {
		String filterData = "10";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
//			switchTo(promoCodesTab);
			enterData(txtSearchPromoCode, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Promo Code is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					System.out.println(filterData+ " "+eachRow.get("Value"));

					if (!eachRow.get("Value").contains(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Value: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Value Column");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(promoCodesTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyOrder(PromoCodesTabs promoCodesTab, int rowCount) throws Exception {
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterData = InputPropertyUtils.get("EXISTING_ORDER_FOR_PROMOCODES");
//			switchTo(promoCodesTab);
			enterData(txtSearchPromoCode, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Promo Code is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Applies To").contains(filterData)) {
						throw new Exception(
								"Filtered Records doesn't have the expected Applies To Order: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Applies To Column with Order");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(promoCodesTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public PromoCodesPage verifyRecordsCount(PromoCodesTabs promoCodesTab) {
		try {
			sleepFor(300);
			int rowCount = 0, recordsPerPage = 0, totRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(By.xpath(
							DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(promoCodesTab))))
					.getText());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(promoCodesTab))));
			sleepFor(500);

			if (findElementPresence(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))) {
				recordsPerPage = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
			} else {
				recordsPerPage = totRecords;
			}

			if (totRecords < recordsPerPage) {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount + " for " + getStringValue(promoCodesTab));
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount + " for "
							+ getStringValue(promoCodesTab));
				}
			} else {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				while (checkCondition(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"),
						ElementCheckStrategy.DISPLAYED)) {
					clickElement(By.xpath("//i[@class='datatable-icon-right']"));

					rowCount = rowCount
							+ DriverManager.getDriver()
									.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size()
							- 1;
				}
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount);
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount);
				}
			}
		} catch (Exception e) {
			Assert.fail("Unable to Verify Records Count. " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage clickAndChooseFilter(String filterType)  {
		
		try {
			sleepFor(3000);
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			ExtentLogger.pass("Successfully Selected as " + filterType + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}

public PromoCodesPage clickAndChooseFilterManger(String filterType)  {
		
		try {
			sleepFor(3000);
			clickElement(btnFilter);
			sleepFor(500);
			

			ExtentLogger.pass("Successfully Selected as " + filterType + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}
	public PromoCodesPage applySubTypeFilterAndVerify(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterValue = "", filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			completeData = readCurrentTable();
			System.out.println(readCurrentTable());

			if (completeData.size() == 0) {
				ExtentLogger.log("No Records Found for the Filter");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					// uncomment once organizer pays is fixed
					if (!eachRow.get("Type").equalsIgnoreCase(filterSubType)) {
						throw new Exception("Filtered Records doesn't have the expected Type: " + filterSubType);
					}
				}
			}
			if (!filterSubType.equalsIgnoreCase("free shipping")) {
				filterValue = "10";
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterValue, filterSubType)), filterValue);
				clickElement(btnApplyFilter);
				sleepFor(1000);
				completeData.clear();
				completeData = readCurrentTable();

				if (completeData.size() == 0) {
					ExtentLogger.log("No Records Found for the Filter");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						// uncomment once organizer pays is fixed
						if (!eachRow.get("Type").equalsIgnoreCase(filterSubType)) {
							throw new Exception("Filtered Records doesn't have the expected Type: " + filterSubType);
						}
						if (!eachRow.get("Value").contains(filterValue.trim())) {
							throw new Exception("Filtered Records doesn't have the expected Value: " + filterValue);
						}
					}
				}
			}
			clickElementJS(By.xpath("//div[contains(@class,'selected-filters__close-icon')]//i"));
			sleepFor(500);
			ExtentLogger.pass("Verified Filtering Funtionality for " + filterSubType + " Values");
			sleepFor(1000);
		} catch (Exception e) {
			Assert.fail("Failed in Applying Type Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage applyOrderFilterAndVerify(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
//				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
//				sleepFor(500);
			completeData = readCurrentTable();
			sleepFor(3000);

			if (filterSubType.equalsIgnoreCase("specific group order")) {
				clickElementJS(
						By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
				sleepFor(500);
				completeData = readCurrentTable();
				String orderNumber = "51855"; /*edited by vidya - uncommented this line*/
			//	String orderNumber = "773"; /*edited by vidya - commented this line*/

				clickElementJS(drpDwnOrder);
				enterData(txtOrderNumber, orderNumber);
				sleepFor(500);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrderNumber, orderNumber)));

				sleepFor(1000);
				completeData.clear();
				completeData = readCurrentTable();

				if (completeData.size() == 0) {
					ExtentLogger.log("No Records Found for the Filter");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						if (!eachRow.get("Applies To").contains(orderNumber)) {
							throw new Exception("Filtered Records doesn't have the expected Order: " + orderNumber);
						}
					}
				}
				ExtentLogger.pass("Verified Filtering Funtionality for " + filterSubType + " Values");
			} else {

				if (filterSubType.equalsIgnoreCase("All Group Orders")) {
					sleepFor(500);
					clickElementJS(selectAppliesToButton);
					sleepFor(1000);
					String appliesAllGroupOrders = "All Group Orders";

					completeData.clear();
					completeData = readCurrentTable();

					if (completeData.size() == 0) {
						ExtentLogger.log("No Records Found for the Filter");
					} else {
						for (HashMap<String, String> eachRow : completeData) {
							if (!eachRow.get("Applies To").contains(appliesAllGroupOrders)) {
								throw new Exception("Filtered Records doesn't have the expected All Group Orders "
										+ appliesAllGroupOrders);
							}
						}
					}
					ExtentLogger.pass("Verified Filtering Funtionality for " + filterSubType + " Values");

				}
				clickElementJS(By.xpath("//div[contains(@class,'selected-filters__close-icon')]//i"));
				sleepFor(1000);

			}
		} catch (Exception e) {
			Assert.fail("Failed in Applying Order Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage applyDateFilterAndVerify(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(txtDateFilter, filterSubType)));
			selectDate("1", "Jan", "2022");
			sleepFor(500);
			completeData = readCurrentTable();

			if (completeData.size() == 0) {
				ExtentLogger.log("No Records Found for the Filter");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (filterType.equalsIgnoreCase("starts")) {
						if (!eachRow.get("Starts").equalsIgnoreCase("Jan 1")) {
							throw new Exception("Filtered Records doesn't have the expected Starts Date: " + "Jan 1");
						}
					} else if (filterType.equalsIgnoreCase("ends")) {
						if (!eachRow.get("Ends").equalsIgnoreCase("Jan 1")) {
							throw new Exception("Filtered Records doesn't have the expected Ends Date: " + "Jan 1");
						}
					}

				}
			}
			sleepFor(1000);
			ExtentLogger.pass("Applied " + filterSubType + " SubFilter and Verified Filtered Record");
		} catch (Exception e) {
			Assert.fail("Failed in Applying Date Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage applyFilter(String filterType, String filterSubType) {
		String filterValue = "10";
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);

			enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterValue, filterSubType)), filterValue);
			clickElement(btnApplyFilter);
			sleepFor(1000);

		} catch (Exception e) {
			Assert.fail("Failed in Applying Filter: " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}
	/* type - percentage filter for manger login */
	public PromoCodesPage applyFilterMangerlogin(String filterType, String filterSubType) {
		String filterValue = "10";
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);

		} catch (Exception e) {
			Assert.fail("Failed in Applying Filter: " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public String getStringValue(PromoCodesTabs promoCodesTab) {
		String tabString = "";
		if (promoCodesTab.equals(PromoCodesTabs.ACTIVE)) {
			tabString = "Active";
		} else if (promoCodesTab.equals(PromoCodesTabs.ALL)) {
			tabString = "All";
		} else if (promoCodesTab.equals(PromoCodesTabs.DISABLED)) {
			tabString = "Disabled";
		}
		return tabString;
	}

	public boolean isFeatureAdded(String feature) {
		try {
			if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), feature))) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// changes done by vidya
	public int getColumntempIndex(String colName) throws Exception {
		int index = 0;
		if (colName.equalsIgnoreCase("promo code"))
		//	index = 4;
			index = 5;
		else if (colName.equalsIgnoreCase("status"))
		//	index = 7;
			index = 9;
		else if (colName.equalsIgnoreCase("type"))
		//	index = 10;
			index = 13;
		else if (colName.equalsIgnoreCase("value"))
		//	index = 13;
			index = 17;
		else if (colName.equalsIgnoreCase("applies to"))
		//	index = 16;
		//	index = 22;
			index = 19;
		else if (colName.equalsIgnoreCase("usage limit"))
		//	index = 19;
		//	index = 26;
			index = 21;
		else if (colName.equalsIgnoreCase("starts"))
		//	index = 22;
		//	index = 30;
			index = 25;
		else if (colName.equalsIgnoreCase("ends"))
		//	index = 26;
		//	index = 34;
			index = 28;

		return index;
	}

	public PromoCodesPage getLocalTime() {
		try {
			clickElement(drpDwnStartTime);
			DateFormat formatter = new SimpleDateFormat("HH:mm a");
			SimpleDateFormat parser = new SimpleDateFormat("HH:mm a");
			Date currentESTTime = new Date();

			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			System.out.println("CurrentEST: " + formatter.format(currentESTTime));
			System.out.println(LocalTime.parse("09:00"));

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return this;
	}

	public PromoCodesPage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}

		return this;
	}

	public PromoCodesPage verifyStatusColumn(PromoCodesTabs promoCodesTab) {
		HashSet<String> colData;
		try {

			sleepFor(2000);
			colData = new HashSet<>(readCompleteColumnData(getColumntempIndex("Status"), promoCodesTab));
			System.out.println("colData =" + colData);
			for (String data : colData) {
				if (!data.trim().equalsIgnoreCase(getStringValue(promoCodesTab))) {
					throw new Exception("Status does not match");
				}
			}
			ExtentLogger.pass("Verify Data Present in Status Column in " + getStringValue(promoCodesTab) + " tab for "
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS"));
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Data in Status Column. " + e.getMessage());
		}
		return this;
	}
	/* type - percentage filter for manger login */
	public PromoCodesPage applySubTypeFilterAndVerifyMangerLogin(String filterSubType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String filterValue = "", filterType = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(radioFilterType, filterType, filterSubType)));
			sleepFor(500);
			completeData = readCurrentTable();
			System.out.println(readCurrentTable());

			if (completeData.size() == 0) {
				ExtentLogger.log("No Records Found for the Filter");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					// uncomment once organizer pays is fixed
					if (!eachRow.get("Type").equalsIgnoreCase(filterSubType)) {
						throw new Exception("Filtered Records doesn't have the expected Type: " + filterSubType);
					}
				}
			}
			if (filterSubType.equalsIgnoreCase("Percentage")) {
				sleepFor(1000);
				completeData.clear();
				completeData = readCurrentTable();

				if (completeData.size() == 0) {
					ExtentLogger.log("No Records Found for the Filter");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						// uncomment once organizer pays is fixed
						if (!eachRow.get("Type").equalsIgnoreCase(filterSubType)) {
							throw new Exception("Filtered Records doesn't have the expected Type: " + filterSubType);
						}
						
					}
				}
			}else if (filterSubType.equalsIgnoreCase("Organizer Pays")) {
				filterValue = "10";
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterValue, filterSubType)), filterValue);
				clickElement(btnApplyFilter);
				sleepFor(1000);
				completeData.clear();
				completeData = readCurrentTable();

				if (completeData.size() == 0) {
					ExtentLogger.log("No Records Found for the Filter");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						// uncomment once organizer pays is fixed
						if (!eachRow.get("Type").equalsIgnoreCase(filterSubType)) {
							throw new Exception("Filtered Records doesn't have the expected Type: " + filterSubType);
						}
						if (!eachRow.get("Value").contains(filterValue.trim())) {
							throw new Exception("Filtered Records doesn't have the expected Value: " + filterValue);
						}
					}
				}
				
			}
			clickElementJS(By.xpath("//div[contains(@class,'selected-filters__close-icon')]//i"));
			sleepFor(2000);
			clickElement(btnFilter);
			sleepFor(500);
			ExtentLogger.pass("Verified Filtering Funtionality for " + filterSubType + " Values");
			sleepFor(1000);
		} catch (Exception e) {
			Assert.fail("Failed in Applying Type Filter " + filterSubType + ". " + e.getMessage());
		}
		return this;
	}

	public PromoCodesPage enterExistingPromoCode() {
		String randCode = "PURCHASEPROMOCODE";
		try {
			
			enterData(txtPromoCode, randCode);
			clickTab(txtPromoCode);
			
			
			Assert.assertEquals(
					findElementPresence(By.xpath("//div[contains(@class,'form-error')]//div[contains(text(),'"
							+ PROMOCODES_INVALID_PROMOCODE + "')]")),
					true, "Validation for PromoCode is not displayed");
			
			ExtentLogger.pass("Verified that a new PromoCode cannot be Created using Existing Code String that is " + randCode);
			sleepFor(1000);
			clearData(txtPromoCode);
			
		} catch (Exception e) {
			Assert.fail("Failed in Providing Invalid PromoCode and Verifying Validations" + e.getMessage());
		}
		return this;
	}
	
}
