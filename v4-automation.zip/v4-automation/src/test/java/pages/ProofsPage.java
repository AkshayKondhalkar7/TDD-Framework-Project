package pages;

import static appConstants.ApplicationConstants.*;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.logging.log4j.core.tools.Generate.ExtendedLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.amazonaws.services.waf.model.Predicate;
import com.mysql.cj.jdbc.Driver;

import appEnums.ProofsTabs;
import appEnums.UserOperation;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.ProofsPageElements;
import reports.ExtentLogger;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class ProofsPage extends MasterPage implements ProofsPageElements {

	public ProofsPage switchTo(ProofsTabs proofTab) {
		try {
			scrollToTop();
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(proofTab))));
			ExtentLogger.pass("Switched to " + getStringValue(proofTab) + " Tab.");
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(proofTab) + " Tab. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage clickCreateProofButton() {

		try {
			clickElement(btnCreateProofss);
			if (!findElementPresence(divCreateProoof)) {
				throw new Exception("Proof Details Title Not Found during Creation.");
			}
			ExtentLogger.pass("Clicked Create Proof Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Create Proof Button. " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage clickAddProofButton() {

		try {
			clickElement(btnAddProofs);
			if (!findElementPresence(divAddProductInfo)) {
				throw new Exception("Product Info Not Found during Add Proof.");
			}
			ExtentLogger.pass("Clicked Add Proof Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Add Create Proof Button. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage fillProofDetails(String clientType) {

		String proofTitle = "", clientName = "", campaign = "";
		
		String bckgclr = DriverManager.getDriver().findElement(By.xpath("//div[@class='wizard-steps horizontal']")).getCssValue("background-color");
		System.out.println(bckgclr);
		
		
		try {
			proofTitle = "Proof " + DataGeneratorUtils.randString();
			campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS");
			enterData(txtProofTitle, proofTitle);

			if (clientType.equalsIgnoreCase("Existing")) {
				clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			} else if (clientType.equalsIgnoreCase("New")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

		
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			} else if (clientType.equalsIgnoreCase("New With Business")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClientWithNotStudent();
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

		
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			}

			clickElement(drpDwnCampaign);
			enterData(txtCampaign, campaign);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
			sleepFor(500);

			clickElementJS(btnProductInfo);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);
			ExtentLogger.pass("Filled Proof Details Successfully.");

		} catch (Exception e) {
			Assert.fail("Failed in Filling Proof Details. " + e.getMessage());
		}
		return this;
	}
	
	public ProofsPage fillProofsDetails(String clientType) {

		String proofTitle = "", clientName = "", campaign = "";
		try {
			proofTitle = "Proof " + DataGeneratorUtils.randString();
			campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS");
			enterData(txtProofTitle, proofTitle);

			if (clientType.equalsIgnoreCase("Existing")) {
				clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			} else if (clientType.equalsIgnoreCase("New")) {
				clickElement(btnCreateClient);
				sleepFor(1000);
				createAndCanelClient();
				sleepFor(1000);
				clickElement(btnCreateClient);
				sleepFor(1000);
				createClient();
				sleepFor(1000);
				clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			}

			clickElement(drpDwnCampaign);
			enterData(txtCampaign, campaign);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
			sleepFor(500);

			clickElementJS(btnProductInfo);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);
			ExtentLogger.pass("Filled Proof Details Successfully.");

		} catch (Exception e) {
			Assert.fail("Failed in Filling Proof Details. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage createClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);
			clickElementJS(drpDwnSchoolClient);
			sleepFor(200);
			enterData(drpDwnSchoolClient, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(By.xpath(
					DynamicXpathUtils.getXpathForString(drpDwnSchoolValueClient, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganizationClient);
			sleepFor(200);
			enterData(drpDwnOrganizationClient, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(200);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValueClient,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));

			/* added by vidya on 03.30.2022 */

			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));
	
			clickElementJS(btnCreateAccount);
			clickElementJS(btnBackToWork);
			sleepFor(1000);
			ExtentLogger.pass("Created Client for Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Creating Client for Proof. " + e.getMessage());
		}
		return this;
	}
	
	public ProofsPage createAndCanelClient() {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

			enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

			enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
					contactDetailsMap.get("PHONENUMBER"));

			clickElementJS(btnSetEmailAndPassword);

			enterData(txtemail, passwordDetailsMap.get("EMAIL"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));

			clickElementJS(btnAddInfo);
			clickElementJS(drpDwnSchoolClient);
			sleepFor(200);
			enterData(drpDwnSchoolClient, schoolDetailsMap.get("SCHOOL"));
			sleepFor(200);
			clickElementJS(By.xpath(
					DynamicXpathUtils.getXpathForString(drpDwnSchoolValueClient, schoolDetailsMap.get("SCHOOL"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

			clickElementJS(drpDwnOrganizationClient);
			sleepFor(200);
			enterData(drpDwnOrganizationClient, schoolDetailsMap.get("ORGANIZATION"));
			sleepFor(200);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValueClient,
					schoolDetailsMap.get("ORGANIZATION"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
					schoolDetailsMap.get("ORGANIZATION"));

			clickElementJS(btnPosition);
			enterData(btnPosition, "Apparel 123");
			sleepFor(2000);

			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));

			
	//		clickElement(btnCancelClient);
			clickElementJS(btnCancelClient);
			sleepFor(500);
			clickElement(selectYes);
			
			
//			clickElementJS(btnCreateAccount);
//			clickElementJS(btnBackToWork);
			sleepFor(1000);
			ExtentLogger.pass("Closed Client for Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Failed to close Client for Proof. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage fillProductInfo() {
		String styleCode = "";
		String color = "Black";
		try {
			styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);

			clickElementJS(btnAddLocAndDesign);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
			
			System.out.println("styleCode = "+styleCode);
			System.out.println("color = " +color);
			
			ExtentLogger.pass("Filled Product Info Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Filling Product Info. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage fillProductInfo(String type) {
		String styleCodeExternal = "" , styleCodeFP = "" , styleCodeAlpha = "";
		String colorExternal = "Blue", colorFP = "Beige" ;
		String productName = "Shirts" , productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html" ;
		try {
			if (type.equalsIgnoreCase("External")) {

				styleCodeExternal = "New Custom Code";

				clickElementJS(drpDwnStyleCode);
				enterData(txtStyleCode, styleCodeExternal);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString("//span[contains(text(),'%s')]", styleCodeExternal)));
				sleepFor(5000);

				enterData(txtCustomColor, "Blue");
				enterData(txtCustomProductName, "Shirts");
				enterData(txtCustomProductLink, "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
				
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEEXTERNAL", styleCodeExternal);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOREXTERNAL", colorExternal);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", productName);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTLINK", productLink);
				
			} else if (type.equalsIgnoreCase("FP")) {
				styleCodeFP = "Fresh Prints Madison Shorts FP16";
				clickElementJS(drpDwnStyleCode);
				enterData(txtStyleCode, styleCodeFP);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeFP)));
				sleepFor(500);

				clickElement(drpDwnColor);
				clickElementJS(optionColor);

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEFB", styleCodeFP);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORFP", colorFP);
				
				if (!findElementPresence(By.xpath("//img[@class='apparel__preview']"))) {
					ExtentLogger.fail("Apparel Previews are not displayed for FP Style Codes");
				}

			} else if (type.equalsIgnoreCase("Alpha")) {
				styleCodeAlpha = "Gildan G800";
				clickElementJS(drpDwnStyleCode);
				enterData(txtStyleCode, styleCodeAlpha);
				sleepFor(1000);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeAlpha)));
				sleepFor(500);

				clickElement(drpDwnColor);
				clickElementJS(optionColor);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEALPHA", styleCodeAlpha);
			}
			clickElementJS(btnAddLocAndDesign);

//			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
			ExtentLogger.pass("Filled Product Info Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Filling Product Info. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage fillLocationAndDesign(String printType) {
		try {
			int count = 2;
			if (printType.equalsIgnoreCase("Multiple")) {
				for (int i = 1; i <= count - 1; i++)
					clickElementJS(btnAddLocation);

				for (int i = 1; i <= count; i++) {
					clickElementJS(By.xpath("(//div[contains(text(),'" + DataGeneratorUtils.randPrintingTypeForProofs()
							+ "')])[" + i + "]"));
					enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtDescArt, String.valueOf(i))),
							"Sample Description " + String.valueOf(i));
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, String.valueOf(i))));
					clickElementJS(
							By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, String.valueOf(i))));
					ExtentLogger.pass("Successfully Added Location and Design Details for Location " + i);
				}

			} else {
				clickElementJS(By.xpath("//div[contains(text(),'" + printType + "')]"));
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtDescArt, "1")), "Sample Description 1");

				ExtentLogger.pass("Successfully Filled Details in Location and Design Sections");
			}
		} catch (Exception e) {
			Assert.fail("Failed in Filling Location and Design. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage addCustomNameAndNumber(String type) {
		try {
			if (type.equalsIgnoreCase("Name")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "1")));
				chooseColor("Custom Name");
			} else if (type.equalsIgnoreCase("Number")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "1")));
				chooseColor("Custom Number");
			} else if (type.equalsIgnoreCase("both")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "1")));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "1")));
			}
			ExtentLogger.pass("Added Custom Details Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Adding Custom Name and Numbers. " + e.getMessage());
		}
		return this;
	}

	public void chooseColor(String type) throws Exception {
		hoverOver(By.xpath(DynamicXpathUtils.getXpathForString(iconColorPicker, type)));

		if (type.equalsIgnoreCase("custom name"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[1]"));
		else if (type.equalsIgnoreCase("custom number"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[5]"));
	}

	// Added by Vidya //
	public void editchooseColor(String type) throws Exception {
		hoverOver(By.xpath(DynamicXpathUtils.getXpathForString(iconColorPicker, type)));

		if (type.equalsIgnoreCase("custom name"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[3]"));
		else if (type.equalsIgnoreCase("custom number"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[8]"));
	}

	public ProofsPage uploadReferenceImage(int count) {
		String location = "";
		try {
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(imgUploadImg, "1")));
			sleepFor(3000);
			location = System.getProperty("user.dir");

			for (int i = 1; i <= count; i++) {
				sleepFor(2000);
				chooseAndUploadFile(location + File.separator + "images" + File.separator + "proof" + i + ".png");
				sleepFor(2000);
				if (count - i == 0) {
				//	break;
					System.out.println("No more upload");
				} else {
					clickElementJS(By.xpath("//label[contains(text(),'Upload More')]"));
					System.out.println(" upload more");
					sleepFor(1000);
				}
			}
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
					By.xpath("//div[contains(@class,'latest-uploaded-image-wrapper ng-star')]"));
			ExtentLogger.pass("Uploaded Reference Image Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Uploading Reference Image. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage enterLicensing() {
		String collegiateMark = "", organization = "";
		try {
			collegiateMark = DataGeneratorUtils.randSchoolName();
			organization = DataGeneratorUtils.randOrganizationName();

			clickElementJS(drpdwnCollegiateMark);
			enterData(txtCollegiateMark, collegiateMark);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));

			clickElementJS(drpdwnOrganization);
			enterData(txtOrganization, organization);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));

			 sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);
           
            
			ExtentLogger.pass("Added Licensing Details Successfully.");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Licensing Info");
		}
		return this;
	}

	public ProofsPage saveProof() {
		try {
			clickElement(btnSubmitProof);
//			sleepFor(500);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_CREATION_SUCCESS_MESSAGE + "')]"));

//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
//					By.xpath("//div[contains(text(),'" + PROOFS_ASSIGNEMENT_SUCCESS_MESSAGE + "')]"));

			ExtentLogger.pass("Saved and Assigned the Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Proof. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage addAnotherProofItem() {
		try {
			clickElement(btnAddAnotherProofItem);

			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'Proof Item #1 Saved')]"));
			ExtentLogger.pass("Clicked Add Another Proof Item Button Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Add Another Proof Item. " + e.getMessage());
		}

		return this;
	}
	
	public ProofsPage addAnother2ProofItem() {
		try {
			clickElement(btnAddAnotherProofItem);

			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'Proof Item #2 Saved')]"));
			ExtentLogger.pass("Clicked Add Another Proof Item Button Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Add Another Proof Item. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage filterProof() {
		String proofName = "";
		try {
			proofName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFTITLE");
			System.out.println("proofName = " + proofName);
			enterData(txtSearchProof, proofName);
			ExtentLogger.pass("Filtered " + proofName + " Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Filtering " + proofName + " Proof. " + e.getMessage());
		}
		return this;
	}

	// Changes done by Vidya
	public ProofsPage verifyDashboard(String operationType) {
		ArrayList<HashMap<String, String>> completeData = null;
		String proofNo = "", type = "", proofName = "", client = "";
		try {
			sleepFor(2000);
			completeData = readCurrentTable();

			if (operationType.equalsIgnoreCase("create")) {

				type = "In Progress";
				proofName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFTITLE");
				client = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME");
				proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFID");
				System.out.println("proofNo = " + proofNo);

//				printMap(completeData);
				if (completeData.size() != 1) {
					throw new Exception("Searched Record is not filtered Correctly.");
				} else {
					for (HashMap<String, String> eachRow : completeData) {
						proofNo = eachRow.get("Proof #");
						if (!eachRow.get("Type").equalsIgnoreCase(type)) {
							System.out.println(eachRow.get("Type") + ": " + type);
							throw new Exception("Filtered Records doesn't have the expected Type: " + type);
						}
						if (!eachRow.get("Proof Name").equalsIgnoreCase(proofName)) {
							System.out.println(eachRow.get("Proof Name") + ": " + proofName);
							throw new Exception("Filtered Records doesn't have the expected Proof Name: " + proofName);
						}
						if (!RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
								.equalsIgnoreCase("client")) {
							if (!eachRow.get("Client").equalsIgnoreCase(client)) {
								System.out.println(eachRow.get("Client") + ": " + client);
								throw new Exception("Filtered Records doesn't have the expected Client: " + client);
							}
						}
					}

					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFID", proofNo);
					
				}
			}

			ExtentLogger.pass("Verfied Dashboard after Filtering the Created Proof");
		} catch (Exception e) {
			Assert.fail("Failed in Verfying Data after " + operationType + " Operation. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage filterDataAndVerifyAllColumns(ProofsTabs proofsTab) {
		try {
			sleepFor(1000);
			switchTo(proofsTab);
			sleepFor(500);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			filterAndVerifyProofID(proofsTab, rowCount);
			filterAndVerifyProofName(proofsTab, rowCount);
			filterAndVerifyClient(proofsTab, rowCount);

		} catch (Exception e) {
			Assert.fail("Unable to Filter specified Data and Verify Columns for " + getStringValue(proofsTab) + ". "
					+ e.getMessage());
		}

		return this;
	}
	
	/*This filter for Non available values in our Data table */
	public ProofsPage filterDataAndVerifyAllColumn(ProofsTabs proofsTab) {
		try {
			sleepFor(1000);
			switchTo(proofsTab);
			sleepFor(500);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			filterAndVerifyProofid(proofsTab, rowCount);
			filterAndVerifyProofsName(proofsTab, rowCount);
			filterAndVerifyClientName(proofsTab, rowCount);

		} catch (Exception e) {
			Assert.fail("Unable to Filter specified Data and Verify Columns for " + getStringValue(proofsTab) + ". "
					+ e.getMessage());
		}

		return this;
	}

	// Changes done by Vidya
	public void filterAndVerifyProofID(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "";
		int filterIdx = 0;
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			// filterData = getData(
			// By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx +
			// "]//div)[1]"));
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[2]"));
			enterData(txtSearchProof, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Proof # is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Proof #").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Proof ID: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Proof #");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyProofid(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "115040";
		
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			enterData(txtSearchProof, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Proof #").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Proof ID: " + filterData);
					}
				}

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + PROOFS_NOSEARCH_FOUND + "')]"));
				
			ExtentLogger.pass("Searching Functionality is Verifed for Proof #");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	// Changes done by Vidya
	
	public void filterAndVerifyProofName(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;

		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			// filterData = getData(
			// By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx +
			// "]//div)[8]"));
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[7]"));
			enterData(txtSearchProof, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Proof Name is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Proof Name").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Proof Name: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Proof Name");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void filterAndVerifyProofsName(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "Testing Name";
		ArrayList<HashMap<String, String>> completeData = null;

		try {
			
			enterData(txtSearchProof, filterData);
			sleepFor(1500);
			completeData = readCurrentTable();
		
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Proof Name").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Proof Name: " + filterData);
					}
				}
			
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + PROOFS_NOSEARCH_FOUND + "')]"));
				
				ExtentLogger.pass("Searching Functionality is Verifed for Proof Name");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	public void filterAndVerifyClient(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		int filterIdx = 0;
		String filterData = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
			filterData = getData(
					By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[11]"));
			enterData(txtSearchProof, filterData);
			sleepFor(2000);
			completeData = readCurrentTable();
			if (completeData.size() == 0) {
				throw new Exception("Searched Client is not filtered.");
			} else {
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterData);
					}
				}
			}
			ExtentLogger.pass("Searching Functionality is Verifed for Client");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void filterAndVerifyClientName(ProofsTabs proofsTab, int rowCount) throws Exception {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		String filterData = "Virat Kohli";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			enterData(txtSearchProof, filterData);
			sleepFor(2000);
			completeData = readCurrentTable();
			
				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterData)) {
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterData);
					}
				}
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + PROOFS_NOSEARCH_FOUND + "')]"));
				
			ExtentLogger.pass("Searching Functionality is Verifed for Client");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(700);
			switchTo(proofsTab);
			sleepFor(700);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// changes done by Vidya
	public ArrayList<HashMap<String, String>> readCurrentTable() throws Exception {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		String loggedInAs = "";
		try {
			loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");

			if (loggedInAs.equalsIgnoreCase("admin")) {
				for (int i = 1; i <= 6; i++) {

					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
					header.add(colData);
				}
				for (int i = 2; i <= rowCount; i++) {
					HashMap<String, String> eachRow = new HashMap<>();
					// int temp1 = 1, temp2 = 8, temp3 = 20;
					// int temp1 = 2, temp2 = 7, temp3 = 26, temp4 = 16;
					int temp1 = 2, temp2 = 7, temp3 = 20, temp4 = 16;
					for (int j = 1; j <= 6; j++) {
						String data = "";
						if (j <= 2) {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp1 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp1 + "]");
							// temp1 += 4;
							temp1 += 3;

						} else if (j > 2 && j <= 4) {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp2 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp2 + "]");
							// temp2 += 3;
							temp2 += 4;
						} else if (j == 5) {

							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp4 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp4 + "]");

						}

						else {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp3 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp3 + "]");
						}
						eachRow.put(header.get(j - 1), data);
					}
					fullData.add(eachRow);
					System.out.println(eachRow);
				}
			} else if (loggedInAs.equalsIgnoreCase("manager")) {
				for (int i = 1; i <= 5; i++) {

					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
					header.add(colData);
				}
				for (int i = 2; i <= rowCount; i++) {
					HashMap<String, String> eachRow = new HashMap<>();
					int temp1 = 5;

					for (int j = 1; j <= 5; j++) {
						String data = "";

						if (j == 1) {
							data = getData(
									By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[2]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[2]");
						} else {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp1 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp1 + "]");
							temp1 += 3;
							// temp1 += 5;
						}

						eachRow.put(header.get(j - 1), data);
					}
					fullData.add(eachRow);
					System.out.println(eachRow);
				}
			} else if (loggedInAs.equalsIgnoreCase("client")) {
				for (int i = 1; i <= 4; i++) {
					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
					header.add(colData);
				}
				for (int i = 2; i <= rowCount; i++) {
					HashMap<String, String> eachRow = new HashMap<>();
					int temp1 = 5;
					for (int j = 1; j <= 4; j++) {
						String data = "";

						if (j == 1) {
							data = getData(
									By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[2]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[2]");
						} else {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + temp1 + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ temp1 + "]");
							temp1 += 3;
							// temp1 += 5;
						}

						eachRow.put(header.get(j - 1), data);
					}
					fullData.add(eachRow);
					System.out.println(eachRow);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return fullData;
	}
 
	public void printMap(ArrayList<HashMap<String, String>> fullData) {
		for (HashMap<String, String> rows : fullData) {
			for (Map.Entry<String, String> entry : rows.entrySet()) {
				System.out.println(entry.getKey() + ": " + entry.getValue());
			}
			System.out.println("-----------");
		}
	}

	// changes done by vidya
	public int getColumntempIndex(String colName) throws Exception {
		// int index = 0;
		int index = 1;

		if (colName.equalsIgnoreCase("proof #"))
			// index = 1;
			index = 2;
		else if (colName.equalsIgnoreCase("type"))
			index = 5;
		else if (colName.equalsIgnoreCase("proof name"))
			// index = 8;
			index = 7;
		else if (colName.equalsIgnoreCase("client"))
			// index = 12;
			index = 11;
	//	else if (colName.equalsIgnoreCase("campus manager"))
			else if (colName.equalsIgnoreCase("manager"))
			// index = 15;
			index = 16;
		else if (colName.equalsIgnoreCase("last updated"))
			index = 22;
		// index = 26;

		if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("manager"))
			if (colName.equalsIgnoreCase("client")) {
				// index = 10;
				index = 11;
			}

		return index;
	}

	public String getStringValue(ProofsTabs proofTab) {
		String tabString = "";
		if (proofTab.equals(ProofsTabs.ALL)) {
			tabString = "All";
		} else if (proofTab.equals(ProofsTabs.IN_PROGRESS)) {
			tabString = "In Progress";
		} else if (proofTab.equals(ProofsTabs.DONE)) {
			tabString = "Done";
		}
		return tabString;
	}

	// changes done by vidya
	public ProofsPage sortAndVerifyAllColumns(ProofsTabs proofTab) {
		// String[] colnames = { "Proof #", "Proof Name", "Client" };// , "Last Updated"
		// };

		// String tabUser=proofTab.toString();
		ArrayList<String> colnames = new ArrayList<String>();
		ArrayList<String> actualColData = null;

		try {
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("Client")) {

				colnames.add("Proof ");
				colnames.add("Proof Name");
				// colnames.add("Last Updated");

			} else {

				colnames.add("Proof ");
				colnames.add("Proof Name");
				colnames.add("Client");

			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), proofTab));

				if (column.equalsIgnoreCase("applies to")) {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(proofTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(proofTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				} else {
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);

					getSortedDataAndCompare(proofTab, column, actualColData, "asc");
					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
					sleepFor(1000);
					getSortedDataAndCompare(proofTab, column, actualColData, "dsc");
					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
				}
			}
		} catch (Exception e) {
			Assert.fail("Failed During Sorting and Verification in " + proofTab.toString() + " Tab." + e.getMessage());
		}
		return this;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, ProofsTabs proofsTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
//			boolean multiplePages = findElementPresence(
//					By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, proofsTab));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
					scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					sleepFor(2000);
					clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					sleepFor(2000);
					columnData.addAll(readColumnData(colIdx, proofsTab));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, proofsTab));
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public ArrayList<String> readColumnData(int idx, ProofsTabs proofsTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		String data = "";
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			for (int i = 2; i <= rowCount; i++) {
				data = getData(
						By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + idx + "]"));
				if (data.equalsIgnoreCase("n/a"))
					data = "";
				columnData.add(data);
			}
		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}
		return columnData;
	}

	public void getSortedDataAndCompare(ProofsTabs proofsTab, String colName, ArrayList<String> actualColData,
			String order) throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		try {
			sleepFor(2000);
			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), proofsTab));
			System.out.println("Data from UI: ");
			printArrayList(sortedColData);
			tempList.clear();
			tempList = sortArrayList(actualColData, order, colName);
			System.out.println("Manually Sorted Data: ");
			printArrayList(tempList);
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
						+ getStringValue(proofsTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Correctly in "
						+ getStringValue(proofsTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;

		if (colName.equalsIgnoreCase("proof #")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String num1, String num2) {
					Integer n1 = Integer.parseInt(num1);
					Integer n2 = Integer.parseInt(num2);
					return (n1.compareTo(n2) * ord);
				}
			});
		} else {
			Collections.sort(dataList, new Comparator<String>() {
				public int compare(String data1, String data2) {
					return (data1.compareTo(data2) * ord);
				}
			});
		}

		return dataList;
	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + " : " + sortedColData.get(i).split(" ")[0] + " / "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}

		return match;
	}

	public ProofsPage clickAndChooseFilter(String filterType) {
		try {
			clickElement(btnFilter);
			sleepFor(500);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));

			ExtentLogger.pass("Successfully Selected as " + filterType + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage applyFilter(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("client")) {

				filterValue = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} 
	//		else if (filterType.equalsIgnoreCase("campus manager")) 
				else if (filterType.equalsIgnoreCase("manager")) 
			{
		//		filterValue = InputPropertyUtils.get("EXISTING_MANAGER_FOR_PROOFS");	
				filterValue = InputPropertyUtils.get("EXISTING_MANAGER_FOR_PROOFS_SEARCH");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} else {
				throw new Exception(filterType + " is not supported.");
			}
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}
		return this;
	}
	
	public ProofsPage applyFilterforNonAvailable(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("client")) {

				filterValue = "Robert Downey";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} 
	//		else if (filterType.equalsIgnoreCase("campus manager")) 
				else if (filterType.equalsIgnoreCase("manager")) 
			{
				filterValue = "Testing Manager";

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} else {
				throw new Exception(filterType + " is not supported.");
			}
			
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_NOSEARCH_FOUND + "')]"));
			
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}
		return this;
	}

	public ProofsPage verifyDashboard() {
		String filterType = "", filterValue = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDVALUE");

			completeData = readCurrentTable();
			if (filterType.equalsIgnoreCase("client")) {

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Client").equalsIgnoreCase(filterValue)) {
						System.out.println(eachRow.get("Client"));
						throw new Exception("Filtered Records doesn't have the expected Client: " + filterValue);
					}
				}
			} 
		//	else if (filterType.equalsIgnoreCase("campus manager")) 
			else if (filterType.equalsIgnoreCase("manager")) 	
			{
				completeData = readCurrentTable();

				for (HashMap<String, String> eachRow : completeData) {
			//		if (!eachRow.get("Campus Manager").contains(filterValue))
						if (!eachRow.get("Manager").contains(filterValue))
					{
						throw new Exception("Filtered Records doesn't have the expected Campus Manager " + filterValue);
					}
				}
			}

			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass(
					"Found " + completeData.size() + " matches after applying Filter. Verified all Matched Records has "
							+ filterType + " as " + filterValue + ".");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Dashboard after filtering. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage verifyTypeColumn(ProofsTabs proofsTab) {
		HashSet<String> colData;
		try {
			sleepFor(2000);
			colData = new HashSet<>(readCompleteColumnData(getColumntempIndex("Type"), proofsTab));
			for (String data : colData) {
				if (!data.trim().equalsIgnoreCase(getStringValue(proofsTab))) {
					throw new Exception("Status does not match");
				}
			}
			ExtentLogger.pass("Verify Data Present in Status Column in " + getStringValue(proofsTab) + " tab for "
					+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS"));
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Data in Status Column. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage verifyRecordsCount(ProofsTabs proofsTab) {
		try {
			sleepFor(300);
			int rowCount = 0, recordsPerPage = 0, totRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(By.xpath(
							DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(proofsTab))))
					.getText());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(proofsTab))));
			sleepFor(500);

			if (findElementPresence(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))) {
				recordsPerPage = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
			} else {
				recordsPerPage = totRecords;
			}

			if (totRecords < recordsPerPage) {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount + " for " + getStringValue(proofsTab));
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount + " for "
							+ getStringValue(proofsTab));	
				}
			} else {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				while (checkCondition(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"),
						ElementCheckStrategy.DISPLAYED)) {
					clickElement(By.xpath("//i[@class='datatable-icon-right']"));

					rowCount = rowCount
							+ DriverManager.getDriver()
									.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size()
							- 1;
				}
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount);
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount);
				}
			}
		} catch (Exception e) {
			Assert.fail("Unable to Verify Records Count. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage proofDetailsValidations() {
		try {
			clickElementJS(txtProofTitle);
			clickTab(txtProofTitle);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_PROOFTITLE_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Proof Title is not Displayed");
			}

			clickElementJS(drpDwnCampaign);
			clickTab(txtCampaign);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_CAMPAIGN_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Campaign is not Displayed");
			}

			clickElementJS(drpDwnClientName);
			clickTab(txtClientName);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_CLIENT_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Client Name is not Displayed");
			}

			fillProofDetails("Existing");
			ExtentLogger.pass("Verified Validations in Proof Details Page");
		} catch (Exception e) {
			Assert.fail("Failed in Proof Details Field Validations. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage productInfoValidations() {
		String styleCode = "";
		try {
			clickElementJS(drpDwnStyleCode);
			clickTab(txtStyleCode);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_STYLECODE_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Style Code is not Displayed");
			}

			styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));

			clickElementJS(drpDwnColor);
			clickTab(txtColor);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_COLOR_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Color is not Displayed");
			}

			clickElement(drpDwnColor);
			clickElementJS(optionColor);

			ExtentLogger.pass("Verified Validations in Product Info Page");
			clickElementJS(btnAddLocAndDesign);
		} catch (Exception e) {
			Assert.fail("Failed in Product Info Field Validations. " + e.getMessage());
		}
		return this;
	}	
	
	public ProofsPage referenceImageValidations() {
		try {
			uploadReferenceImage(1);

			if (!findElementPresence(By.xpath("//div[contains(@class,'latest-uploaded-image-wrapper ng-star')]"))) {
				throw new Exception("Image is not Uploaded");
			}

			clickElementJS(By.xpath("//img[contains(@class,'remove-image')]"));
			if (!findElementPresence(By.xpath(DynamicXpathUtils.getXpathForString(imgUploadImg, "1")))) {
				throw new Exception("Image is not getting removed");
			}

			ExtentLogger.pass("Verified Adding and Removing Reference Images");
		} catch (Exception e) {
			Assert.fail("Failed in Reference Images Validation. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage addAndRemoveLocations() {
		try {
			clickElementJS(btnAddLocation);
			sleepFor(1000);
			if (DriverManager.getDriver().findElements(By.xpath("//img[contains(@src,'cancel_proof_default')]"))
					.size() != 2) {
				throw new Exception("New Location is not getting Added");
			}
			sleepFor(2000);
			clickElementJS(By.xpath("(//img[contains(@src,'cancel_proof_default')])[1]"));
			sleepFor(1000);
			if (DriverManager.getDriver().findElements(By.xpath("//img[contains(@src,'cancel_proof_default')]"))
					.size() != 0) {
				throw new Exception("New Location is not getting Deleted");
			}

			ExtentLogger.pass("Verified Adding and Removing Locations");
		} catch (Exception e) {
			Assert.fail("Failed in Locations Validation. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage licensingInfoValidations() {
		try {
			scrollToBottom();
			clickElementJS(drpdwnCollegiateMark);
			clickTab(txtCollegiateMark);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_COLLEGIATE_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Collegiate is not Displayed");
			}

			clickElementJS(drpdwnOrganization);
			clickTab(txtOrganization);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_ORG_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Organization is not Displayed");
			}

			ExtentLogger.pass("Verified Validations in Licensing Info Section");
		} catch (Exception e) {
			Assert.fail("Failed in Licensing Info Field Validations. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage editProofDetails(String type) {
		String clientName = "", proofTitle = "", campaign = "";
		try {
			clickElementJS(iconDownEditProofDetails);

			proofTitle = "Proof " + DataGeneratorUtils.randString();
			campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS");
			enterData(txtProofTitle, proofTitle);

			if (type.equalsIgnoreCase("Existing")) {
				clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");
				clickElement(drpDwnClientName);
				enterData(txtClientName, clientName);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
				sleepFor(500);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);

			ExtentLogger.pass("Verfied Editing Proof Details");
			clickElementJS(iconDownEditProofDetails);
			sleepFor(500);
		} catch (Exception e) {
			Assert.fail("Failed in Edit . " + e.getMessage());
		}
		return this;
	}

	public ProofsPage editProductInfo() {
		String styleCode = "";
		try {
		//	clickElementJS(iconDownEditProductDetails);

			styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
		//	scrollToElement(drpDwnStyleCode);

			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			clickElementJS(txtStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clearData(txtColor);
			enterData(txtColor, "Black");
			clickElementJS(optionColor);

			ExtentLogger.pass("Verfied Editing Product Info");
			clickElementJS(iconDownEditProductDetails);
		} catch (Exception e) {
			Assert.fail("Failed in Editing Product Info. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage clickProof(String type) {

		sleepFor(1000);
		String proofNo = "";

		try {

			if (type.equalsIgnoreCase("existing")) {

				proofNo = InputPropertyUtils.get("EXISTING_ID_FOR_PROOF");

			} else 
			  if(type.equalsIgnoreCase("Existing RequestRevision")) {
			
				proofNo = InputPropertyUtils.get("EXISTING_ID_FOR_PROOF_REQUESTREVISION");
			}
			  else if (type.equalsIgnoreCase("Existing for color")) {
				  
				proofNo = "121286";  
			  }
			
			else {

				
				proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFID");

			}
			
			enterData(txtSearchProof, proofNo);
			System.out.println("proofNo = " + proofNo);

			sleepFor(2000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(lnkProofNumber, proofNo)));
			//RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ProofNo", proofNo);

			sleepFor(1000);

			ExtentLogger.pass("selected the Proof for Edit ");
		} catch (Exception e) {

			Assert.fail("Failed selected the Proof for Edit " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage editProofTitle() {

		String proofTitle = "";

		try {

			proofTitle = "Proof " + DataGeneratorUtils.randString();
			enterData(txtProofTitle, proofTitle);
			sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);

			ExtentLogger.pass("Verfied Editing Proof Title");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Proof Title . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage clickDetailsButton() {

		try {

			clickElementJS(btnDetails);
			sleepFor(1000);

			ExtentLogger.pass("Successfully Selected Details Icon");

		} catch (Exception e) {
			Assert.fail("Unable Select Details Icon . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage editCilent(String userType) {

		String clientName = "";

		if (userType.equalsIgnoreCase("ADMIN")) {

			clientName = InputPropertyUtils.get("ADMIN_EDIT_EXISTING_CLIENT_FOR_PROOFS");

		} else {
			clientName = InputPropertyUtils.get("EDIT_EXISTING_CLIENT_FOR_PROOFS");
		}

		try {

			
			//clickElementJS(drpDwnClientName);
			sleepFor(500);
			clearData(txtClientName);
			enterData(txtClientName, clientName);
		    ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,txtClientName);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
			sleepFor(500);
			ExtentLogger.pass("Verfied Editing Client Name");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Client Name . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage editSubmittedBy() {

		sleepFor(1000);

		String submittedBy = "";

		try {

			sleepFor(1000);
			submittedBy = InputPropertyUtils.get("EXISTING_SUBMITTEDBY_FOR_PROOFS");
			sleepFor(1000);
			clickElement(drpDownSubmittedBy);
			clearData(txtSubmittedby);
			sleepFor(500);
			enterData(txtSubmittedby, submittedBy);
			sleepFor(500);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionSubmittedby, submittedBy)));
			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUBMITTEDBY", submittedBy);

			ExtentLogger.pass("Verfied Editing Submitted By");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Submitted By . " + e.getMessage());
		}
		return this;
	}

	// Added by Vidya //
	public ProofsPage editRelatedCampaign() {

		String campaign = "";

		try {

			// campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS");
			campaign = InputPropertyUtils.get("EDIT_EXISTING_CAMPAIGN_FOR_PROOFS");

			clickElement(drpDwnCampaign);
			enterData(txtCampaign, campaign);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);

			ExtentLogger.pass("Verfied Editing RelatedCampaign ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit RelatedCampaign . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage hoverThreeDotsandEditButton() {
		try {
			hoverOver(btnThreeDots);
			clickElementJS(btnedit);
			ExtentLogger.pass("Successfully HoverOvered  ThreeDotsButton & selected Edit Button ");

		} catch (Exception e) {
			Assert.fail("Unable to HoverOver ThreeDotsButton & Edit Button  . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage clickEditbutton() {

		try {

			clickElementJS(btnDetails);
			sleepFor(1000);

			ExtentLogger.pass("Successfully Selected Edit Icon");

		} catch (Exception e) {
			Assert.fail("Unable Select Edit Icon . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage editStyleCode() {
		String styleCode = "";

		try {

			styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
			scrollToElement(drpDwnStyleCode);
			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
			sleepFor(500);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);

			ExtentLogger.pass("Verfied Editing styleCode ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit styleCode . " + e.getMessage());
		}
		return this;

	}

	// Added by Vidya //
	public ProofsPage editColor() {
		
		String color= "Black";

		try {

			clickElement(drpDwnColor);
			clearData(txtColor);
			enterData(txtColor, color);
			clickElementJS(optionColor);
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);

			ExtentLogger.pass("Verfied Editing Color ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Color . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage editCollegiateMarks() {

		String collegiateMark = "";

		try {

			collegiateMark = DataGeneratorUtils.randSchoolName();

			clickElementJS(drpdwnCollegiateMark);
			clearData(txtCollegiateMark);
			enterData(txtCollegiateMark, collegiateMark);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);

			ExtentLogger.pass("Verfied ,Editing Collegiate Mark  ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Collegiate Mark  . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage editOrganization() {

		String organization = "";

		try {

			organization = DataGeneratorUtils.randOrganizationName();

			clickElementJS(drpdwnOrganization);
			clearData(txtOrganization);
			enterData(txtOrganization, organization);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);

			ExtentLogger.pass("Verfied Editing Organization  ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Organization  . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage fillCollegiateMarks() {

		String collegiateMark = "";

		try {

			collegiateMark = DataGeneratorUtils.randSchoolName();

			clickElementJS(drpdwnCollegiateMark);
			clearData(txtCollegiateMark);
			enterData(txtCollegiateMark, collegiateMark);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);

			ExtentLogger.pass("Verfied Editing Collegiate Mark  ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Collegiate Mark  . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage fillOrganization() {

		String organization = "";

		try {

			organization = DataGeneratorUtils.randOrganizationName();

			clickElementJS(drpdwnOrganization);
			clearData(txtOrganization);
			enterData(txtOrganization, organization);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);

			ExtentLogger.pass("Verfied Editing Organization  ");

		} catch (Exception e) {
			Assert.fail("Failed in Edit Organization  . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage hoverThreeDotsandDeleteButton() {

		try {

			hoverOver(btnThreeDotsforDelete);
			clickElementJS(btnDelete);
			ExtentLogger.pass("Successfully HoverOvered  ThreeDotsButton & selected Delete Button ");

		} catch (Exception e) {
			Assert.fail("Unable to HoverOver ThreeDotsButton & Delete Button  . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage clickDeleteOption() {

		try {

			clickElementJS(optionaDeleteProof);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_DELETION_SUCCESS_MESSAGE + "')]"));

			ExtentLogger.pass("Successfully Deleted the Proof");

		} catch (Exception e) {
			Assert.fail("Unable to Deleted the Proof . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage verifyDashboardDelete(String operationType) {

		ArrayList<HashMap<String, String>> completeData = null;

		String proofNo = "";
		// String proofName = "";

		try {

			sleepFor(2000);
			completeData = readCurrentTable();

			if (operationType.equalsIgnoreCase("existing")) {

				proofNo = InputPropertyUtils.get("EXISTING_ID_FOR_PROOF");

			} else {

				// proofName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),
				// "PROOFTITLE");
				proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFID");

			}

			enterData(txtSearchProof, proofNo);
			System.out.println("proofNo = " + proofNo);
			sleepFor(1000);

			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
			System.out.println("rowCount = " + rowCount);

			if (rowCount == 1) {

				ExtentLogger.pass(" Successfully Deleted the Proof");
			}

			ExtentLogger.pass("Verfied Dashboard after Filtering the Delete Proof");

		}

		catch (Exception e) {
			Assert.fail("Unable to Deleted the Proof . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage saveEditProof() {
		try {
			clickElement(btnEditSave);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_EDITED_SUCCESS_MESSAGE + "')]"));

			ExtentLogger.pass("Saved Edit Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Edit Proof. " + e.getMessage());
		}
		return this;
	}

//Added by Vidya //
	public ProofsPage filterEditProof(String type) {

		sleepFor(1000);
		String proofNo = "";

		try {

			if (type.equalsIgnoreCase("existing")) {

				proofNo = InputPropertyUtils.get("EXISTING_ID_FOR_PROOF");

			} 
			
			else if (type.equalsIgnoreCase("Existing for color")) {
				  
				proofNo = "121286";  
			  }
			else {

				proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFID");

			}

			enterData(txtSearchProof, proofNo);
			System.out.println("proofNo = " + proofNo);

			sleepFor(1000);

			ExtentLogger.pass("Filtered " + proofNo + " Proof Successfully");
		} catch (Exception e) {

			Assert.fail("Failed Filtering  the Proof  " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage filterEditedProof(String type) {

		sleepFor(500);
		String proofNo = "";

		try {

			if (type.equalsIgnoreCase("existing")) {

				proofNo = InputPropertyUtils.get("EXISTING_ID_FOR_PROOF");

			} else {

				// proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(),
				// "ProofNo");
				proofNo = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFID");

			}

			enterData(txtSearchProof, proofNo);
			System.out.println("proofNo = " + proofNo);
			sleepFor(1000);

			ExtentLogger.pass("Filtered the Edited Proof Successfully");
		} catch (Exception e) {

			Assert.fail("Unable to Filtered the Edited Proof " + e.getMessage());
		}

		return this;

	}
	
	// Added by Vidya //
	public ProofsPage logOutProofs() {

		DBSetupUtils.setupUserDatabase();
		sleepFor(2000);
		try {

			System.out.println(DriverManager.getDriver().findElement(profileIconNew).getText());
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(profileIconNew));
			sleepFor(3000);
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(lnkLogoutMenu));

			ExtentLogger.pass("Logged Out of the Application");

		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return new ProofsPage();
	}

//Added by Vidya //
	public ProofsPage editDescribetheArt() {

		try {

			clickElementJS(editTxtDescArt);
			clearData(editTxtDescArt);

			enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtDescArt, "1")), "Sample Description Edit 1");

			ExtentLogger.pass("Successfully Edited Details in Description  Sections");

		} catch (Exception e) {
			Assert.fail("Failed in Edited Description . " + e.getMessage());
		}

		return this;
	}

	// Added by Vidya //
	public ProofsPage editCustomNameAndNumber(String type) {
		try {
			if (type.equalsIgnoreCase("Name")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "1")));
				editchooseColor("Custom Name");
			} else if (type.equalsIgnoreCase("Number")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "1")));
				editchooseColor("Custom Number");
			} else if (type.equalsIgnoreCase("both")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "1")));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "1")));
			}
			ExtentLogger.pass("Added Custom Details Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Adding Custom Name and Numbers. " + e.getMessage());
		}
		return this;
	}

	// Added by Vidya //
	public ProofsPage addNewStyleCode() {
		String styleCode = "New Style Code";

		try {

			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			enterData(txtStyleCode, styleCode);
			sleepFor(500);

			Actions action = new Actions(DriverManager.getDriver());
			action.moveToElement(DriverManager.getDriver().findElement(optionNewStyleCode));
			action.click().build().perform();
			action.sendKeys(Keys.ENTER);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);

			ExtentLogger.pass("Verfied Added New styleCode ");

		} catch (Exception e) {
			Assert.fail("Failed in Add New styleCode . " + e.getMessage());
		}
		return this;

	}

	// Added by Vidya //
	public ProofsPage addNewColor() {
		String color = "Blue";

		try {

			clickElementJS(txtAddColor);
			clearData(txtAddColor);
			enterData(txtAddColor, color);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);

			ExtentLogger.pass("Verfied Added New  Color ");

		} catch (Exception e) {
			Assert.fail("Failed in Add New  Color . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage addProductName() {
		String productName = "Amazon Shopping";

		try {

			clickElementJS(txtProductName);
			clearData(txtProductName);
			enterData(txtProductName, productName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCT NAME", productName);

			ExtentLogger.pass("Verfied Added Product Name  ");

		} catch (Exception e) {
			Assert.fail("Failed in Add Product Name . " + e.getMessage());
		}

		return this;

	}

	// Added by Vidya //
	public ProofsPage addProductLink() {

		String productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html";

		try {

			clickElement(txtProductLink);
			clearData(txtProductLink);
			enterData(txtProductLink, productLink);

			ExtentLogger.pass("Verfied Added Product Link ");

		} catch (Exception e) {
			Assert.fail("Failed in Add Product Link. " + e.getMessage());
		}

		return this;

	}

// Added by Vidya //
	public ProofsPage addOrganizationOthers() {

		String organization = "Other";
		String organizationName = "Custom Organization";
		try {

			clickElementJS(drpdwnOrganization);
			clearData(txtOrganization);
			enterData(txtOrganization, organization);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));
			sleepFor(500);

			clickElementJS(txtorganizationname);
			enterData(txtorganizationname, organizationName);
			ExtentLogger.pass("Entered Organization details Successfully.");

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OGANIZATION NAME", organizationName);

		} catch (Exception e) {
			Assert.fail("Failed in Entering Organization details");
		}

		return this;

	}

//Added by Vidya //
	public ProofsPage enterCollegiateMark() {

		String collegiateMark = "";

		try {

			collegiateMark = DataGeneratorUtils.randSchoolName();
			clickElementJS(drpdwnCollegiateMark);
			clearData(txtCollegiateMark);
			enterData(txtCollegiateMark, collegiateMark);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
			ExtentLogger.pass("Entered CollegiateMark details Successfully.");

		} catch (Exception e) {
			Assert.fail("Failed in Entering CollegiateMark details");
		}

		return this;
	}

	
	public ProofsPage clickAddLocationandDesign() {

		try {

			clickElementJS(btnAddLocAndDesign);

			ExtentLogger.pass("Successfully Clicked Add Location & Design Button");

		} catch (Exception e) {
			ExtentLogger.fail("Failed to Click Add Location & Design Button " + e.getMessage());
		}

		return this;

	}

	
	public ProofsPage clickSubmit() {
		try {
			clickElement(btnSubmitProof);
			sleepFor(500);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_ADDITION_SUCCESS_MESSAGE + "')]"));

			ExtentLogger.pass("Saved Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Proof. " + e.getMessage());
		}
		return this;
	}

	
	public ProofsPage clickProductLink() {

		try {

			sleepFor(1000);
			scrollToElement(clickProductLink);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,clickProductLink);
			clickElement(clickProductLink);
			

			ExtentLogger.pass("Clicked Product Link ");

		} catch (Exception e) {
			Assert.fail("Failed to Click Product Link " + e.getMessage());
		}

		return this;

	}

	
	public ProofsPage verifyLinkOpen() {
		
//		WebDriver wait =(WebDriver) new WebDriverWait(DriverManager.getDriver(), 1000);
//		wait.until((JavascriptExecutor)WebDriver).executeScript("return document.readyState").equals("complete"));
		
		sleepFor(5000);

		String windowBefore=DriverManager.getDriver().getWindowHandle();

		try {
			
			sleepFor(5000);
			Set<String> windows =DriverManager.getDriver().getWindowHandles();
			
			for (String eachwindow :windows )// go to last window 
			{
				DriverManager.getDriver().switchTo().window(eachwindow);
			}
			
			URL url = new URL(DriverManager.getDriver().getCurrentUrl());
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("GET");
			Set<Cookie> cookies = DriverManager.getDriver().manage().getCookies();
			String cookieString = "";

			for (Cookie cookie : cookies) {
			    cookieString += cookie.getName() + "=" + cookie.getValue() + ";";
			}

			httpURLConnection.addRequestProperty("Cookie", cookieString);
			Assert.assertEquals(200, httpURLConnection.getResponseCode());

	
			ExtentLogger.pass("Verified the Product Link Successfully Opened  ");
			
			

		} catch (Exception e) {
			Assert.fail("Failed to Open Product Link " + e.getMessage());
		}

		
		DriverManager.getDriver().switchTo().window(windowBefore);
		
		return this;
	}

public ProofsPage selectProof() {
	
	try {
		
		clickElement(selectProof);
		
	} catch (Exception e) {
		Assert.fail(e.getMessage());
	}
	
	return this;
}

	
	public ProofsPage addAnotherLocation() {

		try {

			scrollToElement(btnAddLocation);
			sleepFor(1000);
			clickElementJS(btnAddLocation);

			ExtentLogger.pass("Clicked Add Another Location Button Successfully");

		} catch (Exception e) {
			Assert.fail("Failed to Click Add Another Location Button " + e.getMessage());
		}

		return this;

	}

	public ProofsPage addAnotherPrintType(String printType) {

		try {

			scrollToElement(btnAddLocation);
			sleepFor(1000);
			clickElementJS(By.xpath("(//div[contains(text(),'" + printType + "')])[2]"));

			ExtentLogger.pass("Successfully Selected Print Type ");
		} catch (Exception e) {
			Assert.fail("Failed to Select Print Type. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage addaontherDescribetheArt() {

		try {

			clickElementJS(editTxtDescArt);
			clearData(editTxtDescArt);

			enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtDescArt, "2")),
					"Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.Amazon.com, Inc. is an American multinational technology company which focuses on e-commerce, cloud computing, digital streaming, and artificial intelligence. It has been referred to as \"one of the most influential economic and cultural forces in the world\", and is one of the world's most valuable brands.");

			ExtentLogger.pass("Successfully Filled Details in Description  Sections");

		} catch (Exception e) {
			Assert.fail("Failed in Fill Description . " + e.getMessage());
		}

		return this;
	}

	public ProofsPage saveEditProofAddLocation() {
		try {
			clickElement(btnEditSave);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + PROOFS_ADDLOCATION_SUCCESS_MESSAGE + "')]"));

			
			ExtentLogger.pass("Saved Edit Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to  Edit Proof. " + e.getMessage());
		}
		return this;
	}
	
	public ProofsPage verifyArrowButton() {
		
		try {
			
		//	clickElementJS(downArrowButton);
			scrollToElement(scrollDownCheck);
			sleepFor(1000);
			
		//	ExtentLogger.pass("Verfied Down Arrow Button Successfully");
			ExtentLogger.pass("Verifed Scrolling down the Page Successfully");
			
		} catch (Exception e) {
	//		Assert.fail("Failed to Verify Down Arrow Button.  " + e.getMessage());
			Assert.fail("Failed to Verify Scroll down the page.  " + e.getMessage());
		}
		
		return this;
	}

	public ProofsPage addOtherReferenceImage(int count) {

		String location = "";
		try {

			clickElementJS(referUploadImg);
			sleepFor(3000);
			location = System.getProperty("user.dir");
			sleepFor(5000);

			for (int i = 1; i <= count; i++) {
				sleepFor(2000);
				chooseAndUploadFile(location + File.separator + "images" + File.separator + "proof" + i + ".png");
				sleepFor(2000);
				if (count - i == 0) {
				//	break;
					System.out.println("no more upload");
				} else {
					sleepFor(1000);
				}
			}
			ExtentLogger.pass("Uploaded Reference Image Successfully");

		} catch (Exception e) {
			Assert.fail("Failed in Uploading Reference Image. " + e.getMessage());
		}

		return this;
	}

	public ProofsPage connectdb() {

		try {

			DBSetupUtils.setupUserDatabase();
			sleepFor(500);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return this;
	}
	
	public ProofsPage productInfoValidationsWithProductLink() {
		String styleCode = "";
		try {
			clickElementJS(drpDwnStyleCode);
			clickTab(txtStyleCode);
			sleepFor(200);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_STYLECODE_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Style Code is not Displayed");
			}

			addNewStyleCode();
			sleepFor(1000);

			clickElementJS(txtAddColor);
			enterData(txtAddColor, "black");
			
			clickElementJS(txtProductName);
			enterData(txtProductName, "");
			clickTab(txtProductLink);
			sleepFor(200);
			
			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_PRODUCTNAME_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Prodct Name is not Displayed");
			}

			addProductName();
			sleepFor(1000);
			
			clickElementJS(txtProductLink);
			enterData(txtProductLink, "");
			sleepFor(200);
			
			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PROOFS_PRODUCTLINK_EMPTY_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Prodct Name is not Displayed");
			}

			addProductLink();
			sleepFor(1000);
			
			ExtentLogger.pass("Verified Validations in Product Info Page");
			clickElementJS(btnAddLocAndDesign);
		} catch (Exception e) {
			Assert.fail("Failed in Product Info Field Validations. " + e.getMessage());
		}
		return this;
	}	

	public ProofsPage clickCancelButton() {
		
		try {
			
			clickElement(btnCancel);
			sleepFor(500);
			clickElement(btnYes);
			
			ExtentLogger.pass("Cancelled Edited Proof Successfully");
			
		} catch (Exception e) {
			Assert.fail("Unable to Cancel Edited Proof. " + e.getMessage());
		}
		
		return this;
	}
	
	public ProofsPage selectDescribetheArt() {
		
		try {
			
			scrollToElement(btnAddLocation);
			clickElementJS(editTxtDescArt);
			
			WebElement txtDesc=DriverManager.getDriver().findElement(textDescArt);
			txtDesc.sendKeys(Keys.chord(Keys.CONTROL, "A"));
			sleepFor(1000);
		
			ExtentLogger.pass("Successfully Selected Details in Description  Sections");
		} catch (Exception e) {
			Assert.fail("Failed to Select Description . " + e.getMessage());
		}
		
		return this;
		
	}
	
	public ProofsPage clickLinkButton() {
		
		try {
			
			clickElementJS(btnLink);
			sleepFor(1000);
			
			ExtentLogger.pass("Successfully Clicked the Link Button");
			
		} catch (Exception e) {
			Assert.fail("Failed to Click the Link Button. " + e.getMessage());
		}
		
		return this;
	}
	
	public ProofsPage addHyperlink() {
		
		try {
			
			sleepFor(1000);
			DriverManager.getDriver().switchTo().alert().sendKeys("https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
			DriverManager.getDriver().switchTo().alert().accept();
			sleepFor(1000);
			
			ExtentLogger.pass("Successfully Added the Hyper Link in Description");
		} catch (Exception e) {
			Assert.fail("Failed to Add the Hyper Link in Description. " + e.getMessage());
		}
		
		return this;
	}
	
	public ProofsPage clickHyperlinkinDesArt() {
		
		try {
			
			clickElementJS(selectHyperLink);
			sleepFor(1000);
			
//			Actions action = new Actions(DriverManager.getDriver());
//			action.moveToElement(DriverManager.getDriver().findElement(selectHyperLink));
//			action.click().build().perform();
//			action.sendKeys(Keys.ENTER);
			
			
			ExtentLogger.pass("Successfully Clicked Hyperlink");
			
		} catch (Exception e) {
			Assert.fail("Failed to Click HyperLink . " + e.getMessage());
		}
		
		return this;
	}
	
	public ProofsPage saveProofforHyperlink() {
		try {
			clickElement(btnEditSave);
			sleepFor(500);
			ExtentLogger.pass("Saved Edit Proof Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Edit Proof. " + e.getMessage());
		}
		return this;
	}
	
	public ProofsPage addProofItemButtonAbsence() {

		 try {
					
			 if(findElementPresence(btnAddProofs)) {
				 Assert.fail("Add Proof Button Presence in Cilent.");
			 }else {
				 ExtentLogger.pass("Verified that Add Proof Item are not displayed by Default");
			 }

		} catch (Exception e) {
			Assert.fail("Add Proof Item Displayed in Cilent. " + e.getMessage());
		}
		return this;
	}

	public ProofsPage editButtonAbsence() {
		
		 try {
				
				if(findElementPresence(btnThreeDots))	{
				Assert.fail("Edit Proof Button Presence in Cilent.");
				} else {
					ExtentLogger.pass("Verified that Edit Button are not displayed by Default");
				}

			} catch (Exception e) {
				Assert.fail("Edit Button Displayed in Cilent. " + e.getMessage());
			}
		

		return this;
	}

	public ProofsPage deleteButtonAbsence() {
		
		
		 try {
				
				if(findElementPresence(btnThreeDotsforDelete)) {
				Assert.fail("Add Proof Button Presence in Cilent.");
				}else {
					ExtentLogger.pass("Verified that Delete Button are not displayed by Default");
				}

			} catch (Exception e) {
				Assert.fail("Delete Button Displayed in Cilent. " + e.getMessage());
			}

		return this;
	}

	public ProofsPage addCustomNameAndNumberanotherlocation(String type) {
		try {
			if (type.equalsIgnoreCase("Name")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "2")));
				selectColor("Custom Name");
			} else if (type.equalsIgnoreCase("Number")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "2")));
				selectColor("Custom Number");
			} else if (type.equalsIgnoreCase("both")) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, "2")));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, "2")));
			}
			ExtentLogger.pass("Added Custom Details Successfully");
		} catch (Exception e) {
			Assert.fail("Failed in Adding Custom Name and Numbers. " + e.getMessage());
		}
		return this;
	}	

	public void selectColor(String type) throws Exception {
		hoverOver(By.xpath(DynamicXpathUtils.getXpathForString(iconColorSelect, type)));

		if (type.equalsIgnoreCase("custom name"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[1]"));
		else if (type.equalsIgnoreCase("custom number"))
			clickElementJS(By.xpath("(//div[@class='product-color'])[5]"));
	}	
	
public ProofsPage clickRequestRevision() {
	
	try {
		
		clickElement(btnRequestRevision);
		sleepFor(500);
		
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
				By.xpath("//label[contains(text(),'Placing a Revision Request')]"));
		
	//	clickElement(btndeletelocation);
		ExtentLogger.pass("Clicked Request Revision Button Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Click Request Revision Button. " + e.getMessage());
	}
	
	return this;
}	

public ProofsPage selectStyleCodeForRR() {
	String styleCode = "";

	try {

		styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
		clickElementJS(drpDwnStyleCodeforRR);
		clearData(txtStyleCodeForRR);
		enterData(txtStyleCodeForRR, styleCode);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCodeForRR, styleCode)));
		sleepFor(500);

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);

		ExtentLogger.pass("Selected styleCode Successfully");

	} catch (Exception e) {
		Assert.fail("Failed to Select styleCode . " + e.getMessage());
	}
	return this;

}


public ProofsPage selectColorForRR() {

	try {

		clickElement(drpDwnColorForRR);
		clearData(txtColorForRR);
		clickElementJS(optionColorForRR);

		ExtentLogger.pass("Selected  Color Successfully");

	} catch (Exception e) {
		Assert.fail("Failed to Select Color . " + e.getMessage());
	}

	return this;

}


public ProofsPage selectCollegiateMarksForRR() {

	String collegiateMark = "";

	try {

		collegiateMark = DataGeneratorUtils.randSchoolName();

		clickElementJS(drpdwnCollegiateMarkForRR);
		clearData(txtCollegiateMarkForRR);
		enterData(txtCollegiateMarkForRR, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMarkForRR, collegiateMark)));

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);

		ExtentLogger.pass("Selected Collegiate Mark Successfully ");

	} catch (Exception e) {
		Assert.fail("Failed to Select Collegiate Mark  . " + e.getMessage());
	}

	return this;
}


public ProofsPage selectOrganizationForRR() {

	String organization = "";

	try {

		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnOrganizationForRR);
		clearData(txtOrganizationForRR);
		enterData(txtOrganizationForRR, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganizationForRR, organization)));

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);

		ExtentLogger.pass("Selected Organization Successfully ");

	} catch (Exception e) {
		Assert.fail("Failed to Select Organization  . " + e.getMessage());
	}

	return this;
}

public ProofsPage txtDescriptionForRR() {
	
	
	try {
		
		int count = 2;
	//	int count = 1;
		for (int i = 1; i <= count; i++) {
			
			enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtDescArtForRR, String.valueOf(i))),"Sample Description " + String.valueOf(i));
		}
		
		ExtentLogger.pass("Successfully Filled Details in Description ");
		
	} catch (Exception e) {
		Assert.fail("Failed in Filling Description. " + e.getMessage());
	}
	
	return this;
}

public ProofsPage SelectPrintTypeForRR() {
	
	
	try {
		
		int count = 2;
	//	int count = 1;
		for (int i = 1; i <= count; i++) {
			
			clickElementJS(By.xpath("(//div[contains(text(),'" + DataGeneratorUtils.randPrintingTypeForProofs()+ "')])[" + i + "]"));
		}
		
		ExtentLogger.pass("Successfully Selected PrintType ");
		
	} catch (Exception e) {
		Assert.fail("Failed to select PrintType" + e.getMessage());
	}
	
	return this;
}

public ProofsPage SelectCustomNameandNumberForRR() {
	
	
	try {
		
	//	int count = 2;
		int count = 1;
		for (int i = 1; i <= count; i++) {
			
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomName, String.valueOf(i))));
			clickElementJS(By.xpath("(//div[@class='product-color'])[1]"));
			
//			if( if = 1) {
//				clickElementJS(By.xpath("(//div[@class='product-color'])[1]"));
//				}else {
//				clickElementJS(By.xpath("(//div[@class='colors-container d-flex'])[3]"));
//				}
			
//			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(toggleCustomNumber, String.valueOf(i))));
//			clickElementJS(By.xpath("(//div[@class='product-color'])[5]"));
//			sleepFor(500);
		}
		
		
		
		ExtentLogger.pass("Successfully Selected Custom Name & Number");
		
	} catch (Exception e) {
		Assert.fail("Failed to select Custom Name & Number" + e.getMessage());
	}
	
	return this;
}

public ProofsPage uploadReferenceImageForRR(int count) {
	String location = "";
	
	try {
		
		for (int i = 1; i <= count; i++) {
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(uploadReferImg, String.valueOf(i))));
		sleepFor(3000);
		location = System.getProperty("user.dir");
		sleepFor(2000);
		chooseAndUploadFile(location + File.separator + "images" + File.separator + "proof" + i + ".png");
		sleepFor(2000);
		
		}
		ExtentLogger.pass("Uploaded Reference Image Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed in Uploading Reference Image. " + e.getMessage());
	}
	
	
	return this;
}

public ProofsPage clickSubmitRR() {
	
	try {
		
		clickElement(btnSubmitRR);
		sleepFor(500);
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
				By.xpath("//div[contains(text(),'" + PROOFS_REQUESTREVISION_EMPTY_MESSAGE + "')]"));
		
		ExtentLogger.pass("Successfully Clicked Submit");
		
	} catch (Exception e) {
		Assert.fail("Failed to click Submit" + e.getMessage());
	}
	
	return this;
}

public ProofsPage verifyRevisionRequest() {
	
	try {
		sleepFor(500);
		clickElement(btnOriginProof);
		System.out.println("Selected Origin Proof");
		sleepFor(2000);
		clickElement(btnRevisionProof);
		System.out.println("Selected Revision Proof");
		sleepFor(2000);
			
		ExtentLogger.pass("Revision Request Verfied Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Verfying Revision Request"  + e.getMessage());
	}
	
	return this;
}

public ProofsPage cancelProof() {
	try {
		sleepFor(1000);
		clickElement(btnCloseProof);

		ExtentLogger.pass("Cancelled the Proof Successfully");
	} catch (Exception e) {
		Assert.fail("Unable to Cancel the Proof. " + e.getMessage());
	}
	return this;
}

public ProofsPage selectProductInfo() {
	
	try {
		
		clickElement(clickProductInfo);
		sleepFor(500);
		
		ExtentLogger.pass("Selected the Product Info Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Select Product Info. " + e.getMessage());
	}
	
	return this;
}


public ProofsPage verifyProof(){

	String styleCode = "" , color = "" , collegiateMarks = "", organization = "";
	
	try {
			
			sleepFor(500);
			softAssert = new SoftAssert();
			
			styleCode = getData(By.xpath("//div[@class='label apparel-label ng-star-inserted']"));
			color = getData(By.xpath("//div[@class='label ng-star-inserted']"));
			
			//ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
			//	By.xpath("//div[contains(text(),'Collegiate Marks')]"));
			collegiateMarks = getData(By.xpath("(//*[@ng-reflect-type='summary'])[1]"));
			
			//ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
		    //	By.xpath("//div[contains(text(),'Organization')]"));
			organization = getData(By.xpath("(//*[@ng-reflect-type='summary'])[2]"));
			
			softAssert.assertEquals(styleCode,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODE"),
					"Unexpected Style Code in Proof");
			
			softAssert.assertEquals(color,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLOR"),
					"Unexpected Color in Proof");
		
			softAssert.assertEquals(collegiateMarks,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK"),
					"Unexpected Collegiate Marks in Proof");
			
			softAssert.assertEquals(organization,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
					"Unexpected Organization in Proof");
			
			softAssert.assertAll();
			ExtentLogger.pass("Verfied Proof item");
			
		} catch (Exception e) {
			Assert.fail("Failed to Verify Proof item.  " + e.getMessage());
		}
	return this;
}

public ProofsPage verifyApparelProof() {
	
	String styleCodeExternal = "" , colorExternal = "" , productName = "", productLink = "", collegiateMarks = "", organization = "";
	
	try {
		sleepFor(500);
		scrollToElement(selectProof2);
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,selectProof2);
		clickElementJS(selectProof2);
		sleepFor(500);
		
		softAssert = new SoftAssert();
		
		styleCodeExternal = getData(By.xpath("(//div[@class='label ng-star-inserted'])[1]"));
		colorExternal = getData(By.xpath("(//div[@class='label ng-star-inserted'])[2]"));
		productName = getData(By.xpath("//div[@class='label apparel-label']"));
//		productLink = getData(By.xpath("//a[@class='label apparel-label apparel-link d-block ng-star-inserted']"));
		collegiateMarks = getData(By.xpath("(//*[@ng-reflect-type='summary'])[1]"));
		organization = getData(By.xpath("(//*[@ng-reflect-type='summary'])[2]"));
		
		softAssert.assertEquals(styleCodeExternal,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEEXTERNAL"),
				"Unexpected Style Code in Proof");
		
		softAssert.assertEquals(colorExternal,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLOREXTERNAL"),
				"Unexpected Color in Proof");
		
		softAssert.assertEquals(productName,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRODUCTNAME"),
				"Unexpected Product Name in Proof");
		
//		softAssert.assertEquals(productLink,
//				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRODUCTLINK"),
//				"Unexpected Product Link in Proof");

		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK"),
				"Unexpected Collegiate Marks in Proof");
		
		softAssert.assertEquals(organization,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
				"Unexpected Organization in Proof");
		
		
		softAssert.assertAll();
		
		
		ExtentLogger.pass("Verfied Apparel Proof");
	} catch (Exception e) {
		Assert.fail("Failed to Verify Apparel Proof.  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage verifyFPProof() {
	
	String styleCode = "" , color = "" , collegiateMarks = "", organization = "";
	
	try {
		
		clickElement(selectProof3);
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCode = getData(By.xpath("//div[@class='label apparel-label ng-star-inserted']"));
		color = getData(By.xpath("//div[@class='label ng-star-inserted']"));
		collegiateMarks = getData(By.xpath("(//*[@ng-reflect-type='summary'])[1]"));
		organization = getData(By.xpath("(//*[@ng-reflect-type='summary'])[2]"));
		
		softAssert.assertEquals(styleCode,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEFB"),
				"Unexpected Style Code in Proof");
		
		softAssert.assertEquals(color,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLORFP"),
				"Unexpected Color in Proof");
		
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK"),
				"Unexpected Collegiate Marks in Proof");
		
		softAssert.assertEquals(organization,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
				"Unexpected Organization in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Verfied FP Proof");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify FP Proof.  " + e.getMessage());
	}
	
	return this;
	
}

public ProofsPage verifyProofsDetails() {
	
	String proofTitle = "", clientName = "", campaign = "";
	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
//		proofTitle = DriverManager.getDriver().findElement(By.xpath("//input[@id='null']")).getAttribute("placeholder");
//		System.out.println("proofTitle = "+proofTitle);
		
//		proofTitle = getData(By.xpath("//input[@ng-reflect-name='title']"));
		proofTitle = getAttributeValue(txtProofTi, "value");
		System.out.println(proofTitle);
		clientName = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		campaign = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		
		softAssert.assertEquals(proofTitle,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFTITLE"),
				"Unexpected Organization in Proof");
		
		softAssert.assertEquals(clientName,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME"),
				"Unexpected ClientName in Proof");
		
		softAssert.assertEquals(campaign,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CAMPAIGN"),
				"Unexpected Campaign in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Verfied Proofs Details");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Proofs Details.  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage editProductInfos(String type) {
	
	String styleCodeExternal = "";
	String colorExternal = "Blue";
	String productName = "Shirts" , productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html" ;
	String styleCode = "";
	String color = "Black";
	try {
		
		if (type.equalsIgnoreCase("External")) {
			styleCodeExternal = "New Custom Code";
			
			scrollToBottom();
			sleepFor(500);
			clickElementJS(drpDwnStyleCode);
			sleepFor(500);
			clearData(txtStyleCode);
			sleepFor(500);
			enterData(txtStyleCode, styleCodeExternal);
			sleepFor(500);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString("//span[contains(text(),'%s')]", styleCodeExternal)));
			sleepFor(2000);
			
			enterData(txtCustomColor, "Blue");
			sleepFor(2000);
			scrollToElement(txtCustomProductLink);
			sleepFor(500);
			enterData(txtCustomProductName, "Shirts");
			sleepFor(500);
			enterData(txtCustomProductLink, "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEEXTERNAL", styleCodeExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOREXTERNAL", colorExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", productName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTLINK", productLink);
			
		}
		if (type.equalsIgnoreCase("ExistingCode")) {
			
			styleCode = InputPropertyUtils.get("EXISTING_STYLECODE_FOR_PROOFS");
			clickElementJS(txtStyleCode);
			clearData(txtStyleCode);
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		}
		
		sleepFor(500);
		ExtentLogger.pass("Successfully Edited Product Infos");
		
	} catch (Exception e) {
		Assert.fail("Failed in Edit Product Infos. " + e.getMessage());
	}
	
	return this;
}

public ProofsPage editLicensingInfos() {
	
	String collegiateMark = "", organization = "";
	try {
		collegiateMark = DataGeneratorUtils.randSchoolName();
		organization = DataGeneratorUtils.randOrganizationName();

		clickElementJS(drpdwnCollegiateMark);
		clearData(txtCollegiateMark);
		enterData(txtCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionCollegiateMark, collegiateMark)));

		clickElementJS(drpdwnOrganization);
		clearData(txtOrganization);
		enterData(txtOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionOrganization, organization)));

		sleepFor(1000);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARK", collegiateMark);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", organization);

		ExtentLogger.pass("Successfully Edited Licensing Infos.");
	} catch (Exception e) {
		Assert.fail("Failed in Edit Licensing Info");
	}
	
	return this;
}

public ProofsPage saveEditProofCode() {
	try {
		clickElement(btnEditSave);
		// ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
		//		By.xpath("//div[contains(text(),'" + PROOFS_EDITED_SUCCESS_MESSAGE + "')]"));
		
		ExtentLogger.pass("Saved Edit Proof Successfully");
	} catch (Exception e) {
		Assert.fail("Unable to Save Edit Proof. " + e.getMessage());
	}
	return this;
}

public ProofsPage editProofItem() {
	
	String styleCode = "Russell Athletic 29HBM", color = "Black";
	
	try {
		
		clickElementJS(iconDownEditProductDetails);
		sleepFor(1000);
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		clickElementJS(txtStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);
		
		clickElement(drpDwnColor);
		clearData(txtColor);
		enterData(txtColor, color);
		clickElementJS(optionColor);
		sleepFor(500);
		
		editImageItem(1);
		
		scrollToElement(txtArt);
		sleepFor(500);
		
		clickElementJS(locDigitalPrint);
		sleepFor(100);
		clickElement(txtArt);
		clearData(txtArt);
		enterData(txtArt, "Edited Data");
		sleepFor(100);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		
		ExtentLogger.pass("Successfully Edited Proof Item.");
		clickElementJS(iconDownEditProductDetails);
		
	} catch (Exception e) {
		Assert.fail("Failed in Edit Proof Item");
	}
	
	return this;
}

public ProofsPage saveLeftPanel() {
	
	try {
		
		clickElement(btnSaveleftPanel);
		sleepFor(100);
		
		ExtentLogger.pass("Successfully Clicked Save Edit Button.");
	} catch (Exception e) {
		Assert.fail("Failed to Click Save Edit Button");
	}
	
	return this;
}

public ProofsPage editFPProofItem() {
	
	String styleCodeFP ="Fresh Prints Bond St Hoodie FP20" , colorFP ="Beige";
	
	try {	
		clickElementJS(iconDownEditFPProduct);
		sleepFor(1000);
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		clickElementJS(txtStyleCode);
		enterData(txtStyleCode, styleCodeFP);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeFP)));
		sleepFor(500);
		
		clickElement(drpDwnColor);
		clearData(txtColor);
		enterData(txtColor, colorFP);
		clickElementJS(optionColor);
		sleepFor(500);
		
		editImageItem(1);
		
		scrollToElement(txtArt);
		sleepFor(500);
		
		clickElementJS(locScreenPrint);
		sleepFor(100);
		clickElement(txtArt);
		clearData(txtArt);
		enterData(txtArt, "Edited Data");
		sleepFor(100);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEFB", styleCodeFP);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORFP", colorFP);
		
		
		ExtentLogger.pass("Successfully Edited FP Proof Item.");
		
		clickElementJS(iconDownEditFPProduct);
		
	} catch (Exception e) {
		Assert.fail("Failed in Edit FP Proof Item");
	}
	
	return this;
	
}

public ProofsPage editAlphaProofItem() {
	
	String styleCodeAlpha ="Gildan G186" , colorAlpha ="Ash";
	
	try {	
		clickElementJS(iconDownEditAlphaProduct);
		sleepFor(1000);
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		clickElementJS(txtStyleCode);
		enterData(txtStyleCode, styleCodeAlpha);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeAlpha)));
		sleepFor(500);
		
		clickElement(drpDwnColor);
		clearData(txtColor);
		enterData(txtColor, colorAlpha);
		clickElementJS(optionColor);
		sleepFor(500);
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEALPHA", styleCodeAlpha);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORALPHA", colorAlpha);
		
		ExtentLogger.pass("Successfully Edited Alpha Proof Item.");
		
		clickElementJS(iconDownEditAlphaProduct);
		
	} catch (Exception e) {
		Assert.fail("Failed in Edit Alpha Proof Item");
	}
	
	return this;
}

public ProofsPage editImageItem(int count) {
	
	String location = "";
	
	try {
		clickElement(btnImageChange);
		sleepFor(3000);
		location = System.getProperty("user.dir");

		for (int i = 1; i <= count; i++) {
			sleepFor(2000);
			chooseAndUploadFile(location + File.separator + "images" + File.separator + "proof" + i + ".png");
			sleepFor(2000);
			if (count - i == 0) {
			//	break;
				System.out.println("No more upload");
			} else {
				clickElement(By.xpath("//label[contains(text(),'Upload More')]"));
				System.out.println(" upload more");
				sleepFor(1000);
			}
		}
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
				By.xpath("//div[contains(@class,'latest-uploaded-image-wrapper ng-star')]"));
		ExtentLogger.pass("Uploaded Reference Image Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed in Edit Image Proof Item");
	}
	
	return this;
}

public ProofsPage verifyAlphaProof() {
	
	String styleCodeAlpha = "" , colorAlpha = "" , collegiateMarks = "", organization = "";
	
	try {
		
		clickElement(selectAlpha);
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		styleCodeAlpha = getData(By.xpath("//div[@class='label apparel-label ng-star-inserted']"));
		colorAlpha = getData(By.xpath("//div[@class='label ng-star-inserted']"));
		collegiateMarks = getData(By.xpath("(//*[@ng-reflect-type='summary'])[1]"));
		organization = getData(By.xpath("(//*[@ng-reflect-type='summary'])[2]"));
		
		softAssert.assertEquals(styleCodeAlpha,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STYLECODEALPHA"),
				"Unexpected Style Code in Proof");
		
		softAssert.assertEquals(colorAlpha,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLORALPHA"),
				"Unexpected Color in Proof");
		
		softAssert.assertEquals(collegiateMarks,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK"),
				"Unexpected Collegiate Marks in Proof");
		
		softAssert.assertEquals(organization,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
				"Unexpected Organization in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Verfied Alpha Proof");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Alpha Proof.  " + e.getMessage());
	}
	
	return this;
	
}

public ProofsPage reFillProofDetails(String type) {
	String clientName = "", proofTitle = "", campaign = "";
	try {

		proofTitle = "Proof " + DataGeneratorUtils.randString();
		campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS");
		enterData(txtProofTitle, proofTitle);

		if (type.equalsIgnoreCase("Existing")) {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");
			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		}

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);

		ExtentLogger.pass("Verfied Editing Proof Details");
		sleepFor(500);
	} catch (Exception e) {
		Assert.fail("Failed in Edit Proof Details. " + e.getMessage());
	}
	return this;
}

public ProofsPage clickBackToProofsDetails() {
	
	
	try {
		
		sleepFor(3000);
		clickElement(btnBackToProofsDetails);
		sleepFor(100);
		
		ExtentLogger.pass("Successfully Clicked BackTo Proofs Details Button");
	} catch (Exception e) {
		Assert.fail("Failed to Click BackTo Proofs Details Button . " + e.getMessage());
	}
	
	return this;
}

public ProofsPage refillProofDetails(String clientType) {

	String proofTitle = "", clientName = "", campaign = "";
	
	try {
		proofTitle = "Proof " + DataGeneratorUtils.randString();
		campaign = InputPropertyUtils.get("EXISTING_CAMPAIGN_FOR_PROOFS_Refill");
		clearData(txtProofTitle);
		enterData(txtProofTitle, proofTitle);

		if (clientType.equalsIgnoreCase("Existing")) {
			clientName = InputPropertyUtils.get("EXISTING_CLIENT_FOR_PROOFS");
			clickElement(drpDwnClientName);
			clearData(txtClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		} else if (clientType.equalsIgnoreCase("New")) {
			clickElement(btnCreateClient);
			sleepFor(1000);
			createClient();
			clientName = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME");

	
			clickElement(drpDwnClientName);
			enterData(txtClientName, clientName);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionClientName, clientName)));
			sleepFor(500);
		}

		clickElement(drpDwnCampaign);
		clearData(txtCampaign);
		enterData(txtCampaign, campaign);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionCampaign, campaign)));
		sleepFor(500);

		clickElementJS(btnProductInfo);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROOFTITLE", proofTitle);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CLIENTNAME", clientName);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CAMPAIGN", campaign);
		ExtentLogger.pass("Re Filled Proof Details Successfully.");

	} catch (Exception e) {
		Assert.fail("Failed in Re Filling Proof Details. " + e.getMessage());
	}
	return this;
}

public ProofsPage clickBackToProductInfo() {
	
	
	try {
		
		sleepFor(3000);
		clickElement(btnBackToProductInfo);
		sleepFor(100);
		
		ExtentLogger.pass("Successfully Clicked BackTo Product Info Button");
	} catch (Exception e) {
		Assert.fail("Failed to Click BackTo Product Info Button . " + e.getMessage());
	}
	
	return this;
}

public ProofsPage RefillProductInfo(String type) {
	String styleCodeExternal = "" , styleCodeFP = "" , styleCodeAlpha = "";
	String colorExternal = "Blue", colorFP = "Beige" ;
	String productName = "Shirts" , productLink = "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html" ;
	try {
		if (type.equalsIgnoreCase("External")) {

			styleCodeExternal = "New Custom Code";

			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			enterData(txtStyleCode, styleCodeExternal);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString("//span[contains(text(),'%s')]", styleCodeExternal)));
			sleepFor(5000);

			enterData(txtCustomColor, "Blue");
			enterData(txtCustomProductName, "Shirts");
			enterData(txtCustomProductLink, "https://www.alphabroder.com/product/2229/code-five-youth-five-star-tee.html");
			
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEEXTERNAL", styleCodeExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOREXTERNAL", colorExternal);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTNAME", productName);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRODUCTLINK", productLink);
			
		} else if (type.equalsIgnoreCase("FP")) {
			styleCodeFP = "Fresh Prints Madison Shorts FP16";
			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			enterData(txtStyleCode, styleCodeFP);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeFP)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEFB", styleCodeFP);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLORFP", colorFP);
			
			if (!findElementPresence(By.xpath("//img[@class='apparel__preview']"))) {
				ExtentLogger.fail("Apparel Previews are not displayed for FP Style Codes");
			}

		} else if (type.equalsIgnoreCase("Alpha")) {
			styleCodeAlpha = "Gildan G800";
			clickElementJS(drpDwnStyleCode);
			clearData(txtStyleCode);
			enterData(txtStyleCode, styleCodeAlpha);
			sleepFor(1000);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCodeAlpha)));
			sleepFor(500);

			clickElement(drpDwnColor);
			clickElementJS(optionColor);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODEALPHA", styleCodeAlpha);
		}
		clickElementJS(btnAddLocAndDesign);

//		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		ExtentLogger.pass("Re Filled Product Info Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Re Filling Product Info. " + e.getMessage());
	}
	return this;
}

public ProofsPage RefillProductInfo() {
	String styleCode = "";
	String color = "Black";
	try {
		styleCode = "Russell Athletic 25843M";
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);

		clickElement(drpDwnColor);
		clickElementJS(optionColor);

		clickElementJS(btnAddLocAndDesign);

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		
		System.out.println("styleCode = "+styleCode);
		System.out.println("color = " +color);
		
		ExtentLogger.pass("Filled Product Info Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Filling Product Info. " + e.getMessage());
	}
	return this;
}

public ProofsPage verifyEditedProofsDetails() {
	
	String proofTitle = "", clientName = "", campaign = "", submittedBy ="";
	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		proofTitle = getAttributeValue(txtProofTi, "value");
		clientName = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[1]"));
		submittedBy = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		campaign = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[3]"));
		
		softAssert.assertEquals(proofTitle,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROOFTITLE"),
				"Unexpected Organization in Proof");
		
		softAssert.assertEquals(clientName,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CLIENTNAME"),
				"Unexpected ClientName in Proof");
		
		softAssert.assertEquals(submittedBy,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUBMITTEDBY"),
				"Unexpected SubmittedBy in Proof");
		
		softAssert.assertEquals(campaign,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CAMPAIGN"),
				"Unexpected Campaign in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Verfied Edited Proofs Details");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Edited Proofs Details.  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage clickManager() {
	
	try {
		
		clickElement(dataManager);
		ExtentLogger.pass("Successfully Clicked Manager");
		
	} catch (Exception e) {
		Assert.fail("Failed to Click Manager .  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage editManagerName() {
	
	String manager = "";
	
	try {
		
		manager = InputPropertyUtils.get("EXISTING_SUBMITTEDBY_FOR_PROOFS");
		enterData(dataManager, manager);
		sleepFor(200);
		clickElement(selectManager);
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
				By.xpath("//div[contains(text(),'" + PROOFS_MANAGERNAME_EDITED_SUCCESS_MESSAGE + "')]"));	
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MANAGER", manager);
		
		ExtentLogger.pass("Successfully Edited Manager Name ");
		
	} catch (Exception e) {
		Assert.fail("Failed to Edit Manager .  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage clickProofNo() {
	
	String proofNo = "121302" ;
	
	try {
		
		enterData(txtSearchProof, proofNo);
		sleepFor(200);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(lnkProofNumber, proofNo)));
		ExtentLogger.pass("Successfully Clicked Proof ");
		
	} catch (Exception e) {
		Assert.fail("Failed to Click Proof .  " + e.getMessage());
	}
	
	return this;
	
}

public ProofsPage verifyManager() {
	
	String manager = "";
	
	try {
		
		sleepFor(1000);
		softAssert = new SoftAssert();
		
		manager = getData(By.xpath("(//span[@class='ng-value-label ng-star-inserted'])[2]"));
		
		softAssert.assertEquals(manager,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MANAGER"),
				"Unexpected Manager in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Verified Manager Name");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Manager Name.  " + e.getMessage());
	}
	
	return this;
}

public ProofsPage filterNewClient() {
	String email = "";
	try {
		email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
		System.out.println("proofName = " + email);
		enterData(txtSearchProof, email);
		ExtentLogger.pass("Filtered " + email + " Client Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Filtering " + email + " Client. " + e.getMessage());
	}
	return this;
}

public ProofsPage navigateToClientPage(String platform) {
	sleepFor(5000);
	try {
		sleepFor(5000);
		if (platform.equalsIgnoreCase("desktop")) {
			System.out.println(DriverManager.getDriver().findElement(lnkClientsNavIcon).getText() + " ***** ");
			clickElement(lnkClientsNavIcon);
			sleepFor(5000);
			System.out.println(DriverManager.getDriver().findElement(titleClients).getText());
			if (!DriverManager.getDriver().findElement(titleClients).isDisplayed()) {
				throw new Exception("Not Navigated to Clients Page");
			}
		} else if (platform.equalsIgnoreCase("mobile")) {
			clickElement(iconHamburger);
			sleepFor(5000);
			clickElement(lnkClientsNavIcon);
			sleepFor(5000);
			if (!DriverManager.getDriver().findElement(titleClientsMobile).isDisplayed()) {
				throw new Exception("Not Navigated to Clients Page");
			}
		}

		ExtentLogger.pass("Navigated to Clients Page");

	} catch (Exception e) {
		Assert.fail("Unable to Navigate to Clients Page. " + e.getMessage());
	}
	return this;
}


public ProofsPage hoverAndSelectOption(UserOperation userOperation) {
	try {
		String email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
		String fname = getData(By.xpath("(//div[@class='data-table__cell'])[1]"));

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "IMPERSONATEFULLNAME", fname);
		sleepFor(1000);
		hoverOver(By.xpath("//span[contains(text(),'" + email + "')]"));
		if (userOperation.equals(UserOperation.DELETE)) {
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserDeleteIcon, email)));
			ExtentLogger.pass("Hovered over the Record and Clicked Delete Icon");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Delete");
		} 
		

	} catch (Exception e) {
		Assert.fail("Unable to Hover and Select " + userOperation.toString() + ". " + e.getMessage());
	}

	return this;
}

public ProofsPage enterConfirmation() {
	try {
	
		clickElement(btnClientDelete);
		ExtentLogger.pass("Clicked Delete Button in the Confirmation Dialog");

	} catch (Exception e) {
		Assert.fail("Unable to provide Confirmation. " + e.getMessage());
	}

	return this;
}

public ProofsPage verifySuccessMessage() {
	String toastrLocator = null;
	try {
		 
			toastrLocator = "//div[contains(text(),'" + DELETION_MESSAGE + "')]";
		

		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath(toastrLocator));
		sleepFor(500);

		ExtentLogger.pass("Verified the Success Toastr Message");
	} catch (Exception e) {
		Assert.fail("Unable to Verify Success Message. " + e.getMessage());
	}
	return this;
}


public ProofsPage leftPanelProductInfoandlicensingInfoValidations() {
	String styleCode = "Russell Athletic 29HBM", color = "Black";
	String collegiateMark = "", organization = "";
	try {
		
		clickElementJS(iconDownEditProductDetails);
		sleepFor(1000);
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		clickElementJS(txtStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);		
		scrollToElement(txtArt);
		sleepFor(500);
		clickElement(txtArt);
		clearData(txtArt);
		sleepFor(100);
		clickElementJS(drpdwnleftpanelCollegiateMark);
		clearData(txtleftpanelCollegiateMark);
		sleepFor(100);
		clickElementJS(drpdwnleftpanelOrganization);
		clearData(txtleftpanelOrganization);
		sleepFor(100);
		
		if (!findElementPresence(btnSaveNotEnable)) {
			throw new Exception("Save Edit Button is Enable in Left Panel");
		}
		else {
			
			ExtentLogger.pass("Save Edit Button is Not Enable in Left Panel");
			System.out.println("Save Edit Button is Not Enable in Left Panel");
		}		

		clickElementJS(iconDownEditProductDetails);
		sleepFor(200);
		clickElementJS(iconDownEditProductDetails);
		sleepFor(1000);
		clickElementJS(drpDwnStyleCode);
		clearData(txtStyleCode);
		clickElementJS(txtStyleCode);
		enterData(txtStyleCode, styleCode);
		clickElement(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));
		sleepFor(500);
		
		clickElement(drpDwnColor);
		clearData(txtColor);
		enterData(txtColor, color);
		clickElementJS(optionColor);
		sleepFor(500);
		
		scrollToElement(txtArt);
		sleepFor(500);
		
		clickElement(txtArt);
		clearData(txtArt);
		enterData(txtArt, "Edited Data");
		sleepFor(100);
		
		collegiateMark = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COLLEGIATEMARK");
		organization = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION");
		
		clickElementJS(drpdwnleftpanelCollegiateMark);
		clearData(txtleftpanelCollegiateMark);
		enterData(txtleftpanelCollegiateMark, collegiateMark);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionleftpanelCollegiateMark, collegiateMark)));
		sleepFor(200);
		clickElementJS(drpdwnleftpanelOrganization);
		clearData(txtleftpanelOrganization);
		enterData(txtleftpanelOrganization, organization);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionleftpanelOrganization, organization)));
		
		
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLOR", color);
		
		clickElementJS(iconDownEditProductDetails);
		
		ExtentLogger.pass("Verified Save Button Product Info Page Left Panel");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Save Button Product Info Page Left Panel. " + e.getMessage());
	}
	
	return this;
}

public ProofsPage createClientWithNotStudent() {
	try {
		HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();
		HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();
		HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();

		enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", contactDetailsMap.get("FULLNAME"));

		enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
				contactDetailsMap.get("PHONENUMBER"));

		clickElementJS(btnSetEmailAndPassword);

		enterData(txtemail, passwordDetailsMap.get("EMAIL"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));

		enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
		enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
				passwordDetailsMap.get("PASSWORD"));

		clickElementJS(btnAddInfo);
		
		clickElementJS(chkBoxClientTye);

		enterData(txtBusiness, schoolDetailsMap.get("BUSINESS"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BUSINESS",
				schoolDetailsMap.get("BUSINESS"));

		enterData(txtTitle, schoolDetailsMap.get("TITLE"));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TITLE", schoolDetailsMap.get("TITLE"));

		clickElementJS(btnCreateAccount);
		sleepFor(200);
		clickElementJS(btnBackToWork);
		sleepFor(1000);
		ExtentLogger.pass("Created Client for Proof Successfully");
	} catch (Exception e) {
		Assert.fail("Failed in Creating Client for Proof. " + e.getMessage());
	}
	return this;
}

public ProofsPage saveEdit() {
	try {
		clickElement(btnEditSave);
		ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
				By.xpath("//div[contains(text(),'" + PROOFS_STYLECODE_CHANGE_MESSAGE + "')]"));

		ExtentLogger.pass("Saved Edit Proof Successfully");
	} catch (Exception e) {
		Assert.fail("Unable to Save Edit Proof. " + e.getMessage());
	}
	return this;
}

public ProofsPage deleteLocation() {
	
	try {
		
		clickElementJS(btnDeleteLocation);
		sleepFor(200);
		
		ExtentLogger.pass("Deleted Proof Location Successfully");
		
	} catch (Exception e) {
		Assert.fail("Unable to Delete Proof Location . " + e.getMessage());
	}
	
	
	return this;
}

public ProofsPage saveProofLocation() {
	try {
		clickElement(btnEditSave);
		sleepFor(500);
		ExtentLogger.pass("Saved Edit Proof Successfully");
	} catch (Exception e) {
		Assert.fail("Unable to Save Edit Proof. " + e.getMessage());
	}
	return this;
}

public ProofsPage verifyLocation() {
	
	try {
		
		if (findElementPresence(btnlocation2)) {
			throw new Exception("Location 2 is Not Deleted");
		}
		else {
			
			ExtentLogger.pass("Location 2 is Deleted Successfully ");
		}
		
		
		ExtentLogger.pass("Verified Location Successfully");
		
	} catch (Exception e) {
		Assert.fail("Failed to Verify Location .  " + e.getMessage());
	}
	
	return this;
}



}	