package pages;

import static appConstants.ApplicationConstants.*;
import org.openqa.selenium.JavascriptExecutor;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;

import org.apache.commons.math3.util.Precision;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.UserType;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.QuotersPageElements;
import reports.ExtentLogger;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class QuotersPage extends MasterPage implements QuotersPageElements {
	String garment= "";

	public QuotersPage enterStyleCodeInfo(String type ,String GarmentType) {
		String styleCode = "", quantity = "" ;
		try {

			quantity = String.valueOf(ThreadLocalRandom.current().nextInt(2, 50));

			if (type.equalsIgnoreCase("alpha")) {
				styleCode = InputPropertyUtils.get("TYPE1_ALPHA_STYLECODE");
			} else if (type.equalsIgnoreCase("otherapparels")) {
				styleCode = InputPropertyUtils.get("TYPE4_OTHERAPPAREL_STYLECODE");
			} else if (type.equalsIgnoreCase("fp")) {
				styleCode = InputPropertyUtils.get("TYPE4_FP_STYLECODE");
			}

			
			
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));

			clickElement(drpDwnColorCode);
			Thread.sleep(4000);
			
			
			By txtColorCode = By.xpath("//app-select[@ng-reflect-name='color']//ng-select//input");		
			if(GarmentType.equalsIgnoreCase("White")) {
				 garment = GarmentType;

				
				enterData(txtColorCode, "White");
				
				Thread.sleep(2000);

				 clickElementJS(optionColorCode);

					Thread.sleep(2000);

				
		 
				
				 

			    
				
			}
			
		
			else {
				garment = "NonWhite";
				
				 System.out.println("Garment is " +garment +" so clicking any one of the garment color");
					clickElementJS(optionColorCode);


			}
			



			enterData(txtQuantity, quantity);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "APPARELTYPE", "Style Code");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TYPE", type);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STYLECODE", styleCode);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "QUANTITY", quantity);

			ExtentLogger.pass("Entered Style Code Apparel Information Successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed in Entering Style Code. " + e.getMessage());
		}
		return this;
	}

	// The changes that we are making is for white garment so toggle button will be on and prices of the garment will be changed
	public QuotersPage enterBlankPriceInfoWhite(String garmentType) {
		String blankPrice = "", quantity = "";
		try {

				
			blankPrice = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
			quantity = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));

			clickElementJS(lnkEnterBlankPrice);
			enterData(txtBlankPrice, blankPrice);
			
			if (garmentType.equalsIgnoreCase("white")) {
			clickElementJS(toggleWhiteGarment);
			garment =garmentType;
			}
			else
			{
				System.out.println("Toggle button is not selected so we are by default going for non- white garment");
			}
			
			enterData(txtQuantity, quantity);
				

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "APPARELTYPE", "Blank Price");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BLANKPRICE", blankPrice);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "QUANTITY", quantity);

			ExtentLogger.pass("Entered Blank Price Apparel Information Successfully for white garment.");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Style Code. " + e.getMessage());
		}
		return this;
	}

	// The changes that we are making is for Non - white garment so toggle button will be on and prices of the garment will be changed

	public QuotersPage enterBlankPriceInfoNonWhite(String garment) {
		String blankPrice = "", quantity = "";
		try {
					
			blankPrice = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));
			quantity = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));

			clickElementJS(lnkEnterBlankPrice);
			enterData(txtBlankPrice, blankPrice);
			
			if (garment.equalsIgnoreCase("nonwhite")) {
				System.out.println("Toggle button is not selected so we are going for non- white garment/ check the calc for non white");

			
			}

			enterData(txtQuantity, quantity);
			

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "APPARELTYPE", "Blank Price");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BLANKPRICE", blankPrice);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "QUANTITY", quantity);

			ExtentLogger.pass("Entered Blank Price Apparel Information Successfully for Non - white garment");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Style Code. " + e.getMessage());
		}
		return this;
	}

	
	
	
	
	
	
	
	
	
	
	
/* added by vidya */
	
	public QuotersPage enterBlankPriceDecimalInfo() {
		String blankPrice ="";
		String quantity = "";
		try {

		    DecimalFormat df =new DecimalFormat();
		    df.setMaximumFractionDigits(2);
			

		//	blankPrice = String.valueOf(ThreadLocalRandom.current().nextFloat(2.0f, 20.0f));
		//	blankPrice = String.valueOf (df.format(ThreadLocalRandom.current().nextFloat(2.0f, 20.0f)));
		    blankPrice = String.valueOf (ThreadLocalRandom.current().nextDouble(2.0f, 20.0f));
		
			quantity = String.valueOf(ThreadLocalRandom.current().nextInt(2, 20));

			clickElementJS(lnkEnterBlankPrice);
			enterData(txtBlankPrice, blankPrice);
			clickElementJS(toggleWhiteGarment);
			enterData(txtQuantity, quantity);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "APPARELTYPE", "Blank Price");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BLANKPRICE", blankPrice);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "QUANTITY", quantity);

			ExtentLogger.pass("Entered Blank Price Apparel Information Successfully.");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Style Code. " + e.getMessage());
		}
		return this;
	}
	
	public QuotersPage selectApparelType(String apparelType) {
		try {
			if (apparelType.equalsIgnoreCase("stylecode")) {
				clickElementJS(lnkEnterStyleCode);
			} else if (apparelType.equalsIgnoreCase("blankprice")) {
				clickElementJS(lnkEnterBlankPrice);
			}
			ExtentLogger.pass("Selected " + apparelType + " Apparel Link");
		} catch (Exception e) {
			Assert.fail("Failed in Switching to " + apparelType + ". " + e.getMessage());
		}
		return this;
	}

	public QuotersPage enterLicensedMarks() {
		String collegiateMarks = "", greekRoyalties = "";
		try {
			collegiateMarks = "Yes";
			greekRoyalties = "Yes";

			if (collegiateMarks.equalsIgnoreCase("yes")) {
				scrollToElement(collegiateMarkYes);
				clickElementJS(collegiateMarkYes);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARKS", "Yes");
			} else if (collegiateMarks.equalsIgnoreCase("no")) {
				scrollToElement(collegiateMarkNo);
				clickElementJS(collegiateMarkNo);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEMARKS", "No");
			}

			if (greekRoyalties.equalsIgnoreCase("yes")) {
				scrollToElement(greekMarkYes);
				clickElementJS(greekMarkYes);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GREEKROYALTIES", "Yes");
			} else if (greekRoyalties.equalsIgnoreCase("no")) {
				scrollToElement(greekMarkNo);
				clickElementJS(greekMarkNo);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GREEKROYALTIES", "No");
			}
			ExtentLogger.pass("Entered Licensed Marks Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Enter Licensed Marks. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage enterPrintLocations(String locationCount) {
		int count = 3;
		try {
			if (locationCount.equalsIgnoreCase("multiple")) {
				for (int i = 0; i < count; i++)
					clickElement(btnAddPrintLocation);

				clickElementJS(By.xpath(
						"(//label[contains(text(),'# of Colors')]//following::app-button[@class='change-bg']/button)[1]"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC1", "Yes");

				clickElement(By.xpath("(//app-select[@ng-reflect-name='type']//ng-select)[2]"));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(
						"(//span[contains(@class,'ng-option-label') and contains(text(),'%s')])", "Digital Print")));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC2", "Yes");

				clickElement(By.xpath("(//app-select[@ng-reflect-name='type']//ng-select)[3]"));
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(
						"(//span[contains(@class,'ng-option-label') and contains(text(),'%s')])", "Embroidery")));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC3", "Yes");

				clickElement(By.xpath("(//app-select[@ng-reflect-name='type']//ng-select)[4]"));
				sleepFor(500);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(
						"(//span[contains(@class,'ng-option-label') and contains(text(),'%s')])", "Gold/Silver Foil")));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC4", "Yes");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ALLTYPES", "Yes");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRINTINGTYPE", "All");

			}
			ExtentLogger.pass("Entered Print Locations Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Enter Print Locations Information. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage enterPrintLocations(String type, String property) {
		int count = 1;
		try {
			switch (type.toLowerCase()) {
			case "screen print":
				count = Integer.parseInt(property);

				for (int i = 1; i <= count; i++)
					clickElementJS(btnAddNumberOfColors);
				break;

			case "digital print":
				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE"))) {
					clickElement(drpdwnPrintType);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionPrintType, type)));
				}

				clickElement(drpdwnPrintSubType);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionPrintSubType, property)));
				break;

			case "embroidery":
				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE"))) {
					clickElement(drpdwnPrintType);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionPrintType, type)));
				}

				clickElement(drpdwnPrintSubType);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionPrintSubType, property)));
				break;

			case "gold/silver foil":
				clickElement(drpdwnPrintType);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionPrintType, type)));
				break;

			default:
				throw new Exception("Unsupported Printing Type " + type);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRINTINGTYPE", type);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRINTINGSUBTYPE", property);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC1", "Yes");
			ExtentLogger.pass("Entered Print Locations Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Enter Print Locations Information. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage toggleAddOns() {

		try {
			String dueIn = DataGeneratorUtils.randShippingDateAddOns();
			scrollToElement(toggleCustomName);
			clickElementJS(toggleCustomName);
			if (getAttributeValue(toggleCustomName, "value").equalsIgnoreCase("true"))
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNAME", "Yes");
			else
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNAME", "No");

			scrollToElement(toggleCustomNumber);
			clickElementJS(toggleCustomNumber);
			if (getAttributeValue(toggleCustomNumber, "value").equalsIgnoreCase("true"))
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNUMBER", "Yes");
			else
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNUMBER", "No");

			if (dueIn.equalsIgnoreCase("7to10")) {
				scrollToElement(toggleCustomDue7to10);
				clickElementJS(toggleCustomDue7to10);
				if (getAttributeValue(toggleCustomDue7to10, "value").equalsIgnoreCase("true"))
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DUEIN", "7to10");

			} else if (dueIn.equalsIgnoreCase("11to13")) {
				scrollToElement(toggleCustomDue11to13);
				clickElementJS(toggleCustomDue11to13);
				if (getAttributeValue(toggleCustomDue11to13, "value").equalsIgnoreCase("true"))
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "DUEIN", "11to13");

			}
			if (getAttributeValue(toggleCustomDue11to13, "value").equalsIgnoreCase("true")
					|| getAttributeValue(toggleCustomDue7to10, "value").equalsIgnoreCase("true"))
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "RUSHSHIPPING", "Yes");
			else
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "RUSHSHIPPING", "No");

			scrollToElement(toggleIndividualShipping);
			clickElementJS(toggleIndividualShipping);
			if (getAttributeValue(toggleIndividualShipping, "value").equalsIgnoreCase("true"))
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INDIVIDUALSHIPPING", "Yes");
			else
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INDIVIDUALSHIPPING", "No");

			ExtentLogger.pass("Selected AddOns Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Select AddOns. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage verifyPrices(UserType userType) {
		String perUnitValue = "", totalPriceValue = "", gpmValue = "";
		String apparel = "", greekRoyalties = "", collegiateRoyalties = "", commission = "", loc1Printing = "",
				shipping = "", misc = "", chargedPrice = "", revenue = "", cost = "", profit = "", gpm = "";
		String customNames = "", customNumbers = "", rushShipping = "", individualShipping = "", loc2Printing = "",
				loc3Printing = "", loc4Printing = "";
		try {
			sleepFor(4000);
			softAssert = new SoftAssert();
			apparel = "input[ng-reflect-name='apparelPrice']";
			greekRoyalties = "input[ng-reflect-name='greekRoyalties']";
			collegiateRoyalties = "input[ng-reflect-name='collegiateRoyalties']";
			commission = "input[ng-reflect-name='commission']";
			loc1Printing = "input[ng-reflect-name='location1printing']";
			shipping = "input[ng-reflect-name='shipping']";

			loc2Printing = "input[ng-reflect-name='location2printing']";
			loc3Printing = "input[ng-reflect-name='location3printing']";
			loc4Printing = "input[ng-reflect-name='location4printing']";
			individualShipping = "input[ng-reflect-name='individualShipping']";
			rushShipping = "input[ng-reflect-name='rushShipping']";
			customNames = "input[ng-reflect-name='customNames']";
			customNumbers = "input[ng-reflect-name='customNumbers']";

			misc = "input[ng-reflect-name='miscellaneous']";
			chargedPrice = "input[ng-reflect-name='chargedPrice']";
			revenue = "input[ng-reflect-name='revenue']";
			cost = "input[ng-reflect-name='cost']";
			profit = "input[ng-reflect-name='profit']";
			gpm = "input[ng-reflect-name='gpm']";

			if (userType.equals(UserType.ADMIN)) {

				ExtentLogger.log("Apparel: " + readDataUsingJavascriptExecutorFromCSSLocator(apparel).replace(",", ""));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "APPARELVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(apparel).replace(",", ""));

				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ADJUSTMENTS"))
						&& Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE")
							.equalsIgnoreCase("otherapparels")) {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(apparel).replace(",", ""), "2.21",
								"Unexpected Apparel Price Value For Other Apparel");
					} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE")
							.equalsIgnoreCase("fp")) {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(apparel).replace(",", ""), "6.90",
								"Unexpected Apparel Price Value for FP");
					}
				}

				if (isFeatureAdded("LOC1")) {
					ExtentLogger.log("Loc1 Printing: " + readDataUsingJavascriptExecutorFromCSSLocator(loc1Printing).replace(",", ""));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC1PRINTINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(loc1Printing).replace(",", ""));
				}

				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ALLTYPES"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
							.equalsIgnoreCase("gold/silver foil")) {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(loc1Printing), "2.00",
								"Unexpected Location1 Printing Value");
					} else if (!RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
							.equalsIgnoreCase("screen print")) {
						softAssert.assertEquals(
								Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(loc1Printing)),
								getPrintingPrice(), "Unexpected Location1 Printing Value");
					}
				}

				if (isFeatureAdded("LOC2")) {
					ExtentLogger.log("Loc2 Printing: " + readDataUsingJavascriptExecutorFromCSSLocator(loc2Printing));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC2PRINTINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(loc2Printing));
				}

				if (isFeatureAdded("LOC3")) {
					ExtentLogger.log("Loc3 Printing: " + readDataUsingJavascriptExecutorFromCSSLocator(loc3Printing));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC3PRINTINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(loc3Printing));
				}

				if (isFeatureAdded("LOC4")) {
					ExtentLogger.log("Loc4 Printing: " + readDataUsingJavascriptExecutorFromCSSLocator(loc4Printing));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOC4PRINTINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(loc4Printing));
				}

				ExtentLogger.log("Shipping: " + readDataUsingJavascriptExecutorFromCSSLocator(shipping));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPINGVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(shipping));

				if (isFeatureAdded("INDIVIDUALSHIPPING")) {
					ExtentLogger.log("Individual Shipping: "
							+ readDataUsingJavascriptExecutorFromCSSLocator(individualShipping));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "INDIVIDUALSHIPPINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(individualShipping));

					if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE")))
					{
						if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE")
								.equalsIgnoreCase("alpha")) {
							softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(individualShipping),
									"8.00", "Unexpected Individual Shipping Value");
						} else {
							softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(individualShipping),
									"5.00", "Unexpected Individual Shipping Value");
						}
					} else
					{
						/* added & changed  by vidya*/
						
						Object Str =RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BLANKPRICE");
						System.out.println(((Object)Str).getClass().getSimpleName());
						System.out.println(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BLANKPRICE"));
						//((Object)BLANKPRICE).getClass().getSimpleName());
						
						//if (Integer.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BLANKPRICE")) < 8)
						
						/* changed datatpye from int to double - by vidya */
						
						//chamge blankprice from 8 to 7.50 by kirty as asked by niraj
						
						if (Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BLANKPRICE")) < 7.50)	
						{
							softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(individualShipping),
									"5.00", "Unexpected Individual Shipping Value");
						} else {
							softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(individualShipping),
									"8.00", "Unexpected Individual Shipping Value");
						}
					}
				}

				if (isFeatureAdded("CUSTOMNAME")) {
					ExtentLogger.log("Custom Names: " + readDataUsingJavascriptExecutorFromCSSLocator(customNames));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNAMEVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(customNames));

					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
							.equalsIgnoreCase("embroidery")
							|| RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
									.equalsIgnoreCase("all")) {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(customNames), "7.00",
								"Unexpected Custom Names Value");
					} else {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(customNames), "3.00",
								"Unexpected Custom Names Value");
					}
				}

				if (isFeatureAdded("CUSTOMNUMBER")) {
					ExtentLogger.log("Custom Number: " + readDataUsingJavascriptExecutorFromCSSLocator(customNumbers));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CUSTOMNUMBERVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(customNumbers));

					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
							.equalsIgnoreCase("embroidery")
							|| RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE")
									.equalsIgnoreCase("all")) {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(customNumbers), "7.00",
								"Unexpected Custom Number Value");
					} else {
						softAssert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(customNumbers), "3.00",
								"Unexpected Custom Number Value");
					}
				}

				ExtentLogger.log("Miscellaneous: " + readDataUsingJavascriptExecutorFromCSSLocator(misc));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "MISCELLANEOUSVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(misc));
				softAssert.assertEquals(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(misc)),
						getMiscsPrice(Integer
								.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"))),
						" Unexpected Miscellaneous Price");

				if (isFeatureAdded("RUSHSHIPPING")) {
					ExtentLogger.log("Rush Shipping: " + readDataUsingJavascriptExecutorFromCSSLocator(rushShipping));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "RUSHSHIPPINGVALUE",
							readDataUsingJavascriptExecutorFromCSSLocator(rushShipping));
					softAssert.assertEquals(
							Precision.round(
									Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(rushShipping)), 0),
							Precision.round(getFees(), 0), " Unexpected Rush Shipping Price");
				}

				ExtentLogger.log("Commission: " + readDataUsingJavascriptExecutorFromCSSLocator(commission));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COMMISSIONVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(commission));

				if ((Precision.round(getCommissionCost(),
						0) < Precision.round(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(commission)), 0) - 1)
						|| (Precision.round(getCommissionCost(), 0) > Precision
								.round(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(commission)), 0)
								+ 1)) {
					
					Double scDouble = getCommissionCost();
					System.out.println(scDouble+"kirty value");
					
					softAssert.fail("Unexpected Commission Charges");
				}

				ExtentLogger.log("Greek Royalties: " + readDataUsingJavascriptExecutorFromCSSLocator(greekRoyalties));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GREEKROYALTIESVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(greekRoyalties));

				if ((Precision.round(getCharges("Greek Royalties"),
						0) < Precision.round(
								Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(greekRoyalties)), 0)
								- 1)
						|| (Precision.round(getCharges("Greek Royalties"), 0) > Precision.round(
								Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(greekRoyalties)), 0)
								+ 1)) {
					softAssert.fail("Unexpected Greek Royalties");
				}

				ExtentLogger.log(
						"Collegiate Royalties: " + readDataUsingJavascriptExecutorFromCSSLocator(collegiateRoyalties));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COLLEGIATEROYALTIESVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(collegiateRoyalties));

				if ((Precision.round(getCharges("Collegiate Royalties"), 0) < Precision.round(
						Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(collegiateRoyalties)), 0) - 1)
						|| (Precision.round(getCharges("Collegiate Royalties"),
								0) > Precision
										.round(Double.parseDouble(
												readDataUsingJavascriptExecutorFromCSSLocator(collegiateRoyalties)), 0)
										+ 1)) {
					softAssert.fail("Unexpected Collegiate Royalties");
				}

				ExtentLogger.log("Charged Price: " + readDataUsingJavascriptExecutorFromCSSLocator(chargedPrice).replace(",", ""));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CHARGEDPRICEVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(chargedPrice).replace(",", ""));
				System.out.println("Charged Price Calc: " + getCharges("Charged Price"));

				if ((Precision.round(getCharges("Charged Price"),
						0) < Precision.round(
								Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(chargedPrice).replace(",", "")), 0) - 3)
						|| (Precision.round(getCharges("Charged Price"), 0) > Precision.round(
								Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(chargedPrice).replace(",", "")), 0)
								+ 3)) {
					throw new Exception("Unexpected Charge Price");
				}

				// Revenue=ChargedPrice * quantity
				ExtentLogger.log("Revenue: " + readDataUsingJavascriptExecutorFromCSSLocator(revenue).replace(",", ""));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "REVENUEVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(revenue).replace(",", ""));
				double revValue = Double.parseDouble(
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CHARGEDPRICEVALUE"))
						* Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"));
				revValue = Precision.round(revValue, 2);
				softAssert.assertEquals(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(revenue).replace(",", "")),
						revValue, "Unexpected Revenue Value");

				ExtentLogger.log("Cost: " + readDataUsingJavascriptExecutorFromCSSLocator(cost).replace(",", ""));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COSTVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(cost).replace(",", ""));
				getCharges("cost");

				// profit=revenue-cost
				ExtentLogger.log("Profit: " + readDataUsingJavascriptExecutorFromCSSLocator(profit).replace(",", ""));
				double profitVal = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "REVENUEVALUE"))
						- Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COSTVALUE"));
				profitVal = Precision.round(profitVal, 2);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PROFITVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(profit).replace(",", ""));
				softAssert.assertEquals(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(profit).replace(",", "")),
						profitVal, "Unexpected Profit Value");

				// gpm=profit/revenue
				double gpmVal = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PROFITVALUE"))
						/ Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "REVENUEVALUE"));
				gpmVal = Precision.round(Precision.round(gpmVal, 4) * 100, 2);
				ExtentLogger.log("GPM: " + readDataUsingJavascriptExecutorFromCSSLocator(gpm).replace(",", ""));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GPMVALUE",
						readDataUsingJavascriptExecutorFromCSSLocator(gpm));
				softAssert.assertEquals(Double.parseDouble(readDataUsingJavascriptExecutorFromCSSLocator(gpm).replace(",", "")), gpmVal,
						"Unexpected GPM Value");

				perUnitValue = getData(divPerUnitCost);
				softAssert.assertNotEquals(Double.parseDouble(perUnitValue.substring(1)), 0,
						"Per Unit Cost is not displayed Correctly");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PERUNITVALUE", perUnitValue);

				totalPriceValue = getData(divTotalPrice).replace(",", "");
				softAssert.assertNotEquals(Double.parseDouble(totalPriceValue.substring(1)), 0,
						"Total Price is not displayed Correctly");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALPRICEVALUE", totalPriceValue);

				gpmValue = getData(divGPMPercentage).replace(",", "");
				softAssert.assertNotEquals(Double.parseDouble(gpmValue.substring(0, gpmValue.length() - 1)), 0,
						"GPM Percentage is not displayed Correctly");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GPMVALUE", gpmValue);
			} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
				perUnitValue = getData(divPerUnitCost).replace(",", "");
				Assert.assertNotEquals(Double.parseDouble(perUnitValue.substring(1)), 0.00,
						"Per Unit Cost is not displayed Correctly");

				totalPriceValue = getData(divTotalPrice).replace(",", "");
				Assert.assertNotEquals(Double.parseDouble(totalPriceValue.substring(1)), 0.00,
						"Total Price is not displayed Correctly");

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PERUNITVALUE", perUnitValue);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALPRICEVALUE", totalPriceValue);
			}
			softAssert.assertAll();
			sleepFor(1000);
			ExtentLogger.pass("Verified Prices for Quote Request.");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Prices. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage verifyPrices(String isDisplayed) {
		String perUnitValue = "", totalPriceValue = "";
		try {
			sleepFor(4000);

			if (isDisplayed.equalsIgnoreCase("displayed")) {
				perUnitValue = getData(divPerUnitCost).replace(",", "");
				Assert.assertNotEquals(Double.parseDouble(perUnitValue.substring(1)), 0.00,
						"Per Unit Cost is not displayed Correctly");

				totalPriceValue = getData(divTotalPrice).replace(",", "");
				Assert.assertNotEquals(Double.parseDouble(totalPriceValue.substring(1)), 0.00,
						"Total Price is not displayed Correctly");
			} else {
				perUnitValue = getData(divPerUnitCost).replace(",", "");
				Assert.assertEquals(Double.parseDouble(perUnitValue.substring(1)), 0.00,
						"Per Unit Cost is not as Expected");

				totalPriceValue = getData(divTotalPrice).replace(",", "");
				Assert.assertEquals(Double.parseDouble(totalPriceValue.substring(1)), 0.00,
						"Total Price is not as Expected");
			}
			ExtentLogger.pass("Verified that Prices are " + isDisplayed);
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Prices whether it is displayed or not. " + e.getMessage());
		}
		return this;
	}

	public QuotersPage verifyThumbNails() {
		try {
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE").equalsIgnoreCase("alpha")) {
				if (findElementPresence(imgApparelThumbnail)) {
					if (DriverManager.getDriver().findElement(imgApparelThumbnail).getAttribute("src")
							.equalsIgnoreCase("")) {
						Assert.fail("Apparel Images are Broken");
					}
					hoverOver(imgApparelThumbnail);

					List<WebElement> previews = DriverManager.getDriver().findElements(imgApparelPreviews);

					for (int i = 0; i < previews.size(); i++) {
						if (previews.get(i).getAttribute("src").equalsIgnoreCase("")) {
							Assert.fail("Apparel Preview Images are Broken");
							break;
						}
					}
				} else {
					ExtentLogger.fail("Apparel Thumbnails are not displayed for Type1 Apparels.");
				}
			}

			ExtentLogger.pass("Successfully Verified Thumbnails and its Previews.");
		} catch (Exception e) {
			Assert.fail("Failed During Verification of Thumbnails. " + e.getMessage());
		}
		return this;
	}

	public QuotersPage applyAdjustmentsAndVerifyPrices(UserType userType) {

		try {
			enterData(txtApparel, "25");
			sleepFor(1000);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ADJUSTMENTS", "Yes");

			verifyPrices(userType);

			ExtentLogger.pass("Applied Adjustments and Verified Prices Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Apply Adjustments and Verify Prices. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage verifyValidationMessage() {

		try {
			sleepFor(2000);
			clickElementJS(btnAddNumberOfColors);

			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + QUOTERS_APPARELINFO_REQUIRED_MESSAGE + "')]"));

			Assert.assertTrue(checkCondition(
					By.xpath(
							"//label[contains(text(),'Style Code')]//following-sibling::div[contains(@class,'error')]"),
					ElementCheckStrategy.DISPLAYED), "Validation is not Displayed for Style Code.");

			Assert.assertTrue(checkCondition(
					By.xpath(
							"//label[contains(text(),'Color Code')]//following-sibling::div[contains(@class,'error')]"),
					ElementCheckStrategy.DISPLAYED), "Validation is not Displayed for Color Code.");

			Assert.assertTrue(checkCondition(
					By.xpath("//label[contains(text(),'Quantity')]//following-sibling::div[contains(@class,'error')]"),
					ElementCheckStrategy.DISPLAYED), "Validation is not Displayed for Color Code.");

			Assert.assertTrue(checkCondition(
					By.xpath(
							"//label[contains(text(),'Color Code')]//following-sibling::div[contains(@class,'error')]"),
					ElementCheckStrategy.DISPLAYED), "Validation is not Displayed for Color Code.");

			Assert.assertTrue(checkCondition(
					By.xpath(
							"//p[contains(text(),'Licensed Marks')]//following-sibling::div[contains(@class,'error')]"),
					ElementCheckStrategy.DISPLAYED), "Validation is not Displayed for Color Code.");

			ExtentLogger.pass("Verified Validation Messages Successfully.");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Validation Messages. " + e.getMessage());
		}

		return this;
	}

	public QuotersPage verifyInvalidStyleCode() {
		
		
		try {
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, DataGeneratorUtils.randString());

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + QUOTERS_INVALIDSTYLECODE_MESSAGE + "')]"))) {
				throw new Exception("Invalid Style Code Message is not displayed");
			}
			ExtentLogger.pass("Verified Validation for Invalid Style Code");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Invalid Style Code. " + e.getMessage());
		}
		return this;
	}

	public QuotersPage deletePrintLocations() {
		int count = 3;
		try {
			for (int i = 0; i < count; i++)
				clickElement(btnAddPrintLocation);

			for (int i = 0; i < count; i++) {
				clickElementJS(By.xpath("(//img[contains(@src,'delete')]//parent::button)[1]"));
				sleepFor(1000);
			}
			Assert.assertEquals(findElementPresence(By.xpath("//img[contains(@src,'delete')]//parent::button")), false,
					"Print Locations are not deleted.");

			ExtentLogger.pass("Verified Adding and Deleting Print Locations");
		} catch (Exception e) {
			Assert.fail("Failed in Deleting Print Locations. " + e.getMessage());
		}
		return this;
	}

	public double getMiscsPrice(int quantity) {
		if (quantity <= 6)
			return 3;
		else if (quantity <= 11 && quantity > 6)
			return 2.5;
		else if (quantity < 24 && quantity > 11)
			return 2;
		else if (quantity <= 48 && quantity > 24)
			return 1.75;
		else if (quantity <= 100 && quantity > 48)
			return 1.5;
		else if (quantity <= 250 && quantity > 100)
			return 1.4;
		else
			return 1.25;
	}

	public double getPrintingPrice() throws Exception {
		String printingType = "", subType = "";
		double quantity = 0;
		try {
			printingType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGTYPE");
			subType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRINTINGSUBTYPE");
			quantity = Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"));

			switch (printingType.toLowerCase().trim()) {
			case "digital print":
				if (subType.equalsIgnoreCase("pocket area")) {
					
					
					if(garment.equalsIgnoreCase("white")) {
						
						
					if (quantity >= 1 && quantity <= 5)
						return 6.00;
					else if (quantity >= 6 && quantity <= 23)
						return 3.75;
					else if (quantity >= 24 && quantity <= 47)
						return 2.75;
					else if (quantity >= 48 && quantity <= 143)
						return 2.50;
					else if (quantity >= 144 && quantity <= 499)
						return 2.25;
					else
						return 2.00;
					}
					
					else {
						
						
						
						if (quantity >= 1 && quantity <= 5)
							return 6.50;
						else if (quantity >= 6 && quantity <= 23)
							return 4.25;
						else if (quantity >= 24 && quantity <= 47)
							return 3.50;
						else if (quantity >= 48 && quantity <= 143)
							return 3.25;
						else if (quantity >= 144 && quantity <= 499)
							return 3.00;
						else
							return 2.75;
						}
						
				
						
						
						
						
						
						
				} else if (subType.equalsIgnoreCase("entire shirt")) {
					
					if(garment.equalsIgnoreCase("white")) {
						
						
					if (quantity >= 1 && quantity <= 5)
						return 8.50;
					else if (quantity >= 6 && quantity <= 23)
						return 6.00;
					else if (quantity >= 24 && quantity <= 47)
						return 5.50;
					else if (quantity >= 48 && quantity <= 143)
						return 4.50;
					else if (quantity >= 144 && quantity <= 499)
						return 4.25;
					else
						return 3.50;
					}
					
					else {
						
						
						
						if (quantity >= 1 && quantity <= 5)
							return 9.00;
						else if (quantity >= 6 && quantity <= 23)
							return 7.00;
						else if (quantity >= 24 && quantity <= 47)
							return 6.00;
						else if (quantity >= 48 && quantity <= 143)
							return 5.25;
						else if (quantity >= 144 && quantity <= 499)
							return 5.00;
						else
							return 4.50;
						}
						
				
						
						
						
				} else {
					throw new Exception("Unsupported Sub Printing Type: " + subType);
				}

			case "embroidery":
				if (subType.equalsIgnoreCase("custom pocket")) {
					if (quantity >= 1 && quantity <= 11)
						return 5.00;
					else if (quantity >= 12 && quantity <= 17)
						return 4.75;
					else if (quantity >= 18 && quantity <= 35)
						return 4.50;
					else if (quantity >= 36 && quantity <= 143)
						return 4.25;
					else
						return 4.00;
				} else if (subType.equalsIgnoreCase("hat/ headwear")) {
					return Precision.round((2.75 + (30 / quantity)), 2);
				} else if (subType.equalsIgnoreCase("pocket area")) {
					return Precision.round((2.50 + (30 / quantity)), 2);
				} else if (subType.equalsIgnoreCase("greek letters")) {
					return Precision.round((8.80 + (30 / quantity)), 2);
				} else {
					throw new Exception("Unsupported Sub Printing Type: " + subType);
				}

			case "gold/silver foil":
				return 2.00;

			default:
				throw new Exception("Unsupported Printing Type: " + printingType);
			}
		} catch (Exception e) {
			Assert.fail("Unable to get Printing Prices. " + e.getMessage());
		}
		return 0;
	}

	public boolean isFeatureAdded(String feature) throws Exception {
		boolean added = false;

		try {
			if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), feature))) {
				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), feature).equalsIgnoreCase("yes")) {
					added = true;
				}
			}
		} catch (Exception e) {
			throw new Exception("Unable to read data for " + feature + "." + e.getMessage());
		}

		return added;
	}

	public double getFees() throws Exception {
		double feesAmount = 0;
		try {
			if (isFeatureAdded("RUSHSHIPPING")) {
				feesAmount = getCharges("Apparel") + getCharges("Printing") + getCharges("Shipping")
						+ getCharges("Misc") + getCharges("Customization");

				if (Objects.nonNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DUEIN"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DUEIN")
							.equalsIgnoreCase("7to10")) {
						feesAmount = (feesAmount * 0.3);
					} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "DUEIN")
							.equalsIgnoreCase("11to13")) {
						feesAmount = (feesAmount * 0.2);
					}
				}
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FEES", String.valueOf(feesAmount));
			}

		} catch (Exception e) {
			throw new Exception("Unable to calculate Fees Amount. " + e.getMessage());
		}
		return feesAmount;
	}

	public double getCommissionCost() throws Exception {
		double commissionCost = 0, priceSubtotal = 0, priceMargin = 0, fees = 0, priceCost = 0;
		try {
			priceSubtotal = getCharges("Apparel") + getCharges("Printing") + getCharges("Shipping") + getCharges("Misc")
					+ getCharges("Customization");
			System.out.println("PriceSubTotal: " + priceSubtotal);
			fees = getFees();
//			System.out.println("Fees: " + fees);

			priceCost = priceSubtotal + fees;

//			System.out.println("PriceCost: " + priceCost);

			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "APPARELTYPE")
					.equalsIgnoreCase("style code"))
				priceMargin = priceCost * 0.77;
			else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "APPARELTYPE")
					.equalsIgnoreCase("blank price"))
				priceMargin = priceCost * 0.8;
			else
				System.out.println("Unsupported ApparelType.");
			System.out.println("PriceMargin: " + priceMargin);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICECOST", String.valueOf(priceCost));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICEMARGIN", String.valueOf(priceMargin));

			commissionCost = (priceCost + priceMargin) * 0.08;
			System.out.println("CommionCalc: " + commissionCost);
		} catch (Exception e) {
			throw new Exception("Unable to calculate Commission Cost. " + e.getMessage());
		}
		return commissionCost;
	}

	public double getSecondaryMargin() throws Exception {
		double cost = 0, totalCost = 0;
		try {
			totalCost = Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICECOST"))
					+ Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMMISSIONVALUE"))
					+ Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEMARGIN"));
			totalCost *= Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"));
			if (totalCost <= 200) {
				cost = 1.15;
			} else if (totalCost > 200 && totalCost <= 300) {
				cost = 1.05;
			} else {
				cost = 1;
			}
		} catch (Exception e) {
			throw new Exception("Unable to Secondary Margin. " + e.getMessage());
		}
		return cost;
	}

	public double getCharges(String chargeType) throws Exception {
		double charges = 0, priceUnit = 0, greekLicensingCost = 0;
		try {
			switch (chargeType.toLowerCase().trim()) {
			case "customization":
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNAME"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNAME")
							.equalsIgnoreCase("yes")) {
						charges += Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNAMEVALUE"));
					}
				}
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNUMBER"))) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNUMBER")
							.equalsIgnoreCase("yes")) {
						charges += Double.parseDouble(
								RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CUSTOMNUMBERVALUE"));
					}
				}
				break;

			case "apparel":
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "APPARELVALUE"))) {
					return Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "APPARELVALUE"));
				}
				break;

			case "printing":
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC1PRINTINGVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC1PRINTINGVALUE"));
				}
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC2PRINTINGVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC2PRINTINGVALUE"));
				}
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC3PRINTINGVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC3PRINTINGVALUE"));
				}
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC4PRINTINGVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOC4PRINTINGVALUE"));
				}
				break;

			case "cost":
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICECOST"))) {
					charges += Double
							.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICECOST"));
				}
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMMISSIONVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMMISSIONVALUE"));
				}
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"))) {
					charges *= Double
							.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "QUANTITY"));
				}

//				System.out.println("CostCalc: " + charges);
				break;

			case "shipping":
				if (!Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPINGVALUE"))) {
					charges += Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPINGVALUE"));
				}
				break;

			case "misc":
				if (!Objects
						.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MISCELLANEOUSVALUE"))) {
					return Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "MISCELLANEOUSVALUE"));
				}
				break;

			case "greek royalties":
				if (isFeatureAdded("GREEKROYALTIES")) {
					priceUnit = getPriceUnit();
					charges = priceUnit * 0.095;
				}
//				System.out.println("GreekCalc: " + Precision.round(charges, 2));
				break;

			case "collegiate royalties":
				if (isFeatureAdded("COLLEGIATEMARKS")) {
					priceUnit = getPriceUnit();

					if (isFeatureAdded("GREEKROYALTIES")) {
						greekLicensingCost = getCharges("Greek Royalties");
					}
					charges = (priceUnit + greekLicensingCost) * 0.12;

				}
//				System.out.println("CollegiateCalc: " + Precision.round(charges, 2));
				break;
			case "individual shipping":
				if (isFeatureAdded("INDIVIDUALSHIPPING")) {
					charges = Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "INDIVIDUALSHIPPINGVALUE"));
				}
//				System.out.println("Individual Shipping: " + Precision.round(charges, 2));
				break;
			case "charged price":
				charges = Double
						.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEUNIT"))
						+ getCharges("Greek Royalties") + getCharges("Collegiate Royalties")
						+ getCharges("Individual Shipping");

				if (Double.parseDouble(
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "APPARELVALUE")) > 7.2) {
					charges += 3;
				}
//				System.out.println("Charged Price: " + Precision.round(charges, 2));
				break;
			default:
				throw new Exception("Unsupported Charge Type: " + chargeType);
			}

		} catch (Exception e) {
			throw new Exception("Unable to get Charges. " + e.getMessage());
		}
		return charges;
	}

	public double getPriceUnit() throws Exception {
		double priceUnit = 0;
		try {
			priceUnit = (Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICECOST"))
					+ Double.parseDouble(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PRICEMARGIN"))
					+ Double.parseDouble(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMMISSIONVALUE")))
					* getSecondaryMargin();

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PRICEUNIT", String.valueOf(priceUnit));
//			System.out.println("Price Unit: " + priceUnit);
		} catch (Exception e) {
			throw new Exception("Unable to Calculate Price Unit. " + e.getMessage());
		}
		return priceUnit;
	}

	public QuotersPage changeStyleCode() {
		String styleCode="";
		try {
			styleCode="Gildan G182";
			clickElementJS(drpDwnStyleCode);
			enterData(txtStyleCode, styleCode);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(optionStyleCode, styleCode)));			
		} catch (Exception e) {
			Assert.fail("Failed in Changing Style Code. " + e.getMessage());
		}
		return this;
	}

	public QuotersPage verifyStocks() {
		String s_qty = "", l_qty = "", m_qty = "", xl_qty = "", apparelType = "";
		try {
			s_qty = InputPropertyUtils.get("S_QTY");
			l_qty = InputPropertyUtils.get("L_QTY");
			m_qty = InputPropertyUtils.get("M_QTY");
			xl_qty = InputPropertyUtils.get("XL_QTY");
			apparelType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TYPE");
			softAssert = new SoftAssert();

			if (findElementPresence(divStocksQty)) {
				if (apparelType.equalsIgnoreCase("fp")) {
					softAssert.assertEquals(getData(By.xpath("//span[text()='S']//following-sibling::span")), s_qty,
							"S Stock Qty doesn't Match");
					softAssert.assertEquals(getData(By.xpath("//span[text()='M']//following-sibling::span")), m_qty,
							"M Stock Qty doesn't Match");
					softAssert.assertEquals(getData(By.xpath("//span[text()='L']//following-sibling::span")), l_qty,
							"L Stock Qty doesn't Match");
					softAssert.assertEquals(getData(By.xpath("//span[text()='XL']//following-sibling::span")), xl_qty,
							"XL Stock Qty doesn't Match");

					softAssert.assertAll();
				}
			} else {
				throw new Exception("Stocks Section is not Displayed");
			}
			ExtentLogger.pass("Verified Stock Section");
		} catch (Exception e) {
			Assert.fail("Failed in Verifying Stocks. " + e.getMessage());
		}
		return this;
	}

	public QuotersPage clickPerUnit() {
		
		try {
			
			clickElement(btnPerunit);
			
			ExtentLogger.pass("clicked Per unit");
			
		} catch (Exception e) {
			Assert.fail("Failed to click per unit . " + e.getMessage());
		}
		
		return this;
	}	
	
}
