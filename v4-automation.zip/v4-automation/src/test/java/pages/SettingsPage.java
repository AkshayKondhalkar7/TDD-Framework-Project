package pages;

import static appConstants.ApplicationConstants.*;

import java.sql.DriverAction;
import java.util.HashMap;

import org.openqa.selenium.By;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import appEnums.UserOperation;
import appEnums.UserType;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import masterClasses.MasterPage;
import pageElements.SettingsPageElements;
import reports.ExtentLogger;
import tests.Settings_EditAccountDetails;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class SettingsPage extends MasterPage implements SettingsPageElements {

	public static String editedName = "";
	public static String editedPhoneNo = "";
	public static String editedSchoolName = "";
	public static String editedBusiness = "";
	public static String editedTitle = "";
	public static String editedShippingName = "";
	public static String editedStreetName = "";
	public static String editedStateName = "";
	public static String editedCityName = "";
	public static String editedOrgName = "";

	public SettingsPage clickEditDetailButtonOfSettings() throws InterruptedException {

		try {

			System.out.println(DriverManager.getDriver().findElement(EditDetailsButton).isDisplayed());

			clickElement(EditDetailsButton);

			if (!findElementPresence(titleSettings)) {
				throw new Exception("Settings Page Title Not Found during Updation.");
			}
			ExtentLogger.pass("Clicked Edit Details Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Edit Details Settings Button. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage editFullName() throws Exception {

		hoverOverWithEnteringData(FullNameTextBox);

		Boolean Flag = DriverManager.getDriver().findElement(FullNameTextBox).isDisplayed();
		if (!Flag) {
			throw new Exception("Settings Page Full Name TextBox must not be enabled. ");

		}

		String randName = "";
		try {
			randName = DataGeneratorUtils.randFullName().toUpperCase();
			System.out.println(randName);
			enterData(FullNameTextBox, randName);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDFULLNAME", randName);

			ExtentLogger.pass("Edited the FullName: " + randName + " Successfully");

			editedName = DriverManager.getDriver().findElement(FullNameTextBox).getAttribute("ng-reflect-model");

			System.out.println("editedName = " + editedName);

		} catch (Exception e) {

			Assert.fail("Unable to Edit Full Details while Editing User. " + e.getMessage());
		}
		System.out.println("Name = " + randName);

		return new SettingsPage();
	}

	// added by vidya //

	public SettingsPage editBusiness() throws Exception {

		hoverOverWithEnteringData(txtBusiness);

		Boolean Flag = DriverManager.getDriver().findElement(txtBusiness).isDisplayed();
		if (!Flag) {
			throw new Exception("Settings Page Business TextBox must not be enabled. ");

		}

		String business = "Cricket";
		try {

			System.out.println(business);
			enterData(txtBusiness, business);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDBUSINESS", business);
			ExtentLogger.pass("Edited the Business: " + business + " Successfully");

			editedBusiness = DriverManager.getDriver().findElement(txtBusiness).getAttribute("ng-reflect-model");

		} catch (Exception e) {

			Assert.fail("Unable to Edit Business Details while Editing User. " + e.getMessage());
		}

		return this;
	}

	// added by vidya //

	public SettingsPage editTitle() throws Exception {

		hoverOverWithEnteringData(txtTitle);

		Boolean Flag = DriverManager.getDriver().findElement(txtTitle).isDisplayed();
		if (!Flag) {
			throw new Exception("Settings Page Business TextBox must not be enabled. ");

		}

		String title = "Batsman";
		try {

			System.out.println(title);
			enterData(txtTitle, title);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDTITLE", title);
			ExtentLogger.pass("Edited the Title: " + title + " Successfully");
			editedTitle = DriverManager.getDriver().findElement(txtTitle).getAttribute("ng-reflect-model");

		} catch (Exception e) {

			Assert.fail("Unable to Edit Title Details while Editing User. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage editPhoneNumber() throws Exception {

		Boolean Flag = clickElement(PhoneNumberTextBox);
		if (!Flag) {
			throw new Exception("Settings Page PhoneNumber TextBox must not be enabled. ");

		}

		String randNo = "";
		try {
			randNo = DataGeneratorUtils.randPhoneNumber();
			enterData(PhoneNumberTextBox, randNo);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDPHONENUMBER", randNo);
			ExtentLogger.pass("Edited the PhoneNumber: " + randNo + " Successfully");
			editedPhoneNo = DriverManager.getDriver().findElement(PhoneNumberTextBox).getAttribute("ng-reflect-model");

		} catch (Exception e) {

			Assert.fail("Unable to Edit Phone Details while Editing User. " + e.getMessage());
		}
		return this;
	}

	public SettingsPage editEmailAddress() throws Exception {

		Boolean Flag = clickElement(EmailTextBox);
		if (!Flag) {
			throw new Exception("Settings Page Email TextBox must not be enabled. ");

		}

		String randNo = "";
		try {
			randNo = DataGeneratorUtils.randEmail("");
			enterData(EmailTextBox, randNo);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDEMAILID", randNo);
			ExtentLogger.pass("Edited the Email: " + randNo + " Successfully");

		} catch (Exception e) {

			Assert.fail("Unable to Edit Email Details while Editing User. " + e.getMessage());
		}
		return this;
	}

	public SettingsPage editPasswordSettings() throws Exception {
		try {

			clickElement(EditPwdButton);

			if (!findElementPresence(titleSettings)) {
				throw new Exception("Settings Page Title Not Found during Updation.");
			}
			ExtentLogger.pass("Clicked Edit pwd Details Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Edit pwd Details Settings Button. " + e.getMessage());
		}
		

		return this;
	}

	public SettingsPage editNewPassword() throws Exception {
		try {

			String password = LoginPage.getPasswordreuse();

			// String password =
			// InputPropertyUtils.get("EXISTING_ADMIN_PASSWORDFORSETTINGS");
			InputPropertyUtils.get("EXISTING_ADMIN_PASSWORD");

			clickElementJS(CurrentPwdTextBox);

			enterData(CurrentPwdTextBox, password);
			clickElementJS(NewPwdTextBox);
			enterData(NewPwdTextBox, password);
			enterData(ConfirmNewPwdTextBox, password);

			sleepFor(4000);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDPASSWORD", password);

			ExtentLogger.pass("Clicked Edit pwd current/new Details " + password + " Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Edit pwdcurrent/new Details Settings Button. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage editNewPasswordImpersonation(String userType) throws Exception {
		String password = "";

		try {

			if (userType.equals("ADMIN")) {
				password = InputPropertyUtils.get("EXISTING_ADMIN_PASSWORD");
			}
			if (userType.equals("CAMPUS_MANAGER")) {
				password = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORD");
			}
			if (userType.equals("CLIENT")) {
				password = InputPropertyUtils.get("EXISTING_CUSTOMER_PASSWORD");
			}
			if (userType.equals("PRINTER")) {
				password = InputPropertyUtils.get("EXISTING_PRINTER_PASSWORD");
			}
			if (userType.equals("FULFILLMENT_CENTER")) {
				password = InputPropertyUtils.get("EXISTING_FULFILLMENT_PASSWORD");
			}

			System.out.println(password);

			clickElementJS(CurrentPwdTextBox);

			enterData(CurrentPwdTextBox, password);
			// System.out.println("current password = " +password);

			clickElementJS(NewPwdTextBox);

			enterData(NewPwdTextBox, password);

			// System.out.println("new password = "+password);

			enterData(ConfirmNewPwdTextBox, password);

			sleepFor(4000);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDPASSWORD", password);

			ExtentLogger.pass("Clicked Edit pwd current/new Details " + password + " Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Edit pwdcurrent/new Details Settings Button. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage saveDetailsButton() throws Exception {
		try {
			scrollToBottom();
			scrollToElement(btnSaveDetails);
			clickElement(btnSaveDetails);
			sleepFor(5000);

			if (!findElementPresence(titleSettings)) {
				throw new Exception("Settings Page Title Not Found during Updation.");
			}
			ExtentLogger.pass("Clicked Save Details Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Click Save Details Settings Button. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage cancelButton() throws Exception {
		try {
			scrollToElement(CancelButton);
			/*
			 * JavascriptExecutor jse = (JavascriptExecutor)DriverManager.getDriver();
			 * jse.executeScript("arguments[0].scrollIntoView()", CancelButton);
			 */
			sleepFor(3000);

			clickElement(CancelButton);
			sleepFor(2000);
			clickElement(cancelYesBtn);
			sleepFor(2000);

			if (!findElementPresence(titleSettings)) {
				throw new Exception("Settings Page Title Not Found during Updation.");
			}
			ExtentLogger.pass("Clicked Cancel Details Settings Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to click Cancel Details Settings Button. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage fieldValidations() {
		try {

			enterData(CurrentPwdTextBox, " ");
			enterData(NewPwdTextBox, " ");
			enterData(ConfirmNewPwdTextBox, " ");
			clickElement(EmailTextBox);
			passwordMismatchSettings();
			enterData(FullNameTextBox, " ");
			enterData(EmailTextBox, " ");
			enterData(PhoneNumberTextBox, " ");

			if ((!findElementPresence(
					By.xpath("//div[contains(text(),'" + CURRENT_PASSWORD_EMPTY_INVALID_MESSAGE + "')]"))
					&& !findElementPresence(
							By.xpath("//div[contains(text(),'" + SETNEW_PASSWORD_EMPTY_INVALID_MESSAGE + "')]"))
					&& !findElementPresence(
							By.xpath("//div[contains(text(),'" + CONFIRMNEW_PASSWORD_EMPTY_INVALID_MESSAGE + "')]"))
					&& !findElementPresence(By.xpath("//div[contains(text(), '" + FULLNAME_INVALID_MESSAGE + "')]"))
					&& !findElementPresence(By.xpath("//div[contains(text(), '" + PHONE_INVALID_MESSAGE + "')]"))
					&& !findElementPresence(
							By.xpath("//div[contains(text(), '" + EMPTYEMAIL_INVALID_MESSAGE + "')]")))) {
				throw new Exception(" Empty Validation for fields are not Displayed");
			}
			ExtentLogger.pass("Validations are working properly");

		} catch (Exception e) {
			e.printStackTrace();
			ExtentLogger.fail("Validations are not displayed as Expected for the Passwords. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage passwordMismatchSettings() {
		try {

			enterData(CurrentPwdTextBox, "Test123");
			sleepFor(2000);

			enterData(NewPwdTextBox, "123");
			sleepFor(2000);

			enterData(ConfirmNewPwdTextBox, " ");

			clickElement(EmailTextBox);

			if (!findElementPresence(By.xpath("//div[contains(text(),'" + SETTINGS_PASSWORD_INVALID_MESSAGE + "')]"))) {
				throw new Exception("Validation for Password Match is not Displayed");
			}

			ExtentLogger.pass("Verified Validations for Password ");
			System.out.println("Invalid password displayed");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Validations are not displayed as Expected for Password. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage editShippingName() throws Exception {

		hoverOverWithEnteringData(ShippingNameTextBox);

		Boolean Flag = DriverManager.getDriver().findElement(ShippingNameTextBox).isDisplayed();
		if (!Flag) {
			throw new Exception("Settings Page Full Name TextBox must not be enabled. ");

		}

		String shippingName = "";
		try {
			shippingName = DataGeneratorUtils.randShipmentName().toUpperCase();
			enterData(ShippingNameTextBox, shippingName);
			System.out.println(shippingName);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDSHIPPINGNAME", shippingName);
			ExtentLogger.pass("Edited the shipping name: " + shippingName + " Successfully");
			editedShippingName = DriverManager.getDriver().findElement(ShippingNameTextBox)
					.getAttribute("ng-reflect-model");

		} catch (Exception e) {

			Assert.fail("Unable to Edit Full Details while Editing. " + e.getMessage());
		}
		return this;
	}

	public void editTextBoxes(By ObjectAddress, String TextBoxName, String randName, String EditDetailsRunTimeVar)
			throws Exception {

		Boolean Flag = DriverManager.getDriver().findElement(ObjectAddress).isDisplayed();
		if (!Flag) {
			throw new Exception("Settings Page TextBox must not be enabled. ");
		}
		try {

			enterData(ObjectAddress, randName);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), EditDetailsRunTimeVar, randName);
			ExtentLogger.pass("Edited the " + TextBoxName + ":" + randName + " Successfully");

		} catch (Exception e) {

			Assert.fail("Unable to Edit " + TextBoxName + " while Editing. " + e.getMessage());
		}

	}

	public SettingsPage editStreetName() {

		try {
			editTextBoxes(StreetNameTextBox, "Street Name", DataGeneratorUtils.randStreet().toUpperCase(),
					"EDITEDSTREETNAME");
			editedStreetName = DriverManager.getDriver().findElement(StreetNameTextBox)
					.getAttribute("ng-reflect-model");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;

	}

	public SettingsPage editCityName() {

		try {
			editTextBoxes(CityTextBox, "City Name", DataGeneratorUtils.randCity().toUpperCase(), "EDITEDCITYNAME");
			editedCityName = DriverManager.getDriver().findElement(CityTextBox).getAttribute("ng-reflect-model");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;

	}

	public SettingsPage editStateName() {

		try {
			clickElement(drpDwnState);
			sleepFor(1000);
			editTextBoxes(drpDwnState, "State Name", DataGeneratorUtils.randState().toUpperCase(), "EDITEDSTATENAME");
			editedStateName = DriverManager.getDriver().findElement(drpDwnState).getAttribute("ng-reflect-model");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;

	}

	public SettingsPage editZipCode() {

		try {
			editTextBoxes(ZipCodeTextBox, "Zip Code", DataGeneratorUtils.randZipCode().toUpperCase(), "EDITEDZIPCODE");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;

	}

	public SettingsPage editSchoolName() {

		By drpDwnSchool = By.xpath(
				"//div[contains(text(),'School') and contains(@class,'label')]//following::input[@role='combobox'][1]");
		try {
			editTextBoxes(drpDwnSchool, "School ", DataGeneratorUtils.randSchoolName().toUpperCase(),
					"EDITEDSCHOOLNAME");
			editedSchoolName = DriverManager.getDriver().findElement(drpDwnSchool).getAttribute("ng-reflect-model");
			System.out.println(editedSchoolName);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return this;
	}

	public SettingsPage editOrgName() {

		try {
			editTextBoxes(drpDwnOrganization, "Organization", DataGeneratorUtils.randOrganizationName().toUpperCase(),
					"EDITEDORGNAME");
			editedOrgName = DriverManager.getDriver().findElement(drpDwnOrganization).getAttribute("ng-reflect-model");
			System.out.println(editedOrgName);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return this;
	}

	public SettingsPage editTimeZone() {

		try {

			String txtTimezone = "(//div[contains(text(),'Select Timezone')]//following::div[contains(text(), \"EST\")])[1]";
			DriverManager.getDriver().findElement(By.xpath(txtTimezone)).click();

			ExtentLogger.pass("Edited the TimeZone" + ":" + txtTimezone + " Successfully");

		} catch (Exception e) {
			Assert.fail("Unable to Edit Timezone while Editing. " + e.getMessage());

			e.printStackTrace();
		}

		return this;

	}

	/* to verify the updated name is correct or not */

	public SettingsPage logOutandVerifyUpdatedName() {

		try {

			String name = DriverManager.getDriver().findElement(profileIconNew).getText();

			sleepFor(3000);
			System.out.println(name + " " + editedName);

			try {
				if (editedName.equalsIgnoreCase(name)) {
					ExtentLogger.pass("Name of the logged in user expected " + editedName + " and found " + name);

				}
			} catch (Exception e) {
				ExtentLogger.fail("Name of the logged in user expected " + editedName + " and found " + name);
			}

			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(profileIconNew));
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(lnkLogoutMenu));

			ExtentLogger.pass("Logged Out of the Application with the name of " + name);
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedPhoneNo() {

		try {

			// String phnoeNo =
			// DriverManager.getDriver().findElement(PhoneNumberTextBox).getText();
			String phnoeNo = DriverManager.getDriver().findElement(PhoneNumberTextBox).getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(phnoeNo + " " + editedPhoneNo);

			try {
				if (editedPhoneNo.equalsIgnoreCase(phnoeNo)) {
					ExtentLogger
							.pass("PhoneNo of the logged in user expected " + editedPhoneNo + " and found " + phnoeNo);

				}
			} catch (Exception e) {
				ExtentLogger.fail("PhoneNo of the logged in user expected " + editedPhoneNo + " and found " + phnoeNo);

			}

			ExtentLogger.pass("Sucussfully PhoneNo verifed for " + phnoeNo);
		} catch (Exception e) {
			Assert.fail("Failed PhoneNo verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedSchool() {

		try {

			String schoolName = DriverManager.getDriver().findElement(drpDwnSchool).getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(schoolName + " " + editedSchoolName);

			try {
				if (editedSchoolName.equalsIgnoreCase(schoolName)) {
					ExtentLogger.pass("SchoolName of the logged in user expected " + editedSchoolName + " and found "
							+ schoolName);

				}
			} catch (Exception e) {
				ExtentLogger.fail(
						"SchoolName of the logged in user expected " + editedSchoolName + " and found " + schoolName);

			}

			ExtentLogger.pass("Sucussfully SchoolName verifed for " + schoolName);
		} catch (Exception e) {
			Assert.fail("Failed SchoolName verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedOrg() {

		try {

			String orgName = DriverManager.getDriver().findElement(drpDwnOrganization).getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(orgName + " " + editedOrgName);

			try {
				if (editedOrgName.equalsIgnoreCase(orgName)) {
					ExtentLogger.pass(
							"Organization of the logged in user expected " + editedOrgName + " and found " + orgName);

				}
			} catch (Exception e) {
				ExtentLogger
						.fail("Organization of the logged in user expected " + editedOrgName + " and found " + orgName);

			}

			ExtentLogger.pass("Sucussfully SchoolName verifed for " + orgName);
		} catch (Exception e) {
			Assert.fail("Failed SchoolName verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedShippingName() {

		try {

			String shippingName = DriverManager.getDriver().findElement(ShippingNameTextBox)
					.getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(shippingName + " " + editedShippingName);

			try {
				if (editedBusiness.equalsIgnoreCase(shippingName)) {
					ExtentLogger.pass("ShippingName of the logged in user expected " + editedShippingName
							+ " and found " + shippingName);

				}
			} catch (Exception e) {
				ExtentLogger.fail("ShippingName of the logged in user expected " + editedShippingName + " and found "
						+ shippingName);

			}

			ExtentLogger.pass("Sucussfully ShippingName verifed for " + shippingName);
		} catch (Exception e) {
			Assert.fail("Failed ShippingName verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedStreetName() {

		try {

			String streetName = DriverManager.getDriver().findElement(StreetNameTextBox)
					.getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(streetName + " " + editedStreetName);

			if (editedStreetName.equalsIgnoreCase(streetName)) {

//					("StreetName of the logged in user expected " + editedStreetName + " and found "
//							+ streetName);

				System.out.println(
						("StreetName of the logged in user expected " + editedStreetName + " and found " + streetName));
			}

			ExtentLogger.pass("Sucussfully StreetName verifed for " + streetName);
		} catch (Exception e) {
			Assert.fail("Failed StreetName verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedCityNmae() {

		try {

			String cityNmae = DriverManager.getDriver().findElement(CityTextBox).getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(cityNmae + " " + editedCityName);

			if (editedCityName.equalsIgnoreCase(cityNmae)) {
				ExtentLogger
						.pass("CityNmae of the logged in user expected " + editedCityName + " and found " + cityNmae);

			}

			ExtentLogger.pass("Sucussfully CityNmae verifed for " + cityNmae);
		} catch (Exception e) {
			Assert.fail("Failed CityNmae verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedTitle() {

		try {

	//		String title = getData(txtTitle);
			String title = DriverManager.getDriver().findElement(txtTitle).getAttribute("ng-reflect-model");

			sleepFor(3000);
			System.out.println(title + " " + editedTitle);

			try {
				if (editedTitle.equalsIgnoreCase(title)) {
					ExtentLogger.pass("Title of the logged in user expected " + editedTitle + " and found " + title);

				}
			} catch (Exception e) {
				ExtentLogger.fail("Title of the logged in user expected " + editedTitle + " and found " + title);

			}

			ExtentLogger.pass("Sucussfully Title verifed for " + title);
		} catch (Exception e) {
			Assert.fail("Failed Title verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	// added by vidya //
	public SettingsPage verifyUpdatedBusiness() {

		try {

			String business = DriverManager.getDriver().findElement(txtBusiness).getAttribute("ng-reflect-model");

			sleepFor(2000);
			System.out.println(business + " " + editedBusiness);

			try {
				if (editedBusiness.equalsIgnoreCase(business)) {
					ExtentLogger.pass(
							"Business of the logged in user expected " + editedBusiness + " and found " + business);

				}
			} catch (Exception e) {
				ExtentLogger
						.fail("Business of the logged in user expected " + editedBusiness + " and found " + business);

			}

			ExtentLogger.pass("Sucussfully Business verifed for " + business);
		} catch (Exception e) {
			Assert.fail("Failed Business verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	public SettingsPage verifyUpdatedName() {
		try {

			// String name =
			// DriverManager.getDriver().findElement(profileIconNew).getText();
			String name = getData(profileIconNew);

			sleepFor(3000);
			System.out.println(name + " " + editedName);

			try {
				if (editedName.equalsIgnoreCase(name)) {
					ExtentLogger.pass("Name of the logged in user expected " + editedName + " and found " + name);

				}
			} catch (Exception e) {
				ExtentLogger.fail("Name of the logged in user expected " + editedName + " and found " + name);
			}

			ExtentLogger.pass("Sucussfully Name verifed for " + name);

		} catch (Exception e) {
			Assert.fail("Failed Name verifed for " + e.getMessage());
		}

		return new SettingsPage();
	}

	public SettingsPage clickOnUnsubscribeMailingList() throws Exception {

		sleepFor(3000);
		clickElement(rejoinourmail);
		sleepFor(3000);
		DriverManager.getDriver().findElement(UnsubscribeToMailingBox).click();
		sleepFor(3000);
		String editedemail;
		try {
			editedemail = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAILID");
			if (DBSetupUtils.selectQuery(editedemail) == null) {

				ExtentLogger
						.fail(" After Unsubscribtion Database deleted the entries succesfully for user" + editedemail);

			}

			ExtentLogger
					.pass("After Unsubscribtion Database not deleted the entries succesfully for user\"+editedemail");

			sleepFor(3000);
			DriverManager.getDriver().findElement(rejoinourmail).click();

			editedemail = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EDITEDEMAILID");
			if (DBSetupUtils.selectQuery(editedemail) == null) {

				System.out.print("Database check");
				ExtentLogger.pass(" After Subscribtion Database added the entries succesfully for user" + editedemail);

			}

			ExtentLogger.fail("After Subscribtion Database not added the entries succesfully for user\" +editedemail");

		} catch (Exception e) {

			e.printStackTrace();
		}

		return this;

	}

	public SettingsPage stopImpersonationAndVerifyLandingPage(UserType userType, String platform) {
		String fullname = "", impName = "";
		try {
			fullname = InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME").toLowerCase().trim();
			String name = DriverManager.getDriver().findElement(profileIconNew).getText();

			System.out.println("name = " + name);

			if (platform.equalsIgnoreCase("desktop")) {
				clickElementJS(btnStopImpersonation);
				sleepFor(1000);
				impName = getData(profileNameOld).toLowerCase().trim();

				if (!(fullname.contains(impName))) {
					throw new Exception(
							"Profile Name(" + impName + ") does not match with Full Name(" + fullname + ")");
				}

			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElementJS(btnStopImpersonation);
				sleepFor(1000);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");
			ExtentLogger.pass("Stopped Impersonation and Verified Landing Page");
		} catch (Exception e) {
			Assert.fail("Unable to Stop Impersonation and Verify Landing Page. " + e.getMessage());
		}

		return this;
	}

	public SettingsPage impersonateAndSettings() {
		loginPage.navigateToUsersPage("desktop").filterUser(UserType.ADMIN, "Desktop")
				.hoverAndSelectOption(UserOperation.IMPERSONATE).verifyImpersonationLandingPage(UserType.ADMIN);
		try {
			loginPage.navigateToSettingsPage("desktop").clickEditDetailButtonOfSettings().editPasswordSettings();
		} catch (InterruptedException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		return this;

	}

public SettingsPage logOutSet() {
		
		DBSetupUtils.setupUserDatabase();
		sleepFor(2000);
		try {
			
			System.out.println(DriverManager.getDriver().findElement(profileIconNew).getText());
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(profileIconNew));
			sleepFor(3000);
			executeJS("arguments[0].click()", DriverManager.getDriver().findElement(lnkLogoutMenu));

			ExtentLogger.pass("Logged Out of the Application");
		//	DBSetupUtils.setupUserDatabase();
			
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

		return new SettingsPage();
	}

public SettingsPage editBusinessToSchool() {
	
	HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();
	
	
	try {
		
		clickElementJS(chkBoxClientTye);
		sleepFor(500);
		
		clickElementJS(drpDwnSchoolClient);
		sleepFor(200);
		enterData(drpDwnSchoolClient, schoolDetailsMap.get("SCHOOL"));
		sleepFor(200);
		clickElementJS(By.xpath(
				DynamicXpathUtils.getXpathForString(drpDwnSchoolValueClient, schoolDetailsMap.get("SCHOOL"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

		clickElementJS(drpDwnOrganizationClient);
		sleepFor(200);
		enterData(drpDwnOrganizationClient, schoolDetailsMap.get("ORGANIZATION"));
		sleepFor(200);
		clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValueClient,
				schoolDetailsMap.get("ORGANIZATION"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
				schoolDetailsMap.get("ORGANIZATION"));

		clickElementJS(btnPosition);
		enterData(btnPosition, "Apparel 123");
		sleepFor(2000);

		clickElementJS(
				By.xpath(DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR", schoolDetailsMap.get("GRADYEAR"));
		
		ExtentLogger.pass("Edited the School Details Successfully");
		
		
		
	} catch (Exception e) {
		Assert.fail("Unable to Edit School Details while Editing User. " + e.getMessage());
	}
	
	return this;
}

public SettingsPage verifySchoolDetails() {
	
	String  school = "", organization = "";
	
	try {
		
		softAssert = new SoftAssert();
		
		school = getData(By.xpath("(//span[@ng-reflect-escape='true'])[1]"));
		organization = getData(By.xpath("(//span[@ng-reflect-escape='true'])[2]"));
		
		
		softAssert.assertEquals(school,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"),
				"Unexpected Collegiate Marks in Proof");
		
		softAssert.assertEquals(organization,
				RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"),
				"Unexpected Organization in Proof");
		
		softAssert.assertAll();
		ExtentLogger.pass("Sucussfully verifed School Details");
		
	} catch (Exception e) {
		Assert.fail("Failed to verify School Details" + e.getMessage());
	}
	
	return this;
	
}

public SettingsPage editSchoolToBusiness() {
	
	String business = "Cricket";
	String title = "Batsman";
	
	try {
		
		clickElementJS(chkBoxClientTye);
		sleepFor(500);
		enterData(txtBusiness, business);

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDBUSINESS", business);
		ExtentLogger.pass("Edited the Business: " + business + " Successfully");
		
		enterData(txtTitle, title);

		RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EDITEDTITLE", title);
		ExtentLogger.pass("Edited the Title: " + title + " Successfully");
		

		editedBusiness = DriverManager.getDriver().findElement(txtBusiness).getAttribute("ng-reflect-model");
		editedTitle = DriverManager.getDriver().findElement(txtTitle).getAttribute("ng-reflect-model");
		
		
	} catch (Exception e) {
		Assert.fail("Unable to Edit Business Details while Editing User. " + e.getMessage());
	}
	
	return this;
}

public SettingsPage connectdb() {

	try {

		DBSetupUtils.setupUserDatabase();
		sleepFor(500);

	} catch (Exception e) {
		// TODO: handle exception
	}

	return this;
}

public SettingsPage editPosition() {

	try {
		
		clickElementJS(btnPosition);
		enterData(btnPosition, "Apparel 123");
		sleepFor(1000);

	} catch (Exception e) {
		e.printStackTrace();
	}

	return this;
}
	
}
