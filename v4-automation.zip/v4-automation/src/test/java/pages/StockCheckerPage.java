package pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import appEnums.PromoCodesTabs;
import appEnums.StockCheckerTabs;
import drivers.DriverManager;
import frameworkEnums.ElementCheckStrategy;
import masterClasses.MasterPage;
import pageElements.StockCheckerPageElements;
import reports.ExtentLogger;
import utilities.DynamicXpathUtils;
import utilities.RunTimePropertyFileUtils;

public class StockCheckerPage extends MasterPage implements StockCheckerPageElements {

	// Added By Akshay // Switch to method Not Required

	public StockCheckerPage enterProddetails(String enterProduct) {
		/**
		 * Used For search Product by Name And StyleCode
		 **/
		try {
			enterData(txtSearchStock, enterProduct);
			
			// add run time property Method 

			ExtentLogger.pass("Entered the Product Name " + enterProduct + " Sucessfully");
		} catch (Exception e) {
			Assert.fail("Failed in Entering Product Name " + e.getMessage());
		}
		return this;
	}

	public StockCheckerPage clickonProduct() {
		
		try {
			clickElement(styleCode);
			sleepFor(500);

			ExtentLogger.pass("Clicked on Product Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to click on Product. " + e.getMessage());
		}
		return this;
	}
	
	public StockCheckerPage verifyBlankCost() throws Exception {
		boolean flag = false;
		try {
			flag = checkCondition (StockCheckBlankCost , ElementCheckStrategy.DISPLAYED) ;
			
			// Verify that Blank Cost Listed is highest among the suppliers (Validations required)
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (flag) {}else {throw new Exception("Unable to Verify BlankCost" );
		}
		return this;
	}
		
	
	public StockCheckerPage verifyStockLevel() throws Exception {
		boolean flag = false;
		try {
			flag = checkCondition (stockCheckMSize , ElementCheckStrategy.DISPLAYED) ;
			
            // Verify that Stock level Listed fetched this from UI should be compared with the API's (Validations required)
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (flag) {}else {throw new Exception("Unable to Verify Stock level" );
		}
		return this;
	}
	
	public StockCheckerPage clickonQuotelink (){
		Actions alt;
		try {
			alt = new Actions(DriverManager.getDriver());
			alt.moveToElement(DriverManager.getDriver().findElement(stockCheckDownarrow));
			
		} 
		catch(Exception e){
			e.printStackTrace();
		}
		return this;
	}
//	public StockCheckerPage sortAndVerifyAllColumns(StockCheckerTabs stockCheckerTab) {
//		String[] colnames = { "Colors / Dist.", "Blank Cost" };
//		ArrayList<String> actualColData = null;
//		try {
//			sleepFor(2000);
////			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
//			for (String column : colnames) {
//				actualColData = new ArrayList<>();
//				actualColData.addAll(readCompleteColumnData(getColumntempIndex(column), stockCheckerTab));
//
//				if (column.equalsIgnoreCase("applies to")) {
//					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
//					sleepFor(1000);
//
//					getSortedDataAndCompare(stockCheckerTab, column, actualColData, "asc");
//					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");
//
//					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
//					sleepFor(1000);
//					getSortedDataAndCompare(stockCheckerTab, column, actualColData, "dsc");
//					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
//				} else {
//					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
//					sleepFor(1000);
//
//					getSortedDataAndCompare(stockCheckerTab, column, actualColData, "asc");
//					ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");
//
//					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
//					sleepFor(1000);
//					getSortedDataAndCompare(stockCheckerTab, column, actualColData, "dsc");
//					ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
//				}
//			}
//		} catch (Exception e) {
//			Assert.fail("Failed During Sorting and Verification in " + getStringValue(stockCheckerTab) + " Tab. "
//					+ e.getMessage());
//		}
//		return this;
//	}
//	
//	public void getSortedDataAndCompare(StockCheckerTabs stockCheckerTab, String colName, ArrayList<String> actualColData,
//			String order) throws Exception {
//		ArrayList<String> sortedColData = new ArrayList<String>();
//		ArrayList<String> tempList = new ArrayList<String>();
//		try {
//			sleepFor(2000);
//			sortedColData.addAll(readCompleteColumnData(getColumntempIndex(colName), stockCheckerTab));
//			System.out.println("Data from UI: ");
//			printArrayList(sortedColData);
//			tempList.clear();
//			tempList = sortArrayList(actualColData, order, colName);
//			System.out.println("Manually Sorted Data: ");
//			printArrayList(tempList);
//			if (compareLists(sortedColData, actualColData)) {
//				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
//						+ getStringValue(stockCheckerTab) + " Tab.");
//			} else {
//				throw new Exception("Data in " + colName + " Column is not Sorted in " + order + " Order Correctly in "
//						+ getStringValue(stockCheckerTab) + " Tab.");
//			}
//		} catch (Exception e) {
//			throw new Exception("Failed in Sorting and Comparing Records. " + e.getMessage());
//		}
//	}
	
	public int getColumntempIndex(String colName) throws Exception {
		int index = 0;
		if (colName.equalsIgnoreCase("Colors / Dist."))
		//	index = 4;
			index = 5;
		else if (colName.equalsIgnoreCase("Blank Cost"))
		//	index = 7;
			index = 9;
		return index;
	}
		
		public String getStringValue(StockCheckerTabs stockCheckerTab) {
			String tabString = "";
			if (stockCheckerTab.equals(StockCheckerTabs.ACTIVE)) {
				tabString = "Active";
			} else if (stockCheckerTab.equals(StockCheckerTabs.ALL)) {
				tabString = "All";
			} else if (stockCheckerTab.equals(PromoCodesTabs.DISABLED)) {
				tabString = "Disabled";
			}
			return tabString;
		}
}