package pages;

import static appConstants.ApplicationConstants.*;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import appUtilities.DataGeneratorUtils;
import drivers.DriverManager;
import factories.ExplicitWaitFactory;
import frameworkEnums.ElementCheckStrategy;
import frameworkEnums.WaitStrategy;
import masterClasses.MasterPage;
import pageElements.UsersPageElements;
import reports.ExtentLogger;
import utilities.DBSetupUtils;
import utilities.DynamicXpathUtils;
import utilities.InputPropertyUtils;
import utilities.RunTimePropertyFileUtils;

public class UsersPage extends MasterPage implements UsersPageElements {

	public UsersPage clickAddUsersButton(String platform) {
		try {
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").toLowerCase().trim()
					.equals("manager")) {

				if (platform.equalsIgnoreCase("desktop")) {
					clickElementJS(iconCreateClient);
				} else if (platform.equalsIgnoreCase("mobile")) {
					clickElementJS(iconCreateUserForManagerMobile);
				}

				if (!findElementPresence(iconClose))
					throw new Exception("Division for Entering Client Details is not Displayed");

			} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").toLowerCase().trim()
					.equals("admin")) {

				if (platform.equalsIgnoreCase("desktop")) {
					clickElementJS(iconCreateUser);
				} else if (platform.equalsIgnoreCase("mobile")) {
					clickElementJS(iconCreateUserForAdminMobile);
				}

				if (!findElementPresence(divCreateUserCheck))
					throw new Exception("Division for Selecting Users is not Displayed");
			}
			ExtentLogger.pass("Clicked Create User Button");
		} catch (Exception e) {
			Assert.fail("Failed in clicking of Add Users Button. " + e.getMessage());
		}
		return this;
	}

	public UsersPage switchTo(UserTabs userType) {
		try {
			scrollToTop();
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(userType))));

			ExtentLogger.pass("Switched to " + StringUtils.capitalize(userType.toString().toLowerCase()) + " Tab.");

		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + getStringValue(userType) + " Tab. " + e.getMessage());
		}
		return this;
	}

	public UsersPage switchTo(UserType userType) {
		try {
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(userType))));
		} catch (Exception e) {
			Assert.fail("Unable to Switch to " + userType.toString() + " Tab. " + e.getMessage());
		}

		return this;
	}

	public UsersPage choosePaginationCount(String count) {
		try {
			if (checkCondition(drpDwnRecordsCount, ElementCheckStrategy.DISPLAYED)) {
				scrollToElement(drpDwnRecordsCount);
				scrollToBottom();
				sleepFor(700);
				clickElement(drpDwnRecordsCount);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(recordsCountValue, count)));
				sleepFor(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Unable to Choose Pagination Count. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterUser(UserType userType, String platform) {
		String email = null, password = null;

		try {
			switch (userType.toString().toLowerCase()) {
			case "admin":
				email = InputPropertyUtils.get("EXISTING_ADMIN_EMAIL");
				password = InputPropertyUtils.get("EXISTING_ADMIN_PASSWORD");
				break;
			case "campus_manager":
				if (getTestCaseName().toLowerCase().contains("editexisting")) {
					email = InputPropertyUtils.get("ADMIN_EDIT_MANAGER_EMAIL");
					password = InputPropertyUtils.get("ADMIN_EDIT_MANAGER_PASSWORD");
				} else {
					email = InputPropertyUtils.get("EXISTING_MANAGER_EMAIL");
					password = InputPropertyUtils.get("EXISTING_MANAGER_PASSWORD");
				}

				break;
			case "client":
				if (getTestCaseName().toLowerCase().contains("editexisting")) {
					if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
							.equalsIgnoreCase("admin")) {
						email = InputPropertyUtils.get("ADMIN_EDIT_CUSTOMER_EMAIL");
						password = InputPropertyUtils.get("ADMIN_EDIT_CUSTOMER_PASSWORD");
					} else {
						email = InputPropertyUtils.get("MANAGER_EDIT_CUSTOMER_EMAIL");
						password = InputPropertyUtils.get("MANAGER_EDIT_CUSTOMER_PASSWORD");
					}
				} else {
					email = InputPropertyUtils.get("EXISTING_CUSTOMER_EMAIL");
					password = InputPropertyUtils.get("EXISTING_CUSTOMER_PASSWORD");
				}

				break;
			case "printer":
				email = InputPropertyUtils.get("EXISTING_PRINTER_EMAIL");
				password = InputPropertyUtils.get("EXISTING_PRINTER_PASSWORD");
				break;
			case "fulfillment_center":
				email = InputPropertyUtils.get("EXISTING_FULFILLMENT_EMAIL");
				password = InputPropertyUtils.get("EXISTING_FULFILLMENT_PASSWORD");
				break;
			default:
				break;
			}
			if (platform.equalsIgnoreCase("desktop")) {
				enterData(txtFilterData, email);
			} else if (platform.equalsIgnoreCase("mobile")) {
				enterData(txtFilterDataMobile, email);
			}
			
			System.out.println("email : "+ email);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);
			sleepFor(1000);
			ExtentLogger.pass("Successfully Filtered User with Email: " + email);
		} catch (Exception e) {
			Assert.fail("Unable to Enter Data in Search Input Field. " + e.getMessage());
		}

		return this;
	}
	
	public UsersPage filterUserImpersonate(UserType userType, String platform) {
		String email = null, password = null;

		try {
			switch (userType.toString().toLowerCase()) {
			case "admin":
				email = InputPropertyUtils.get("EXISTING_ADMIN_EMAIL");
				password = InputPropertyUtils.get("EXISTING_ADMIN_PASSWORD");
				break;
			case "campus_manager":
				if (getTestCaseName().toLowerCase().contains("editexisting")) {
					email = InputPropertyUtils.get("ADMIN_EDIT_MANAGER_EMAIL");
					password = InputPropertyUtils.get("ADMIN_EDIT_MANAGER_PASSWORD");
				} else {
					email = InputPropertyUtils.get("IMPERSONATE_MANAGER_EMAIL");
					password = InputPropertyUtils.get("IMPERSONATE_MANAGER_PASSWORD");
				}

				break;
			default:
				break;
			}
			if (platform.equalsIgnoreCase("desktop")) {
				enterData(txtFilterData, email);
			} else if (platform.equalsIgnoreCase("mobile")) {
				enterData(txtFilterDataMobile, email);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);
			sleepFor(1000);
			ExtentLogger.pass("Successfully Filtered User with Email: " + email);
		} catch (Exception e) {
			Assert.fail("Unable to Enter Data in Search Input Field. " + e.getMessage());
		}

		return this;
	}


	public UsersPage hoverAndSelectOption(UserOperation userOperation) {
		try {
			String email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
		//	String fname = getData(By.xpath("(//div[@class='data-table__cell'])[1]"));
			String fname = getData(By.xpath("(//div[@class='datatable-body-cell-label'])[1]"));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "IMPERSONATEFULLNAME", fname);
			sleepFor(1000);
			hoverOver(By.xpath("//span[contains(text(),'" + email + "')]"));
			if (userOperation.equals(UserOperation.DEACTIVATE)) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserDeactivateIcon, email)));
				ExtentLogger.pass("Hovered over the Record and Clicked DeActivate Icon");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Deactivate");
			} else if (userOperation.equals(UserOperation.REACTIVATE)) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserReactivateIcon, email)));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Reactivate");
				ExtentLogger.pass("Hovered over the Record and Clicked ReActivate Icon");
			} else if (userOperation.equals(UserOperation.IMPERSONATE)) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserImpersonateIcon, email)));
				ExtentLogger.pass("Hovered over the Record and Clicked Impersonate Icon");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Impersonate");
			} else if (userOperation.equals(UserOperation.UPDATE)) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserEditIcon, email)));
				ExtentLogger.pass("Hovered over the Record and Clicked Edit Icon");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Update");
			} else if (userOperation.equals(UserOperation.DELETE)) {
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(filteredUserDeleteIcon, email)));
				ExtentLogger.pass("Hovered over the Record and Clicked Delete Icon");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Delete");
			}

		} catch (Exception e) {
			Assert.fail("Unable to Hover and Select " + userOperation.toString() + ". " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterConfirmation(UserOperation userOperation, String platform) {
		try {
			if (platform.equalsIgnoreCase("desktop")) {
				if (userOperation.equals(UserOperation.DEACTIVATE)) {
					clickElement(btnDeActivate);
					ExtentLogger.pass("Clicked DeActivate Button in the Confirmation Dialog");
				} else if (userOperation.equals(UserOperation.DELETE)) {
					clickElement(btnDelete);
					ExtentLogger.pass("Clicked Delete Button in the Confirmation Dialog");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				if (userOperation.equals(UserOperation.DEACTIVATE)) {
					clickElementJS(btnDeActivateMobile);
					ExtentLogger.pass("Clicked DeActivate Button in the Confirmation Dialog");
				} else if (userOperation.equals(UserOperation.DELETE)) {

					clickElementJS(btnDeleteMobile);
					ExtentLogger.pass("Clicked Delete Button in the Confirmation Dialog");
				}
			}

		} catch (Exception e) {
			Assert.fail("Unable to provide Confirmation. " + e.getMessage());
		}

		return this;
	}

	public UsersPage verifySuccessMessage(UserOperation type) {
		String toastrLocator = null;
		try {
			if (type.equals(UserOperation.CREATE)) {
				toastrLocator = "//div[contains(text(),'" + CREATE_SUCCESS_MESSAGE + "')]";
			} else if (type.equals(UserOperation.UPDATE)) {
				toastrLocator = "//div[contains(text(),'" + UPDATE_SUCCESS_MESSAGE + "')]";
			} else if (type.equals(UserOperation.REACTIVATE)) {
				toastrLocator = "//div[contains(text(),'" + REACTIVATION_MESSAGE + "')]";
			} else if (type.equals(UserOperation.DEACTIVATE)) {
				toastrLocator = "//div[contains(text(),'" + DEACTIVATION_MESSAGE + "')]";
			} else if (type.equals(UserOperation.DELETE)) {
				toastrLocator = "//div[contains(text(),'" + DELETION_MESSAGE + "')]";
			}

			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath(toastrLocator));
			sleepFor(500);

			ExtentLogger.pass("Verified the Success Toastr Message");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Success Message. " + e.getMessage());
		}
		return this;	
	}

	public UsersPage verifyFailureMessage() {
		String toastrLocator = null;
		try {
			toastrLocator = "//div[contains(text(),'" + EXISTING_MESSAGE + "')]";
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath(toastrLocator));
			sleepFor(500);
			ExtentLogger.pass("Verified the User Creation Failure Toastr Message");

		} catch (Exception e) {
			Assert.fail("Unable to Verify Failure Message. Existing Toastr Message is not Displayed.");
		}

		return this;
	}

	public UsersPage verifyImpersonationLandingPage(UserType userType) {
		String fullname = "", impName = "";
		try {
			sleepFor(1000);
			fullname = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "IMPERSONATEFULLNAME")
					.toLowerCase().trim();
			impName = getData(profileNameOld).toLowerCase().trim();
			System.out.println("name  " +impName);

			if (!(fullname.contains(impName))) {
				throw new Exception("Profile Name(" + impName + ") does not match with Full Name(" + fullname + ")");
			}

			if (userType.equals(UserType.ADMIN)) {
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");
			} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");
			}
			ExtentLogger.pass("Verified Landing Page after Impersonation.");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Landing Page while Impersonation. " + e.getMessage());
		}

		return this;
	}

	public UsersPage selectUserType(UserType userType) {
		try {
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(userTypeSelection, getStringValue(userType))));
			ExtentLogger.pass("Successfully Selected UserType while Creating Users");
			sleepFor(300);
		} catch (Exception e) {
			Assert.fail("Unable to Select UserType while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterBasicDetails() {
		sleepFor(2000);
		try {
			HashMap<String, String> basicDetailsMap = DataGeneratorUtils.generateBasicDetails();

			enterData(txtFullname, basicDetailsMap.get("FULLNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", basicDetailsMap.get("FULLNAME"));

			enterData(txtCompany, basicDetailsMap.get("COMPANY"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COMPANY", basicDetailsMap.get("COMPANY"));

			clickElementJS(btnAddContactInfo);

			ExtentLogger.pass("Entered Basic Details without any Issues");

		} catch (Exception e) {
			Assert.fail("Unable to Enter Basic Details while Creating User. " + e.getMessage());
		}

		return this;
	}

	public String getExistingEmail(UserType userType) {
		if (userType.equals(UserType.ADMIN)) {
			return InputPropertyUtils.get("EXISTING_ADMIN_EMAIL");
		} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
			return InputPropertyUtils.get("EXISTING_MANAGER_EMAIL");
		} else if (userType.equals(UserType.CLIENT)) {
			return InputPropertyUtils.get("EXISTING_CUSTOMER_EMAIL");
		} else if (userType.equals(UserType.FULFILLMENT_CENTER)) {
			return InputPropertyUtils.get("EXISTING_FULFILLMENT_EMAIL");
		} else if (userType.equals(UserType.PRINTER)) {
			return InputPropertyUtils.get("EXISTING_PRINTER_EMAIL");
		}

		return null;

	}

	public UsersPage verifyFieldValidations(UserType userType, String platform) {

		try {
			clickAddUsersButton(platform);

			if (!RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").toLowerCase().trim()
					.equalsIgnoreCase("manager")) {
				selectUserType(userType);
			}

			ExtentLogger.pass("Verifying Validations for: " + getStringValue(userType));

			if (userType.equals(UserType.ADMIN)) {
				fullNameValidations("admin");
				phoneValidations("admin");
				emailValidations("admin");
				clickSetPassword();
				passwordValidations();
			} else if (userType.equals(UserType.CLIENT)) {
				fullNameValidations("client");
				phoneValidations("client");
				clickSetEmailPassword();
				emailValidations("client");
				passwordValidations();
				clickAddInfo();
				schoolValidations("client");
				organizationValidations("client");
				businessAndTitleValidations("client");
			} else if (userType.equals(UserType.PRINTER)) {
				fullNameValidations("printer");
				companyValidations();
				clickAddContactInfo();
				phoneValidations("printer");
				emailValidations("printer");
				clickSetPassword();
				passwordValidations();
				clickAddShippingInfo();
				shippingNameValidations(platform);
				addressValidation();
			} else if (userType.equals(UserType.FULFILLMENT_CENTER)) {
				fullNameValidations("FC");
				companyValidations();
				clickAddContactInfo();
				phoneValidations("FC");
				emailValidations("FC");
				clickSetPassword();
				passwordValidations();
				clickAddShippingInfo();
				shippingNameValidations(platform);
				addressValidation();
			} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
				fullNameValidations("CM");
				phoneValidations("CM");
				emailValidations("CM");
				clickSetPassword();
				passwordValidations();
				clickAddInfo();
				schoolValidations("client");
				organizationValidations("client");
			}
			clickElementJS(iconClose);
			if (platform.equalsIgnoreCase("desktop")) {
				clickElementJS(btnYes);
			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElementJS(btnYesMobile);
			}

		} catch (Exception e) {
			Assert.fail("Validations are not Displayed Correctly. " + e.getMessage());
		}

		return this;

	}

	public void clickSetPassword() throws Exception {
		clickElementJS(btnSetPassword);
	}

	public void clickAddContactInfo() throws Exception {
		clickElementJS(btnAddContactInfo);
	}

	public void clickSetEmailPassword() throws Exception {
		clickElementJS(btnSetEmailAndPassword);
	}

	public void clickAddShippingInfo() throws Exception {
		clickElementJS(btnAddShippingInfo);
	}

	public void clickAddInfo() throws Exception {
		clickElementJS(btnAddInfo);
	}

	public void clickCreateAccount() throws Exception {
		clickElementJS(btnCreateAccount);
	}

	public void fullNameValidations(String userType) {
		String nameInputs[] = { "123", "!@#", "Sam" };
		try {
			enterData(txtFullname, "");
			clickTab(txtFullname);

			if (!findElementPresence(
					By.xpath("//div[contains(text(),'" + EMPTY_INVALID_MESSAGE.replace("<<>>", "full name") + "')]"))) {
				throw new Exception("Empty Validation for Full Name is not Displayed");
			}

			for (int i = 0; i < nameInputs.length; i++) {
				enterData(txtFullname, nameInputs[i]);
				clickTab(txtFullname);

				if (!findElementPresence(By.xpath(
						"//div[contains(text(),'" + EMPTY_INVALID_MESSAGE.replace("<<>>", "full name") + "')]"))) {
					throw new Exception("Invalid Validation for Full Name is not Displayed for " + userType);
				}
			}

			enterData(txtFullname, DataGeneratorUtils.randFullName());
			ExtentLogger.pass("Verified Validations for Full Name");
		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for FullName. " + e.getMessage());
		}
	}

	public void phoneValidations(String userType) {
		String phoneInputs[] = { "abcd", "98765432", "&^*^*%%" };
		try {
			enterData(txtPhone, "");
			clickTab(txtPhone);

			if (!findElementPresence(By.xpath(
					"//div[contains(text(),'" + EMPTY_INVALID_MESSAGE.replace("<<>>", "phone number") + "')]"))) {
				throw new Exception("Empty Validation for Phone is not Displayed");
			}

			for (int i = 0; i < phoneInputs.length; i++) {
				enterData(txtPhone, phoneInputs[i]);
				clickTab(txtPhone);
				if (!findElementPresence(By.xpath("//div[contains(text(),'" + PHONE_INVALID_MESSAGE + "')]"))) {
					throw new Exception("Invalid Validation for Phone is not Displayed");
				}
			}
			ExtentLogger.pass("Verified Validations for Phone");
			enterData(txtPhone, DataGeneratorUtils.randPhoneNumber());

		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Phone. " + e.getMessage());
		}
	}

	public void emailValidations(String userType) {

		String emailInputs[] = { "123", "!@%", "Sam Ash" };
		try {
			sleepFor(2000);
			enterData(txtemail, "");
			clickTab(txtemail);
			sleepFor(2000);

			if (!findElementPresence(
					By.xpath("//div[contains(text(),'" + EMPTY_INVALID_MESSAGE.replace("<<>>", "email") + "')]"))) {
				throw new Exception("Empty Validation for Email is not Displayed");
			}

			for (int i = 0; i > emailInputs.length; i++) {
				sleepFor(3000);
				enterData(txtemail, emailInputs[i]);
				clickTab(txtemail);
				if (!findElementPresence(By.xpath("//*[text()=" + EMAIL_INVALID_MESSAGE + "]"))) {
					throw new Exception("Invalid Validation for Email is not Displayed");
				}
			}
			ExtentLogger.pass("Verified Validations for Email");
			enterData(txtemail, DataGeneratorUtils.randEmail(DataGeneratorUtils.randName()));
		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Email. " + e.getMessage());
		}
	}

	public void passwordValidations() {
		try {
			sleepFor(8000);
			enterData(txtPassword, "");
			clickTab(txtPassword);
			if(!findElementPresence(By.xpath("//div[contains(text(),'" + PASSWORD_EMPTY_INVALID_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for Password is not Displayed");
			}
			enterData(txtPassword, "Test123");

			enterData(txtConfirmPassword, "Test");
			clickTab(txtConfirmPassword);
			if (!findElementPresence(By.xpath("//div[contains(text(),'" + PASSWORD_MISMATCH_MESSAGE + "')]"))) {
				throw new Exception("Validation for Password Match is not Displayed");
			}

			ExtentLogger.pass("Verified Validations for Password");
			enterData(txtConfirmPassword, "Test123");

		} catch (Exception e) {
			e.printStackTrace();
			ExtentLogger.fail("Validations are not displayed as Expected for Password. " + e.getMessage());
		}
	}

	public void schoolValidations(String userType) {
		try {
			String school = DataGeneratorUtils.randSchoolName();
			clickElementJS(drpDwnSchool);
			clickTab(drpDwnSchool);
			sleepFor(200);

			if (!findElementPresence(By
					.xpath("//div[contains(text(),'" + SCHOOL_ORG_INVALID_MESSAGE.replace("<<>>", "school") + "')]"))) {
				throw new Exception("Empty Validation for School is not Displayed");
			}

			clickElementJS(drpDwnSchool);
			enterData(drpDwnSchool, school);
			sleepFor(200);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, school)));
			ExtentLogger.pass("Verified Validations for School");

		} catch (Exception e) {
			e.printStackTrace();
			ExtentLogger.fail("Validations are not displayed as Expected for School. " + e.getMessage());
		}
	}

	public void organizationValidations(String userType) {
		try {
			String org = DataGeneratorUtils.randOrganizationName();

			clickElementJS(drpDwnOrganization);
			clickTab(drpDwnOrganization);
			sleepFor(200);
			if (!findElementPresence(
					By.xpath("//div[contains(text(),'" + SCHOOL_ORG_INVALID_MESSAGE.replace("<<>>", "org") + "')]"))) {
				throw new Exception("Empty Validation for Organization is not Displayed");
			}

			clickElementJS(drpDwnOrganization);
			enterData(drpDwnOrganization, org);
			sleepFor(200);
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue, org)));
			ExtentLogger.pass("Empty Verified Validations for Organization");

		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Organization. " + e.getMessage());
		}
	}

	public void businessAndTitleValidations(String userType) {
		try {
			clickElementJS(chkBoxClientTye);

			enterData(txtBusiness, "");
			clickTab(txtBusiness);
			if (!findElementPresence(By.xpath("//div[contains(text(),'"
					+ BUSINESS_TITLE_INVALID_MESSAGE.replace("<<>>", "business name") + "')]"))) {
				throw new Exception("Empty Validation for Business is not Displayed");
			}
			ExtentLogger.pass("Verified Validations for Business");
			enterData(txtBusiness, "Test Business");

			enterData(txtTitle, "");
			clickTab(txtTitle);
			if (!findElementPresence(By.xpath(
					"//div[contains(text(),'" + BUSINESS_TITLE_INVALID_MESSAGE.replace("<<>>", "title") + "')]"))) {
				throw new Exception("Empty Validation for Title is not Displayed");
			}

			ExtentLogger.pass("Verified Validations for Title");
			enterData(txtTitle, "Test Title");

		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Business/Title. " + e.getMessage());
		}
	}

	public void companyValidations() {
		try {
			enterData(txtCompany, "");
			clickTab(txtCompany);
			if (!findElementPresence(By.xpath(
					"//div[contains(text(),'" + EMPTY_INVALID_MESSAGE.replace("<<>>", "company name") + "')]"))) {
				throw new Exception("Empty Validation for Company is not Displayed");
			}

			ExtentLogger.pass("Verified Validations for Company");
			enterData(txtCompany, "Test Company");

		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Company. " + e.getMessage());
		}
	}

	public void shippingNameValidations(String platform) {
		try {
			enterData(txtShippingName, "");
			clickTab(txtShippingName);
			if (!findElementPresence(By.xpath("//div[contains(text(),'" + SHIPPING_NAME_INVALID_MESSAGE + "')]"))) {

				throw new Exception("Empty Validation for Shipping Name is not Displayed");
			}
			ExtentLogger.pass("Verified Validations for Shipping Name");
			enterData(txtShippingName, "Test Shipping");
			if (platform.equalsIgnoreCase("desktop")) {
				clickElement(btnNext);
			}

		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Shipping Name. " + e.getMessage());
		}
	}

	public void addressValidation() {
		try {
			enterData(txtStreet, "");
			clickTab(txtStreet);
			if (!findElementPresence(By.xpath(
					"//div[contains(text(),'" + ADDRESS_INVALID_MESSAGE.replace("<<>>", "street name") + "')]"))) {
				throw new Exception("Empty Validation for Street Name is not Displayed");
			}

			enterData(txtStreet, DataGeneratorUtils.randStreet());

			enterData(txtCity, "");
			clickTab(txtCity);
			if (!findElementPresence(

					By.xpath("//div[contains(text(),'" + ADDRESS_INVALID_MESSAGE.replace("<<>>", "city") + "')]"))) {
				throw new Exception("Empty Validation for City Name is not Displayed");
			}

			clickElement(drpDwnState);
			enterData(drpDwnState, "");
			clickTab(drpDwnState);
			if (!findElementPresence(By.xpath("//div[contains(text(),'" + STATE_INVALID_MESSAGE + "')]"))) {
				throw new Exception("Empty Validation for State is not Displayed");
			}

			clickElement(drpDwnState);
			enterData(drpDwnState, DataGeneratorUtils.randString());
			if (!findElementPresence(noStateFoundOption)) {
				throw new Exception("No State Found Option is not Displayed");
			}
			clickTab(drpDwnState);

			enterData(txtZipCode, "");
			clickTab(txtZipCode);
			if (!findElementPresence(By
					.xpath("//div[contains(text(),'" + ADDRESS_INVALID_MESSAGE.replace("<<>>", "zip code") + "')]"))) {
				throw new Exception("Empty Validation for State is not Displayed");
			}
			ExtentLogger.pass("Verified Validations for Address");
		} catch (Exception e) {
			ExtentLogger.fail("Validations are not displayed as Expected for Address. " + e.getMessage());
		}
	}

	public UsersPage enterContactDetails(UserType userType, UserOperation userOperation) {
		try {
			HashMap<String, String> contactDetailsMap = DataGeneratorUtils.generateContactDetails();

			if (getTestCaseName().toLowerCase().contains("existing")) {
				contactDetailsMap.put("EMAIL", getExistingEmail(userType));
			}

			if (userOperation.equals(UserOperation.CREATE)) {
				sleepFor(3000);
				if (userType.equals(UserType.ADMIN) || userType.equals(UserType.CAMPUS_MANAGER)) {
					enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
							contactDetailsMap.get("FULLNAME"));

					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					if (userOperation.equals(UserOperation.CREATE)) {
						enterData(txtemail, contactDetailsMap.get("EMAIL"));
						RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL",
								contactDetailsMap.get("EMAIL"));
					}

					clickElementJS(btnSetPassword);
				}

				else if (userType.equals(UserType.CLIENT)) {
					enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
							contactDetailsMap.get("FULLNAME"));

					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					clickElementJS(btnSetEmailAndPassword);
				}

				else if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {
					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					enterData(txtemail, contactDetailsMap.get("EMAIL"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL",
							contactDetailsMap.get("EMAIL"));

					clickElementJS(btnSetPassword);
				}

				ExtentLogger.pass("Successfully Entered Contact Details while Creating Users");
			} else if (userOperation.equals(UserOperation.UPDATE)) {
				if (userType.equals(UserType.ADMIN) || userType.equals(UserType.CAMPUS_MANAGER)) {
					enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
							contactDetailsMap.get("FULLNAME"));

					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					if (userOperation.equals(UserOperation.CREATE)) {
						enterData(txtemail, contactDetailsMap.get("EMAIL"));
						RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL",
								contactDetailsMap.get("EMAIL"));
					}

					clickElementJS(btnSetPassword);
				}

				else if (userType.equals(UserType.CLIENT)) {
					enterData(txtFullname, contactDetailsMap.get("FULLNAME"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
							contactDetailsMap.get("FULLNAME"));

					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					clickElementJS(btnSetEmailAndPassword);
				}

				else if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {
					enterData(txtPhone, contactDetailsMap.get("PHONENUMBER"));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER",
							contactDetailsMap.get("PHONENUMBER"));

					clickElementJS(btnSetPassword);
				}

				ExtentLogger.pass("Successfully Entered Contact Details while Editing Users");
			}

		} catch (Exception e) {
			Assert.fail("Unable to Enter Contact Details while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterPasswordDetails(UserType userType, UserOperation userOperation) {
		try {
			HashMap<String, String> passwordDetailsMap = DataGeneratorUtils.generatePasswordDetails();

			if (getTestCaseName().toLowerCase().contains("existing")) {
				passwordDetailsMap.put("EMAIL", getExistingEmail(userType));
			}

			if (userType.equals(UserType.CLIENT)) {
				enterData(txtemail, passwordDetailsMap.get("EMAIL"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", passwordDetailsMap.get("EMAIL"));
			}
			sleepFor(300);
			enterData(txtPassword, passwordDetailsMap.get("PASSWORD"));
			enterData(txtConfirmPassword, passwordDetailsMap.get("PASSWORD"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD",
					passwordDetailsMap.get("PASSWORD"));
			ExtentLogger.pass("Successfully Entered Password Details for the User");

			if (userType.equals(UserType.CLIENT) || userType.equals(UserType.CAMPUS_MANAGER)) {
				clickElementJS(btnAddInfo);

			} else if (!userType.equals(UserType.ADMIN)) {
				clickElementJS(btnAddShippingInfo);

			}

		} catch (Exception e) {
			Assert.fail("Unable to Enter Password Details while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterSchoolAndOrganizationDetails(UserType userType, UserOperation userOperation) {
		try {
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();
			String randOrg = InputPropertyUtils.get("CUSTOM_ORG_NAME"),
					randSchool = InputPropertyUtils.get("CUSTOM_SCHOOL_NAME");

			clickElementJS(drpDwnSchool);
			sleepFor(200);

			if (getTestCaseName().toLowerCase().contains("customschool")) {
				enterData(drpDwnSchool, randSchool);
				if (!findElementPresence(itemNoSchool)) {
					ExtentLogger.fail("No School Found is not displayed for Custom School. ");
				}
				enterData(drpDwnSchool, "Other");
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, "Other")));

				enterData(txtSchool, randSchool);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", "Other");
			} else {
				enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
				clickElementJS(By
						.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));
			}

			clickElementJS(drpDwnOrganization);
			sleepFor(200);
			if (getTestCaseName().toLowerCase().contains("customorganization")) {
				enterData(drpDwnOrganization, randOrg);

				
				if (!findElementPresence(itemNoOrg)) {
					ExtentLogger.fail("No Organization Found is not displayed for Custom Organization.");
				}

				enterData(drpDwnOrganization, "Other");
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue, "Other")));

				enterData(txtOrganization, randOrg);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", "Other");
			} else {
				enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
				sleepFor(200);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
						schoolDetailsMap.get("ORGANIZATION"))));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
						schoolDetailsMap.get("ORGANIZATION"));
			}

			sleepFor(500);
			ExtentLogger.pass("Filled School/Org Details for the User");

		} catch (Exception e) {
			Assert.fail("Unable to Enter School/Business Details while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterSchoolAndOrganizationDetails(String type, UserOperation userOperation) {
		try {
			HashMap<String, String> schoolDetailsMap = DataGeneratorUtils.generateSchoolAndOrgDetails();
			sleepFor(300);

			if (type.equalsIgnoreCase("business")) {
				clickElementJS(chkBoxClientTye);

				enterData(txtBusiness, schoolDetailsMap.get("BUSINESS"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BUSINESS",
						schoolDetailsMap.get("BUSINESS"));

				enterData(txtTitle, schoolDetailsMap.get("TITLE"));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TITLE", schoolDetailsMap.get("TITLE"));
			} else if (type.equalsIgnoreCase("school")) {
				sleepFor(2000);
				clickElementJS(drpDwnSchool);
				sleepFor(200);
				enterData(drpDwnSchool, schoolDetailsMap.get("SCHOOL"));
				sleepFor(200);
				clickElementJS(By
						.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, schoolDetailsMap.get("SCHOOL"))));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", schoolDetailsMap.get("SCHOOL"));

				clickElementJS(drpDwnOrganization);
				sleepFor(200);
				enterData(drpDwnOrganization, schoolDetailsMap.get("ORGANIZATION"));
				sleepFor(200);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue,
						schoolDetailsMap.get("ORGANIZATION"))));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION",
						schoolDetailsMap.get("ORGANIZATION"));
				sleepFor(2000);
				/* added by vidya on 03.25.2022 */
				clickElementJS(btnPosition);
				enterData(btnPosition, "Apparel 123");
				sleepFor(2000);

				clickElementJS(By.xpath(
						DynamicXpathUtils.getXpathForString(txtgraduationYear, schoolDetailsMap.get("GRADYEAR"))));
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "GRADYEAR",
						schoolDetailsMap.get("GRADYEAR"));
			}

		} catch (Exception e) {
			Assert.fail("Unable to Enter School/Org Details while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage enterShippingAddress(UserOperation userOperation, String platform) {
		try {
			HashMap<String, String> shippingDetailsMap = null;

			if (getTestCaseName().toLowerCase().contains("invalidaddress")) {
				shippingDetailsMap = DataGeneratorUtils.generateShippingDetails("Invalid");
			} else {
				shippingDetailsMap = DataGeneratorUtils.generateShippingDetails("Valid");
			}

			enterData(txtShippingName, shippingDetailsMap.get("SHIPPINGNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPINGNAME",
					shippingDetailsMap.get("SHIPPINGNAME"));

			enterData(txtAttentionName, shippingDetailsMap.get("ATTENTIONNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ATTENTIONNAME",
					shippingDetailsMap.get("ATTENTIONNAME"));

			if (!platform.equalsIgnoreCase("mobile")) {
				clickElementJS(btnNext);
			}

			enterData(txtStreet, shippingDetailsMap.get("STREET"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STREET", shippingDetailsMap.get("STREET"));

			enterData(txtSuite, shippingDetailsMap.get("SUITE"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUITE", shippingDetailsMap.get("SUITE"));

			enterData(txtCity, shippingDetailsMap.get("CITY"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CITY", shippingDetailsMap.get("CITY"));

			clickElement(drpDwnState);
			enterData(drpDwnState, shippingDetailsMap.get("STATE"));
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnStateValue, shippingDetailsMap.get("STATE"))));

			enterData(txtZipCode, shippingDetailsMap.get("ZIPCODE"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ZIPCODE", shippingDetailsMap.get("ZIPCODE"));

			clickElement(
					By.xpath(DynamicXpathUtils.getXpathForString(txtTimezone, shippingDetailsMap.get("TIMEZONE"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TIMEZONE",
					shippingDetailsMap.get("TIMEZONE"));

			ExtentLogger.pass("Entered Shipping Address Fields Successfully");

			if (getTestCaseName().toLowerCase().contains("invalidaddress")) {
				clickElementJS(btnCreateAccount);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, divInvalidAddress);
				clickElement(btnNo);
				ExtentLogger.pass("Address Validations are verified Successfully");
				clickElementJS(iconClose);
				clickElementJS(btnYes);

			}

		} catch (Exception e) {
			Assert.fail("Unable to Enter Shipping Address while Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage verifyAccountSummary(UserType userType, UserOperation userOperation, String platform) {
		try {
			if (userOperation.equals(UserOperation.CREATE)) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'Account Created')]"));
				clickElementJS(By.xpath("//div[contains(text(),'Account Created')]"));
			} else if (userOperation.equals(UserOperation.UPDATE)) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'Account Updated')]"));
				clickElementJS(By.xpath("//div[contains(text(),'Account Updated')]"));
			}

			verifyContactDetails(userType);
			verifyPasswordDetails(userType);
			verifySchoolAndOrgDetails(userType);
			verifyShippingDetails(userType, platform);

			ExtentLogger.pass("Verified the Data in Account Summary Page.");
			if (userOperation.equals(UserOperation.UPDATE)) {
				clickElementJS(btnBackToWork);
			}

		} catch (Exception e) {
			Assert.fail("Unable to Verify Account Summary while Creating User. " + e.getMessage());
		}

		return this;
	}

	public void verifyContactDetails(UserType userType) throws Exception {
		String fullName, phoneNumber, company;
		sleepFor(1000);
		try {
			if (userType.equals(UserType.ADMIN) || userType.equals(UserType.CAMPUS_MANAGER)) {
//				fullName = "app-contact-info > div > div.form-wrapper__form-fields.ng-star-inserted > div.form-group > app-input > div > input";
//				phoneNumber = "app-contact-info > div > div:nth-child(2) > div.form-group > app-input > div > input";

				fullName = "input[ng-reflect-name='fname']";
				phoneNumber = "input[ng-reflect-name='phone']";

				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(fullName).toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME").toLowerCase(),
						"FullName Doesn't Match.");
				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(phoneNumber),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PHONENUMBER"),
						"Phone Number Doesn't Match.");

			} else if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {
//				fullName = "app-contact-info > div > div:nth-child(1) > div.form-group > app-input > div > input";
//				company = "app-contact-info > div > div:nth-child(2) > div.form-group > app-input > div > input";
//				phoneNumber = "app-contact-info > div > div:nth-child(3) > div.form-group > app-input > div > input";

				fullName = "input[ng-reflect-name='fname']";
				company = "input[ng-reflect-name='company']";
				phoneNumber = "input[ng-reflect-name='phone']";

				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(fullName).toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME").toLowerCase(),
						"FullName Doesn't Match.");
				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(phoneNumber),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PHONENUMBER"),
						"Phone Number Doesn't Match.");
				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(company).toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMPANY").toLowerCase(),
						"Company Doesn't Match.");

			} else if (userType.equals(UserType.CLIENT)) {
//				fullName = "app-contact-info > div > div.form-wrapper__form-fields.ng-star-inserted > div.form-group > app-input > div > input";
//				phoneNumber = "app-contact-info > div > div:nth-child(2) > div.form-group > app-input > div > input";

				fullName = "input[ng-reflect-name='fname']";
				phoneNumber = "input[ng-reflect-name='phone']";

				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(fullName).toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME").toLowerCase(),
						"FullName Doesn't Match.");
				Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(phoneNumber),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PHONENUMBER"),
						"Phone Number Doesn't Match.");
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	public void verifyPasswordDetails(UserType userType) throws Exception {
		String email, password;
		sleepFor(1000);
		try {
//			email = "app-set-password > div > div.form-wrapper__form-fields.ng-star-inserted > div.form-group > app-input > div > input";
//			password = "app-set-password > div > div:nth-child(2) > div.form-group.position-relative > app-input > div > input";
			email = "input[ng-reflect-name='email']";
			password = "input[ng-reflect-name='password']";

			Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(email).toLowerCase(),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL").toLowerCase(),
					"Email Doesn't Match.");
			Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(password),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PASSWORD"),
					"Password Doesn't Match.");

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	public void verifySchoolAndOrgDetails(UserType userType) throws Exception {
		String schoolName, organizationName, gradYear;
		String business, title;
		sleepFor(1000);
		try {
			if (userType.equals(UserType.CAMPUS_MANAGER)) {
				schoolName = "(//div[contains(text(),'School')])[2]//following::span[2]";
				organizationName = "//div[contains(text(),'Organization')]//following::span[2]";

				Assert.assertEquals(DriverManager.getDriver().findElement(By.xpath(schoolName)).getText().toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL").toLowerCase(),
						"School Name Name Doesn't Match.");
				Assert.assertEquals(
						DriverManager.getDriver().findElement(By.xpath(organizationName)).getText().toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION").toLowerCase(),
						"Organization Doesn't Match.");

			} else if (userType.equals(UserType.CLIENT)) {

				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))) {
//					business = "app-school-organization > div > div > div:nth-child(1) > div.form-group > app-input > div > input";
//					title = "app-school-organization > div > div > div:nth-child(2) > div.form-group > app-input > div > input";
//
//					Assert.assertEquals(readDataUsingJavascriptExecutor(business).toLowerCase(),
//							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BUSINESS").toLowerCase(),
//							"Business Doesn't Match.");
//					Assert.assertEquals(readDataUsingJavascriptExecutor(title).toLowerCase(),
//							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TITLE").toLowerCase(),
//							"Title Doesn't Match.");

					business = "input[ng-reflect-name='business']";
					title = "input[ng-reflect-name='title']";

					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(business).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BUSINESS").toLowerCase(),
							"Business Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(title).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TITLE").toLowerCase(),
							"Title Doesn't Match.");

				} else {
					schoolName = "(//div[contains(text(),'School')])[2]//following::span[2]";
					organizationName = "//div[contains(text(),'Organization')]//following::span[2]";
					gradYear = "//div[contains(text(),'Grad')]//following::div[contains(@class,'selected')]";

					Assert.assertEquals(
							DriverManager.getDriver().findElement(By.xpath(schoolName)).getText().toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL").toLowerCase(),
							"School Doesn't Match.");
					Assert.assertEquals(
							DriverManager.getDriver().findElement(By.xpath(organizationName)).getText().toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION")
									.toLowerCase(),
							"Organization Doesn't Match.");
					Assert.assertEquals(DriverManager.getDriver().findElement(By.xpath(gradYear)).getText(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "GRADYEAR"),
							"Graduation Year Doesn't Match.");
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}

	public void verifyShippingDetails(UserType userType, String platform) throws Exception {
		String shippingName = "", attentionName = "", streetName = "", suiteName = "", city = "", zipcode = "",
				timezone = "";
		sleepFor(1000);

		try {
			if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {

				if (platform.equalsIgnoreCase("desktop")) {
//					shippingName = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.ng-star-inserted > div:nth-child(1) > div.form-group > app-input > div > input";
//					attentionName = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.ng-star-inserted > div:nth-child(2) > div.form-group > app-input > div > input";
//					streetName = "app-shipping-address > div > div:nth-child(2) > div:nth-child(1) > div.form-group > app-input > div > input";
//					suiteName = "app-shipping-address > div > div:nth-child(2) > div:nth-child(2) > div.form-group > app-input > div > input";
//					city = "app-shipping-address > div > div:nth-child(3) > div:nth-child(1) > div.form-group > app-input > div > input";
//					zipcode = "app-shipping-address > div > div:nth-child(4) > div.form-wrapper__form-fields.address-form__field.ng-star-inserted > div.form-group > app-input > div > input";
//					timezone = "//div[contains(text(),'Select Timezone')]//following::div[2]";

					shippingName = "input[ng-reflect-name='shipping']";
					attentionName = "input[ng-reflect-name='attention']";
					streetName = "input[ng-reflect-name='street']";
					suiteName = "input[ng-reflect-name='suite']";
					city = "input[ng-reflect-name='city']";
					zipcode = "input[ng-reflect-name='zipcode']";
					timezone = "//div[contains(text(),'Select Timezone')]//following::div[2]";

					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(shippingName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SHIPPINGNAME")
									.toLowerCase(),
							"Shipping Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(attentionName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ATTENTIONNAME")
									.toLowerCase(),
							"Attention Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(streetName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STREET").toLowerCase(),
							"Street Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(suiteName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUITE").toLowerCase(),
							"Suite Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(city).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CITY").toLowerCase(),
							"City Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutorFromCSSLocator(zipcode),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ZIPCODE"),
							"ZipCode Doesn't Match.");
					Assert.assertEquals(DriverManager.getDriver().findElement(By.xpath(timezone)).getText(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TIMEZONE"),
							"TimeZone Doesn't Match.");

				} else if (platform.equalsIgnoreCase("mobile")) {
					shippingName = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.shipping-attn-wrapper.ng-star-inserted > div:nth-child(1) > div.form-group > app-input > div > input";
					attentionName = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.shipping-attn-wrapper.ng-star-inserted > div:nth-child(2) > div.form-group > app-input > div > input";
					streetName = "app-shipping-address > div > div.form-wrapper__form-fields.address-form__field.ng-star-inserted > div.form-group > app-input > div > input";
					suiteName = "app-shipping-address > div > div:nth-child(3) > div > div.form-group > app-input > div > input";
					city = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.state-city-wrapper > div.form-wrapper__form-fields.address-form__field.city-field > div.form-group > app-input > div > input";
					zipcode = "app-shipping-address > div > div.d-flex.address-form__address-row.mx-auto.state-city-wrapper > div.d-flex.address-form__field.ng-star-inserted > div.form-wrapper__form-fields.zipcode-field > div.form-group > app-input > div > input";
					timezone = "//div[contains(text(),'Select Timezone')]//following::div[contains(@class,'selected')]";

					Assert.assertEquals(
							readDataUsingJavascriptExecutor(shippingName).toLowerCase(), RunTimePropertyFileUtils
									.getRunTimeProperty(getTestCaseName(), "SHIPPINGNAME").toLowerCase(),
							"Shipping Name Doesn't Match.");
					Assert.assertEquals(
							readDataUsingJavascriptExecutor(attentionName).toLowerCase(), RunTimePropertyFileUtils
									.getRunTimeProperty(getTestCaseName(), "ATTENTIONNAME").toLowerCase(),
							"Attention Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutor(streetName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "STREET").toLowerCase(),
							"Street Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutor(suiteName).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SUITE").toLowerCase(),
							"Suite Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutor(city).toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "CITY").toLowerCase(),
							"City Name Doesn't Match.");
					Assert.assertEquals(readDataUsingJavascriptExecutor(zipcode),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ZIPCODE"),
							"ZipCode Doesn't Match.");
					Assert.assertEquals(DriverManager.getDriver().findElement(By.xpath(timezone)).getText(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TIMEZONE"),
							"TimeZone Doesn't Match.");
				}

			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// changes done by vidya on june 22
	public UsersPage editAccountSummary(UserType userType) {
		try {
			String fname = DataGeneratorUtils.randFullName(), phone = DataGeneratorUtils.randPhoneNumber(),
					school = DataGeneratorUtils.randSchoolName(), org = DataGeneratorUtils.randOrganizationName(),
					title = DataGeneratorUtils.randTitle(), company = DataGeneratorUtils.randCompany(),
					business = DataGeneratorUtils.randBusiness(), shippingName = DataGeneratorUtils.randShipmentName(),
					attentionName = DataGeneratorUtils.randAttentionName();

			enterData(txtFullname, fname);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME", fname);
			enterData(txtPhone, phone);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PHONENUMBER", phone);

	//		if (userType.equals(UserType.CLIENT) || userType.equals(UserType.CAMPUS_MANAGER))
				if (userType.equals(UserType.CAMPUS_MANAGER)) {
				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))
						&& !findElementPresence(drpDwnSchool)) {
					enterData(txtBusiness, business);
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BUSINESS", business);

					enterData(txtTitle, title);
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TITLE", title);

				}   else {
					clickElementJS(drpDwnSchool);
					enterData(drpDwnSchool, "");
					enterData(drpDwnSchool, school);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, school)));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", school);

					clickElementJS(drpDwnOrganization);
					enterData(drpDwnOrganization, "");
					enterData(drpDwnOrganization, org);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue, org)));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", org);

				}

			}
			
			if (userType.equals(UserType.CLIENT) ) {
				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))
						&& !findElementPresence(drpDwnSchool)) {
					enterData(txtBusiness, business);
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "BUSINESS", business);

					enterData(txtTitle, title);
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TITLE", title);


				}   else {
					clickElementJS(drpDwnSchool);
					enterData(drpDwnSchool, "");
					enterData(drpDwnSchool, school);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnSchoolValue, school)));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SCHOOL", school);

					clickElementJS(drpDwnOrganization);
					enterData(drpDwnOrganization, "");
					enterData(drpDwnOrganization, org);
					clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnOrganizationValue, org)));
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ORGANIZATION", org);
					
					clickElementJS(btnPosition);
					enterData(btnPosition, "");
					enterData(btnPosition, "Apparel 123");
					sleepFor(2000);
					

				}

			}
			
			
			else if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {
				enterData(txtCompany, company);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "COMPANY", company);

				enterData(txtShippingName, shippingName);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPINGNAME", shippingName);

				enterData(txtAttentionName, attentionName);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ATTENTIONNAME", attentionName);
			}

			ExtentLogger.pass("Edited the Existing Details Succesfully");

			clickElementJS(btnSaveEdits);
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					By.xpath("//div[contains(text(),'" + UPDATE_SUCCESS_MESSAGE + "')]"));
			ExtentLogger.pass("Verified Updation Toaster Message");

		} catch (Exception e) {
			Assert.fail("Unable to Edit Account Summary. " + e.getMessage());
		}

		return this;
	}

	public UsersPage navigateToUsersDashboard(UserOperation userOperation, String platform) {
		try {
			clickElement(btnBackToWork);
			if (userOperation.equals(UserOperation.UPDATE) && platform.equalsIgnoreCase("mobile")) {
				clickElementJS(iconCloseMoreOptionsMobile);
				if (findElementPresence(iconCloseMoreOptionsMobile)) {
					clickElementJS(iconCloseMoreOptionsMobile);
				}
			}
			ExtentLogger.pass("Successfully Navigated back to Users Dashboard after creating User");
			sleepFor(2000);
		} catch (Exception e) {
			Assert.fail("Unable to Navigate to Users Dashboard after Creating User. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterAndVerifyDashboard(UserType userType, UserOperation userOperation) {
		try {
			String email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
			enterData(txtFilterData, email);
			System.out.println(txtFilterData);
			sleepFor(1000);
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin")) {
				switchTo(userType);
			}
			ArrayList<HashMap<String, String>> completeData = readCurrentTable(userType);
			sleepFor(4000);

			if (userOperation.equals(UserOperation.DELETE)) {

				if (completeData.size() != 0) {
					throw new Exception("Deleted User is still displayed after Filter.");
				}
				ExtentLogger.pass("Verified that the Deleted User is not displayed in Dashboard");
			} else if (userOperation.equals(UserOperation.VIEW)) {

				if (completeData.size() != 1) {
					throw new Exception("Deleted User is not displayed in Admin's Dashboard.");
				}
				ExtentLogger.pass("Verified that the Deleted User is displayed in Admin's Dashboard");

			} else {

				if (completeData.size() > 1 || completeData.size() < 1) {

					throw new Exception("Unable to Filter Created User");
				}

				verifyDashboard(userType, completeData.get(0));
				ExtentLogger.pass("Filtered and Verified the User Details");
			}

		} catch (Exception e) {
			Assert.fail("Failed to Verify Dashboard. " + e.getMessage());
		}

		return this;

	}

	public void verifyDashboard(UserType userType, HashMap<String, String> data) {
		try {
			Assert.assertEquals(data.get("Full name").toLowerCase(),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME").toLowerCase(),
					"FullName Doesn't Match.");
			Assert.assertEquals(data.get("Email").toLowerCase(),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL").toLowerCase(),
					"Email Doesn't Match.");
			Assert.assertEquals(data.get("Phone"),
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "PHONENUMBER").toLowerCase(),
					"Phone Doesn't Match.");

			if (userType.equals(UserType.PRINTER) || userType.equals(UserType.FULFILLMENT_CENTER)) {
				Assert.assertEquals(data.get("Company").toLowerCase(),
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMPANY").toLowerCase(),
						"Company Doesn't Match.");
			}

			if (userType.equals(UserType.CLIENT)) {

				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin")) {

					if (Objects
							.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE"))) {
						Assert.assertEquals(data.get("Campus Manager").toLowerCase(),
								InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME").toLowerCase(),
								"Campus Manager is not Updated correctly in the Table. ");

					} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE")
							.equalsIgnoreCase("assign")) {
						Assert.assertEquals(data.get("Campus Manager").toLowerCase(),
								InputPropertyUtils.get("MASTER_MANAGER_USERNAME").toLowerCase(),
								"Campus Manager is not Updated correctly in the Table. ");

					} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE")
							.equalsIgnoreCase("reassign")) {
						Assert.assertEquals(data.get("Campus Manager").toLowerCase(),
								InputPropertyUtils.get("VERIFY_MANAGER_USERNAME").toLowerCase(),
								"Campus Manager is not Updated correctly in the Table. ");
					}

				}

				if (Objects.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))) {
					Assert.assertEquals(data.get("Company").toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BUSINESS").toLowerCase(),
							"Company Doesn't Match.");
				} else {

					Assert.assertEquals(data.get("School").toLowerCase(),
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL").toLowerCase(),
							"School Doesn't Match.");
					Assert.assertEquals(
							data.get("Organization").toLowerCase(), RunTimePropertyFileUtils
									.getRunTimeProperty(getTestCaseName(), "ORGANIZATION").toLowerCase(),
							"Organization Doesn't Match.");
				}
			}
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	public UsersPage assignCampusManager(String type) {
		try {
			sleepFor(2000);
			String assignCMUserName = InputPropertyUtils.get("MASTER_MANAGER_USERNAME");
			String reassignCMName = InputPropertyUtils.get("VERIFY_MANAGER_USERNAME");

			enterData(txtFilterData, RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL"));

			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnCampusManager,
					RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL"))));

			if (type.equalsIgnoreCase("assign")) {
				enterData(drpDwnCampusManagerInput, assignCMUserName);
				clickElementJS(
						By.xpath(DynamicXpathUtils.getXpathForString(drpDwnCampusManagerValue, assignCMUserName)));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + UPDATE_MANAGER_TO_CLIENT_MESSAGE + "')]"));
				ExtentLogger.pass("Successfully Assigned " + assignCMUserName + " Campus Manager to the Client");

			} else if (type.equalsIgnoreCase("reassign")) {
				enterData(drpDwnCampusManagerInput, reassignCMName);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpDwnCampusManagerValue, reassignCMName)));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
						By.xpath("//div[contains(text(),'" + UPDATE_MANAGER_TO_CLIENT_MESSAGE + "')]"));
				ExtentLogger.pass("Successfully Assigned " + reassignCMName + " Campus Manager to the Client");

			}
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", type);

		} catch (Exception e) {
			Assert.fail("Unable to Assign Campus Manager for the Client. " + e.getMessage());
		}

		return this;
	}

	public UsersPage stopImpersonationAndVerifyLandingPage(UserType userType, String platform) {
		String fullname = "", impName = "";
		try {
			fullname = InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME").toLowerCase().trim();

			if (platform.equalsIgnoreCase("desktop")) {
				clickElementJS(btnStopImpersonation);
				sleepFor(1000);
				impName = getData(profileNameOld).toLowerCase().trim();

				if (!(fullname.contains(impName))) {
					throw new Exception(
							"Profile Name(" + impName + ") does not match with Full Name(" + fullname + ")");
				}
			} else if (platform.equalsIgnoreCase("mobile")) {
				clickElementJS(btnStopImpersonation);
				sleepFor(1000);
			}

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");
			ExtentLogger.pass("Stopped Impersonation and Verified Landing Page");
		} catch (Exception e) {
			Assert.fail("Unable to Stop Impersonation and Verify Landing Page. " + e.getMessage());
		}

		return this;
	}

	public UsersPage clickBackAndVerifyLandingPage(String platform) {
		String fullname = "", impName = "";
		try {
			fullname = InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME").trim();

			if (platform.equalsIgnoreCase("desktop")) {
				DriverManager.getDriver().navigate().back();
				sleepFor(2000);
				impName = getData(profileNameNew).trim();
				if ((fullname.toLowerCase().contains(impName.toLowerCase()))) {
					throw new Exception(
							"Impersonation is Stopped and lanaded Back to Admin's Dashboard which is not expected.");
				}
			}

//			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");
			ExtentLogger.pass("Clicked Back Icon and Verified Landing Page");
		} catch (Exception e) {
			Assert.fail("Failed in Clicking Back and Verifying Landing Page. " + e.getMessage());
		}
		return this;
	}

	public UsersPage clickAndChooseFilter(String filterType) {
		try {
			clickElement(btnFilter);
			sleepFor(300);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());

			if (filterType.toLowerCase().contains("custom")) {
				clickElement(
						By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType.split(" ")[1])));
			} else {
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));
			}

			ExtentLogger.pass(
					"Successfully Selected as " + filterType.split(" ")[filterType.split(" ").length - 1] + " Filter.");
		} catch (Exception e) {
			Assert.fail("Failed During Choosing Filter. " + e.getMessage());
		}

		return this;
	}

	public UsersPage getFilterOptionsAndVerify(String filterType) {
		HashSet<String> colData = null;
		List<WebElement> options = null;
		List<String> column = null;
		HashSet<String> optData = null;
		try {
			column = readCompleteColumnData(getColumnIndex(filterType), UserTabs.CLIENT);
			optData = new HashSet<>();
			colData = new HashSet<>();

			for (String item : column) {
				if (item.length() > 0)
					colData.add(item);
			}

			clickElement(btnFilter);
			sleepFor(300);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDAS", filterType.toString());
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilterOption, filterType)));
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)));

			options = DriverManager.getDriver().findElements(By.xpath("//span[contains(@class,'ng-option-label')]"));

			for (WebElement option : options)
				optData.add(option.getText());

			if (optData.equals(colData)) {
				ExtentLogger.pass("Verified the List of Options available for Filtering as " + filterType
						+ ". Items available for filter and Items Available in DataTable matches. "
						+ colData.toString());

			} else {
				ExtentLogger.fail("List of filter options are not as Expected for " + filterType
						+ ". Items Available in the DataTable are: " + colData.toString()
						+ " whereas Items Available in Filter are " + optData.toString());
			}

			sleepFor(3000);
			clickElement(txtFilterData);
		} catch (Exception e) {
			Assert.fail("Failed in Verifing Options. " + e.getMessage());
		}

		return this;
	}

	public UsersPage applyFilter(String filterType) {
		try {
			String filterValue = "";

			if (filterType.equalsIgnoreCase("campus manager")) {

				filterValue = InputPropertyUtils.get("EXISTING_MANAGER_USERNAME");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} else if (filterType.equalsIgnoreCase("school")) {

				filterValue = InputPropertyUtils.get("EXISTING_SCHOOL_NAME");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE",
						InputPropertyUtils.get("EXISTING_SCHOOL_NAME"));

			} else if (filterType.equalsIgnoreCase("organization")) {

				filterValue = InputPropertyUtils.get("EXISTING_ORGANIZATION_NAME");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			} else if (filterType.equalsIgnoreCase("company")) {

				filterValue = InputPropertyUtils.get("EXISTING_COMPANY_NAME");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType)), filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} else if (filterType.equalsIgnoreCase("custom organization")) {

				filterValue = InputPropertyUtils.get("CUSTOM_ORG_NAME");

				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType.split(" ")[1])),
						filterValue);
				clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);

			} else if (filterType.equalsIgnoreCase("custom school")) {

				filterValue = InputPropertyUtils.get("CUSTOM_SCHOOL_NAME");
				enterData(By.xpath(DynamicXpathUtils.getXpathForString(txtFilterOption, filterType.split(" ")[1])),
						filterValue);
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOption, filterValue)));

				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTEREDVALUE", filterValue);
			}

			else {

				throw new Exception(filterType + " is not supported.");
			}
			ExtentLogger.pass("Selected Filter Type as " + filterType.split(" ")[filterType.split(" ").length - 1]
					+ " and Filtered " + filterValue);
		} catch (Exception e) {
			Assert.fail("Unable to Filter User As " + filterType.split(" ")[filterType.split(" ").length - 1] + ". "
					+ e.getMessage());
		}

		return this;
	}

	public UsersPage verifyDashboard() {
		String filterType = "", filterValue = "";
		ArrayList<HashMap<String, String>> completeData = null;
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDAS");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTEREDVALUE");
			if (filterType.equalsIgnoreCase("campus manager")) {
				completeData = readCurrentTable(UserType.CLIENT);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Campus Manager").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Campus Manager");
					}
				}
			} else if (filterType.equalsIgnoreCase("school")) {
				completeData = readCurrentTable(UserType.CLIENT);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("School").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected School");
					}
				}
			} else if (filterType.equalsIgnoreCase("organization")) {
				completeData = readCurrentTable(UserType.CLIENT);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Organization").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Organization");
					}
				}
			} else if (filterType.equalsIgnoreCase("company")) {
				completeData = readCurrentTable(UserType.CLIENT);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Company").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Company");
					}
				}
			} else if (filterType.equalsIgnoreCase("custom organization")) {
				completeData = readCurrentTable(UserType.CAMPUS_MANAGER);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("Organization").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected Organization");
					}
				}
			} else if (filterType.equalsIgnoreCase("custom school")) {
				completeData = readCurrentTable(UserType.CAMPUS_MANAGER);

				for (HashMap<String, String> eachRow : completeData) {
					if (!eachRow.get("School").equalsIgnoreCase(filterValue)) {
						throw new Exception("Filtered Records doesn't have the expected School");
					}
				}
			}

			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass(
					"Found " + completeData.size() + " matches after applying Filter. Verified all Matched Records has "
							+ filterType.split(" ")[filterType.split(" ").length - 1] + " as " + filterValue + ".");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Dashboard after filtering. " + e.getMessage());
		}

		return this;
	}

	// changes done by vidya
	public int getColumnIndex(String colName) throws Exception {

		int index = 0;

		if (colName.equalsIgnoreCase("full name"))
			 index = 1;
			//index = 5;
		else if (colName.equalsIgnoreCase("type"))
			// index = 2;
		//	index = 8;
		//	index = 6;
			index = 4;
		else if (colName.equalsIgnoreCase("campus manager"))
			// index = 3;
		//	index = 11;
		index = 9;
		else if (colName.equalsIgnoreCase("email"))
			// index = 4;
		//	index = 16;
	//	index = 11;
		index = 9;
		else if (colName.equalsIgnoreCase("phone"))
			// index = 5;
		//	index = 21;
		//	index = 14;
			index = 11;
		else if (colName.equalsIgnoreCase("school"))
			// index = 6;
		//	index = 26;
	//	index = 17;
		index = 15;
		else if (colName.equalsIgnoreCase("organization"))
			// index = 7;
		//	index = 31;
		//	index = 20;
		index = 18;
		else if (colName.equalsIgnoreCase("company"))
			// index = 8;
		//	index = 36;
	//	index = 23;
		index = 21;

		if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("manager")
				&& index > 2)
			// index--;

			if (colName.equalsIgnoreCase("full name"))
		//		index = 5;
				index = 3;
			else if (colName.equalsIgnoreCase("type"))
		//		index = 8;
		//		index = 6;
				index = 4;
			else if (colName.equalsIgnoreCase("campus manager"))
				index = 11;
			else if (colName.equalsIgnoreCase("email"))
		//		index = 14;
				index = 9;
			else if (colName.equalsIgnoreCase("phone"))
		//		index = 16;
				index = 12;
			else if (colName.equalsIgnoreCase("school"))
		//		index = 24;
				index = 15;
			else if (colName.equalsIgnoreCase("organization"))
		//		index = 29;
				index = 18;
			else if (colName.equalsIgnoreCase("company"))
		//		index = 34;
				index = 21;

		return index;

	}

	// changes done by vidya
	public int getColIndex(String colName) throws Exception {

		int index = 0;

		if (colName.equalsIgnoreCase("full name"))
			index = 1;
		//	index = 5;
		else if (colName.equalsIgnoreCase("type"))
			// index = 2;
			// index = 8;
		//	index = 6;
			index = 4;
		/*
		 * else if (colName.equalsIgnoreCase("campus manager")) index = 3;
		 */
		else if (colName.equalsIgnoreCase("email"))
			// index = 3;
			index = 9;
		else if (colName.equalsIgnoreCase("phone"))
			// index = 4;
		//	index = 16;
			index =11;
		else if (colName.equalsIgnoreCase("school"))
			// index = 5;
		//	index = 20;
			index = 14;
		else if (colName.equalsIgnoreCase("organization"))
			// index = 6;
		//	index = 26;
			index = 18;
		else if (colName.equalsIgnoreCase("company"))
			// index = 7;
		//	index = 30;
		//	index = 22;
		index = 21;

		return index;

	}
	public int getColIndexCM(String colName) throws Exception {

		int index = 0;

		if (colName.equalsIgnoreCase("full name"))
			 index = 1;
			//index = 5;
		else if (colName.equalsIgnoreCase("type"))
			// index = 2;
		//	index = 8;
		//	index = 6;
			index = 4;
//		else if (colName.equalsIgnoreCase("campus manager"))
//			// index = 3;
//		//	index = 11;
//		index = 9;
		else if (colName.equalsIgnoreCase("email"))
			// index = 4;
		//	index = 16;
		//	index = 11;
		//	index = 10;
		index = 9;
		else if (colName.equalsIgnoreCase("phone"))
			// index = 5;
		//	index = 21;
		//	index = 14;
		//	index = 13;
		index = 12;
		else if (colName.equalsIgnoreCase("school"))
			// index = 6;
		//	index = 26;
		//	index = 17;
			index = 15;
		else if (colName.equalsIgnoreCase("organization"))
			// index = 7;
		//	index = 31;
		//	index = 20;
			index = 18;

		return index;

	}
	

	
	public int getColIndexClient(String colName) throws Exception {
		int index = 0;
		if (colName.equalsIgnoreCase("full name"))
			index = 1;
		else if (colName.equalsIgnoreCase("type"))
			index = 4;
		else if (colName.equalsIgnoreCase("email"))
			index = 15;
	//		index = 12;
		else if (colName.equalsIgnoreCase("phone"))
			index =18;
	//		index = 15;
		else if (colName.equalsIgnoreCase("school"))
			index = 21;
	//		index = 18;
		else if (colName.equalsIgnoreCase("organization"))
			index = 24;
	//		index = 21;
		else if (colName.equalsIgnoreCase("company"))
		index = 27;
	//	index = 24;

		return index;
	}

	public UsersPage sortAndVerifyAllColumns(UserTabs userTab) {

		String tabUser = userTab.toString();
		ArrayList<String> colnames = new ArrayList<String>();
		if (tabUser.equalsIgnoreCase("CAMPUS_MANAGER")) {
			colnames.add("Full name");
			colnames.add("Email");
			colnames.add("Phone");
			colnames.add("School");
			colnames.add("Organization");
		} else {
			colnames.add("Full name");
			colnames.add("Email");
			colnames.add("Phone");
			colnames.add("School");
			colnames.add("Organization");
			colnames.add("Company");
		}

		ArrayList<String> actualColData = null;
		try {
			sleepFor(2000);
//			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, By.xpath("//span[contains(text(),'Rows')]"));
			for (String column : colnames) {
				actualColData = new ArrayList<>();
				String usrtab = userTab.toString();
				sleepFor(1000);

				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("Printer")) {

					actualColData.addAll(readCompleteColumnData(getColIndex(column), userTab));
				} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("FULFILLMENT_CENTER")) {
					actualColData.addAll(readCompleteColumnData(getColIndex(column), userTab));
				}else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("CAMPUS_MANAGER")) {
					actualColData.addAll(readCompleteColumnData(getColIndexCM(column), userTab));
				}else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("CLIENT")) {
					actualColData.addAll(readCompleteColumnData(getColIndexClient(column), userTab));
				}
				else {
					actualColData.addAll(readCompleteColumnData(getColumnIndex(column), userTab));
				}
				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
				sleepFor(1000);
				getSortedDataAndCompare(userTab, column, actualColData, "asc");
				ExtentLogger.pass("Verified Ascending Order Sorting of " + column + " Column.");

				clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(sortIcon, column)));
				sleepFor(1000);
				getSortedDataAndCompare(userTab, column, actualColData, "dsc");
				ExtentLogger.pass("Verified Descending Order Sorting of " + column + " Column.");
			}
			sleepFor(500);
		} catch (Exception e) {
			Assert.fail("Unable to Sort and Verify Columns for " + getStringValue(userTab) + ". " + e.getMessage());
		}

		return this;
	}

	public ArrayList<String> readCompleteColumnData(int colIdx, UserTabs userTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<>();

		try {
//			boolean multiplePages = findElementPresence(
//					By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
			boolean multiplePages = checkCondition(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"),
					ElementCheckStrategy.DISPLAYED);
			if (multiplePages) {
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE,
						By.xpath("//span[contains(text(),'Rows')]//following::ng-select"));
				int maxRow = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));

				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.PRESENCE, By.xpath("//datatable-pager"));
				int records = Integer.parseInt(DriverManager.getDriver().findElement(By.xpath("//datatable-pager"))
						.getAttribute("ng-reflect-count"));

				columnData.addAll(readColumnData(colIdx, userTab));

				int tempCount = records - maxRow;

				while (tempCount > 0) {
		//			scrollToElement(By.xpath("//i[@class='datatable-icon-right']"));
					scrollToElement(By.xpath("//i[@class='datatable-icon-skip']"));
					sleepFor(2000);
		//			clickElementJS(By.xpath("//i[@class='datatable-icon-right']//parent::a"));
					clickElementJS(By.xpath("//i[@class='datatable-icon-skip']//parent::a"));
					sleepFor(2000);
					columnData.addAll(readColumnData(colIdx, userTab));
					tempCount = tempCount - maxRow;
				}

				if (records > maxRow) {
					moveToFirstPage();
					sleepFor(1000);
				}
			} else {
				columnData.addAll(readColumnData(colIdx, userTab));
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		return columnData;
	}

	public void getSortedDataAndCompare(UserTabs userTab, String colName, ArrayList<String> actualColData, String order)
			throws Exception {
		ArrayList<String> sortedColData = new ArrayList<String>();
		ArrayList<String> tempList = new ArrayList<String>();
		String usrtab = userTab.toString();
		try {

			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("admin")
					&& usrtab.equalsIgnoreCase("Printer")) {

				sortedColData.addAll(readCompleteColumnData(getColIndex(colName), userTab));
				System.out.println("Data from UI");
				printArrayList(sortedColData);
			} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("FULFILLMENT_CENTER")) {
				sortedColData.addAll(readCompleteColumnData(getColIndex(colName), userTab));
				System.out.println("Data from UI");
				printArrayList(sortedColData);
			} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin") && usrtab.equalsIgnoreCase("CLIENT")) {
				sortedColData.addAll(readCompleteColumnData(getColIndexClient(colName), userTab));
				System.out.println("Data from UI");
				printArrayList(sortedColData);
			} else {
				sortedColData.addAll(readCompleteColumnData(getColumnIndex(colName), userTab));
				System.out.println("Data from UI");
				printArrayList(sortedColData);
			}

			// sortedColData.addAll(readCompleteColumnData(getColumnIndex(colName),
			// userTab));
//			printArrayList(sortedColData);
			tempList = sortArrayList(actualColData, order, colName);
//			printArrayList(tempList);
			System.out.println("Manually Sorted Data ");
			printArrayList(tempList);
			
			if (compareLists(sortedColData, actualColData)) {
				ExtentLogger.pass(colName + " Column Data is sorted in " + order + " Correctly in "
						+ getStringValue(userTab) + " Tab.");
			} else {
				throw new Exception("Data in " + colName + " is not Sorted in " + order + " Correctly in "
						+ getStringValue(userTab) + " Tab.");
			}
		} catch (Exception e) {
			throw new Exception("Unable to Sort and Compare Data. " + e.getMessage());
		}

	}

	public boolean compareLists(ArrayList<String> sortedColData, ArrayList<String> actualList) {
		boolean match = true;
		for (int i = 0; i < sortedColData.size(); i++) {
			if (!(sortedColData.get(i).split(" ")[0].equalsIgnoreCase(actualList.get(i).split(" ")[0]))) {
				System.out.println("Difference: " + i + ": " + sortedColData.get(i).split(" ")[0] + " "
						+ actualList.get(i).split(" ")[0]);
				match = false;
				break;
			}
		}

		return match;
	}

	// Changes done by Vidya
	public ArrayList<String> readColumnData(int idx, UserTabs userTab) throws Exception {
		ArrayList<String> columnData = new ArrayList<String>();
		try {
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size(), temp = 13;
			System.out.println("rowCount in readcolumndata = " + rowCount);

			String data = "", user = "",
					loggedInAs = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS");
			System.out.println("idx =" + idx);
		//	int k = 8;
			int k = 6;
			if (loggedInAs.equalsIgnoreCase("admin")) {

				for (int i = 2; i <= rowCount; i++) {

					user = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[6]"));
			//		System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[6]");
					System.out.println("user = " + user);

					if (idx <= 3) {
						// data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])["
						// + i + "]//div)["+ (idx * 3) + "]"));
//						data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//								+ (idx * 3) + "]"));

						data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
								+ (idx * 1) + "]"));
						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
								+ (idx * 1) + "]");
						System.out.println("data in idx <= 3   = " + data);

					}
				
					if (user.toLowerCase().contains("client")) {
					//	if (idx == 5)
						if ((idx <= 9) & (idx > 3)){
							// data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])["
							// + i + "]//div)[" + ((idx * 4) + 1) + "]"));
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + (idx * 1) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ (idx * 1) + "]");
							System.out.println("data in idx == 5  =" + data);
						} 
						else if (idx > 5) {
							// data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])["
							// + i + "]//div)[" + (idx + getTempIdx(idx)) + "]"));
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + ((idx * 1) + k) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + (idx * 1) + "]");
							System.out.println("data in idx > 5  = " + data);

						}
					}

					else {
						if (idx > 3) {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + (idx * 1) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ (idx * 1) + "]");
							System.out.println("data in idx > 3  = " + data);
						}
					}

					if (data.equalsIgnoreCase("n/a"))
						data = "";

					columnData.add(data);
				}
			} else if (loggedInAs.equalsIgnoreCase("manager")) {
				for (int i = 2; i <= rowCount; i++) {

					// data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])["
					// + i + "]//div)[" + (idx * 3) + "]"));
					data = getData(By.xpath(
							"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (idx * 1) + "]"));
					System.out.println(
							"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (idx * 1) + "]");
					System.out.println("data =" + data);

					if (data.equalsIgnoreCase("n/a"))
						data = "";

					columnData.add(data);
				}
			}
		//	k++;

		} catch (Exception e) {
			throw new Exception("Unable to read Data. " + e.getMessage());
		}

		return columnData;
	}

	public int getTempIdx(int colIdx) {
		if (colIdx == 4)
			return 13;
		else if (colIdx == 5)
			return 15;
		else if (colIdx == 6)
			return 17;
		else if (colIdx == 7)
			return 19;
		else if (colIdx == 8)
			return 21;

		return 0;

	}

	public ArrayList<String> sortArrayList(ArrayList<String> dataList, String order, String colName) {
		final int ord = order.equals("asc") ? 1 : -1;
		if (colName.equalsIgnoreCase("phone")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String num1, String num2) {
					Long n1 = Long.parseLong(num1);
					Long n2 = Long.parseLong(num2);
					return (n1.compareTo(n2) * ord);
				}
			});
		} else if (colName.equalsIgnoreCase("email")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String data1, String data2) {
					return (data1.split("@")[0].compareTo(data2.split("@")[0]) * ord);
				}
			});
		} else if (colName.equalsIgnoreCase("full name")) {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String data1, String data2) {
					return (data1.split(" ")[0].compareTo(data2.split(" ")[0]) * ord);
				}
			});
		} else {
			Collections.sort(dataList, new Comparator<String>() {

				public int compare(String data1, String data2) {
					return (data1.compareTo(data2) * ord);
				}
			});
		}

		return dataList;
	}

	public void printArrayList(ArrayList<String> columnData) {
		columnData.forEach(System.out::println);
		System.out.println("-------------");
	}

	public UsersPage filterDataAndVerifyAllColumns(UserTabs userTab) {
		try {
			sleepFor(1000);
			if (!userTab.equals(UserTabs.CLIENT)) {

				switchTo(userTab);

			}

			sleepFor(500);
			int rowCount = DriverManager.getDriver()
					.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();

			filterAndVerifyFullName(userTab, rowCount);
			filterAndVerifyEmail(userTab, rowCount);
//			filterAndVerifyPhone(userTab, rowCount);
			if (userTab.equals(UserTabs.CLIENT)) {
				filterAndVerifyPhone(userTab, rowCount);
				filterAndVerifySchool(userTab);
				filterAndVerifyOrganization(userTab);
//				filterAndVerifyCampusManager(userTab);
//				filterAndVerifyCompany(userTab);
			} else if (userTab.equals(UserTabs.PRINTER) || userTab.equals(UserTabs.FULFILLMENT_CENTER)) {
				// filterAndVerifyOrganization(userTab);
				filterAndVerifyPhone(userTab, rowCount);
				filterAndVerifyCompany(userTab);
			}

		} catch (Exception e) {
			Assert.fail("Unable to Filter specified Data and Verify Columns for " + getStringValue(userTab) + ". "
					+ e.getMessage());
		}

		return this;
	}

	// Changes done by vidya
	public void filterAndVerifyOrganization(UserTabs userTab) {
		String usertab = userTab.toString();
		try {
			String filterData = InputPropertyUtils.get("EXISTING_ORGANIZATION_NAME");
			enterData(txtFilterData, filterData);
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = null;

			if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {

				completeData = readCurrentTable(UserType.PRINTER);
			} else if (usertab.equalsIgnoreCase("CLIENT")) {

				completeData = readCurrentTable(UserType.CLIENT);
			} else {

				completeData = readCurrentTable(UserType.ADMIN);
			}
			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}
			for (HashMap<String, String> eachRow : completeData) {
				if (!eachRow.get("Organization").equalsIgnoreCase(filterData)) {
					throw new Exception("Filtered Records doesn't have the expected Organization");
				}
			}
			ExtentLogger.pass("Filtering Functionality is Verifed for Organization");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(2000);
			switchTo(userTab);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for Organization. " + e.getMessage());
		}
	}

	// Changes done by vidya
	public void filterAndVerifyCompany(UserTabs userTab) {
		String usertab = userTab.toString();
		try {
			String filterData = InputPropertyUtils.get("EXISTING_COMPANY_NAME");
			enterData(txtFilterData, filterData);
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = null;

			if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {

				completeData = readCurrentTable(UserType.PRINTER);
			} else if (usertab.equalsIgnoreCase("CLIENT")) {

				completeData = readCurrentTable(UserType.CLIENT);
			} else {

				completeData = readCurrentTable(UserType.ADMIN);
			}
			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}

			for (HashMap<String, String> eachRow : completeData) {
				if (!eachRow.get("Company").equalsIgnoreCase(filterData)) {
					throw new Exception("Filtered Records doesn't have the expected Company");
				}
			}
			ExtentLogger.pass("Filtering Functionality is Verifed for Company");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(2000);
			switchTo(userTab);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for Company. " + e.getMessage());
		}
	}

	// Changes done by vidya
	public void filterAndVerifySchool(UserTabs userTab) {
		String usertab = userTab.toString();
		try {
			String filterData = InputPropertyUtils.get("EXISTING_SCHOOL_NAME");
			enterData(txtFilterData, filterData);
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = null;

			if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {

				completeData = readCurrentTable(UserType.PRINTER);
			} else if (usertab.equalsIgnoreCase("CLIENT")) {

				completeData = readCurrentTable(UserType.CLIENT);
			} else {

				completeData = readCurrentTable(UserType.ADMIN);
			}

			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}
			for (HashMap<String, String> eachRow : completeData) {
				if (!eachRow.get("School").equalsIgnoreCase(filterData)) {
					throw new Exception("Filtered Records doesn't have the expected School");
				}
			}
			ExtentLogger.pass("Filtering Functionality is Verifed for School");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(2000);
			switchTo(userTab);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for School. " + e.getMessage());
		}
	}

	// Changes done by vidya
	public void filterAndVerifyPhone(UserTabs userTab, int rowCount) {

		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		int idx;

		String usertab = userTab.toString();

		if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {
		//	idx = 16;
			idx = 11;
			
		} else if (usertab.equalsIgnoreCase("CLIENT")) {
		//	idx = 29;
			idx = 20;
		} else {
		//	idx = 21;
		//	idx = 14;
			idx = 11;
			switchTo(userTab);
			
		}

		int filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
		String filterData = "";

		try {

			if (userTab.equals(UserTabs.CLIENT)) {
//				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
//						+ "]//div)[" + (idx + 13) + "]"));
				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]"));
			} else {
//				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
//						+ "]//div)[" + (idx * 3) + "]"));
				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]"));
			}
			enterData(txtFilterData, filterData);
			sleepFor(2000);

			ArrayList<HashMap<String, String>> completeData = null;

			if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {

				completeData = readCurrentTable(UserType.PRINTER);
			} else if (usertab.equalsIgnoreCase("CLIENT")) {

				completeData = readCurrentTable(UserType.CLIENT);
			} else {

				completeData = readCurrentTable(UserType.ADMIN);
			}

			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}

			for (HashMap<String, String> eachRow : completeData) {
				if (!eachRow.get("Phone").equalsIgnoreCase(filterData)) {
					throw new Exception("Filtered Records doesn't have the expected Phone");
				}
			}

			ExtentLogger.pass("Filtering Functionality is Verifed for Phone");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(1000);
			switchTo(userTab);
			sleepFor(1000);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for Phone. " + e.getMessage());
		}
	}

	// Changes done by vidya
	public void filterAndVerifyEmail(UserTabs userTab, int rowCount) {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		int idx;
		String usertab = userTab.toString();
		if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {
			// idx = 3;
		//	idx = 11;
			idx = 9;
		} else if (usertab.equalsIgnoreCase("CLIENT")) {
		//	idx = 21;
		//	idx = 17;
		//	idx = 15;
			idx = 16;
		} else if (usertab.equalsIgnoreCase("CAMPUS_MANAGER")) {
			idx = 9;
			switchTo(UserTabs.CAMPUS_MANAGER);
		}
		else {
			// idx = 4;
		//	idx = 16;
		//	idx = 11;
			idx = 9;
		}
		int filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
		String filterData = "";
		System.out.println("idx = "+ idx);

		try {
			sleepFor(2000);
			if (userTab.equals(UserTabs.CLIENT)) {
//				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
//						+ "]//div)[" + ((idx * 4) + 1) + "]"));
				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]"));
				System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]");
			} else {
//				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
//						+ "]//div)[" + (idx * 3) + "]"));
				filterData = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]"));
				System.out.println("((//div[contains(@class,'datatable-row-center')])[" + filterIdx
						+ "]//div)[" + (idx * 1) + "]");
			}

			enterData(txtFilterData, filterData);
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = null;

			if (usertab.equalsIgnoreCase("FULFILLMENT_CENTER") || usertab.equalsIgnoreCase("PRINTER")) {

				completeData = readCurrentTable(UserType.PRINTER);
			} else if (usertab.equalsIgnoreCase("CLIENT")) {

				completeData = readCurrentTable(UserType.CLIENT);
			} else {

				completeData = readCurrentTable(UserType.ADMIN);
			}

			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}
			for (HashMap<String, String> eachRow : completeData) {
				if (!eachRow.get("Email").equalsIgnoreCase(filterData)) {
					throw new Exception("Filtered Records doesn't have the expected Email");
				}
			}
			ExtentLogger.pass("Filtering Functionality is Verifed for Email");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(1000);
			switchTo(userTab);
			sleepFor(1000);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for Email. " + e.getMessage());
		}
	}

	// changes done by vidya
	public void filterAndVerifyFullName(UserTabs userTab, int rowCount) {
		rowCount = DriverManager.getDriver().findElements(By.xpath("//div[contains(@class,'datatable-row-center')]"))
				.size();
		 int idx = 1, filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
	//	int idx = 5, filterIdx = ThreadLocalRandom.current().nextInt(2, rowCount);
		String arr[] = null;
		boolean match = false;
		try {
			String filterData = getData(By.xpath(
					"((//div[contains(@class,'datatable-row-center')])[" + filterIdx + "]//div)[" + (idx * 1) + "]"));
			enterData(txtFilterData, filterData);
			sleepFor(2000);
			ArrayList<HashMap<String, String>> completeData = readCurrentTable(UserType.ADMIN);
			if (completeData.size() < 1) {
				if (!findElementPresence(noRecordsDiv)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}
			arr = filterData.split(" ");
			for (HashMap<String, String> eachRow : completeData) {

				match = false;
				for (int i = 0; i < arr.length; i++) {
					if (eachRow.toString().toLowerCase().contains(arr[i].toLowerCase())) {
						match = true;
						break;
					}
				}
				if (!match) {
					throw new Exception("Matched Data is not present in the Filtered Records");
				}
			}
			ExtentLogger.pass("Filtering Functionality is Verifed for FullName");
			clickElement(By.xpath("//i[@class='ft-x']"));
			sleepFor(1000);
			switchTo(userTab);
			sleepFor(1000);
		} catch (Exception e) {
			Assert.fail("Filter is not working as expected for Full Name. " + e.getMessage());
		}

	}

	// changes done by vidya
	public UsersPage verifyRecordsCount(UserType userType) {
		try {
			sleepFor(300);
			int rowCount = 0, recordsPerPage = 0, totRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(By
							.xpath(DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(userType))))
					.getText());
			clickElementJS(By.xpath(DynamicXpathUtils.getXpathForString(tabSelection, getStringValue(userType))));
			sleepFor(500);

			if (findElementPresence(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))) {
				recordsPerPage = Integer.parseInt(DriverManager.getDriver()
						.findElement(By.xpath("//span[contains(text(),'Rows')]//following::ng-select"))
						.getAttribute("ng-reflect-model"));
			} else {
				recordsPerPage = totRecords;
			}

			if (totRecords < recordsPerPage) {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount + " for " + getStringValue(userType));
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount + " for "
							+ getStringValue(userType));
				}
			} else {
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;
//				while (DriverManager.getDriver()
//						.findElements(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"))
//						.size() == 0) {
				while (checkCondition(By.xpath("//li[@class='disabled']//i[@class='datatable-icon-right']"),
						ElementCheckStrategy.DISPLAYED)) {
					clickElement(By.xpath("//i[@class='datatable-icon-right']"));

					rowCount = rowCount
							+ DriverManager.getDriver()
									.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size()
							- 1;
				}
				if (rowCount == totRecords) {
					ExtentLogger.pass(
							"Total Records displayed in the Tab Title is equal to the Total Number of records displayed in the DataTable: "
									+ rowCount);
				} else {
					throw new Exception("Total Records displayed in the Tab Title is " + totRecords
							+ " but total records displayed in the DataTable is " + rowCount);
				}
			}

		} catch (Exception e) {
			Assert.fail("Unable to Verify Records Count. " + e.getMessage());
		}

		return this;
	}

	// changes done by vidya
	public UsersPage verifyPaginationCount(UserTabs userTab) {
		try {
			switchTo(userTab);
			int totalRecords, rowCount = 0, i = 0;
			int pageCount[] = { 25, 50, 100 };
			totalRecords = Integer.parseInt(DriverManager.getDriver()
					.findElement(
							By.xpath(DynamicXpathUtils.getXpathForString(userRecordsCount, getStringValue(userTab))))
					.getText());

			do {
				sleepFor(300);
				rowCount = DriverManager.getDriver()
						.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size() - 1;

				if (totalRecords > pageCount[i]) {
					if (rowCount != pageCount[i]) {
						throw new Exception("Record Count " + rowCount + " in the Datatable does not match for "
								+ getStringValue(userTab) + " Page with Pagination Count " + pageCount);
					} else {
						ExtentLogger.pass("Records Count Matches with the Selected Value(" + pageCount[i] + ") for "
								+ getStringValue(userTab) + " Page");
					}
				} else {
					ExtentLogger.pass("Total Records available in " + getStringValue(userTab)
							+ " is less than/Equal to the selected value(" + pageCount[i] + "). It has only " + rowCount
							+ " Records");
				}
				i++;
				choosePaginationCount(String.valueOf(pageCount[i]));

			} while (totalRecords > pageCount[i - 1] && i < 3);
			choosePaginationCount("25");
		} catch (Exception e) {
			Assert.fail("Unable to Verify Pagination Count for " + getStringValue(userTab) + " Tab. " + e.getMessage());
		}

		return this;
	}

	// changes done by vidya
	public ArrayList<HashMap<String, String>> readCurrentTable(UserType usertype) {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		// System.out.println(DriverManager.getDriver().findElement(By.xpath("//div[contains(@class,'datatable-row-center')]")).getText());

		int temp = 0;
		System.out.println("rowCount = " + rowCount);

		try {

			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("manager")) {
				for (int i = 1; i <= 7; i++) {
					System.out.println("rowCount = " + rowCount);

					// Getting all the headers data and inserting it into an arraylist
					System.out.println("i = " + i);
					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));

					header.add(colData);
					System.out.println("colData = " + colData);
					// System.out.println("header.add(colData) = " + header.add(colData));

				}
				for (int i = 3; i <= rowCount; i++) {
					int k = 1;
					int r = 4;
					HashMap<String, String> eachRow = new HashMap<>();
					for (int j = 1; j <= 7; j++) {
						System.out.println("j = " + j);
						String data = "";

						if (j <= 7) {

						//	data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 4) + k) + "]"));
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
						//	k--;

							System.out.println("j<=7 " + data);

						}
/**/
//						if (j == 3) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + ((j * j) + 5) + "]"));
//
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ ((j * j) + 5) + "]");
//							System.out.println("j ==3 ");
//
//						}
//
//						if (j == 4) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + (j * j) + "]"));
//
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ (j * j) + "]");
//							System.out.println("j ==4 ");
//
//						}
//
//						if (j > 4) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + ((j * 4) + r) + "]"));
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ ((j * 4) + r) + "]");
//							System.out.println("j > 4 " + data);
//							r++;
//						}
/**/						
						

//						data = getData(By.xpath(
//								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
//						
//						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
//						System.out.println("(j * 3) = " + (j * 3));
						eachRow.put(header.get(j - 1), data);
						System.out.println("header.get(j - 1) = " + header.get(j - 1));
						System.out.println(
								"eachRow.put(header.get(j - 1), data) =" + eachRow.put(header.get(j - 1), data));

					}
					fullData.add(eachRow);
					System.out.println("eachRow =" + eachRow);
				}
				for (int i = 2; i <= rowCount; i++) {
					int k = 1;
					int r = 4;
					HashMap<String, String> eachRow = new HashMap<>();
					for (int j = 1; j <= 7; j++) {
						System.out.println("j = " + j);
						String data = "";

						if (j <= 2) {
							
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 2) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 2) + "]");
							
							System.out.println("j<=2 " + data);
						}
						if ((j <= 7) && (j > 2)) {

//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 4) + k) + "]"));
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
						//	k--;

							System.out.println("j<=7 " + data);

						}
						

/**/											
//						if (j == 3) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + ((j * j) + 5) + "]"));
//
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ ((j * j) + 5) + "]");
//							System.out.println("j ==3 ");
//
//						}
//
//						if (j == 4) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + (j * j) + "]"));
//
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ (j * j) + "]");
//							System.out.println("j ==4 ");
//
//						}
//
//						if (j > 4) {
//
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + ((j * 4) + r) + "]"));
//							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//									+ ((j * 4) + r) + "]");
//							System.out.println("j > 4 " + data);
//							r++;
//						}
						
/**/						

//						data = getData(By.xpath(
//								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
//						
//						System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
//						System.out.println("(j * 3) = " + (j * 3));
						eachRow.put(header.get(j - 1), data);
						System.out.println("header.get(j - 1) = " + header.get(j - 1));
						System.out.println(
								"eachRow.put(header.get(j - 1), data) =" + eachRow.put(header.get(j - 1), data));

					}
					fullData.add(eachRow);
					System.out.println("eachRow =" + eachRow);
				}
			} else {
				// for (int i = 1; i <= 8; i++)
				int count = 0;
				if (usertype.equals(UserType.CLIENT) && RunTimePropertyFileUtils
						.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("ADMIN"))
					count = 8;
				else if (usertype.equals(UserType.CAMPUS_MANAGER) && RunTimePropertyFileUtils
						.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("ADMIN")) {
					
					count = 6;
				} else 
					count = 7;

				for (int i = 1; i <= count; i++) {
					System.out.println("rowCount = " + rowCount);

					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
					String text = DriverManager.getDriver()
							.findElement(By.xpath("(//div[contains(@class,'data-table__cell')])[" + i + "]")).getText();

					header.add(colData);

				}
				for (int i = 2; i <= rowCount; i++) {
					String user = "";
					// temp = 13;
					temp = 15;
					HashMap<String, String> eachRow = new HashMap<>();
					int k = 1;
					int r = 1;
					int s = 4;
					int a = 11 , c = 17;
					
					// for (int j = 1; j <= 8; j++) {
					for (int j = 1; j <= count; j++) {
						System.out.println("count = " + count);
						String data = "";
						System.out.println("j = " + j);

						if (j <= 2) {
//						 if (j <= 3) {

							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 2) + "]"));
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
//							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//									+ "]//div)[" + ((j * 4) + k) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 2) + "]");
						//	k--;

							System.out.println("j<=3 " + data);

							if (j == 2) {
								user = data;
								System.out.println("user = " + user);

							}
						}
						 
						 if ( j ==3 ) {
							 
							 data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));
							 System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
						 }

						if ((usertype.equals(UserType.ADMIN)) || (usertype.equals(UserType.CAMPUS_MANAGER))) {

//							if ((j <= 4) && (j > 2))
								if (j > 3) {

							//	data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 4) + "]"));
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (a) + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (a) + "]");
								a= a+3;
								System.out.println("j > 3 " + data);

							}

//							if (j > 4) {
//
//								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//										+ "]//div)[" + ((j * 4) + r) + "]"));
//								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//										+ ((j * 4) + r) + "]");
//								System.out.println("j > 4 " + data);
//								r++;
//							}

						}

						if (usertype.equals(UserType.CLIENT)) {
							if (j >= 4) {
							//	data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 5) + s) + "]"));
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (c) + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (c) + "]");
								System.out.println("j >= 4 " + data);
								c= c+3;

							}
//							else if (j == 3) {
//								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//										+ "]//div)[" + ((4 * j) + 4) + "]"));
//								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//										+ ((4 * j) + 4) + "]");
//								// temp += 2;
//								System.out.println("j == 3 " + data);
//
//							}
						}
						if ((usertype.equals(UserType.PRINTER)) || (usertype.equals(UserType.FULFILLMENT_CENTER))) {

//							if ((j <= 5) && (j > 3)) {
//
//								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//										+ "]//div)[" + (j * 4) + "]"));
//								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//										+ (j * 4) + "]");
//								System.out.println("j <= 5 " + data);
//
//							} else 
//								if (j == 3)
							if (j > 3){

							//	data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * j) + 2) + "]"));
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (a)  + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (a)  + "]");
								System.out.println("j > 3 " + data);
								a = a+3;
								

							}
//								else if (j > 5) {
//								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
//										+ "]//div)[" + ((j * 4) + 2) + "]"));
//								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
//										+ ((j * 4) + 2) + "]");
//								System.out.println("j > 5 " + data);
//
//							}

						}

//						else {
//							if (j > 3)  {
////								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 3) - 1) + "]"));
////								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 3) - 1) + "]");
//								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 4) +1) + "]"));
//								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + ((j * 5) - 0) + "]");
//
//								System.out.println("j>3 " + data);
//
//							}
//						
//						
//						}
						// System.out.println(header);

						eachRow.put(header.get(j - 1), data);
					}

					System.out.println(eachRow);

					fullData.add(eachRow);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return fullData;
	}

	public ArrayList<HashMap<String, String>> readCurrentTab(UserType usertype, UserTabs usertab) {
		ArrayList<HashMap<String, String>> fullData = new ArrayList<>();
		ArrayList<String> header = new ArrayList<>();
		int rowCount = DriverManager.getDriver()
				.findElements(By.xpath("//div[contains(@class,'datatable-row-center')]")).size();
		// System.out.println(DriverManager.getDriver().findElement(By.xpath("//div[contains(@class,'datatable-row-center')]")).getText());

		int temp = 0;
		System.out.println("rowCount = " + rowCount);

		try {

			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("manager")) {
				for (int i = 1; i <= 7; i++) {
					System.out.println("rowCount = " + rowCount);

					// Getting all the headers data and inserting it into an arraylist
					System.out.println("i = " + i);
					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));

					header.add(colData);
					System.out.println("colData = " + colData);
					// System.out.println("header.add(colData) = " + header.add(colData));

				}
				for (int i = 3; i <= rowCount; i++) {
					HashMap<String, String> eachRow = new HashMap<>();
					for (int j = 1; j <= 7; j++) {
						System.out.println("j = " + j);
						String data = "";

						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));

						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
						System.out.println("(j * 3) = " + (j * 3));
						eachRow.put(header.get(j - 1), data);
						System.out.println("header.get(j - 1) = " + header.get(j - 1));
						System.out.println(
								"eachRow.put(header.get(j - 1), data) =" + eachRow.put(header.get(j - 1), data));

					}
					fullData.add(eachRow);
					System.out.println("eachRow =" + eachRow);
				}
				for (int i = 2; i <= rowCount; i++) {
					HashMap<String, String> eachRow = new HashMap<>();
					for (int j = 1; j <= 7; j++) {
						System.out.println("j = " + j);
						String data = "";

						data = getData(By.xpath(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]"));

						System.out.println(
								"((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)[" + (j * 3) + "]");
						System.out.println("(j * 3) = " + (j * 3));
						eachRow.put(header.get(j - 1), data);
						System.out.println("header.get(j - 1) = " + header.get(j - 1));
						System.out.println(
								"eachRow.put(header.get(j - 1), data) =" + eachRow.put(header.get(j - 1), data));

					}
					fullData.add(eachRow);
					System.out.println("eachRow =" + eachRow);
				}
			} else {
				// for (int i = 1; i <= 8; i++)
				int count = 0;
				String userTab = usertab.toString();
				if (usertype.equals(UserType.CLIENT) && RunTimePropertyFileUtils
						.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS").equalsIgnoreCase("ADMIN")) {
					count = 8;
				}
				if (userTab.equalsIgnoreCase("CLIENT") && usertype.equals(usertype.ADMIN)) {
					count = 8;
				} else {
					count = 7;
				}

				for (int i = 1; i <= count; i++) {
					System.out.println("rowCount = " + rowCount);

					String colData = getData(
							By.xpath("(//span[contains(@class,'datatable-header-cell-label')])[" + i + "]"));
					String text = DriverManager.getDriver()
							.findElement(By.xpath("(//div[contains(@class,'data-table__cell')])[" + i + "]")).getText();

					header.add(colData);

				}
				for (int i = 2; i <= rowCount; i++) {
					String user = "";
					temp = 13;
					HashMap<String, String> eachRow = new HashMap<>();
					// for (int j = 1; j <= 8; j++) {
					for (int j = 1; j <= count; j++) {
						String data = "";

						if (j <= 3) {
							data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
									+ "]//div)[" + (j * 3) + "]"));
							System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
									+ (j * 3) + "]");
							System.out.println("j<3 " + data);

							if (j == 2) {
								user = data;
							}
						}
						if (user.toLowerCase().contains("client")) {
							if (j == 4) {
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
										+ "]//div)[" + (j * 4) + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
										+ (j * 4) + "]");
								System.out.println("j==4 " + data);

							} else if (j > 4) {
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
										+ "]//div)[" + (temp + j) + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
										+ (temp + j) + "]");
								temp += 2;
								System.out.println("j>4 " + data);

							}
						} else {
							if (j > 3) {
								data = getData(By.xpath("((//div[contains(@class,'datatable-row-center')])[" + i
										+ "]//div)[" + ((j * 3) - 1) + "]"));
								System.out.println("((//div[contains(@class,'datatable-row-center')])[" + i + "]//div)["
										+ ((j * 3) - 1) + "]");

								System.out.println("j>3 " + data);

							}
						}
						// System.out.println(header);

						eachRow.put(header.get(j - 1), data);

					}

					System.out.println(fullData);

					fullData.add(eachRow);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return fullData;
	}

	public UsersPage captureTotalRecordsCount(UserTabs userType) {
		String totRecords = "";
		try {
			totRecords = getData(
					By.xpath(DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(userType))));

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALRECORDS", totRecords);
		} catch (Exception e) {
			Assert.fail("Unable to Capture Total Records Available for " + getStringValue(userType) + ". "
					+ e.getMessage());
		}

		ExtentLogger.pass("Captured Total Records Available for " + getStringValue(userType));

		return this;
	}

	public UsersPage verfyTotalRecordsCount(UserTabs userType, UserOperation operationType) {
		int totRecords = 0, expectedCount = 0, inactiveRecordsCount = 0;
		try {
			DriverManager.getDriver().navigate().refresh();
			sleepFor(1000);

			totRecords = Integer.parseInt(getData(
					By.xpath(DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, getStringValue(userType)))));

			inactiveRecordsCount = Integer
					.parseInt(getData(By.xpath(DynamicXpathUtils.getXpathForString(tabTitleRecordsCount, "Inactive"))));

			if (operationType.equals(UserOperation.CREATE)) {
				expectedCount = Integer
						.parseInt(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "TOTALRECORDS")) + 1;

				if (totRecords != expectedCount) {
					throw new Exception("Records Count is not Incremented after " + operationType
							+ " Operation. Expected [" + expectedCount + "] Actual [" + totRecords + "]");
				}
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TOTALRECORDS",
						String.valueOf((totRecords + 1)));

			}

			ExtentLogger.pass("Verified Total Count after performing " + operationType + " Operation on "
					+ getStringValue(userType) + " User.");

		} catch (Exception e) {
			ExtentLogger.fail("Failed in Verifying Total Records Available for " + getStringValue(userType) + ". "
					+ e.getMessage());
		}

		return this;
	}

	public UsersPage clearSearchFilter() {
		try {
			clickElementJS(By.xpath("(//div[contains(@class,'search')]/following::i[@class='ft-x'])[1]"));
			ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE,
					(By.xpath("(//div[contains(@class,'datatable-row-center')])[2]")));
			DriverManager.getDriver().navigate().refresh();
			ExtentLogger.pass("Cleared Search Filter.");
		} catch (Exception e) {
			Assert.fail("Unable to Clear Search filter");
		}

		return this;
	}

	public UsersPage saveData(UserOperation userOperation, String type) {
		try {
			sleepFor(2000);
			if (userOperation.equals(UserOperation.CREATE)) {
				clickElement(btnCreateAccount);
				if (!type.equalsIgnoreCase("existing")) {
					ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, divAccountCreated);
					ExtentLogger.pass("User is Created Successfully");
				} else {
					ExtentLogger.pass("Clicked Created Users Button Successfully");
				}
			} else if (userOperation.equals(UserOperation.UPDATE)) {

			}

		} catch (Exception e) {
			Assert.fail("Unable to Save Records. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterUserInDashboard(UserOperation userOperation, String platform) {
		try {
			String email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");

			if (platform.equalsIgnoreCase("desktop")) {
				enterData(txtFilterData, email);
			} else if (platform.equalsIgnoreCase("mobile")) {
				enterData(txtFilterDataMobile, email);
			}

			sleepFor(500);

		} catch (Exception e) {

		}
		return this;
	}

	public UsersPage verifyCardDetails(UserType userType) {
		try {
			if (!getData(filteredUserNameMobileCard)
					.equalsIgnoreCase(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME"))) {
				ExtentLogger.fail("FullName displayed in the Card doesn't Match. Actual ["
						+ getData(filteredUserNameMobileCard) + "] Expected ["
						+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FULLNAME") + "]");
			}

			if (userType.equals(UserType.CAMPUS_MANAGER)) {

				if (!getData(filteredUserSchoolMobileCard)
						.equalsIgnoreCase(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))) {
					ExtentLogger.fail("School displayed in the Card doesn't Match. Actual ["
							+ getData(filteredUserSchoolMobileCard) + "] Expected ["
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL") + "]");
				}

				if (!getData(filteredUserOrgMobileCard).equalsIgnoreCase(
						RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"))) {
					ExtentLogger.fail("Org displayed in the Card doesn't Match. Actual ["
							+ getData(filteredUserOrgMobileCard) + "] Expected ["
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION") + "]");
				}

			} else if (userType.equals(UserType.FULFILLMENT_CENTER) || userType.equals(UserType.PRINTER)) {

				if (!getData(filteredUserCompanyMobileCard)
						.equalsIgnoreCase(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMPANY"))) {
					ExtentLogger.fail("Company/Business displayed in the Card doesn't Match. Actual ["
							+ getData(filteredUserCompanyMobileCard) + "] Expected ["
							+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "COMPANY") + "]");
				}
			} else if (userType.equals(UserType.CLIENT)) {
				boolean clientWithSchool = getTestCaseName().toLowerCase().contains("withschool");

				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin")) {

					if (Objects
							.isNull(RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "OPERATIONTYPE"))) {

						if (!getData(filteredUserCMNameMobileCard)
								.equalsIgnoreCase(InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME"))) {
							ExtentLogger.fail("Campus Manager is not Updated Correctly. Actual ["
									+ getData(filteredUserCMNameMobileCard) + "] Expected ["
									+ InputPropertyUtils.get("MASTER_ADMIN_LOGIN_FULLNAME") + "]");
						}
					}
				}

				if (clientWithSchool) {
					if (!getData(filteredUserSchoolMobileCard).equalsIgnoreCase(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL"))) {
						ExtentLogger.fail("School displayed in the Card doesn't Match. Actual ["
								+ getData(filteredUserSchoolMobileCard) + "] Expected ["
								+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "SCHOOL") + "]");
					}

					if (!getData(filteredUserOrgMobileCard).equalsIgnoreCase(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION"))) {
						ExtentLogger.fail("Org displayed in the Card doesn't Match. Actual ["
								+ getData(filteredUserOrgMobileCard) + "] Expected ["
								+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "ORGANIZATION") + "]");
					}

				} else {
					if (!getData(filteredUserCompanyMobileCard).equalsIgnoreCase(
							RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BUSINESS"))) {
						ExtentLogger.fail("Company/Business displayed in the Card doesn't Match. Actual ["
								+ RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "BUSINESS")
								+ "] Expected [" + getData(filteredUserCompanyMobileCard) + "]");
					}
				}
			}
			if (findElementPresence(iconCloseMoreOptionsMobile)) {
				clickElementJS(iconCloseMoreOptionsMobile);
			}
			ExtentLogger.pass("Verified the Details in the Card Successfully.");
		} catch (Exception e) {
			Assert.fail("Failed in Card Details Verification. " + e.getMessage());
		}

		return this;
	}

	public UsersPage clickAndSelectOption(UserType userType, UserOperation userOperation) {
		try {
			clickElementJS(filteredUserNameMobileCard);

			if (userOperation.equals(UserOperation.IMPERSONATE)) {
				clickElement(iconMoreMobile);
				clickElement(iconImpersonateMobile);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Impersonate");

				if (userType.equals(UserType.ADMIN)) {
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Admin");
				} else if (userType.equals(UserType.CAMPUS_MANAGER)) {
					RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "LOGGEDINAS", "Manager");
				}

			} else if (userOperation.equals(UserOperation.UPDATE)) {
				clickElement(iconMoreMobile);
				clickElement(iconEditMobile);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Update");
			} else if (userOperation.equals(UserOperation.DELETE)) {
				clickElement(iconMoreMobile);
				clickElement(iconDeleteMobile);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Delete");
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FULLNAME",
						InputPropertyUtils.get("EXISTING_CUSTOMER_NAME"));
			} else if (userOperation.equals(UserOperation.DEACTIVATE)) {
				clickElement(iconMoreMobile);
				clickElement(iconDeactivateMobile);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Deactivate");
			} else if (userOperation.equals(UserOperation.REACTIVATE)) {
				clickElementJS(btnReActivateMobile);
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "Reactivate");
			} else if (userOperation.equals(UserOperation.VIEW)) {
				RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "OPERATIONTYPE", "View");

				return this;
			}

			sleepFor(1000);
			ExtentLogger.pass("Successfully Clicked the User and selected "
					+ StringUtils.capitalize(userOperation.toString().toLowerCase()) + " Menu.");
		} catch (Exception e) {
			Assert.fail("Unable to Click User and Select "
					+ StringUtils.capitalize(userOperation.toString().toLowerCase()) + ". " + e.getMessage());
		}

		return this;
	}

	public UsersPage searchFullNameAndVerifyCard() {
		String[] arr;
		boolean match = true;
		try {
			int cardsCount = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]")).size();
			int filterIdx = ThreadLocalRandom.current().nextInt(1, cardsCount);
			String filterValue = DriverManager.getDriver()
					.findElement(By.xpath("(//label[contains(@class,'user-card__name')])[" + filterIdx + "]"))
					.getText();
			enterData(txtFilterDataMobile, filterValue);
			sleepFor(1000);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));

			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			}
			for (WebElement element : listOfName) {
				arr = element.getText().split(" ");
				match = true;
				for (int i = 0; i < arr.length - 1; i++) {
					if (!filterValue.toLowerCase().contains(arr[i].toLowerCase())) {
						match = false;
						break;
					}
				}
			}
			if (!match)
				ExtentLogger.fail("Matched Data is not present in the Filtered Records for FullName");
			ExtentLogger.pass("Verified all Records after Searching Records");
		} catch (Exception e) {
			Assert.fail("Failed in Verifing Full Name Filter. " + e.getMessage());
		}

		return this;
	}

	public UsersPage searchCompanyAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_COMPANY_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "Company");
			enterData(txtFilterDataMobile, filterValue);
			sleepFor(1000);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			ExtentLogger.pass("Verified all Records after Searching Company: " + filterValue);
		} catch (Exception e) {
			Assert.fail("Failed in Verifing Company Filter. " + e.getMessage());
		}
		return this;
	}

	public UsersPage searchSchoolAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_SCHOOL_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "School");
			enterData(txtFilterDataMobile, filterValue);
			sleepFor(1000);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			ExtentLogger.pass("Verified all Records after Searching School: " + filterValue);
		} catch (Exception e) {
			Assert.fail("Failed in Verifing School Filter. " + e.getMessage());
		}
		return this;
	}

	public UsersPage searchOrgAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_ORGANIZATION_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "Organization");
			enterData(txtFilterDataMobile, filterValue);
			sleepFor(1000);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			ExtentLogger.pass("Verified all Records after Searching Organization: " + filterValue);
		} catch (Exception e) {
			Assert.fail("Failed in Verifing Organization Filter. " + e.getMessage());
		}
		return this;
	}

	public void verifyFilteredCardDetails(List<WebElement> listOfElements) {
		String filterType = "", filterValue = "", type = "", data = "";
		try {
			filterType = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTERTYPE");
			filterValue = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "FILTERVALUE");
			switch (filterType.toLowerCase()) {
			case "company":
				for (int i = 1; i <= listOfElements.size(); i++) {
					clickElementJS(By.xpath("(//label[contains(@class,'user-card__name')])[" + i + "]"));
					sleepFor(1000);
					type = getData(By.xpath("(//label[contains(@class,'details__name')]//following::div)[1]"));

					if (type.equalsIgnoreCase("fulfillment center") || type.equalsIgnoreCase("printer")) {
						data = getData(By.xpath("//label[contains(@class,'details__school-org-text')]"));
						if (!data.trim().equalsIgnoreCase(filterValue.trim()))
							ExtentLogger.fail("Matched Data is not present in the Filtered Records for Company");
						clickElementJS(iconCloseMoreOptionsMobile);
						sleepFor(500);
					}
				}
				break;
			case "school":
				for (int i = 1; i <= listOfElements.size(); i++) {
					clickElementJS(By.xpath("(//label[contains(@class,'user-card__name')])[" + i + "]"));
					sleepFor(1000);
					type = getData(By.xpath("(//label[contains(@class,'details__name')]//following::div)[1]"));

					if (type.equalsIgnoreCase("client") || type.equalsIgnoreCase("campus manager")) {
						data = getData(filteredUserSchoolMobileCard);
						if (!data.trim().equalsIgnoreCase(filterValue.trim()))
							ExtentLogger.fail("Matched Data is not present in the Filtered Records for School");
						clickElementJS(iconCloseMoreOptionsMobile);
						sleepFor(500);
					}
				}
				break;
			case "organization":
				for (int i = 1; i <= listOfElements.size(); i++) {
					clickElementJS(By.xpath("(//label[contains(@class,'user-card__name')])[" + i + "]"));
					sleepFor(1000);
					type = getData(By.xpath("(//label[contains(@class,'details__name')]//following::div)[1]"));

					if (type.equalsIgnoreCase("client") || type.equalsIgnoreCase("campus manager")) {
						data = getData(filteredUserOrgMobileCard);
						if (!data.trim().equalsIgnoreCase(filterValue.trim()))
							ExtentLogger.fail("Matched Data is not present in the Filtered Records for Organization");
						clickElementJS(iconCloseMoreOptionsMobile);
						sleepFor(500);
					}
				}
				break;
			case "campus manager":
				for (int i = 1; i <= listOfElements.size(); i++) {
					clickElementJS(By.xpath("(//label[contains(@class,'user-card__name')])[" + i + "]"));
					sleepFor(1000);
					type = getData(By.xpath("(//label[contains(@class,'details__name')]//following::div)[1]"));

					if (type.equalsIgnoreCase("client")) {
						data = getData(filteredUserCMNameMobileCard);
						if (!data.trim().equalsIgnoreCase(filterValue.trim()))
							ExtentLogger.fail("Matched Data is not present in the Filtered Records for Campus Manager");
						clickElementJS(iconCloseMoreOptionsMobile);
						sleepFor(500);
					}
				}
				break;
			default:
				Assert.fail("Unsupported SearchType Passed in the code.");
				break;
			}
		} catch (Exception e) {
			Assert.fail("Failed During Verification of Search Records for " + filterType + ". " + e.getMessage());
		}
	}

	public UsersPage verifyAvailableFilters() {
		try {
			String[] managerFilters = { "organization", "company", "school" };
			String[] adminFilters = { "organization", "company", "school", "campus manager" };
			clickElementJS(By.xpath("//div[contains(@class,'mobile')]/img[contains(@src,'filter')]"));
			sleepFor(1000);
			List<WebElement> availableMenus = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'filters__filter')]"));

			for (WebElement element : availableMenus) {
				if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("admin")) {
					if (!Arrays.toString(adminFilters).toLowerCase().contains(element.getText().toLowerCase())) {
						throw new Exception(element.getText() + " is not a valid filter for Admin.");
					}
				} else if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
						.equalsIgnoreCase("manager")) {
					if (!Arrays.toString(managerFilters).toLowerCase().contains(element.getText().toLowerCase())) {
						throw new Exception(element.getText() + " is not a valid filter for Admin.");
					}
				}
			}
			clickElementJS(iconCloseMoreOptionsMobile);
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
		return this;
	}

	public UsersPage filterOrgAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_ORGANIZATION_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "Organization");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			clickElementJS(By.xpath("//div[contains(@class,'mobile')]/img[contains(@src,'filter')]"));
			clickElementJS(By.xpath("//label[contains(text(),'Organization')]"));
			enterData(By.xpath("//input[@id='filter-overlay-input']"), filterValue);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOptionMobile, filterValue)));
			sleepFor(500);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass("Filtered " + filterValue + " as Organization and Verified all the records.");
		} catch (Exception e) {
			Assert.fail("Failed during filter and verification of Organization. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterSchoolAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_SCHOOL_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "School");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			clickElementJS(By.xpath("//div[contains(@class,'mobile')]/img[contains(@src,'filter')]"));
			clickElementJS(By.xpath("//label[contains(text(),'School')]"));
			enterData(By.xpath("//input[@id='filter-overlay-input']"), filterValue);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOptionMobile, filterValue)));
			sleepFor(500);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass("Filtered " + filterValue + " as School and Verified all the records.");
		} catch (Exception e) {
			Assert.fail("Failed during filter and verification of School. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterCompanyAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_COMPANY_NAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "Company");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			clickElementJS(By.xpath("//div[contains(@class,'mobile')]/img[contains(@src,'filter')]"));
			clickElementJS(By.xpath("//label[contains(text(),'Company')]"));
			enterData(By.xpath("//input[@id='filter-overlay-input']"), filterValue);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOptionMobile, filterValue)));
			sleepFor(500);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass("Filtered " + filterValue + " as Company and Verified all the records.");
		} catch (Exception e) {
			Assert.fail("Failed during filter and verification of Company. " + e.getMessage());
		}

		return this;
	}

	public UsersPage filterCampusManagerAndVerifyCard() {
		String filterValue = "";
		try {
			filterValue = InputPropertyUtils.get("EXISTING_MANAGER_USERNAME");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERTYPE", "Campus Manager");
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "FILTERVALUE", filterValue);
			clickElementJS(By.xpath("//div[contains(@class,'mobile')]/img[contains(@src,'filter')]"));
			clickElementJS(By.xpath("//label[contains(text(),'Campus Manager')]"));
			enterData(By.xpath("//input[@id='filter-overlay-input']"), filterValue);
			clickElement(By.xpath(DynamicXpathUtils.getXpathForString(drpdwnFilteredOptionMobile, filterValue)));
			sleepFor(500);
			List<WebElement> listOfName = DriverManager.getDriver()
					.findElements(By.xpath("//label[contains(@class,'user-card__name')]"));
			if (listOfName.size() < 1) {
				if (!findElementPresence(noRecordsDivMobile)) {
					throw new Exception("No Records Division is not displayed when no matching records are found.");
				}
			} else {
				verifyFilteredCardDetails(listOfName);
			}
			clickElementJS(By.xpath("//i[contains(@class,'ft-x cursor-pointer')]"));
			ExtentLogger.pass("Filtered " + filterValue + " as Campus Manger and Verified all the records.");
		} catch (Exception e) {
			Assert.fail("Failed during filter and verification of Campus Manager. " + e.getMessage());
		}

		return this;
	}
	
// added by Vidya on june 22
	
	public UsersPage filterDataAndVerifyData(){

		try{
		sleepFor(500);
		enterData(txtFilterData, "testclient36@xyz.com");
		ArrayList<HashMap<String, String>> completeData = null;
		
		ExtentLogger.pass("Filtering Functionality is Verifed for Email");
		}

		catch (Exception e) {
		Assert.fail("Filter is not working as expected for Email. " + e.getMessage());
				
		}

		return this;

		}
	
	public UsersPage connectdb() {

		try {

			DBSetupUtils.setupUserDatabase();
			sleepFor(500);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return this;
	}	
	
	public UsersPage filterUserforDelete(String user, String platform) {
		String email = null, password = null;

		try {
			
			if (user.equalsIgnoreCase("Existing")) {
				
				email = InputPropertyUtils.get("MANAGER_DELETE_CUSTOMER_EMAIL");
				password = InputPropertyUtils.get("MANAGER_DELETE_CUSTOMER_PASSWORD");
			} 
			
			if (platform.equalsIgnoreCase("desktop")) {
				enterData(txtFilterData, email);
			} else if (platform.equalsIgnoreCase("mobile")) {
				enterData(txtFilterDataMobile, email);
			}
			
			System.out.println("email : "+ email);

			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "EMAIL", email);
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "PASSWORD", password);
			sleepFor(1000);
			ExtentLogger.pass("Successfully Filtered User with Email: " + email);
		} catch (Exception e) {
			Assert.fail("Unable to Enter Data in Search Input Field. " + e.getMessage());
		}

		return this;
	}

	public UsersPage VerifyDashboardforDelete(UserType userType) {
		try {
			String email = RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "EMAIL");
			
			if (RunTimePropertyFileUtils.getRunTimeProperty(getTestCaseName(), "LOGGEDINAS")
					.equalsIgnoreCase("admin")) {
				switchTo(userType);
				enterData(txtFilterData, email);
				System.out.println(txtFilterData);
				sleepFor(1000);
			}
			ArrayList<HashMap<String, String>> completeData = readCurrentTable(userType);
			sleepFor(4000);

				if (completeData.size() != 0) {
					throw new Exception("Deleted User is still displayed after Filter.");
				}
				ExtentLogger.pass("Verified that the Deleted User is not displayed in Dashboard");
			

		} catch (Exception e) {
			Assert.fail("Failed to Verify Dashboard. " + e.getMessage());
		}

		return this;

	}	
	
	public UsersPage enterShippingWrongAddress(UserOperation userOperation, String platform) {
		try {
			HashMap<String, String> shippingDetailsMap = null;

			if (getTestCaseName().toLowerCase().contains("invalidaddress")) {
				shippingDetailsMap = DataGeneratorUtils.generateWrongShippingDetails("Invalid");
			} else {
				shippingDetailsMap = DataGeneratorUtils.generateWrongShippingDetails("Valid");
			}

			enterData(txtShippingName, shippingDetailsMap.get("SHIPPINGNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SHIPPINGNAME",
					shippingDetailsMap.get("SHIPPINGNAME"));

			enterData(txtAttentionName, shippingDetailsMap.get("ATTENTIONNAME"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ATTENTIONNAME",
					shippingDetailsMap.get("ATTENTIONNAME"));

			if (!platform.equalsIgnoreCase("mobile")) {
				clickElementJS(btnNext);
			}

			enterData(txtStreet, shippingDetailsMap.get("STREET"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "STREET", shippingDetailsMap.get("STREET"));

			enterData(txtSuite, shippingDetailsMap.get("SUITE"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "SUITE", shippingDetailsMap.get("SUITE"));

			enterData(txtCity, shippingDetailsMap.get("CITY"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "CITY", shippingDetailsMap.get("CITY"));

			clickElement(drpDwnState);
			enterData(drpDwnState, shippingDetailsMap.get("STATE"));
			clickElementJS(
					By.xpath(DynamicXpathUtils.getXpathForString(drpDwnStateValue, shippingDetailsMap.get("STATE"))));

			enterData(txtZipCode, shippingDetailsMap.get("ZIPCODE"));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "ZIPCODE", shippingDetailsMap.get("ZIPCODE"));

			clickElement(
					By.xpath(DynamicXpathUtils.getXpathForString(txtTimezone, shippingDetailsMap.get("TIMEZONE"))));
			RunTimePropertyFileUtils.appendToPropFile(getTestCaseName(), "TIMEZONE",
					shippingDetailsMap.get("TIMEZONE"));

			ExtentLogger.pass("Entered Shipping Address Fields Successfully");

			if (getTestCaseName().toLowerCase().contains("invalidaddress")) {
				clickElementJS(btnCreateAccount);
				ExplicitWaitFactory.explicitWaitUntil(WaitStrategy.VISIBLE, divInvalidAddress);
				clickElement(btnNo);
				ExtentLogger.pass("Address Validations are verified Successfully");
				clickElementJS(iconClose);
				clickElementJS(btnYes);

			}

		} catch (Exception e) {
			Assert.fail("Unable to Enter Shipping Address while Creating User. " + e.getMessage());
		}

		return this;
	}	
	
	public UsersPage saveData() {
		try {
			sleepFor(2000);
			
			clickElement(btnCreateAccount);
			saveWrongAdress();
			
			ExtentLogger.pass("Clicked Created Users Button Successfully");
		} catch (Exception e) {
			Assert.fail("Unable to Save Records. " + e.getMessage());
		}

		return this;
	}
	
	public UsersPage saveWrongAdress() {
		
		try {
			sleepFor(1000);
			clickElement(btnSaveData);
			sleepFor(1000);
			ExtentLogger.pass("Clicked Yes button Successfully for save the Wrong address");
			
		} catch (Exception e) {
			Assert.fail("Unable to Save Wrong address . " + e.getMessage());
		}
		
		return this;
	}
	
}
