package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;



import appEnums.GiftCardsTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class GiftCards_CountVerification extends MasterWrapper {

	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	@TestRail(TestingTC = "1142", StagingTC = "1393")
	public void AdminLogin_GiftCards_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.connectdb()
			.verifyRecordsCount(GiftCardsTabs.ACTIVE)
			.verifyRecordsCount(GiftCardsTabs.DISABLED);
	}
	
	@Test
	@TestRail(TestingTC = "1143", StagingTC = "1394")
	public void AdminLogin_GiftCards_Filter_TabTitleCountVerification() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.connectdb()
			.clickAndChooseFilter("Total Amount")
			.applyFilter("Total Amount")
			.verifyRecordsCount(GiftCardsTabs.ACTIVE)
			.verifyRecordsCount(GiftCardsTabs.DISABLED);
	}
}
