package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class GiftCards_CreateGiftCards extends MasterWrapper{

	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	@TestRail(TestingTC = "1128", StagingTC = "1379")
	public void AdminLogin_CreateGiftCard_ExistingClient_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickCreateGiftCardButton()
			.enterGiftCardCode()
			.enterDollerValue()
			.enterExpiryDate()
			.enterClientDetails("Existing")
			.verifySummary()
			.createGiftCard()
			.filterGiftCard()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1129", StagingTC = "1380")
	public void AdminLogin_CreateGiftCard_NewClient_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickCreateGiftCardButton()
			.enterGiftCardCode()
			.enterDollerValue()
			.enterExpiryDate()
			.enterClientDetails("New")
			.verifySummary()
			.createGiftCard()
			.filterGiftCard()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1130", StagingTC = "1381")
	public void AdminLogin_GiftCard_Validations() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickCreateGiftCardButton()
			.invalidGiftCardAndVerify("Existing")
			.invalidGiftCardAndVerify("Disabled")
			.invalidGiftCardAndVerify("Promocode");
	}
	
	
	@Test
//	@TestRail(TestingTC = "1129", StagingTC = "1380")
	public void AdminLogin_CreateGiftCard_CancelNewClient_NewClient_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickCreateGiftCardButton()
			.enterGiftCardCode()
			.enterDollerValue()
			.enterExpiryDate()
			.enterCancelNewClient("New")
			.verifySummary()
			.createGiftCard()
			.filterGiftCard()
			.verifyDashboard("Create")
			.logOut();
	}	
	
}
