package tests;

import org.testng.annotations.Test;

import appEnums.GiftCardsTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class GiftCards_DataFilterOperations extends MasterWrapper{
	
	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	@TestRail(TestingTC = "1132", StagingTC = "1383")
	public void AdminLogin_GiftCards_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.switchTo(GiftCardsTabs.ACTIVE)
			.filterAndVerifyAllColumns(GiftCardsTabs.ACTIVE)
			.switchTo(GiftCardsTabs.ALL)
			.filterAndVerifyAllColumns(GiftCardsTabs.ALL)
			.switchTo(GiftCardsTabs.DISABLED)
			.filterAndVerifyAllColumns(GiftCardsTabs.DISABLED);
	}
	
	@Test
	@TestRail(TestingTC = "1133", StagingTC = "1384")
	public void AdminLogin_GiftCards_RecordsFilter_Client_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilter("Client")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1134", StagingTC = "1385")
	public void AdminLogin_GiftCards_RecordsFilter_Issued_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickAndChooseFilter("Issued")
			.applyDateFilterAndVerify("On")
			.clickAndChooseFilter("Issued")
			.applyDateFilterAndVerify("After")
			.clickAndChooseFilter("Issued")
			.applyDateFilterAndVerify("Before");
	}
	
	@Test
	@TestRail(TestingTC = "1135", StagingTC = "1386")
	public void AdminLogin_GiftCards_RecordsFilter_Expired_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickAndChooseFilter("Expired")
			.applyDateFilterAndVerify("On")
			.clickAndChooseFilter("Expired")
			.applyDateFilterAndVerify("After")
			.clickAndChooseFilter("Expired")
			.applyDateFilterAndVerify("Before");
	}
	
	@Test
	@TestRail(TestingTC = "1136", StagingTC = "1387")
	public void AdminLogin_GiftCards_RecordsFilter_TotalAmount_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickAndChooseFilter("Total Amount")
			.applyFilter("Total Amount")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1137", StagingTC = "1388")
	public void AdminLogin_GiftCards_RecordsFilter_RemainingAmount_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.clickAndChooseFilter("Remaining Amount")
			.applyFilter("Remaining Amount")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1138", StagingTC = "1389")
	public void AdminLogin_GiftCards_Status_AllTabs_AllUsers() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(GiftCardsTabs.ACTIVE)
			.verifyStatusColumn(GiftCardsTabs.ACTIVE)
			.switchTo(GiftCardsTabs.DISABLED)
			.verifyStatusColumn(GiftCardsTabs.DISABLED)
			.logOut();
	}
}
