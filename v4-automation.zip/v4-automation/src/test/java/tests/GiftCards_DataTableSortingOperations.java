package tests;

import org.testng.annotations.Test;

import appEnums.GiftCardsTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class GiftCards_DataTableSortingOperations extends MasterWrapper {

	// Remove navigateToUsersPage("Desktop") in all testcases once we are able to
	// access GiftCards from V3
	@Test
	@TestRail(TestingTC = "1139", StagingTC = "1390")
	public void AdminLogin_GiftCards_SortingDashboardItems_AllTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)	
//			.navigateToUsersPage("Desktop")
			.navigateToGiftCardsPage("Desktop")
			.switchTo(GiftCardsTabs.ALL)
			.sortAndVerifyAllColumns(GiftCardsTabs.ALL);
	}

	@Test
	@TestRail(TestingTC = "1140", StagingTC = "1391")
	public void AdminLogin_GiftCards_SortingDashboardItems_ActiveTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
				.navigateToGiftCardsPage("Desktop").switchTo(GiftCardsTabs.ACTIVE)
				.sortAndVerifyAllColumns(GiftCardsTabs.ACTIVE);
	}

	@Test
	@TestRail(TestingTC = "1141", StagingTC = "1392")
	public void AdminLogin_GiftCards_SortingDashboardItems_DisabledTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
				.navigateToGiftCardsPage("Desktop").switchTo(GiftCardsTabs.DISABLED)

				.sortAndVerifyAllColumns(GiftCardsTabs.DISABLED);
	}

}
