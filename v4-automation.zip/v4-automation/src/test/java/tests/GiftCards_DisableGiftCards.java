package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class GiftCards_DisableGiftCards extends MasterWrapper {

	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	@TestRail(TestingTC = "1131", StagingTC = "1382")
	public void AdminLogin_DisableExistingGiftCard_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
	     	.navigateToGiftCardsPage("Desktop")
			.disableOneGiftCardAndVerify()
			.disableMultipleGiftCardsAndVerify(2);
	}
}
