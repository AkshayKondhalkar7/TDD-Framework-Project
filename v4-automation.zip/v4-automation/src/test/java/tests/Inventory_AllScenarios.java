package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import masterClasses.MasterWrapper;
import customAnnotations.TestRailAnnotation.TestRail;


public class Inventory_AllScenarios extends MasterWrapper{
	

	
	@Test 
	@TestRail(TestingTC = "9389", StagingTC = "9404")
	public void AdminLogin_Inventory_AddIncomingStocks_SingleProduct_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
		//	.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Single Tab")
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Single Tab")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	
	@Test 
	@TestRail(TestingTC = "9390", StagingTC = "9405")
	public void AdminLogin_Inventory_AddIncomingStocks_Nextmonthdate_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
		//	.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetailsforNextmonth()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Single Tab")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
		}
	
	@Test 
//	@TestRail(TestingTC = "", StagingTC = "")
	public void AdminLogin_Inventory_AddIncomingStocks_Currentdate_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
		//	.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetailsforCurrentDate()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Single Tab")
			.logOutInv();

		}
	
	@Test 
	@TestRail(TestingTC = "9391", StagingTC = "9406")
	public void AdminLogin_Inventory_AddIncomingStocks_MultipleProducts_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
	//		.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(3)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Multiple ProductSingle_Tab")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	
	
	
	
	
	
	@Test  
	@TestRail(TestingTC = "9392", StagingTC = "9407")
	public void AdminLogin_Inventory_AddIncomingStocks_MultipleProductsMultiStock_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(3)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Multiple Product_MultiStock_Single_Tab")
			.chooseProducts(3)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Multiple Product_MultiStock_Single_Tab")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	
	@Test 
	@TestRail(TestingTC = "9393", StagingTC = "9408")
	public void AdminLogin_Inventory_AddIncomingStock_DifferentProducts_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.chooseProducts("Multiple")
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.expandProductDetailsAndVerifyStocks("Different Product")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	@Test 
	@TestRail(TestingTC = "9394", StagingTC = "9409")
	public void AdminLogin_Inventory_EditExistingStocks_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickEditStocksButton(1)
			.EditExistingStocks()
			.saveStocks("Update")
			.filterProduct()
			.verifyEditedStocks()
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	
	@Test 
	@TestRail(TestingTC = "9395", StagingTC = "9410")
	public void AdminLogin_Inventory_DeleteStocks_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.chooseProducts(1)
			.clickEditStocksButton(1)
		    .clickDeleteButton()
			.clickCloseEditButton()
			.filterProduct()
			.expandProductDetailsAndVerifyStocks("Delete")
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	
	@Test 
	@TestRail(TestingTC = "9396", StagingTC = "9411")
	public void AdminLogin_Inventory_AddIncomingStocks_VerifyRestockDate()  {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.expandProductDetailsAndVerifyRestockDate(3)
			.logOutInv();
//			.userLogin(UserType.ADMIN)
//			.logOut();
	}
	
	
	@Test 
	@TestRail(TestingTC = "9397", StagingTC = "9412")
	public void AdminLogin_Inventory_VerifyProductsInEachTab() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyProductNamesInAllTabs()
			.logOutInv();
	}
	
	@Test 
	@TestRail(TestingTC = "9398", StagingTC = "9413")
	public void AdminLogin_Inventory_SearchProductName() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.filterDataAndVerify("Product Name")
			.logOutInv();
	}
	

	
	@Test  
	@TestRail(TestingTC = "9399", StagingTC = "9414")
	public void AdminLogin_Inventory_SortColumns_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
//			.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.choosePaginationCount("100")
			.sortAndVerifyAllTabs()
			.logOutInv();
	}
	
	@Test 
	@TestRail(TestingTC = "9400", StagingTC = "9415")
	public void ManagerLogin_Inventory_SearchProductName() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.filterDataAndVerify("Product Name")
			.logOutInv();
	}
	

	@Test 
	@TestRail(TestingTC = "9401", StagingTC = "9416")
	public void ManagerLogin_Inventory_SortColumns_AllTabs() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.choosePaginationCount("100")
			.sortAndVerifyAllTabs()
			.logOutInv();
	}
	
	@Test 
//	@TestRail(TestingTC = "9389", StagingTC = "9404")
	public void AdminLogin_Inventory_AddIncomingStocks_EditIncomingStocks_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
		//	.navigateToUsersPage("Desktop")
			.navigateToInventoryPage("Desktop")
			.verifyMenuAbsence()
			.filterProduct()
			.chooseProducts(1)
			.clickAddIncomingStocksButton(1)
			.enterStockDetails()
			.saveStocks("Add")
			.filterProduct()
			.chooseProducts(1)
			.clickEditStocksButton(1)
			.EditIncomingStocks()
			.saveStocks("Update")
			.expandProductDetailsAndVerifyStocks("Single Tab")
			.logOutInv();

	}
}
