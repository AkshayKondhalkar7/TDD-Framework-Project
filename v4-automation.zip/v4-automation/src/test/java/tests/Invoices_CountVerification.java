package tests;

import org.testng.annotations.Test;



import appEnums.InvoiceTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Invoices_CountVerification extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "1035", StagingTC = "1286")
	public void AdminLogin_Invoices_TabTitleTotalValueVerification() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.verifyTabTotalAmount(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyTabTotalAmount(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED);
	} 
	
	
	@Test
	@TestRail(TestingTC = "1036", StagingTC = "1287")
	public void ManagerLogin_Invoices_TabTitleTotalValueVerification() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.verifyTabTotalAmount(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyTabTotalAmount(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED);
	}
	
	@Test
	@TestRail(TestingTC = "1037", StagingTC = "1288")
	public void ClientLogin_Invoices_TabTitleTotalValueVerification() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.verifyTabTotalAmount(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyTabTotalAmount(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED);
	}

	
	// Added by Akshay
	 
	 @Test 
	 public void AdminLogin_Invoices_VerifyTabsCount() throws Exception {
	    loginPage.userLogin(UserType.ADMIN) 
	        .navigateToInvoicesPage("Desktop")
            .enterID_admin("Existing")
            .switchTo(InvoiceTabs.OPEN)
			.verifyTabTotalAmount(InvoiceTabs.OPEN)
			.verifyTabs_admin(InvoiceTabs.OPEN)
//			.switchTo(InvoiceTabs.OVERDUE)
//			.verifyTabTotalAmount(InvoiceTabs.OVERDUE)
//			.verifyTabs_admin(InvoiceTabs.OVERDUE)
            .logout();
	 }
	 
	 
	 @Test 
	 public void ManagerLogin_Invoices_VerifyTabsCount() throws Exception {
	    loginPage.userLogin(UserType.CAMPUS_MANAGER) 
	        .navigateToInvoicesPage("Desktop")	
            .enterID_manager("Existing")
            .switchTo(InvoiceTabs.OVERDUE)
            .verifyTabTotalAmount(InvoiceTabs.OVERDUE)
            .verifyTabs_manager(InvoiceTabs.OVERDUE)
//			.switchTo(InvoiceTabs.OPEN)
//			.verifyTabTotalAmount(InvoiceTabs.OPEN)
//			.verifyTabs_manager(InvoiceTabs.OPEN)
            .logout();
	 } 
}
