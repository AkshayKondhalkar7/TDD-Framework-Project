package tests;

import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Invoices_CreateAndEditInvoices extends MasterWrapper {
	
	@Test(enabled = false)
	@TestRail(TestingTC = "1002", StagingTC = "1253")
	public void AdminLogin_CreateInvoice_ExistingClient_MultipleItems_VerifyDashboards() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("Existing")
			.addInvoiceItems(4)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	@Test(enabled = false)
	@TestRail(TestingTC = "1003", StagingTC = "1254")
	public void AdminLogin_CreateInvoice_NewClient_MultipleItems_VerifyDashboards() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("New")
			.addInvoiceItems(1)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1004", StagingTC = "1255")
	public void AdminLogin_EditExistingInvoice_VerifyDashboard_ClientLogin_VerifyInvoice() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPages("Desktop")
			.openInvoiceForEdit("existing for edit")
			.editClientDetails()
			.addInvoiceItems(3)
			.applyDiscounts()
			.saveInvoice("Edit")
			.verifySubTotalAndTotal()
			.openInvoicePage()
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	@Test(enabled = false)
	@TestRail(TestingTC = "1005", StagingTC = "1256")
	public void AdminLogin_Invoices_E2EFlow_Create_Edit_Payments_VerifyDashboards() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("Existing")
			.addInvoiceItems(1)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPages("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.userLogin(UserType.ADMIN)
			.navigateToInvoicesPages("Desktop")
			.openInvoiceForEdit("New")
			.addInvoiceItems(2)
			.verifySubTotalAndTotal()
			.saveInvoice("Edit")
			.openInvoicePage()
			.filterAndVerifyDashboard("Open")
			.logOut()
			.userLogin(UserType.ADMIN)
			.navigateToInvoicesPages("Desktop")
			.filterAndVerifyDashboard("Open")
			.hoverAndChoosePaymentType("Check")
			.fillPaymentDetails("Check")
			.completePaymentAndVerifySuccessMessage()
			.filterAndVerifyDashboard("Closed")
			.openInvoiceForEdit("New")
			.addComments()
			.saveInvoice("Comments")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Closed")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPages("Desktop")
			.filterAndVerifyDashboard("Closed")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1006", StagingTC = "1257")
	public void AdminLogin_Invoices_Validations() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.invoiceDetailsValidations()
			.invoiceItemValidations()
			.logOut();
	}

	@Test
	@TestRail(TestingTC = "1007", StagingTC = "1258")
	public void AdminLogin_EmailInvoiceVerification() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("Existing")
			.addInvoiceItems(2)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.addCustomerPO("Numeric")
			.saveInvoice("Edit")
			.clickEmailInvoiceButton();
			/*.enterMailBody()
			.sendEmail()
			.launchYopMail()
			.openInbox()
			.verifyEmailReceived();
		*/
	}
	
	@Test(enabled = false)
//	@TestRail(TestingTC = "1003", StagingTC = "1254")
	public void AdminLogin_CreateInvoice_CancelNewClient_NewClient_MultipleItems_VerifyDashboards() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("New Cancel New")
			.addInvoiceItems(1)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	

	@Test(enabled = false)	
	public void AdminLogin_CreateInvoice_ExistingClient_MultipleItem_RemoveMultipleItem_VerifyDashboards() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("Existing")
			.addInvoiceItems(4)
			.removeInvoiceItems(3)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	@Test(enabled = false)
	public void AdminLogin_CreateInvoice_NewClient_MultipleItems_RemoveMultipleItem_VerifyDashboards() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAddInvoiceButton()
			.enterClientDetails("New")
			.addInvoiceItems(4)
			.removeInvoiceItems(3)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("New")
			.verifySuccessMessage()
			.filterAndVerifyDashboard("Open")
			.openInvoice()
			.verifyData()
			.downloadInvoicePDFAndVerify()
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	@Test
	public void AdminLogin_EditExistingInvoice_MultipleItems_RemoveMultipleItem_VerifyDashboard_ClientLogin_VerifyInvoice() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPages("Desktop")
			.openInvoiceForEdit("Existing")
			.editClientDetails()
			.addInvoiceItems(4)
			.removeInvoiceItems(3)
			.verifySubTotalAndTotal()
			.applyDiscounts()
			.verifySubTotalAndTotal()
			.saveInvoice("Edit")
			.openInvoicePage()
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut()
			.loginToVerifyInvoiceDashboard(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.filterAndVerifyDashboard("Open")
			.logOut();
	}
	
	

	
}
