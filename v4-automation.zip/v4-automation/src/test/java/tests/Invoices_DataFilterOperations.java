package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.InvoiceTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Invoices_DataFilterOperations extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "1016", StagingTC = "1267")
	public void AdminLogin_Invoices_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OVERDUE)
			.filterAndVerifyAllColumns(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.filterAndVerifyAllColumns(InvoiceTabs.ALL_UNPAID)
			.switchTo(InvoiceTabs.OPEN)
			.filterAndVerifyAllColumns(InvoiceTabs.OPEN);
	}
	
	@Test
	@TestRail(TestingTC = "1017", StagingTC = "1268")
	public void AdminLogin_Invoices_RecordsFilter_Client_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilter("Client")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1018", StagingTC = "1269")
	public void AdminLogin_Invoices_RecordsFilter_Manager_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Manager")
			.applyFilter("Manager")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1019", StagingTC = "1270")
	public void AdminLogin_Invoices_RecordsFilter_DueOn_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Due On")
			.applyFilter("Due On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1020", StagingTC = "1271")
	public void AdminLogin_Invoices_RecordsFilter_CreatedOn_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Created On")
			.applyFilter("Created On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1021", StagingTC = "1272")
	public void ManagerLogin_Invoices_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.filterAndVerifyAllColumns(InvoiceTabs.ALL_UNPAID)
			.switchTo(InvoiceTabs.OPEN)
			.filterAndVerifyAllColumns(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.filterAndVerifyAllColumns(InvoiceTabs.OVERDUE);
	}
	
	@Test
	@TestRail(TestingTC = "1022", StagingTC = "1273")
	public void ManagerLogin_Invoices_RecordsFilter_DueOn_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Due On")
			.applyFilter("Due On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1023", StagingTC = "1274")
	public void ManagerLogin_Invoices_RecordsFilter_CreatedOn_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Created On")
			.applyFilter("Created On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1024", StagingTC = "1275")
	public void ClientLogin_Invoices_RecordsFilter_DueOn_VerifyDashboard() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Due On")
			.applyFilter("Due On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1025", StagingTC = "1276")
	public void ClientLogin_Invoices_RecordsFilter_CreatedOn_VerifyDashboard() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.clickAndChooseFilter("Created On")
			.applyFilter("Created On")
			.verifyDashboard();
	}
	
	@Test
	@TestRail(TestingTC = "1026", StagingTC = "1277")
	public void Invoices_Status_AllTabs_AllUsers() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(InvoiceTabs.OPEN)
			.verifyStatusColumn(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyStatusColumn(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.CLOSED)
			.verifyStatusColumn(InvoiceTabs.CLOSED)
			.logOut()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(InvoiceTabs.OPEN)
			.verifyStatusColumn(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyStatusColumn(InvoiceTabs.OVERDUE)
			.switchTo(InvoiceTabs.CLOSED)
			.verifyStatusColumn(InvoiceTabs.CLOSED)
			.logOut()
			.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(InvoiceTabs.OPEN)
			.verifyStatusColumn(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.verifyStatusColumn(InvoiceTabs.OVERDUE)
			.logOut();
	}
	
	@Test
//	@TestRail(TestingTC = "1021", StagingTC = "1272")
	public void ManagerLogin_Invoices_SearchRecords_WithWrongValues_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.filterAndVerifyAllColumn(InvoiceTabs.ALL_UNPAID)
			.switchTo(InvoiceTabs.OPEN)
			.filterAndVerifyAllColumn(InvoiceTabs.OPEN)
			.switchTo(InvoiceTabs.OVERDUE)
			.filterAndVerifyAllColumn(InvoiceTabs.OVERDUE);
	}

}
