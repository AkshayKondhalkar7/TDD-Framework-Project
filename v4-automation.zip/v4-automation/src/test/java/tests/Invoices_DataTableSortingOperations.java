package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import appEnums.InvoiceTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Invoices_DataTableSortingOperations extends MasterWrapper{

	@Test
	@TestRail(TestingTC = "1027", StagingTC = "1278")
	public void AdminLogin_Invoices_SortingDashboardItems_AllUnPaidTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.choosePaginationCount("100")
			.sortAndVerifyAllColumns(InvoiceTabs.ALL_UNPAID)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1028", StagingTC = "1279")
	public void AdminLogin_Invoices_SortingDashboardItems_OpenTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.sortAndVerifyAllColumns(InvoiceTabs.OPEN)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1029", StagingTC = "1280")
	public void AdminLogin_Invoices_SortingDashboardItems_OverdueTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OVERDUE)
			.sortAndVerifyAllColumns(InvoiceTabs.OVERDUE)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1030", StagingTC = "1281")
	public void ManagerLogin_Invoices_SortingDashboardItems_AllUnPaidTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.sortAndVerifyAllColumns(InvoiceTabs.ALL_UNPAID)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1031", StagingTC = "1282")
	public void ManagerLogin_Invoices_SortingDashboardItems_OpenTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.sortAndVerifyAllColumns(InvoiceTabs.OPEN)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1032", StagingTC = "1283")
	public void ManagerLogin_Invoices_SortingDashboardItems_OverdueTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OVERDUE)
			.sortAndVerifyAllColumns(InvoiceTabs.OVERDUE)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1033", StagingTC = "1284")
	public void ClientLogin_Invoices_SortingDashboardItems_AllUnPaidTab_AllColumns() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.ALL_UNPAID)
			.sortAndVerifyAllColumns(InvoiceTabs.ALL_UNPAID)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1034", StagingTC = "1285")
	public void ClientLogin_Invoices_SortingDashboardItems_OpenTab_AllColumns() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.switchTo(InvoiceTabs.OPEN)
			.sortAndVerifyAllColumns(InvoiceTabs.OPEN)
			.logOut();
	}
}
