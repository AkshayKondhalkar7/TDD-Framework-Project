package tests;

import org.testng.annotations.Test;

import appEnums.InvoiceTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Invoices_PaymentsVerification extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "1008", StagingTC = "1259")
	public void AdminLogin_ExistingInvoice_PayViaCheck_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Check")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Check")
			.fillPaymentDetails("Check")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Check")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Check")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1009", StagingTC = "1260")
	public void AdminLogin_ExistingInvoice_PayViaCreditCard_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Credit Card")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Credit Card")
			.fillPaymentDetails("Credit Card")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Credit Card")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Credit Card")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1010", StagingTC = "1261")
	public void AdminLogin_ExistingInvoice_PayViaVenmo_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Venmo")
			.verifyAvailablePaymentMethods()
			.openInvoice()
			.hoverAndChoosePaymentTypes("Venmo")
			.fillPaymentDetailsVenmo("Venmo")
			.completePaymentAndVerifySuccessMessage()
			.navigateToInvoicesPages("Desktop")
			.clearfilter()
			.filterInvoice("Venmo")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Venmo")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1011", StagingTC = "1262")
	public void AdminLogin_ExistingInvoice_PartialPayments_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Check")
			.fillPartialPaymentDetails()
			.filterInvoice("Check")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Check")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1012", StagingTC = "1263")
	public void ManagerLogin_ExistingInvoice_PayViaCheck_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Check")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Check")
			.verifyMessageInPaymentPage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1013", StagingTC = "1264")
	public void ManagerLogin_ExistingInvoice_PayViaCreditCard_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Credit Card")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Credit Card")
			.fillPaymentDetails("Credit Card")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Credit Card")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1014", StagingTC = "1265")
	public void ClientLogin_ExistingInvoice_PayViaCheck_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Check")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Check")
			.verifyMessageInPaymentPage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1015", StagingTC = "1266")
	public void ClientLogin_ExistingInvoice_PayViaCreditCard_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Credit Card")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Credit Card")
			.fillPaymentDetails("Credit Card")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Credit Card")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.logOut();
	}

	/*Admin login Zero payment _ Check */
	@Test
	@TestRail(TestingTC = "15884", StagingTC = "15887")
	public void AdminLogin_ExistingInvoice_PayViaCheck_ZeroPayment_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Check")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Check")
			.fillZeroPaymentDetails("Check")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Check")
			.openInvoice()
			.verifyZeroPaymentHistory()
			.logOut();
	}	
	
	/*Admin login Zero payment _ CreditCard */
	@Test
	@TestRail(TestingTC = "15885", StagingTC = "15888")
	public void AdminLogin_ExistingInvoice_PayViaCreditCard_ZeroPayment_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Credit Card")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Credit Card")
			.fillZeroPaymentDetails("Credit Card")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Credit Card")
			.openInvoice()
			.verifyZeroPaymentHistory()
			.logOut();
	}
	
	/*Admin login Zero payment _ Venmo */
	@Test
	@TestRail(TestingTC = "15886", StagingTC = "15889")
	public void AdminLogin_ExistingInvoice_PayViaVenmo_ZeroPayment_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Venmo")
			.verifyAvailablePaymentMethods()
			.openInvoice()
			.hoverAndChoosePaymentTypes("Venmo")
			.fillZeroPaymentDetailsVenmo("Venmo")
			.completePaymentAndVerifySuccessMessage()
			.navigateToInvoicesPages("Desktop")
			.clearfilter()
			.filterInvoice("Venmo")
			.openInvoice()
			.verifyZeroPaymentHistory()
			.logOut();
	}
	
	@Test
	public void AdminLogin_ExistingInvoice_PayViaWireTransfer_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Transfer")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Transfer")
			.fillPaymentDetails("Transfer")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Transfer")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Transfer")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}	
	
	@Test
	public void AdminLogin_ExistingInvoice_PayViaZelle_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Zelle")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Zelle")
			.fillPaymentDetails("Zelle")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Zelle")
			.verifyStatus("Closed")
			.switchTo(InvoiceTabs.CLOSED)
			.verifyTabTotalAmount(InvoiceTabs.CLOSED)
			.filterInvoice("Zelle")
			.openInvoice()
			.verifyPaymentHistory()
			.logOut();
	}	
	
	@Test
	public void AdminLogin_ExistingInvoice_PayViaWireTransfer_ZeroPayment_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Transfer")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Transfer")
			.fillZeroPaymentDetails("Transfer")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Transfer")
			.openInvoice()
			.verifyZeroPaymentHistory()
			.logOut();
	}	
	
	@Test
	public void AdminLogin_ExistingInvoice_PayViaZelle_ZeroPayment_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToInvoicesPage("Desktop")
			.connectdb()
			.filterInvoice("Zelle")
			.verifyAvailablePaymentMethods()
			.hoverAndChoosePaymentType("Zelle")
			.fillZeroPaymentDetails("Zelle")
			.completePaymentAndVerifySuccessMessage()
			.filterInvoice("Zelle")
			.openInvoice()
			.verifyZeroPaymentHistory()
			.logOut();
	}
	
	@Test
	public void ManagerLogin_ExistingInvoice_PayViaWireTransfer_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
		.navigateToInvoicesPage("Desktop")
		.connectdb()
		.filterInvoice("Transfer")
		.verifyAvailablePaymentMethods()
		.hoverAndChoosePaymentType("Transfer")
		.verifyMessageInPaymentsPage("Transfer")
		.logOut();
	}	
	
	@Test
	public void ManagerLogin_ExistingInvoice_PayViaZelle_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
		.navigateToInvoicesPage("Desktop")
		.connectdb()
		.filterInvoice("Zelle")
		.verifyAvailablePaymentMethods()
		.hoverAndChoosePaymentType("Zelle")
		.verifyMessageInPaymentsPage("Zelle")
		.logOut();
	}	
	
	@Test
	public void ClientLogin_ExistingInvoice_PayViaWireTransfer_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CLIENT)
		.navigateToInvoicesPage("Desktop")
		.connectdb()
		.filterInvoice("Transfer")
		.verifyAvailablePaymentMethods()
		.hoverAndChoosePaymentType("Transfer")
		.verifyMessageInPaymentsPage("Transfer")
		.logOut();
	}	
	
	@Test
	public void ClientLogin_ExistingInvoice_PayViaZelle_VerifyPaymentDue() {
		
		loginPage.userLogin(UserType.CLIENT)
		.navigateToInvoicesPage("Desktop")
		.connectdb()
		.filterInvoice("Zelle")
		.verifyAvailablePaymentMethods()
		.hoverAndChoosePaymentType("Zelle")
		.verifyMessageInPaymentsPage("Zelle")
		.logOut();
	}	
	
}
