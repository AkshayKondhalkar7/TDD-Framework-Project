package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.OrdersTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Orders_CountVerification extends MasterWrapper{

	@Test
	public void AdminLogin_Orders_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.verifyRecordsCount(OrdersTabs.UNPROCESSED)
			.verifyRecordsCount(OrdersTabs.AT_PRINTER)
			.verifyRecordsCount(OrdersTabs.AT_FULFILLMENT)
			.verifyRecordsCount(OrdersTabs.SHIPPED)
			.verifyRecordsCount(OrdersTabs.DELIVERED)
			.verifyRecordsCount(OrdersTabs.OPEN_GROUP_ORDER)
			.verifyRecordsCount(OrdersTabs.DRAFT)
			.logOut();
	}
	
	@Test
	public void ManagerLogin_Orders_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.verifyRecordsCount(OrdersTabs.UNPROCESSED)
		//	.verifyRecordsCount(OrdersTabs.AT_PRINTER)
		//	.verifyRecordsCount(OrdersTabs.AT_FULFILLMENT)
		//	.verifyRecordsCount(OrdersTabs.SHIPPED)
			.verifyRecordsCount(OrdersTabs.DELIVERED)
			.verifyRecordsCount(OrdersTabs.OPEN_GROUP_ORDER)
			.verifyRecordsCount(OrdersTabs.DRAFT)
			.logOut();
	}
	
}
