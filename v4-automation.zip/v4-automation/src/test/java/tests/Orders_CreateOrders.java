package tests;




import org.testng.annotations.Test;
import org.testng.annotations.Test;

import appEnums.UserType;
import masterClasses.MasterWrapper;
import pages.OrdersPageNew;





public class Orders_CreateOrders extends MasterWrapper {
	
	@Test
	
	public void AdminLogin_CreateSampleOrder() throws Exception {
		
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToOrdersPage("Desktop")
		.navigateTocreateOrder("Desktop")
		.orderCategory("SampleOrder")
		.createSampleOrder()	
		.closeBrowser();
	}
	
	

	
	
	


}
