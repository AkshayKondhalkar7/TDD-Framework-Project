package tests;




import org.testng.annotations.Test;
import org.testng.annotations.Test;

import appEnums.UserType;
import masterClasses.MasterWrapper;




public class Orders_CreateOrders_All extends MasterWrapper {



	
	@Test
	
	public void AdminLogin_CreateSampleOrder() throws Exception {
		
		
		loginPage.userLogin(UserType.ADMIN)
		
		.navigateToOrdersPage("Desktop")
		.navigateTocreateOrder("Desktop")
		.orderCategory("SampleOrder")
		.createSampleOrder()	
		.closeBrowser();
	}
	
	

	
	
	


}
