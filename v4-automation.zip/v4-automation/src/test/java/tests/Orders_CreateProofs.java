package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.OrdersTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Orders_CreateProofs extends MasterWrapper {

	/* Creating Regular order ( IndividualShipment ) with existing client */
	@Test
	public void AdminLogin_CreateRegularOrder_ExistingClient_IndividualShipment_VerifyDashboard() throws Exception {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickOrderButton()
			.selectOrderType("Regular Order")
			.fillOrderDetails("Existing")
			.clickAddProofButton() 
			.fillProofDetails()
			.clickAddQuantityandPrice()
			.fillQuantityandPrice()
			.clickAddShippingAddress()
			.selectShipmentType("Individual Ship");
		
			
			
		
	
		
	//		.logOut();
			
	}

	/* Creating Regular order ( BulkShipment ) with existing client */

	public void AdminLogin_CreateRegularOrder_ExistingClient_BulkShipment_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickOrderButton()
			.selectOrderType("Regular Order")
			.fillOrderDetails("Existing")
			.clickAddProofButton() 
			.fillProofDetails()
			.clickAddQuantityandPrice()
			.fillQuantityandPrice()
			.clickAddShippingAddress()
			.selectShipmentType("Bulk Ship")
			.fillBulkShipmentAddress()
			.clickReviewOrder()
			.verifyReviewOrderDetails()
			.reviewItemDetails()
			.reviewQuantityandPrice()
			.clickSubmit()
			.filterOrder()
			.verifyOrderDashboard()
			
		
			
			
		
	
		
			.logOut();
			
	}
	
	/* Creating Regular order ( BulkShipment ) With Proof Skip*/
	@Test
	public void AdminLogin_CreateRegularOrder_ExistingClient_WithProofSkip_BulkShipment_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickOrderButton()
			.selectOrderType("Regular Order")
			.fillOrderDetails("Existing")
			.clickAddProofButton() 
			.clickProofSkip()
			.fillItemDetails()
			.ClickAddDesignInfo()
			.fillDesignDetails()
			.clickAddQuantityandPrice()
			.fillQuantityandPrice()
			.clickAddShippingAddress()
			.selectShipmentType("Bulk Ship")
			.fillBulkShipmentAddress()
			.clickReviewOrder()
			.verifyReviewOrderDetails()
			.reviewItemDetails()
			.reviewQuantityandPrice()
			.clickSubmit()
			.filterOrder()
			.verifyOrderDashboard()
		
		
	
		
			.logOut();
			
	}
	
	/* Creating Regular order ( BulkShipment ) With Proof Skip with edit left panel before order submit */
	@Test
	public void AdminLogin_CreateRegularOrder_ExistingClient_WithProofSkip_BulkShipment_EditLeftPanel_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickOrderButton()
			.selectOrderType("Regular Order")
			.fillOrderDetails("Existing")
			.clickAddProofButton() 
			.clickProofSkip()
			.fillItemDetails()
			.ClickAddDesignInfo()
			.fillDesignDetails()
			.editleftPanelOrderDetails("Existing")
			.editleftPanelItemDetails()
			
			
//			.clickAddQuantityandPrice()
//			.fillQuantityandPrice()
//			.clickAddShippingAddress()
//			.selectShipmentType("Bulk Ship")
//			.fillBulkShipmentAddress()
//			.clickReviewOrder()

		
	
		
			.logOut();
			
	}
	
	/* Creating Regular order ( BulkShipment ) with existing client Multiple Proofs */
	@Test
	public void AdminLogin_CreateRegularOrder_ExistingClient_BulkShipment_MultipleProofs_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickOrderButton()
			.selectOrderType("Regular Order")
			.fillOrderDetails("Existing")
			.clickAddProofButton() 
			.fillProofDetails()
			.clickAddQuantityandPrice()
			.fillQuantityandPrice()
			.addAnotherItem()
			.fillProofDetails("fp")
			.clickAddQuantityandPrice()
			.fillQuantityandPriceforFP()
			.addAnotherItem()
			.fillProofDetails("Alpha")
			.clickAddQuantityandPrice()
			.fillQuantityandPriceforAlpha()
			.addAnotherItem()
			.fillProofDetails("External")
			.clickAddQuantityandPrice()
			.fillQuantityandPriceforExternal()
			.clickAddShippingAddress()
			.selectShipmentType("Bulk Ship")
			.fillBulkShipmentAddress()
			.clickReviewOrder()
			.reviewItemDetails()
			.reviewQuantityandPrice()
			.selectFPDetails()
			.reviewItemDetailsforFP()
			.reviewQuantityandPriceforFP()
			.selectAlphaDetails()
			.reviewItemDetailsforAlpha()
			.reviewQuantityandPriceforAlpha();
			
		
			
			
		
	
		
//			.logOut();
			
	}

	@Test
	public void AdminLogin_CreateRegularOrder_NewClient__VerifyDashboard() throws Exception {
		loginPage.userLogin(UserType.ADMIN).navigateToUsersPage("Desktop").navigateToOrdersPage("Desktop")
				.clickOrderButton().selectOrderType("Regular Order").fillOrderDetails("new").clickAddProofButton()

				.logOut();

	}

}
