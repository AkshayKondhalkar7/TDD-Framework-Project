package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.OrdersTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Orders_DataFilterOperations extends MasterWrapper{

	@Test
	public void AdminLogin_Orders_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.ALL_ACTIVE)
			.filterAndVerifyAllColumns(OrdersTabs.ALL_ACTIVE)
			.switchTo(OrdersTabs.UNPROCESSED)
			.filterAndVerifyAllColumns(OrdersTabs.UNPROCESSED)
			.switchTo(OrdersTabs.AT_PRINTER)
			.filterAndVerifyAllColumns(OrdersTabs.AT_PRINTER)
			.switchTo(OrdersTabs.AT_FULFILLMENT)
			.filterAndVerifyAllColumns(OrdersTabs.AT_FULFILLMENT)
			.switchTo(OrdersTabs.SHIPPED)
			.filterAndVerifyAllColumns(OrdersTabs.SHIPPED)
			.switchTo(OrdersTabs.DELIVERED)
			.filterAndVerifyAllColumns(OrdersTabs.DELIVERED)
			.switchTo(OrdersTabs.OPEN_GROUP_ORDER)
			.filterAndVerifyAllColumns(OrdersTabs.OPEN_GROUP_ORDER)
			.switchTo(OrdersTabs.FAILED_GROUP_ORDER)
			.filterAndVerifyAllColumns(OrdersTabs.FAILED_GROUP_ORDER)
			.switchTo(OrdersTabs.DRAFT)
			.filterAndVerifyAllColumns(OrdersTabs.DRAFT);
	}
	
	@Test
	public void AdminLogin_Orders_RecordsFilter_AllFilters_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilter("Client")
			.verifyDashboard()
//			.clickAndChooseFilter("Campus Manager")
//			.applyFilter("Campus Manager")
			.clickAndChooseFilter("Manager")
			.applyFilter("Manager")
			.verifyDashboard()
			.clickAndChooseFilter("Type")
			.applyFilter("Indiv Ship")
			.verifyDashboard()
			.clickAndChooseFilter("Type")
			.applyFilter("Bulk Ship")
			.verifyDashboard()
			.clickAndChooseFilter("Created Date")
			.applyDateFilterAndVerify("On")
			.clickAndChooseFilter("Due Date")
			.applyDateFilterAndVerify("On");
	}
	
	@Test
	public void AdminLogin_Orders_SearchRecords_AllTabs_NoAvailableValues_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.ALL_ACTIVE)
			.filterAndVerifyAllColumn(OrdersTabs.ALL_ACTIVE)
			.switchTo(OrdersTabs.UNPROCESSED)
			.filterAndVerifyAllColumn(OrdersTabs.UNPROCESSED)
			.switchTo(OrdersTabs.AT_PRINTER)
			.filterAndVerifyAllColumn(OrdersTabs.AT_PRINTER)
			.switchTo(OrdersTabs.AT_FULFILLMENT)
			.filterAndVerifyAllColumn(OrdersTabs.AT_FULFILLMENT)
			.switchTo(OrdersTabs.SHIPPED)
			.filterAndVerifyAllColumn(OrdersTabs.SHIPPED)
			.switchTo(OrdersTabs.DELIVERED)
			.filterAndVerifyAllColumn(OrdersTabs.DELIVERED)
			.switchTo(OrdersTabs.OPEN_GROUP_ORDER)
			.filterAndVerifyAllColumn(OrdersTabs.OPEN_GROUP_ORDER)
			.switchTo(OrdersTabs.FAILED_GROUP_ORDER)
			.filterAndVerifyAllColumn(OrdersTabs.FAILED_GROUP_ORDER)
			.switchTo(OrdersTabs.DRAFT)
			.filterAndVerifyAllColumn(OrdersTabs.DRAFT);
	}	
	
	
	@Test
	public void AdminLogin_Orders_RecordsFilter_AllFilters_NoAvailableValues_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilterValues("Client")
			.verifyDashboard()
//			.clickAndChooseFilter("Campus Manager")
//			.applyFilterValues("Campus Manager")
			.clickAndChooseFilter("Manager")
			.applyFilterValues("Manager")
			.verifyDashboard()
			.clickAndChooseFilter("Created Date")
			.applyDateFilterAndVerifyValues("On")
			.clickAndChooseFilter("Due Date")
			.applyDateFilterAndVerifyValues("On");
	}	
	
}
