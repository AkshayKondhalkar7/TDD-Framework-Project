package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.OrdersTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Orders_DataTableSortingOperations extends MasterWrapper{
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_AllActiveTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.ALL_ACTIVE)
			.sortAndVerifyAllColumns(OrdersTabs.ALL_ACTIVE);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_UnprocessedTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.UNPROCESSED)
			.sortAndVerifyAllColumns(OrdersTabs.UNPROCESSED);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_AtPrintersTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.AT_PRINTER)
			.sortAndVerifyAllColumns(OrdersTabs.AT_PRINTER);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_AtFulfillmentTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.AT_FULFILLMENT)
			.sortAndVerifyAllColumns(OrdersTabs.AT_FULFILLMENT);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_ShippedTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.SHIPPED)
			.sortAndVerifyAllColumns(OrdersTabs.SHIPPED);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_DeliveredTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.DELIVERED)
			.sortAndVerifyAllColumns(OrdersTabs.DELIVERED);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_FailedGroupOrdersTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.FAILED_GROUP_ORDER)
			.sortAndVerifyAllColumns(OrdersTabs.FAILED_GROUP_ORDER);
	}
	
	@Test
	public void AdminLogin_Orders_SortingDashboardItems_DraftsTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.DRAFT)
			.sortAndVerifyAllColumns(OrdersTabs.DRAFT);
	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_AllActiveTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.ALL_ACTIVE)
			.sortAndVerifyAllColumns(OrdersTabs.ALL_ACTIVE);
	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_UnprocessedTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.UNPROCESSED)
			.sortAndVerifyAllColumns(OrdersTabs.UNPROCESSED);
	}
	
//	@Test
//	public void ManagerLogin_Orders_SortingDashboardItems_AtPrintersTab_AllColumns() {
//		loginPage.userLogin(UserType.CAMPUS_MANAGER)
//			.navigateToClientsPage("Desktop")
//			.navigateToOrdersPage("Desktop")
//			.switchTo(OrdersTabs.AT_PRINTER)
//			.sortAndVerifyAllColumns(OrdersTabs.AT_PRINTER);
//	}
	
//	@Test
//	public void ManagerLogin_Orders_SortingDashboardItems_AtFulfillmentTab_AllColumns() {
//		loginPage.userLogin(UserType.CAMPUS_MANAGER)
//			.navigateToClientsPage("Desktop")
//			.navigateToOrdersPage("Desktop")
//			.switchTo(OrdersTabs.AT_FULFILLMENT)
//			.sortAndVerifyAllColumns(OrdersTabs.AT_FULFILLMENT);
//	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_ShippedTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.SHIPPED)
			.sortAndVerifyAllColumns(OrdersTabs.SHIPPED);
	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_DeliveredTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.DELIVERED)
			.sortAndVerifyAllColumns(OrdersTabs.DELIVERED);
	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_FailedGroupOrdersTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.FAILED_GROUP_ORDER)
			.sortAndVerifyAllColumns(OrdersTabs.FAILED_GROUP_ORDER);
	}
	
	@Test
	public void ManagerLogin_Orders_SortingDashboardItems_DraftsTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToOrdersPage("Desktop")
			.switchTo(OrdersTabs.DRAFT)
			.sortAndVerifyAllColumns(OrdersTabs.DRAFT);
	}

}
