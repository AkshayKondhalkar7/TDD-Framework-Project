package tests;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.junit.Test;

import pages.Permissions;

public class Permissions_check {
	
	
	
	
	
	
	
	@Test
	public static void xyz() {
		
		
		
		Permissions permissions = new Permissions();
		permissions.CreateNewFPTeam("sddf");
	}

}
