package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.PromoCodesTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class PromoCodes_CountVerification extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "1098", StagingTC = "1349")
	public void AdminLogin_PromoCodes_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.verifyRecordsCount(PromoCodesTabs.ACTIVE)
			.verifyRecordsCount(PromoCodesTabs.DISABLED)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1099", StagingTC = "1350")
	public void AdminLogin_PromoCodes_Filter_TabTileCountVerification() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.applyFilter("Type", "Percentage")
			.verifyRecordsCount(PromoCodesTabs.ACTIVE)
			.verifyRecordsCount(PromoCodesTabs.DISABLED)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1100", StagingTC = "1351")
	public void ManagerLogin_PromoCodes_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.verifyRecordsCount(PromoCodesTabs.ACTIVE)
			.verifyRecordsCount(PromoCodesTabs.DISABLED)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1101", StagingTC = "1352")
	public void ManagerLogin_PromoCodes_Filter_TabTitleCountVerification() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.applyFilterMangerlogin("Type", "Percentage")
			.verifyRecordsCount(PromoCodesTabs.ACTIVE)
			.verifyRecordsCount(PromoCodesTabs.DISABLED)
			.logOut();
	}

}
