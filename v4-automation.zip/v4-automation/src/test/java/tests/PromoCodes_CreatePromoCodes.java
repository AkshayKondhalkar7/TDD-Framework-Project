package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class PromoCodes_CreatePromoCodes extends MasterWrapper {
	
	@Test
	@TestRail(TestingTC = "1065", StagingTC = "1316")
	public void AdminLogin_CreatePromoCode_Percentage_AllGroupOrders_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1066", StagingTC = "1317")
	public void AdminLogin_CreatePromoCode_Percentage_AllGroupOrders_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1067", StagingTC = "1318")
	public void AdminLogin_CreatePromoCode_FixedAmount_AllGroupOrders_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Fixed Amount")
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1068", StagingTC = "1319")
	public void AdminLogin_CreatePromoCode_FixedAmount_AllGroupOrders_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Fixed Amount")
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1069", StagingTC = "1320")
	public void AdminLogin_CreatePromoCode_FreeShipping_AllGroupOrders_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Free Shipping")
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1070", StagingTC = "1321")
	public void AdminLogin_CreatePromoCode_FreeShipping_AllGroupOrders_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Free Shipping")
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1071", StagingTC = "1322")
	public void AdminLogin_CreatePromoCode_OrganizerPays_SpecificOrder_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Organizer Pays")
			.selectLimit("1x per person")
			.selectGroupOrder("Specific")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1072", StagingTC = "1323")
	public void AdminLogin_CreatePromoCode_OrganizerPays_SpecificOrder_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Organizer Pays")
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("Specific")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1073", StagingTC = "1324")
	public void ManagerLogin_CreatePromoCode_Percentage_AllGroupOrders_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1074", StagingTC = "1325")
	public void ManagerLogin_CreatePromoCode_Percentage_AllGroupOrders_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1075", StagingTC = "1326")
	public void ManagerLogin_CreatePromoCode_OrganizerPays_SpecificOrder_LimitOneUse_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Organizer Pays")
			.selectLimit("1x per person")
			.selectGroupOrder("Specific")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1076", StagingTC = "1327")
	public void ManagerLogin_CreatePromoCode_OrganizerPays_SpecificOrder_LimitTotalUse_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterPromoCode()
			.selectPromoCodeType("Organizer Pays")
			.selectLimit("Set Total Usage Limit")
			.selectGroupOrder("Specific")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "1079", StagingTC = "1330")
	public void AdminLogin_PromoCode_Validations() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.invalidPromoCodeAndVerify("Existing")
			.invalidPromoCodeAndVerify("Disabled")
			.invalidPromoCodeAndVerify("Giftcard");
	}
	
	@Test
	@TestRail(TestingTC = "1080", StagingTC = "1331")
	public void ManagerLogin_PromoCode_Validations() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.invalidPromoCodeAndVerify("Existing")
			.invalidPromoCodeAndVerify("Disabled")
			.invalidPromoCodeAndVerify("Giftcard");
	}
	
	
	/* AdminLogin Add Promo code with existing promocode (Duplicate name)   */
	@Test
//	@TestRail(TestingTC = "1065", StagingTC = "1316")
	public void AdminLogin_CreatePromoCode_ExistingPromocodeName_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterExistingPromoCode()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	
	/* ManagerLogin Add Promo code with existing promocode (Duplicate name)   */
	@Test
//	@TestRail(TestingTC = "1065", StagingTC = "1316")
	public void ManagerLogin_CreatePromoCode_ExistingPromocodeName_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickCreatePromoCodeButton()
			.enterExistingPromoCode()
			.selectPromoCodeType("Percentage")
			.enterPromoCode()
			.selectLimit("1x per person")
			.selectGroupOrder("All")
			.selectStartDateAndTime()
			.selectEndDateAndTime()
			.verifySummary()
			.createPromoCode()
			.filterPromoCode()
			.verifyDashboard("Create")
			.logOut();
	}
	

}
