package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.PromoCodesTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class PromoCodes_DataFilterOperations extends MasterWrapper {

	@Test(enabled = false)
	@TestRail(TestingTC = "1081", StagingTC = "1332")
	public void AdminLogin_PromoCodes_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ACTIVE)
			.filterAndVerifyAllColumns(PromoCodesTabs.ACTIVE)
			.switchTo(PromoCodesTabs.ALL)
			.filterAndVerifyAllColumns(PromoCodesTabs.ALL)
			.switchTo(PromoCodesTabs.DISABLED)
			.filterAndVerifyAllColumns(PromoCodesTabs.DISABLED);
	}
	
	@Test
	@TestRail(TestingTC = "1082", StagingTC = "1333")
	public void AdminLogin_PromoCodes_RecordsFilter_Type_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Type")
			.applySubTypeFilterAndVerify("Percentage")
			.clickAndChooseFilter("Type")
			.applySubTypeFilterAndVerify("Fixed Amount")
			.clickAndChooseFilter("Type")
			.applySubTypeFilterAndVerify("Organizer Pays")
			.clickAndChooseFilter("Type")
			.applySubTypeFilterAndVerify("Free Shipping");
	}
	
	@Test
	@TestRail(TestingTC = "1083", StagingTC = "1334")
	public void AdminLogin_PromoCodes_RecordsFilter_Starts_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Starts")
			.applyDateFilterAndVerify("On");
	}
	
	@Test
	@TestRail(TestingTC = "1084", StagingTC = "1335")
	public void AdminLogin_PromoCodes_RecordsFilter_Ends_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Ends")
			.applyDateFilterAndVerify("On");
	}
	
	@Test(enabled = false)
	@TestRail(TestingTC = "1085", StagingTC = "1336")
	public void AdminLogin_PromoCodes_RecordsFilter_AppliesTo_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Applies To")
			.applyOrderFilterAndVerify("All Group Orders")
			.clickAndChooseFilter("Applies To")
			.applyOrderFilterAndVerify("Specific Group Order");	
	}
	
	@Test
	@TestRail(TestingTC = "1086", StagingTC = "1337")
	public void ManagerLogin_PromoCodes_SearchRecords_AllTabs_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ALL)
			.filterAndVerifyAllColumns(PromoCodesTabs.ALL)
			.switchTo(PromoCodesTabs.ACTIVE)
			.filterAndVerifyAllColumns(PromoCodesTabs.ACTIVE)
			.switchTo(PromoCodesTabs.DISABLED)
			.filterAndVerifyAllColumns(PromoCodesTabs.DISABLED);
	}
	
	@Test
	@TestRail(TestingTC = "1087", StagingTC = "1338")
	public void ManagerLogin_PromoCodes_RecordsFilter_Type_VerifyDashboard()  {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Type ")
			.applySubTypeFilterAndVerifyMangerLogin("Percentage")
			.clickAndChooseFilter("Type")
			.applySubTypeFilterAndVerifyMangerLogin("Organizer Pays");
	}
	
	@Test
	@TestRail(TestingTC = "1088", StagingTC = "1339")
	public void ManagerLogin_PromoCodes_RecordsFilter_Starts_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Starts")
			.applyDateFilterAndVerify("On");
	}
	
	@Test
	@TestRail(TestingTC = "1089", StagingTC = "1340")
	public void ManagerLogin_PromoCodes_RecordsFilter_Ends_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Ends")
			.applyDateFilterAndVerify("On");
	}
	
	@Test(enabled = false)
	@TestRail(TestingTC = "1090", StagingTC = "1341")
	public void ManagerLogin_PromoCodes_RecordsFilter_AppliesTo_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.clickAndChooseFilter("Applies To")
			.applyOrderFilterAndVerify("All group orders")
			.clickAndChooseFilter("Applies To")
			.applyOrderFilterAndVerify("Specific Group Order");
	}
	
	@Test
	@TestRail(TestingTC = "1091", StagingTC = "1342")
	public void PromoCodes_Status_AllTabs_AllUsers() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(PromoCodesTabs.ACTIVE)
			.verifyStatusColumn(PromoCodesTabs.ACTIVE)
			.switchTo(PromoCodesTabs.DISABLED)
			.verifyStatusColumn(PromoCodesTabs.DISABLED)
			.logOut()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(PromoCodesTabs.ACTIVE)
			.verifyStatusColumn(PromoCodesTabs.ACTIVE)
			.switchTo(PromoCodesTabs.DISABLED)
			.verifyStatusColumn(PromoCodesTabs.DISABLED)
			.logOut();
	}
}
