package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.PromoCodesTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class PromoCodes_DataTableSortingOperations extends MasterWrapper {

	@Test(enabled = false)
	@TestRail(TestingTC = "1092", StagingTC = "1343")
	public void AdminLogin_PromoCodes_SortingDashboardItems_AllTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)	
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ALL)
			.sortAndVerifyAllColumns(PromoCodesTabs.ALL);
	}

	@Test(enabled = false)
	@TestRail(TestingTC = "1093", StagingTC = "1344")
	public void AdminLogin_PromoCodes_SortingDashboardItems_ActiveTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)	
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ACTIVE)
			.sortAndVerifyAllColumns(PromoCodesTabs.ACTIVE);
	}

	@Test(enabled = false)
	@TestRail(TestingTC = "1094", StagingTC = "1345")
	public void AdminLogin_PromoCodes_SortingDashboardItems_DisabledTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.DISABLED)
			.sortAndVerifyAllColumns(PromoCodesTabs.DISABLED);
	}

	@Test(enabled = false)
	@TestRail(TestingTC = "1095", StagingTC = "1346")
	public void ManagerLogin_PromoCodes_SortingDashboardItems_AllTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ALL)
			.sortAndVerifyAllColumns(PromoCodesTabs.ALL);
	}

	@Test(enabled = false)
	@TestRail(TestingTC = "1096", StagingTC = "1347")
	public void ManagerLogin_PromoCodes_SortingDashboardItems_ActiveTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.ACTIVE)
			.sortAndVerifyAllColumns(PromoCodesTabs.ACTIVE);
	}

	@Test(enabled = false)
	@TestRail(TestingTC = "1097", StagingTC = "1348")
	public void ManagerLogin_PromoCodes_SortingDashboardItems_DisabledTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.switchTo(PromoCodesTabs.DISABLED)
			.sortAndVerifyAllColumns(PromoCodesTabs.DISABLED);
	}

}
