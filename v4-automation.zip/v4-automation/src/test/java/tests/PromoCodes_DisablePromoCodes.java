package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;



import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class PromoCodes_DisablePromoCodes extends MasterWrapper {

	@Test
	@TestRail(TestingTC = "1077", StagingTC = "1328")
	public void AdminLogin_DisableExistingPromoCode_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToPromoCodesPage("Desktop")
			.disableOnePromoCodeAndVerify();
		//	.disableMultiplePromoCodesAndVerify(2);
	}
	
	@Test
	@TestRail(TestingTC = "1078", StagingTC = "1329")
	public void ManagerLogin_DisableExistingPromoCode_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToPromoCodesPage("Desktop")
			.disableOnePromoCodeAndVerify();
		//	.disableMultiplePromoCodesAndVerify(2);
	}
}
