package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.ProofsTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Proofs_CountVerification extends MasterWrapper{

	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	public void AdminLogin_Proofs_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.verifyRecordsCount(ProofsTabs.IN_PROGRESS)
			.verifyRecordsCount(ProofsTabs.DONE)
			.logOut();
	}
	
	@Test
	public void ManagerLogin_Proofs_TabTitleTotalCountVerification_AllTabs() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.verifyRecordsCount(ProofsTabs.IN_PROGRESS)
			.verifyRecordsCount(ProofsTabs.DONE)
			.logOut();
	}
}
