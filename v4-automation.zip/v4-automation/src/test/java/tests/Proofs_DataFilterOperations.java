package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.ProofsTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Proofs_DataFilterOperations extends MasterWrapper{
	
	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	public void AdminLogin_Proofs_AdminRecordsFilter_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumns(ProofsTabs.DONE)
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumns(ProofsTabs.IN_PROGRESS)
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumns(ProofsTabs.ALL)
			.logOut();
	}
	
	@Test
	public void AdminLogin_Proofs_RecordsFilter_Client_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilter("Client")
			.verifyDashboard();
	}
	
	@Test
	public void AdminLogin_Proofs_RecordsFilter_CampusManager_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
	//		.clickAndChooseFilter("Campus Manager")
	//		.applyFilter("Campus Manager")
			.clickAndChooseFilter("Manager")
			.applyFilter("Manager")
			.verifyDashboard();
	}
	
	@Test
	public void ManagerLogin_Proofs_RecordsFilter_Client_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilter("Client")
			.verifyDashboard();
	}
	
	@Test
	public void AllUsers_Proofs_Status_AllTabs_AllUsers() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(ProofsTabs.IN_PROGRESS)
			.verifyTypeColumn(ProofsTabs.IN_PROGRESS)
			.switchTo(ProofsTabs.DONE)
			.verifyTypeColumn(ProofsTabs.DONE)
			.logOut()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.choosePaginationCount("100")
			.switchTo(ProofsTabs.IN_PROGRESS)
			.verifyTypeColumn(ProofsTabs.IN_PROGRESS)
			.switchTo(ProofsTabs.DONE)
			.verifyTypeColumn(ProofsTabs.DONE)
			.logOut();
	}

	/*Admin login search Proof# Not in table*/
	@Test
	public void AdminLogin_NoProofInTable_AdminRecordsFilter_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumn(ProofsTabs.DONE)
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumn(ProofsTabs.IN_PROGRESS)
			.switchTo(ProofsTabs.ALL)
			.filterDataAndVerifyAllColumn(ProofsTabs.ALL)
			.logOut();
	}
	
	/*Admin login search Client Not in table*/
	@Test
	public void AdminLogin_Proofs_RecordsFilter_NoClientInTable_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilterforNonAvailable("Client")
			.verifyDashboard();
	}

	/*Admin login search Campus Manager Not in table*/
	@Test
	public void AdminLogin_Proofs_RecordsFilter_NoCampusManagerInTable_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
	//		.clickAndChooseFilter("Campus Manager")
	//		.applyFilterforNonAvailable("Campus Manager")
			.clickAndChooseFilter("Manager")
			.applyFilterforNonAvailable("Manager")
			.verifyDashboard();
	}
	
	/*Manager login search Client Not in table*/
	@Test
	public void ManagerLogin_Proofs_RecordsFilter_NoClientInTable_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickAndChooseFilter("Client")
			.applyFilterforNonAvailable("Client")
			.verifyDashboard();
	}
	
}
