package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.ProofsTabs;
import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Proofs_DataTableSortingOperations extends MasterWrapper{

	//Remove navigateToUsersPage("Desktop") in all testcases once we are able to access GiftCards from V3
	@Test
	public void AdminLogin_Proofs_SortingDashboardItems_AllTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)	
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.ALL)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void AdminLogin_Proofs_SortingDashboardItems_InProgressTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.IN_PROGRESS)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void AdminLogin_Proofs_SortingDashboardItems_DoneTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.DONE)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void ManagerLogin_Proofs_SortingDashboardItems_AllTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)	
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.ALL)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void ManagerLogin_Proofs_SortingDashboardItems_InProgressTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.IN_PROGRESS)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void ManagerLogin_Proofs_SortingDashboardItems_DoneTab_AllColumns() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.DONE)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
	
	@Test
	public void ClientLogin_Proofs_SortingDashboardItems_DoneTab_AllColumns() {
		loginPage.userLogin(UserType.CLIENT)
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.switchTo(ProofsTabs.DONE)
			.sortAndVerifyAllColumns(ProofsTabs.ALL);
	}
}
