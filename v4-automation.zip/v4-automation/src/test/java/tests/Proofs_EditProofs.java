package tests;

import org.testng.annotations.Test;

import appEnums.UserType;
import masterClasses.MasterWrapper;

public class Proofs_EditProofs extends MasterWrapper {
	
	
	/* Admin login Creating new Proof & Edit Proof with existing Client details */
	@Test
	public void AdminLogin_CreateandEditProof_ExistingClient_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickCreateProofButton()
		.fillProofDetails("Existing")
		.fillProductInfo()
		.fillLocationAndDesign("Screen Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterLicensing()
		.saveProof()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.clickProof("Create")
		.clickDetailsButton()
		.editProofTitle()
		.editCilent("ADMIN")
		.editSubmittedBy()
		.editRelatedCampaign()
		.clickDetailsButton()
		.hoverThreeDotsandEditButton()
		.editStyleCode()
		.editCollegiateMarks()
		.editOrganization()
		.editDescribetheArt()
		.editCustomNameAndNumber("Number")
		.saveEditProof()
		.navigateToProofsPage("Desktop")
		.filterEditProof("Create")
		.verifyDashboard("Create")
		.logOut()
		.loginAsManagerToVerifyProofsEdit("Existing")
		.navigateToClientsPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Create")
		.verifyDashboard("Create")
		.logOut()
		.loginAsClientToVerifyProofsEdit("ADMIN")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Create")
		.verifyDashboard("Create")
		.logOut();
		
	}
	
	
	/* Admin Login Edit Proof with ExistingProof */
	@Test
	public void AdminLogin_EditProof_ExistingProof_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickProof("Existing")
		.clickDetailsButton()
		.editProofTitle()
		.editCilent("ADMIN")
		.editSubmittedBy()
		.editRelatedCampaign()
		.clickDetailsButton()
		.hoverThreeDotsandEditButton()
		.editStyleCode()
		.editColor()
		.editCollegiateMarks()
		.editOrganization()
		.saveEditProof()
		.navigateToProofsPage("Desktop")
		.filterEditProof("Existing")
		.verifyDashboard("Existing")
		.logOut()
		.loginAsManagerToVerifyProofsEdit("Existing")
		.navigateToClientsPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Existing")
		.verifyDashboard("Existing")
		.logOut()
		.loginAsClientToVerifyProofsEdit("ADMIN")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Existing")
		.verifyDashboard("Existing")
		.logOut();
		
		
	}	
	
	
	/* Manager login Creating new Proof & Edit Proof with existing Client details */ 
	@Test
	public void ManagerLogin_CreateandEditProof_ExistingClient_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Number")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.clickDetailsButton()
			.editProofTitle()
			.editCilent("MANAGER")
			.editSubmittedBy()
			.editRelatedCampaign()
			.clickDetailsButton()
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editCollegiateMarks()
			.editOrganization()
			.editDescribetheArt()
			.editCustomNameAndNumber("Name")
			.saveEditProof()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Create")
			.verifyDashboard("Create")
			.logOut()
			.loginAsClientToVerifyProofsEdit("MANAGER")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Create")
			.verifyDashboard("Create")
			.logOut();
	}
	
	/* Manager Login Edit Proof with ExistingProof */
	@Test
	public void ManagerLogin_EditProof_ExistingProof_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Existing")
			.clickDetailsButton()
			.editProofTitle()
			.editCilent("MANAGER")
			.editSubmittedBy()
			.editRelatedCampaign()
			.clickDetailsButton()
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.saveEditProof()
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Existing")
			.verifyDashboard("Existing")
			.logOut()
			.loginAsClientToVerifyProofsEdit("MANAGER")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Existing")
			.verifyDashboard("Existing")
			.logOut();
	}
	
	/* Admin login create & Delete ProofItem */
	@Test
	public void AdminLogin_ExistingClient_CreateAndDeleteProofItem_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickCreateProofButton()
		.fillProofDetails("Existing")
		.fillProductInfo()
		.fillLocationAndDesign("Screen Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterLicensing()
		.saveProof()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.clickProof("Create")
		.hoverThreeDotsandDeleteButton() 
		.clickDeleteOption()
		.verifyDashboardDelete("Create")
		.logOut();	
	}
	
	/* Admin login Delete Existing  ProofItem */
	@Test
	public void AdminLogin_DeleteExistingProof_VerifyDashboard() {
	
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("existing")
		.hoverThreeDotsandDeleteButton() 
		.clickDeleteOption()
		.verifyDashboardDelete("existing")
		.connectdb()
		.logOut();
		
		}

	
	/* Manager login create & Delete ProofItem */
	@Test
	public void  ManagerLogin_ExistingClient_CreateAndDeleteProofItem_VerifyDashboard() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
		.navigateToClientsPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickCreateProofButton()
		.fillProofDetails("Existing")
		.fillProductInfo()
		.fillLocationAndDesign("Digital Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterLicensing()
		.saveProof()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.clickProof("Create")
		.hoverThreeDotsandDeleteButton() 
		.clickDeleteOption()
		.verifyDashboardDelete("Create")
		.logOut();	
	}
	
	/* Manager login Delete Existing ProofItem */
	@Test
	public void ManagerLogin_DeleteExistingProof_VerifyDashboard() {
	
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
		.navigateToClientsPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("existing")
		.hoverThreeDotsandDeleteButton() 
		.clickDeleteOption()
		.verifyDashboardDelete("existing")
		.connectdb()
		.logOut();
		
		}
	
	
	/* Admin login Create Proof. Login as Client & Check Add, Edit, Delete buttons not Present */ 
	@Test
	public void AdminLogin_CreateProof_ExistingClient_CheckingEditAndDeletePresenceInClient_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.addProofItemButtonAbsence()
			.editButtonAbsence()
			.deleteButtonAbsence()
			.logOut();
	}
	
	/* Manager login Create Proof. Login as Client & Check Add, Edit, Delete buttons not Present */ 
	@Test
	public void ManagerLogin_CreateProof_ExistingClient_CheckingEditAndDeletePresenceInClient_VerifyDashboard() {
		
			loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.addProofItemButtonAbsence()
			.editButtonAbsence()
			.deleteButtonAbsence()
			.logOut();
	}

	
	/* Admin login Create Proof, Edit Proof with Add another location - verify Down ArrowButton */
	@Test
	public void AdminLogin_CreateandEditProof_AddLocation_verifyArrowButton() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickCreateProofButton()
		.fillProofDetails("Existing")
		.fillProductInfo()
		.fillLocationAndDesign("Screen Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterLicensing()
		.saveProof()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.clickProof("Create")
		.hoverThreeDotsandEditButton()
		.addAnotherLocation()
		.addOtherReferenceImage(1)
		.addaontherDescribetheArt()
		.addCustomNameAndNumberanotherlocation("both")
		.addAnotherPrintType("Digital Print")
		.saveEditProofAddLocation()
		.verifyArrowButton()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.logOut()
		.loginAsClientToVerifyProofs("Existing")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickProof("Create")
		.verifyArrowButton()
		.logOut();
		
	}	

	/* Manager login Create Proof, Edit Proof with Add another location - verify Down ArrowButton */
	@Test
	public void ManagerLogin_CreateandEditProof_AddLocation_verifyArrowButton() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
//			.addCustomNameAndNumber("Number")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.addAnotherLocation()
			.addOtherReferenceImage(1)
			.addaontherDescribetheArt()
			.addCustomNameAndNumberanotherlocation("both")
			.addAnotherPrintType("Digital Print")
			.saveEditProofAddLocation()
			.verifyArrowButton()
			.navigateToProofsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.verifyArrowButton()
			.logOut();
	}	
	
	/*Admin login Adding Other Proof in Existing Proof with Adding Product Link*/ 
	@Test
	public void AdminLogin_AddOtherProof_ExistingProof_AddProductLink_verifyLinkOpen() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("Existing")
		.clickAddProofButton()
		.addNewStyleCode() 
		.addNewColor()
		.addProductName()
		.addNewColor()
		.addProductName()
		.addProductLink()
		.clickAddLocationandDesign()
		.selectProductInfo()
		.addNewStyleCode() 
		.addNewColor()
		.addProductName()
		.addNewColor()
		.addProductName()
		.addProductLink()
		.clickAddLocationandDesign()
		.fillLocationAndDesign("Screen Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterCollegiateMark()
		.addOrganizationOthers()
		.clickSubmit()
		.clickProductLink()
		.verifyLinkOpen() 
		.logOut()
		.loginAsClientToVerifyProofs("Existing")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickProof("Existing")
		.selectProof()
		.clickProductLink()
		.verifyLinkOpen()
		.logOut();
		
		
	}
	
	/* Manager login Adding Other Proof in Existing Proof with Adding Product Link*/ 
	@Test
	public void ManagerLogin_AddOtherProof_ExistingProof_AddProductLink_verifyLinkOpen() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing")
			.clickAddProofButton()
			.addNewStyleCode() 
			.addNewColor()
			.addProductName()
			.addNewColor()
			.addProductName()
			.addProductLink()
			.clickAddLocationandDesign()
			.selectProductInfo()
			.addNewStyleCode() 
			.addNewColor()
			.addProductName()
			.addNewColor()
			.addProductName()
			.addProductLink()
			.clickAddLocationandDesign()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterCollegiateMark()
			.addOrganizationOthers()
			.clickSubmit()
			.clickProductLink()
			.verifyLinkOpen()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Existing")
			.selectProof()
			.clickProductLink()
			.verifyLinkOpen()	
			.logOut();
	}	
	
	
	/* Admin login Create Proof Edit_Description_Hyperlink  */
	@Test
	public void AdminLogin_CreateProof_Edit_Description_Hyperlink_VerifyLink() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.selectDescribetheArt()	
			.clickLinkButton()
			.addHyperlink()
			.saveProofforHyperlink()
			.navigateToProofsPage("Desktop")
		//	.filterProof()
			.clickProof("Create")
		//	.selectProof()
			.clickHyperlinkinDesArt()
			.verifyLinkOpen()			
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.clickProof("Create")
		//	.selectProof()
			.clickHyperlinkinDesArt()
			.verifyLinkOpen()
			.logOut();
	}
	
	/* Manager login Create Proof Edit_Description_Hyperlink  */
	@Test
	public void ManagerLogin_CreateProof_Edit_Description_Hyperlink_VerifyLink() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.selectDescribetheArt()	
			.clickLinkButton()
			.addHyperlink()
			.saveProofforHyperlink()
			.navigateToProofsPage("Desktop")
		//	.filterProof()
			.clickProof("Create")
		//	.selectProof()
			.clickHyperlinkinDesArt()
			.verifyLinkOpen()			
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.clickProof("Create")
		//	.selectProof()
			.clickHyperlinkinDesArt()
			.verifyLinkOpen()
			.logOut();
	}
	
	/* Admin login Edit Existing Proof & Cancel the Edited Values */
	@Test
	public void AdminLogin_ExistingProof_EditProof_CancelEditValues() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("Existing")
		.clickDetailsButton()
		.editProofTitle()
		.editCilent("ADMIN")
		.editSubmittedBy()
		.editRelatedCampaign()
		.clickDetailsButton()
		.hoverThreeDotsandEditButton()
		.editStyleCode()
		.editColor()
		.editCollegiateMarks()
		.editOrganization()
		.clickCancelButton()
		.logOut();
		
}
	
	/* Manager login Edit Existing Proof & Cancel the Edited Values */
	@Test
	public void ManagerLogin_ExistingProof_EditProof_CancelEditValues() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing")
			.clickDetailsButton()
			.editProofTitle()
			.editCilent("MANAGER")
			.editSubmittedBy()
			.editRelatedCampaign()
			.clickDetailsButton()
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.clickCancelButton()
			.logOut();

}

	/* Admin login edit existing style code to other apparel for existing Client  */
	@Test
	public void AdminLogin_CreateProof_ExistingClient_EditToOtherApparel_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("External")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyApparelProof()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyApparelProof()
			.logOut();
	}	
	
	/* Manager login edit existing style code to other apparel for existing Client  */
	@Test
	public void ManagerLogin_CreateProof_ExistingClient_EditToOtherApparel_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("External")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyApparelProof()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyApparelProof()
			.logOut();
	}
	
	/* Admin login edit existing style code to other apparel for New Client  */
	@Test
	public void AdminLogin_CreateProof_NewClient_EditToOtherApparel_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("New")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("External")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyApparelProof()
			.logOut()
			.loginAsClientToVerifyProofs("New")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyApparelProof()
			.logOut();
	}

	/* Manager login edit existing style code to other apparel for existing Client  */
	@Test
	public void ManagerLogin_CreateProof_NewClient_EditToOtherApparel_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("New")
			.fillProductInfo()
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("External")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyApparelProof()
			.logOut()
			.loginAsClientToVerifyProofs("New")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyApparelProof()
			.logOut();
	}
	
	/* Admin login edit to other apparel to existing style code for existing Client  */
	@Test
	public void AdminLogin_CreateProof_ExistingClient_EditToExistingStyleCode_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo("External")
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("ExistingCode")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();
	}		
	
	/* Manager login edit to other apparel to existing style code for existing Client  */
	@Test
	public void ManagerLogin_CreateProof_ExistingClient_EditToExistingStyleCode_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo("External")
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("ExistingCode")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();
	}	
	
	/* Admin login edit to other apparel to existing style code for New Client  */
	@Test
	public void AdminLogin_CreateProof_NewClient_EditToExistingStyleCode_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("New")
			.fillProductInfo("External")
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("ExistingCode")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofs("New")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();
	}	
	
	/* Manager login edit to other apparel to existing style code for New Client  */
	@Test
	public void ManagerLogin_CreateProof_NewClient_EditToExistingStyleCode_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("New")
			.fillProductInfo("External")
			.fillLocationAndDesign("Screen Print")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editProductInfos("ExistingCode")
			.editLicensingInfos()
			.saveEditProofCode()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofs("New")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();
	}		
	
	/* Admin login Creating new Proof & Edit Proof with existing Client details & check the proof details & Product Info */
	@Test
	public void AdminLogin_CreateandEditProof_ExistingClient_VerifyProof() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickCreateProofButton()
		.fillProofDetails("Existing")
		.fillProductInfo("FP")
		.fillLocationAndDesign("Screen Print")
		.addCustomNameAndNumber("Name")
		.uploadReferenceImage(1)
		.enterLicensing()
		.saveProof()
		.navigateToProofsPage("Desktop")
		.filterProof()
		.verifyDashboard("Create")
		.clickProof("Create")
		.clickDetailsButton()
		.editProofTitle()
		.editCilent("ADMIN")
		.editSubmittedBy()
		.editRelatedCampaign()
		.clickDetailsButton()
		.hoverThreeDotsandEditButton()
		.editStyleCode()
		.editColor()
		.editCollegiateMarks()
		.editOrganization()
		.editDescribetheArt()
		.editCustomNameAndNumber("Number")
		.saveEditProof()
		.navigateToProofsPage("Desktop")
		.filterEditProof("Create")
		.verifyDashboard("Create")
		.clickProof("Create")
		.clickDetailsButton()
		.verifyEditedProofsDetails()
		.clickDetailsButton()
		.verifyProof()
		.logOut()
		.loginAsClientToVerifyProofsEdit("ADMIN")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Create")
		.verifyDashboard("Create")
		.clickProof("Create")
		.clickDetailsButton()
		.verifyEditedProofsDetails()
		.clickDetailsButton()
		.verifyProof()
		.logOut();
		
	}	
	
	/* Manager login Creating new Proof & Edit Proof with existing Client details & check the proof details & Product Info */
	@Test
	public void ManagerLogin_CreateandEditProof_ExistingClient_VerifyProof() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo("FP")
			.fillLocationAndDesign("Digital Print")
			.addCustomNameAndNumber("Number")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.clickDetailsButton()
			.editProofTitle()
			.editCilent("MANAGER")
			.editSubmittedBy()
			.editRelatedCampaign()
			.clickDetailsButton()
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.editDescribetheArt()
			.editCustomNameAndNumber("Name")
			.saveEditProof()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Create")
			.verifyDashboard("Create")
			.clickProof("Create")
			.clickDetailsButton()
			.verifyEditedProofsDetails()
			.clickDetailsButton()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofsEdit("MANAGER")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Create")
			.verifyDashboard("Create")
			.clickProof("Create")
			.clickDetailsButton()
			.verifyEditedProofsDetails()
			.clickDetailsButton()
			.verifyProof()
			.logOut();
	}	

	/* Admin Login Edit Proof with ExistingProof & check the proof details & Product Info */
	@Test
	public void AdminLogin_EditProof_ExistingProof_VerifyProof() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("Existing")
		.clickDetailsButton()
		.editProofTitle()
		.editCilent("ADMIN")
		.editSubmittedBy()
		.editRelatedCampaign()
		.clickDetailsButton()
		.hoverThreeDotsandEditButton()
		.editStyleCode()
		.editColor()
		.editCollegiateMarks()
		.editOrganization()
		.saveEditProof()
		.navigateToProofsPage("Desktop")
		.filterEditProof("Existing")
		.verifyDashboard("Existing")
		.clickProof("Existing")
		.clickDetailsButton()
		.verifyEditedProofsDetails()
		.clickDetailsButton()
		.verifyProof()
		.logOut()
		.loginAsClientToVerifyProofsEdit("ADMIN")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.filterEditedProof("Existing")
		.verifyDashboard("Existing")
		.clickProof("Existing")
		.clickDetailsButton()
		.verifyEditedProofsDetails()
		.clickDetailsButton()
		.verifyProof()
		.logOut();
	}	

	/* Manager Login Edit Proof with ExistingProof & check the proof details & Product Info */
	@Test
	public void ManagerLogin_EditProof_ExistingProof_VerifyProof() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing")
			.clickDetailsButton()
			.editProofTitle()
			.editCilent("MANAGER")
			.editSubmittedBy()
			.editRelatedCampaign()
			.clickDetailsButton()
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.saveEditProof()
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Existing")
			.verifyDashboard("Existing")
			.clickProof("Existing")
			.clickDetailsButton()
			.verifyEditedProofsDetails()
			.clickDetailsButton()
			.verifyProof()
			.logOut()
			.loginAsClientToVerifyProofsEdit("MANAGER")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.filterEditedProof("Existing")
			.verifyDashboard("Existing")
			.clickProof("Existing")
			.clickDetailsButton()
			.verifyEditedProofsDetails()
			.clickDetailsButton()
			.verifyProof()
			.logOut();
	}
	
	/* Admin Login Edit Proof with ExistingProof & check the proof details & Product Info */
	@Test
	public void AdminLogin_EditManager_ExistingProof_VerifyManager() {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickManager()
		.editManagerName()
		.clickProofNo()
		.clickDetailsButton()
		.verifyManager()
		.logOut();
	}		
	
	/* Admin login Creating new Proof with existing Client edit the style code & color - showing the Toaster Message "The color of the garment has changed"*/
	@Test
	public void AdminLogin_CreateProof_ExistingClient_EditSytlecode_VerifyToasterMessage() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo("FP")
			.fillLocationAndDesign("Applique")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(2)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.saveEdit()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Create")
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();

	}
	
	/* Admin login Existing Proof edit the style code & color - showing the Toaster Message "The color of the garment has changed"*/
	@Test
	public void AdminLogin_ExistingProof_ExistingClient_EditSytlecode_VerifyToasterMessage() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing for color")
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.saveEdit()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Existing for color")
			.verifyDashboard("Existing")
			.clickProof("Existing for color")
			.logOut();

	}
	
	/* Manager login Creating new Proof with existing Client edit the style code & color - showing the Toaster Message "The color of the garment has changed"*/
	@Test
	public void ManagerLogin_CreateProof_ExistingClient_EditSytlecode_VerifyToasterMessage() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo("FP")
			.fillLocationAndDesign("Applique")
			.addCustomNameAndNumber("Name")
			.uploadReferenceImage(2)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.saveEdit()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Create")
			.verifyDashboard("Create")
			.clickProof("Create")
			.verifyProof()
			.logOut();

	}
	
	/* Manager login Existing Proof edit the style code & color - showing the Toaster Message "The color of the garment has changed"*/
	@Test
	public void ManagerLogin_ExistingProof_ExistingClient_EditSytlecode_VerifyToasterMessage() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing for color")
			.hoverThreeDotsandEditButton()
			.editStyleCode()
			.editColor()
			.editCollegiateMarks()
			.editOrganization()
			.saveEdit()
			.navigateToProofsPage("Desktop")
			.filterEditProof("Existing for color")
			.verifyDashboard("Existing")
			.clickProof("Existing for color")
			.logOut();

	}
	
	/* Admin login Creating new Proof with existing Client details for Multiplelocations & delete location */
	@Test 
	public void AdminLogin_CreateProof_ExistingClient_MultipleLocations_DeleteOneLoctaion_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.uploadReferenceImage(1)
			.fillLocationAndDesign("Multiple")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.deleteLocation()
			.saveProofLocation()
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.verifyLocation()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.verifyLocation()
			.logOut();
	}
	
	/* Manager login Creating new Proof with existing Client details for Multiplelocations & delete location  */
	@Test 
	public void ManagerLogin_CreateProof_ExistingClient_MultipleLocations_DeleteOneLoctaion_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickCreateProofButton()
			.fillProofDetails("Existing")
			.fillProductInfo()
			.uploadReferenceImage(1)
			.fillLocationAndDesign("Multiple")
			.uploadReferenceImage(1)
			.enterLicensing()
			.saveProof()
			.navigateToProofsPage("Desktop")
			.filterProof()
			.verifyDashboard("Create")
			.clickProof("Create")
			.hoverThreeDotsandEditButton()
			.deleteLocation()
			.saveProofLocation()
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.verifyLocation()
			.logOut()
			.loginAsClientToVerifyProofs("Existing")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Create")
			.verifyLocation()
			.logOut();
	}	
	
	
	
}