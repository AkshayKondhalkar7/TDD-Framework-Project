
package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import masterClasses.MasterWrapper;


public class Proofs_EditProofs_RequestRevision extends MasterWrapper {

	@Test
	public void AdminLogin_ExistingProof_EditRequestRevision () {
		
		loginPage.userLogin(UserType.ADMIN)
		.navigateToUsersPage("Desktop")
		.navigateToProofsPage("Desktop")
		.connectdb()
		.clickProof("Existing RequestRevision")
		.clickRequestRevision()
		.selectStyleCodeForRR()
		.selectColorForRR()
		.selectCollegiateMarksForRR()
		.selectOrganizationForRR()
		.addAnotherLocation()
		.txtDescriptionForRR()
		.SelectCustomNameandNumberForRR()
		.SelectPrintTypeForRR()
		.uploadReferenceImageForRR(1)
		.clickSubmitRR()
		.verifyRevisionRequest()
		.logOut()
		.loginAsClientToVerifyProofs("Existing RequestRevision")
		.navigateToInvoicesPage("Desktop")
		.navigateToProofsPage("Desktop")
		.clickProof("Existing RequestRevision")
		.verifyRevisionRequest()
		.logOut();

	}
	
	@Test
	public void ManagerLogin_ExistingProof_EditRequestRevision () {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.navigateToProofsPage("Desktop")
			.connectdb()
			.clickProof("Existing RequestRevision")
			.clickRequestRevision()
			.selectStyleCodeForRR()
			.selectColorForRR()
			.selectCollegiateMarksForRR()
			.selectOrganizationForRR()
			.addAnotherLocation()
			.txtDescriptionForRR()
			.SelectCustomNameandNumberForRR()
			.SelectPrintTypeForRR()
			.uploadReferenceImageForRR(1)
			.clickSubmitRR()
			.verifyRevisionRequest()
			.logOut()
			.loginAsClientToVerifyProofs("Existing RequestRevision")
			.navigateToInvoicesPage("Desktop")
			.navigateToProofsPage("Desktop")
			.clickProof("Existing RequestRevision")
			.verifyRevisionRequest()
			.logOut();

	}
	
}
