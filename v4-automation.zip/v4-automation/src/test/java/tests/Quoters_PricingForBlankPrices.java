package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Quoters_PricingForBlankPrices extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "989", StagingTC = "1240")
	public void AdminLogin_Quoters_BlankPrice_ScreenPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	

	@Test
	@TestRail(TestingTC = "990", StagingTC = "1241")
	public void AdminLogin_Quoters_BlankPrice_DigitalPrint_AddOns_VerifyPrices_WhiteGarment() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	//@TestRail(TestingTC = "990", StagingTC = "1241")
	public void AdminLogin_Quoters_BlankPrice_DigitalPrint_AddOns_VerifyPrices_NonWhiteGarment() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoNonWhite("nonwhite")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	
	
	
	
	
	
	
	@Test
	@TestRail(TestingTC = "991", StagingTC = "1242")
	public void AdminLogin_Quoters_BlankPrice_EmbroideryPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Embroidery", "Pocket area")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Hat/ headwear")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Greek Letters")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Custom pocket")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "992", StagingTC = "1243")
	public void AdminLogin_Quoters_BlankPrice_GoldOrSilverFoilPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Gold/Silver Foil", "")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "993", StagingTC = "1244")
	public void AdminLogin_Quoters_BlankPrice_MultiplePrintLocations_AddOns_Adjustments_VerifyPrices() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.applyAdjustmentsAndVerifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "994", StagingTC = "1245")
	public void ManagerLogin_Quoters_BlankPrice_MultiplePrintLocations_AddOns_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceInfoWhite("white")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.toggleAddOns()
			.verifyPrices(UserType.CAMPUS_MANAGER);
	}

	@Test
//	@TestRail(TestingTC = "", StagingTC = "")
	public void AdminLogin_Quoters_DecimalBlankPrice_ScreenPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceDecimalInfo()
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
//	@TestRail(TestingTC = "", StagingTC = "")
	public void ManagerLogin_Quoters_DecimalBlankPrice_ScreenPrint_AddOns_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterBlankPriceDecimalInfo()
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.toggleAddOns()
			.verifyPrices(UserType.CAMPUS_MANAGER);
	}	
	
}
