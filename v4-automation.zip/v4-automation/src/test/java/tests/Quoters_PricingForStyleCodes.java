package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Quoters_PricingForStyleCodes extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "971", StagingTC = "1222")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_ScreenPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyThumbNails();
	}
	
	@Test
	@TestRail(TestingTC = "972", StagingTC = "1223")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_DigitalPrint_AddOns_VerifyPrices_NonWhite() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyThumbNails();
	}
	
	@Test
	//@TestRail(TestingTC = "972", StagingTC = "1223")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_DigitalPrint_AddOns_VerifyPrices_White() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "White")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyThumbNails();
	}
	
	
	
	
	
	
	
	
	
	
	
	@Test
	@TestRail(TestingTC = "973", StagingTC = "1224")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_EmbroideryPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Embroidery", "Pocket area")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Hat/ headwear")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Greek Letters")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Custom pocket")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyThumbNails();
	}
	
	@Test
	@TestRail(TestingTC = "974", StagingTC = "1225")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_GoldOrSilverFoilPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Gold/Silver Foil", "")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "975", StagingTC = "1226")
	public void AdminLogin_Quoters_Type1_AlphaStyleCode_MultiplePrintLocations_AddOns_Adjustments_VerifyPrices() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.applyAdjustmentsAndVerifyPrices(UserType.ADMIN)
			.verifyThumbNails();
	}
	
	@Test
	@TestRail(TestingTC = "976", StagingTC = "1227")
	public void AdminLogin_Quoters_Type4_OtherApparelStyleCode_ScreenPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "977", StagingTC = "1228")
	public void AdminLogin_Quoters_Type4_OtherApparelStyleCode_DigitalPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "978", StagingTC = "1229")
	public void AdminLogin_Quoters_Type4_OtherApparelStyleCode_EmbroideryPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels" , "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Embroidery", "Pocket area")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Hat/ headwear")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Greek Letters")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Custom pocket")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "979", StagingTC = "1230")
	public void AdminLogin_Quoters_Type4_OtherApparelStyleCode_GoldOrSilverFoilPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Gold/Silver Foil", "")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "980", StagingTC = "1231")
	public void AdminLogin_Quoters_Type4_OtherApparelStyleCode_MultiplePrintLocations_AddOns_Adjustments_VerifyPrices() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels","NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.applyAdjustmentsAndVerifyPrices(UserType.ADMIN);
	}
	
	@Test
	@TestRail(TestingTC = "981", StagingTC = "1232")
	public void AdminLogin_Quoters_Type4_FPStyleCode_ScreenPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Screen Print", "3")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyStocks();
	}
	
	@Test
	@TestRail(TestingTC = "982", StagingTC = "1233")
	public void AdminLogin_Quoters_Type4_FPStyleCode_DigitalPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP","NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Digital Print", "Entire Shirt")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Digital Print", "Pocket Area")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyStocks();
	}
	
	@Test
	@TestRail(TestingTC = "983", StagingTC = "1234")
	public void AdminLogin_Quoters_Type4_FPStyleCode_GoldOrSilverFoilPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Gold/Silver Foil", "")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyStocks();
	}
	
	@Test
	@TestRail(TestingTC = "984", StagingTC = "1235")
	public void AdminLogin_Quoters_Type4_FPStyleCode_EmbroideryPrint_AddOns_VerifyPrices() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Embroidery", "Pocket area")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Hat/ headwear")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Greek Letters")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.enterPrintLocations("Embroidery", "Custom pocket")
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.verifyStocks();
	}
	
	@Test
	@TestRail(TestingTC = "985", StagingTC = "1236")
	public void AdminLogin_Quoters_Type4_FPStyleCode_MultiplePrintLocations_AddOns_Adjustments_VerifyPrices() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP" , "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.ADMIN)
			.toggleAddOns()
			.verifyPrices(UserType.ADMIN)
			.applyAdjustmentsAndVerifyPrices(UserType.ADMIN)
			.verifyStocks();
	}
	
	@Test
	@TestRail(TestingTC = "986", StagingTC = "1237")
	public void ManagerLogin_Quoters_Type1_AlphaStyleCode_MultiplePrintLocations_AddOns_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.clickPerUnit()
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.toggleAddOns()
			.verifyPrices(UserType.CAMPUS_MANAGER);
	}
	
	@Test
	@TestRail(TestingTC = "987", StagingTC = "1238")
	public void ManagerLogin_Quoters_Type4_OtherApparelStyleCode_MultiplePrintLocations_AddOns_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.toggleAddOns()
			.verifyPrices(UserType.CAMPUS_MANAGER);
	}
	
	@Test
	@TestRail(TestingTC = "988", StagingTC = "1239")
	public void ManagerLogin_Quoters_Type4_FPStyleCode_MultiplePrintLocations_AddOns_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("FP" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.toggleAddOns()
			.verifyPrices(UserType.CAMPUS_MANAGER)
			.verifyThumbNails()
			.verifyStocks();
	}

}
