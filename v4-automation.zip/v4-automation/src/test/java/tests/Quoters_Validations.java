package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Quoters_Validations extends MasterWrapper{

	@Test
	@TestRail(TestingTC = "995", StagingTC = "1246")
	public void AdminLogin_Quoters_VerifyingValidations() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.verifyValidationMessage()
			.verifyInvalidStyleCode()
			.deletePrintLocations()
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "996", StagingTC = "1247")
	public void ManagerLogin_Quoters_VerifyingValidations() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.verifyValidationMessage()
			.verifyInvalidStyleCode()
			.deletePrintLocations();
	}
	
	@Test
	@TestRail(TestingTC = "997", StagingTC = "1248")
	public void AdminLogin_SwitchStyleCodesAndApparelTypes_VerifyPrices() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices("Displayed")
			.changeStyleCode()
			.verifyPrices("Not Displayed")
			.enterStyleCodeInfo("Alpha","NonWhite")
			.selectApparelType("BlankPrice")
			.verifyPrices("Not Displayed");
	}
	
	@Test
	@TestRail(TestingTC = "998", StagingTC = "1249")
	public void ManagerLogin_SwitchStyleCodesAndApparelTypes_VerifyPrices() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToQuotersPage("Desktop")
			.enterStyleCodeInfo("OtherApparels" ,"NonWhite")
			.enterLicensedMarks()
			.enterPrintLocations("Multiple")
			.verifyPrices("Displayed")
			.changeStyleCode()
			.verifyPrices("Not Displayed")
			.enterStyleCodeInfo("Alpha", "NonWhite")
			.selectApparelType("BlankPrice")
			.verifyPrices("Not Displayed");
	}
}