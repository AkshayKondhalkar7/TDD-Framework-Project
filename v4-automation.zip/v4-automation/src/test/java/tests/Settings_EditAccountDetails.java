package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import appEnums.UserOperation;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;


public class Settings_EditAccountDetails extends MasterWrapper {

	//we will do DB connection later for clickOnUnsubscribeMailingList
    @Test
	@TestRail(TestingTC = "9419", StagingTC = "9434")
	public void AdminLogin_FieldValidations_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {		
	
	loginPage.userLoginForSettings(UserType.ADMIN)
	.navigateToSettingsPage("desktop")
	.clickEditDetailButtonOfSettings()
	.editPasswordSettings()
	.fieldValidations()
	.cancelButton()
	.clickEditDetailButtonOfSettings()
	.editPasswordSettings()
	.editFullName()
	.editPhoneNumber()
	.editNewPassword()
	.saveDetailsButton()
//	.clickOnUnsubscribeMailingList() 
	.logout()
	.loginToVerify("Desktop")
	.navigateToSettingsPage("desktop")
	.verifyUpdatedName()
	.verifyUpdatedPhoneNo()
	.logOutSet();
 }

	@Test	
	@TestRail(TestingTC = "9420", StagingTC = "9435")
	public void Manager_FieldValidations_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.CAMPUS_MANAGER)
		.navigateToSettingsPage("desktop")
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.fieldValidations()
		.cancelButton()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()
		.editOrgName()
		.editSchoolName()
		.saveDetailsButton()
	//	.clickOnUnsubscribeMailingList()
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.logOutSet();
		}

	

  
  
 
	@Test	
	@TestRail(TestingTC = "9421", StagingTC = "9436")
	public void ClientLogin_FieldValidations_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.CLIENT)
		.navigateToSettingsPage("desktop")
		.connectdb()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.fieldValidations()
		.cancelButton()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()
		.editBusiness()
		.editTitle()
		.saveDetailsButton()
		//.clickOnUnsubscribeMailingList()	
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifyUpdatedBusiness()
		.verifyUpdatedTitle()
		.logOutSet();
		}
	
	
	@Test
	@TestRail(TestingTC = "9422", StagingTC = "9437")
	public void PrinterLogin_FieldValidations_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.PRINTER)
		.navigateToSettingsPage("desktop")
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.fieldValidations()
		.cancelButton()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()
		.editShippingName()
		.editStreetName()
		.editStateName()
		.editCityName()
		.editZipCode()
		.editTimeZone()	
		.saveDetailsButton()
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifyUpdatedShippingName()
		.verifyUpdatedStreetName()
		.verifyUpdatedCityNmae()
		.logOutSet();
		}
	
	
	@Test
	@TestRail(TestingTC = "9423", StagingTC = "9438")
	public void FCLogin_FieldValidations_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.FULFILLMENT_CENTER)
		.navigateToSettingsPage("desktop")
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.fieldValidations()
		.cancelButton()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()
		.editShippingName()
		.editStreetName()
		.editStateName()
		.editCityName()
		.editZipCode()
		.editTimeZone()	
		.saveDetailsButton()
		//.clickOnUnsubscribeMailingList()
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifyUpdatedShippingName()
		.verifyUpdatedStreetName()
		.verifyUpdatedCityNmae()
		.logOutSet();
		}
	
	@Test
	@TestRail(TestingTC = "9424", StagingTC = "9439")
		public void AdminLogin_ImpersonateAdmin_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
			loginPage.userLoginForSettings(UserType.ADMIN);
			loginPage.navigateToUsersPage("desktop")
			.filterUser(UserType.ADMIN, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.ADMIN);
			loginPage.navigateToSettingsPage("desktop")
			.clickEditDetailButtonOfSettings()
			.editPasswordSettings()
			.editFullName()
			.editPhoneNumber()
			.editNewPasswordImpersonation("ADMIN")
			.saveDetailsButton()
			.stopImpersonationAndVerifyLandingPage(UserType.ADMIN, "Desktop")
			.logOut()
			.loginToVerify("Desktop")
			.navigateToSettingsPage("desktop")
			.verifyUpdatedName()
			.verifyUpdatedPhoneNo()
			.logOutSet();
			}
	
	@Test
	@TestRail(TestingTC = "9425", StagingTC = "9440")
	public void AdminLogin_ImpersonateManager_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
			loginPage.userLoginForSettings(UserType.ADMIN);
			loginPage.navigateToUsersPage("desktop")
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CAMPUS_MANAGER)
			.navigateToSettingsPage("desktop")
			.clickEditDetailButtonOfSettings()
			.editPasswordSettings()
			.editFullName()
			.editPhoneNumber()
			.editNewPasswordImpersonation("CAMPUS_MANAGER")
			.editPhoneNumber()
			.editSchoolName()
			.editOrgName()
			.saveDetailsButton()
			.stopImpersonationAndVerifyLandingPage(UserType.CAMPUS_MANAGER, "Desktop")
			.logOut()
			.loginToVerify("Desktop")
			.navigateToSettingsPage("desktop")
			.verifyUpdatedName()
			.verifyUpdatedPhoneNo()
			.logOutSet();
		
		}
	
	@Test
	@TestRail(TestingTC = "9426", StagingTC = "9441")
	public void AdminLogin_ImpersonateClient_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.ADMIN)
		.navigateToUsersPage("desktop")
		.filterUser(UserType.CLIENT, "Desktop")
		.hoverAndSelectOption(UserOperation.IMPERSONATE)
		.verifyImpersonationLandingPage(UserType.CLIENT)
		.navigateToSettingsPage("desktop")
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPasswordImpersonation("CLIENT")
		.editSchoolName()
		.editOrgName()
		.editPosition()
		.saveDetailsButton()
		.stopImpersonationAndVerifyLandingPage(UserType.CLIENT, "Desktop")
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.logOutSet();
		}
	
	@Test
	@TestRail(TestingTC = "9427", StagingTC = "9442")
    public void AdminLogin_ImpersonatePrinter_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.ADMIN)
		.navigateToUsersPage("desktop")
		.filterUser(UserType.PRINTER, "Desktop")
		.hoverAndSelectOption(UserOperation.IMPERSONATE)
		.verifyImpersonationLandingPage(UserType.PRINTER)
		.navigateToSettingsPage("desktop")
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPasswordImpersonation("PRINTER")
		.editShippingName()
		.editStreetName()
		.editStateName()
		.editCityName()
		.editZipCode()
		.editTimeZone()	
		.saveDetailsButton()	
		.stopImpersonationAndVerifyLandingPage(UserType.PRINTER, "Desktop")
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifyUpdatedShippingName()
		.verifyUpdatedStreetName()
		.verifyUpdatedCityNmae()
		.logOutSet();
		}
	
	@Test
	@TestRail(TestingTC = "9428", StagingTC = "9443")
    public void AdminLogin_ImpersonateFC_ChangeSettings_VerifyUserDashboard_VerifyLogin() throws Exception {
	
	loginPage.userLoginForSettings(UserType.ADMIN)
	.navigateToUsersPage("desktop")
	.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
	.hoverAndSelectOption(UserOperation.IMPERSONATE)
	.verifyImpersonationLandingPage(UserType.FULFILLMENT_CENTER)
	.navigateToSettingsPage("desktop")
	.clickEditDetailButtonOfSettings()
	.editPasswordSettings()
	.editFullName()
	.editPhoneNumber()
	.editNewPasswordImpersonation("FULFILLMENT_CENTER")
	.editShippingName()
	.editStreetName()
	.editStateName()
	.editCityName()
	.editZipCode()
	.editTimeZone()	
	.saveDetailsButton()	
	.stopImpersonationAndVerifyLandingPage(UserType.FULFILLMENT_CENTER, "Desktop")
	.logout()
	.loginToVerify("Desktop")
	.navigateToSettingsPage("desktop")
	.verifyUpdatedName()
	.verifyUpdatedPhoneNo()
	.verifyUpdatedShippingName()
	.verifyUpdatedStreetName()
	.verifyUpdatedCityNmae()
	.logOutSet();
	}
	

	@Test	
//	@TestRail(TestingTC = "9421", StagingTC = "9436")
	public void ClientLogin_ChangeSettings_BusinessToSchool_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSettings(UserType.CLIENT)
		.navigateToSettingsPage("desktop")
		.connectdb()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()         
		.editBusinessToSchool()
		.saveDetailsButton()	
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifySchoolDetails()
		.logOutSet();
		}
	
	@Test	
//	@TestRail(TestingTC = "9421", StagingTC = "9436")
	public void ClientLogin_ChangeSettings_SchoolToBusiness_VerifyUserDashboard_VerifyLogin() throws Exception {
		
		loginPage.userLoginForSetting(UserType.CLIENT)
		.navigateToSettingsPage("desktop")
		.connectdb()
		.clickEditDetailButtonOfSettings()
		.editPasswordSettings()
		.editFullName()
		.editPhoneNumber()
		.editNewPassword()         
		.editSchoolToBusiness()
		.saveDetailsButton()	
		.logout()
		.loginToVerify("Desktop")
		.navigateToSettingsPage("desktop")
		.verifyUpdatedName()
		.verifyUpdatedPhoneNo()
		.verifyUpdatedBusiness()
		.verifyUpdatedTitle()
		.logOutSet();
		}
	

	
}

	