package tests;

import org.testng.annotations.Test;

import appEnums.GiftCardsTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class StockChecker_Quotelink extends MasterWrapper {
@Test
	public void AdminLogin_StockChecker_() {
//		loginPage.userLogin(UserType.ADMIN)
//		.navigateToUsersPage("desktop")
//		.navigateToStockCheckerPage("Desktop")
//	    .enterProddetails("GDH100")         // enterStyle code
//	    .clickonProduct()
//	    .verifyStockLevel()
	      
	}

}
