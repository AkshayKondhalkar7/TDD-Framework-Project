package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_CountVerification extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "964", StagingTC = "1215")
	public void AdminLogin_Users_VerifyNumberOfRecords_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.choosePaginationCount("100")
			.verifyRecordsCount(UserType.PRINTER)
			.verifyRecordsCount(UserType.FULFILLMENT_CENTER)
			.verifyRecordsCount(UserType.CLIENT)
			.verifyRecordsCount(UserType.CAMPUS_MANAGER)
			.verifyRecordsCount(UserType.ADMIN)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "965", StagingTC = "1216")
	public void AdminLogin_Users_ApplyFilter_VerifyRecordsCount() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Campus Manager")
			.applyFilter("Campus Manager")
			.switchTo(UserType.CLIENT)
			.verifyRecordsCount(UserType.CLIENT)
			.clickAndChooseFilter("School")
			.applyFilter("School")
			.switchTo(UserType.CLIENT)
			.verifyRecordsCount(UserType.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "966", StagingTC = "1217")
	public void AdminLogin_Users_ModifyPagination_VerifyDashboard_AllTabs() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.verifyPaginationCount(UserTabs.PRINTER)
			.verifyPaginationCount(UserTabs.FULFILLMENT_CENTER)
			.verifyPaginationCount(UserTabs.CLIENT)
			.verifyPaginationCount(UserTabs.CAMPUS_MANAGER)
			.verifyPaginationCount(UserTabs.ADMIN)
			.logOut();
	}
}