package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_CreateUsers extends MasterWrapper{

	@Test
	@TestRail(TestingTC = "908", StagingTC = "1159")
	public void AdminLogin_CreateAdminUser_VerifyDashboard_VerifyLogin() throws Exception {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.ADMIN)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE)
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.ADMIN, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.ADMIN, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "909", StagingTC = "1160")
	public void AdminLogin_CreateClientUserWithSchool_VerifyDashboard_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.CLIENT)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "910", StagingTC = "1161")
	public void AdminLogin_CreateClientUserWithoutSchool_VerifyDashboard_VerifyLogin() {	

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.CLIENT)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("Business", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "911", StagingTC = "1162")
	public void AdminLogin_CreateClientUser_AssignAndReAssignManager_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.CLIENT)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.assignCampusManager("Assign")
			.logOut()
			.loginToVerify("Desktop")
			.logout()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logout()
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.assignCampusManager("ReAssign")
			.logOut()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "912", StagingTC = "1163")
	public void AdminLogin_CreateCampusManagerUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.CAMPUS_MANAGER)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CAMPUS_MANAGER)
			.enterContactDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CAMPUS_MANAGER, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CAMPUS_MANAGER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "913", StagingTC = "1164")
	public void AdminLogin_CreatePrinterUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.PRINTER)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.PRINTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Desktop")
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.PRINTER, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.PRINTER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.PRINTER, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "914", StagingTC = "1165")
	public void AdminLogin_CreateFulfillmentCenterUser_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.FULFILLMENT_CENTER)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Desktop")
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.FULFILLMENT_CENTER, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.FULFILLMENT_CENTER)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "915", StagingTC = "1166")
	public void CampusManagerLogin_CreateClientUserWithSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "916", StagingTC = "1167")
	public void CampusManagerLogin_CreateClientUserWithoutSchool_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("Business", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "917", StagingTC = "1168")
	public void AdminLogin_CreateAdminUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE) 
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "918", StagingTC = "1169")
	public void AdminLogin_CreateClientUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CLIENT)
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "919", StagingTC = "1170")
	public void AdminLogin_CreatePrinterUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.PRINTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Desktop")
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "920", StagingTC = "1171")
	public void AdminLogin_CreateFulfillmentUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Desktop")
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "921", StagingTC = "1172")
	public void AdminLogin_CreateCampusManagerUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CAMPUS_MANAGER)
			.enterContactDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "922", StagingTC = "1173")
	public void CampusManagerLogin_CreateClientUser_ExistingEmail() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "Existing")
			.verifyFailureMessage()
			.logOut();
	}

	@Test
	@TestRail(TestingTC = "923", StagingTC = "1174")
	public void AdminLogin_CreateUsers_FieldValidations() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.verifyFieldValidations(UserType.ADMIN, "Desktop")
			.verifyFieldValidations(UserType.CLIENT, "Desktop")
			.verifyFieldValidations(UserType.CAMPUS_MANAGER, "Desktop")
			.verifyFieldValidations(UserType.PRINTER, "Desktop")
			.verifyFieldValidations(UserType.FULFILLMENT_CENTER, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "924", StagingTC = "1175")
	public void CampusManagerLogin_CreateUsers_FieldValidations() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.verifyFieldValidations(UserType.CLIENT, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "925", StagingTC = "1176")
	public void AdminLogin_InvalidAddress_VerifyValidations() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingAddress(UserOperation.CREATE, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "926", StagingTC = "1177")
	public void AdminLogin_CreateCampusManager_CustomOrganization_CustomSchool_VerifyDashboard_VerifyFilters() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.CAMPUS_MANAGER)
			.enterContactDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails(UserType.CAMPUS_MANAGER, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CAMPUS_MANAGER, UserOperation.CREATE, "Desktop")
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.clickAndChooseFilter("Custom Organization")
			.applyFilter("Custom Organization")
			.switchTo(UserTabs.ALL_ACTIVE)
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.verifyDashboard()
			.clickAndChooseFilter("Custom School")
			.applyFilter("Custom School")
			.switchTo(UserTabs.ALL_ACTIVE)
			.verifyDashboard()
			.logOut();
	}


	@Test
	public void AdminLogin_CreatePrinterUser_WithWrongAddress_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.PRINTER)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.PRINTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.PRINTER, UserOperation.CREATE)
			.enterShippingWrongAddress(UserOperation.CREATE, "Desktop")
			.saveData()
			.verifyAccountSummary(UserType.PRINTER, UserOperation.CREATE, "Desktop")
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.PRINTER, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	public void AdminLogin_CreateFulfillmentCenterUser_WithWrongAddress_VerifyDashboard_VerifyLogin() {

		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.captureTotalRecordsCount(UserTabs.FULFILLMENT_CENTER)
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.FULFILLMENT_CENTER)
			.enterBasicDetails()
			.enterContactDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterPasswordDetails(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.enterShippingWrongAddress(UserOperation.CREATE, "Desktop")
			.saveData()
			.verifyAccountSummary(UserType.FULFILLMENT_CENTER, UserOperation.CREATE, "Desktop")
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.FULFILLMENT_CENTER, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}

	
}
