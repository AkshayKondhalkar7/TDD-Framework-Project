package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_DataFilterOperations extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "945", StagingTC = "1196")
	public void AdminLogin_Users_AdminRecordsSearch_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.ADMIN)
			.filterDataAndVerifyAllColumns(UserTabs.ADMIN)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "946", StagingTC = "1197")
	public void AdminLogin_Users_ClientRecordsSearch_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterDataAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "947", StagingTC = "1198")
	public void AdminLogin_Users_PrinterRecordsSearch_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.PRINTER)
			.filterDataAndVerifyAllColumns(UserTabs.PRINTER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "948", StagingTC = "1199")
	public void AdminLogin_Users_CampusManagerRecordsSearch_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterDataAndVerifyAllColumns(UserTabs.CAMPUS_MANAGER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "949", StagingTC = "1200")
	public void AdminLogin_Users_FulfillmentCenterRecordsSearch_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterDataAndVerifyAllColumns(UserTabs.FULFILLMENT_CENTER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "950", StagingTC = "1201")
	public void AdminLogin_Users_RecordsFilter_CampusManager_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Campus Manager")
			.applyFilter("Campus Manager")
			.switchTo(UserTabs.ALL_ACTIVE)
			.verifyDashboard()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "951", StagingTC = "1202")
	public void AdminLogin_Users_RecordsFilter_School_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("School")
			.applyFilter("School")
			.switchTo(UserTabs.ALL_ACTIVE)
			.verifyDashboard()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "952", StagingTC = "1203")
	public void AdminLogin_Users_RecordsFilter_Organization_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Organization")
			.applyFilter("Organization")
			.switchTo(UserTabs.ALL_ACTIVE)
			.verifyDashboard()
			.logOut();
	}
	
	@Test 
	@TestRail(TestingTC = "953", StagingTC = "1204")
	public void AdminLogin_Users_RecordsFilter_Company_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Company")
			.applyFilter("Company")
			.switchTo(UserTabs.ALL_ACTIVE)
			.verifyDashboard()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "954", StagingTC = "1205")
	public void AdminLogin_Users_FilterCampusManager_SearchRecord_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Campus Manager")
			.applyFilter("Campus Manager")
			.filterDataAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "955", StagingTC = "1206")
	public void AdminLogin_Users_FilterSchool_SearchRecord_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("School")
			.applyFilter("School")
			.filterDataAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "956", StagingTC = "1207")
	public void AdminLogin_Users_FilterOrganization_SearchRecord_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Organization")
			.applyFilter("Organization")
			.filterDataAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test 
	@TestRail(TestingTC = "957", StagingTC = "1208")
	public void AdminLogin_Users_FilterCompany_SearchRecord_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAndChooseFilter("Company")
			.applyFilter("Company")
			.filterDataAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "967", StagingTC = "1218")
	public void ManagerLogin_Clients_RecordsFilter_Company_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAndChooseFilter("Company")
			.applyFilter("Company")
			.verifyDashboard()
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "968", StagingTC = "1219")
	public void ManagerLogin_Clients_RecordsFilter_Organization_VerifyDashboard() {
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAndChooseFilter("Organization")
			.applyFilter("Organization")
			.verifyDashboard()
			.logOut();
	}

	
	
}
