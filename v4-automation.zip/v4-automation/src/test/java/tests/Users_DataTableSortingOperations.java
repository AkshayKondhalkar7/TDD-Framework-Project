package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_DataTableSortingOperations extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "958", StagingTC = "1209")
	public void AdminLogin_Users_SortingDashboardItems_AdminTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.ADMIN)
			.sortAndVerifyAllColumns(UserTabs.ADMIN)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "959", StagingTC = "1210")
	public void AdminLogin_Users_SortingDashboardItems_ClientTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.choosePaginationCount("100")
			.sortAndVerifyAllColumns(UserTabs.CLIENT)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "960", StagingTC = "1211")
	public void AdminLogin_Users_SortingDashboardItems_CampusManagerTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.sortAndVerifyAllColumns(UserTabs.CAMPUS_MANAGER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "961", StagingTC = "1212")
	public void AdminLogin_Users_SortingDashboardItems_PrinterTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.PRINTER)
			.sortAndVerifyAllColumns(UserTabs.PRINTER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "962", StagingTC = "1213")
	public void AdminLogin_Users_SortingDashboardItems_FulfillmentCenterTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.sortAndVerifyAllColumns(UserTabs.FULFILLMENT_CENTER)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "963", StagingTC = "1214")
	public void AdminLogin_Users_SortingDashboardItems_AllActiveTab_AllColumns() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.PRINTER)
			.choosePaginationCount("100")
			.sortAndVerifyAllColumns(UserTabs.PRINTER)
			.logOut();
	}

}
