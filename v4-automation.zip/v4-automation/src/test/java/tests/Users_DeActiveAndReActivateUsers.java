package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_DeActiveAndReActivateUsers extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "940", StagingTC = "1191")
	public void AdminLogin_DeActivateAdminUser_VerifyLogin_ReActivateAdminUser_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.connectdb()
			.switchTo(UserTabs.ADMIN)
			.captureTotalRecordsCount(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Desktop")
			.hoverAndSelectOption(UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Desktop")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.clearSearchFilter()
		//	.switchTo(UserTabs.INACTIVE)
			.switchTo(UserTabs.Inactive)
			.filterUser(UserType.ADMIN, "Desktop")
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Desktop")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Desktop")
			.hoverAndSelectOption(UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.clearSearchFilter()
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "941", StagingTC = "1192")
	public void AdminLogin_DeActivateClientUser_VerifyLogin_ReActivateClientUser_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.connectdb()
			.switchTo(UserTabs.CLIENT)
			.captureTotalRecordsCount(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Desktop")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.clearSearchFilter()
		//	.switchTo(UserTabs.INACTIVE)
			.switchTo(UserTabs.Inactive)
			.filterUser(UserType.CLIENT, "Desktop")
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Desktop")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.clearSearchFilter()
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "942", StagingTC = "1193")
	public void AdminLogin_DeActivatePrinterUser_VerifyLogin_ReActivatePrinterUser_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.connectdb()
			.switchTo(UserTabs.PRINTER)
			.captureTotalRecordsCount(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Desktop")
			.hoverAndSelectOption(UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Desktop")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.clearSearchFilter()
		//	.switchTo(UserTabs.INACTIVE)
			.switchTo(UserTabs.Inactive)
			.filterUser(UserType.PRINTER, "Desktop")
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Desktop")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Desktop")
			.hoverAndSelectOption(UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.clearSearchFilter()
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "943", StagingTC = "1194")
	public void AdminLogin_DeActivateFulfillmentCenterUser_VerifyLogin_ReActivateFulfillmentCenterUser_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.captureTotalRecordsCount(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
			.hoverAndSelectOption(UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Desktop")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.clearSearchFilter()
		//	.switchTo(UserTabs.INACTIVE)
			.switchTo(UserTabs.Inactive)
			.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Desktop")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
			.hoverAndSelectOption(UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.clearSearchFilter()
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "944", StagingTC = "1195")
	public void AdminLogin_DeActivateCampusManagerUser_VerifyLogin_ReActivateCampusManagerUser_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.connectdb()
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.captureTotalRecordsCount(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.DEACTIVATE)
			.enterConfirmation(UserOperation.DEACTIVATE, "Desktop")
			.verifySuccessMessage(UserOperation.DEACTIVATE)
			.clearSearchFilter()
		//	.switchTo(UserTabs.INACTIVE)
			.switchTo(UserTabs.Inactive)
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.DEACTIVATE, "Desktop")
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.REACTIVATE)
			.verifySuccessMessage(UserOperation.REACTIVATE)
			.clearSearchFilter()
			.logOut()
			.loginToVerifyDeActivationAndReActivation(UserOperation.REACTIVATE, "Desktop")
			.logout();
	}

}
