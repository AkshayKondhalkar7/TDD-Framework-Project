package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_DeleteUsers extends MasterWrapper{
	
	@Test
	public void CampusManagerLogin_CreateClientUserWithSchool_DeleteClient_VerifyDashboard() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.hoverAndSelectOption(UserOperation.DELETE)
			.enterConfirmation(UserOperation.DELETE, "Desktop")
			.verifySuccessMessage(UserOperation.DELETE)
			.VerifyDashboardforDelete(UserType.CLIENT)
			.logOut()
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.logOut();
	}
	
	@Test
	public void CampusManagerLogin_CreateClientUserWithoutSchool_DeleteClient_VerifyDashboard() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("Business", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.hoverAndSelectOption(UserOperation.DELETE)
			.enterConfirmation(UserOperation.DELETE, "Desktop")
			.verifySuccessMessage(UserOperation.DELETE)
			.VerifyDashboardforDelete(UserType.CLIENT)
			.logOut()
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.logOut();
	}
	
	@Test
	public void CampusManagerLogin_ExistingClient_DeleteClient_VerifyDashboard() {

		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.connectdb()
			.filterUserforDelete("Existing", "Desktop")
			.hoverAndSelectOption(UserOperation.DELETE)
			.enterConfirmation(UserOperation.DELETE, "Desktop")
			.verifySuccessMessage(UserOperation.DELETE)
			.VerifyDashboardforDelete(UserType.CLIENT)
			.logOut()
			.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.logOut();
	}	
	
	
	
}
