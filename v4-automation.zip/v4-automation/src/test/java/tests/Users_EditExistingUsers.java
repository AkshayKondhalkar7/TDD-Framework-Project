package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserTabs;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_EditExistingUsers extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "927", StagingTC = "1178")
	public void AdminLogin_EditExistingAdminUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.ADMIN)
			.filterUser(UserType.ADMIN, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.ADMIN, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "928", StagingTC = "1179")
	public void AdminLogin_EditExistingCampusManagerUser_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CAMPUS_MANAGER)
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.CAMPUS_MANAGER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CAMPUS_MANAGER, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "929", StagingTC = "1180")
	public void AdminLogin_EditClientUser_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.CLIENT)
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "930", StagingTC = "1181")
	public void AdminLogin_EditExistingPrinterUser_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.PRINTER)
			.filterUser(UserType.PRINTER, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.PRINTER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.PRINTER, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "931", StagingTC = "1182")
	public void AdminLogin_EditExistingFulfillmentCenterUser_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.switchTo(UserTabs.FULFILLMENT_CENTER)
			.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.FULFILLMENT_CENTER)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.FULFILLMENT_CENTER, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "932", StagingTC = "1183")
	public void ManagerLogin_EditExistingClientUser_VerifyDashboard() {
		
		loginPage.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.UPDATE)
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.UPDATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.UPDATE)
			.logOut()
			.loginToVerify("Desktop")
			.logout();
	}

}
