package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;


import appEnums.UserOperation;
import appEnums.UserType;
import customAnnotations.TestRailAnnotation.TestRail;
import masterClasses.MasterWrapper;

public class Users_ImpersonateUsers extends MasterWrapper{
	
	@Test
	@TestRail(TestingTC = "933", StagingTC = "1184")
	public void AdminLogin_ImpersonateAdmin_CreateAdminUser_VerifyDashboard_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.ADMIN, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.clickAddUsersButton("Desktop")
			.selectUserType(UserType.ADMIN)
			.enterContactDetails(UserType.ADMIN, UserOperation.CREATE)
			.enterPasswordDetails(UserType.ADMIN, UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.ADMIN, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.ADMIN)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.ADMIN, UserOperation.CREATE)
			.stopImpersonationAndVerifyLandingPage(UserType.ADMIN, "Desktop")
			.logout()
			.loginToVerify("Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "934", StagingTC = "1185")
	public void AdminLogin_ImpersonateCampusManager_CreateClientUser_VerifyDashboard_VerifyLogin() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
	//		.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.filterUserImpersonate(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAddUsersButton("Desktop")
			.enterContactDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterPasswordDetails(UserType.CLIENT, UserOperation.CREATE)
			.enterSchoolAndOrganizationDetails("School", UserOperation.CREATE)
			.saveData(UserOperation.CREATE, "New")
			.verifyAccountSummary(UserType.CLIENT, UserOperation.CREATE, "Desktop")
			.editAccountSummary(UserType.CLIENT)
			.navigateToUsersDashboard(UserOperation.CREATE, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.stopImpersonationAndVerifyLandingPage(UserType.CLIENT, "Desktop")
			.logout()
			.loginToVerify("Desktop")
			.logout()
			.userLogin(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.CREATE)
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "935", StagingTC = "1186")
	public void AdminLogin_ImpersonateClient_VerifyLandingPage_StopImpersonation() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CLIENT)
			.clickBackAndVerifyLandingPage("Desktop")
			.stopImpersonationAndVerifyLandingPage(UserType.ADMIN, "Desktop")
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "936", StagingTC = "1187")
	public void AdminLogin_ImpersonatePrinter_VerifyLandingPage_StopImpersonation() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.PRINTER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.PRINTER)
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "937", StagingTC = "1188")
	public void AdminLogin_ImpersonateFulfillmentCenter_VerifyLandingPage_StopImpersonation() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.FULFILLMENT_CENTER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.FULFILLMENT_CENTER)
			.logout();
	}
	
	@Test
	@TestRail(TestingTC = "938", StagingTC = "1189")
	public void AdminLogin_ImpersonateManager_DeleteExistingClientUser_VerifyDashboard() {
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.filterUser(UserType.CLIENT, "Desktop")
			.hoverAndSelectOption(UserOperation.DELETE)
			.enterConfirmation(UserOperation.DELETE, "Desktop")
			.verifySuccessMessage(UserOperation.DELETE)
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.DELETE)
			.stopImpersonationAndVerifyLandingPage(UserType.CAMPUS_MANAGER, "Desktop")
			.filterAndVerifyDashboard(UserType.CLIENT, UserOperation.VIEW)
			.logOut();
	}
	
	@Test
	@TestRail(TestingTC = "969", StagingTC = "1220")
	public void AdminLogin_ImpersonateCampusManager_RecordsFilter_VerifyDashboard() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.clickAndChooseFilter("School")
			.applyFilter("School")
			.verifyDashboard()
			.clickAndChooseFilter("Organization")
			.applyFilter("Organization")
			.verifyDashboard()
			.stopImpersonationAndVerifyLandingPage(UserType.CAMPUS_MANAGER, "Desktop")
			.logout();

	}
	
	@Test
	@TestRail(TestingTC = "939", StagingTC = "1190")
	public void AdminLogin_ImpersonateCampusManager_VerifyFilterOptions() {
		
		loginPage.userLogin(UserType.ADMIN)
			.navigateToUsersPage("Desktop")
			.filterUser(UserType.CAMPUS_MANAGER, "Desktop")
			.hoverAndSelectOption(UserOperation.IMPERSONATE)
			.verifyImpersonationLandingPage(UserType.CAMPUS_MANAGER)
			.navigateToClientsPage("Desktop")
			.getFilterOptionsAndVerify("School")
			.getFilterOptionsAndVerify("Organization")
			.getFilterOptionsAndVerify("Company")
			.logout();

	}

}
